<!--
governance_metadata:
  last_reviewed: "2026-10-13"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-13"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# Task Execution Rules (任務執行規範)

本規範為所有開發者與自動化 Agent 執行任務時的強制約束準則。所有代碼實現必須同時遵循最高指導文件 [docs/ENGINEERING_STANDARDS.md](../../docs/ENGINEERING_STANDARDS.md) 與現行三大核心架構決策 ([Meta-ADR 1 ~ 3](../../docs/adr/README.md))。

> **架構願景與核心定位 (Vision & Charter)**：  
> 最原始的目的就是希望將**「人類意圖」**精準無損地轉換為**「機器語言」**，而且機器可以確實無誤、零歧義、零妥協地執行，幾乎 100% 依照人類想要的樣子去落地實作。  
> 當持續年線拉伸至**一百年（Centennial Horizon: 2026 ~ 2126+）**：原則的東西就像太陽升起一樣不會改變（數學真實、借貸複式平衡、呈現邊界外部化、不可篡改的審計軌跡）；會隨時代更迭的，僅僅是運作的模型與具體的計算機器。

---

## 【至高鐵律 0】五階規格驅動演進自閉環流水線與嚴禁打地鼠 (The 5-Stage Evolution Pipeline & Ban on Whac-A-Mole)

**核心演進鐵律：【有問題先討論 ➔ 調整規範 ➔ 產生任務 ➔ 確認執行 ➔ 驗收覆盤與自閉環】**  
**核心精神：嚴禁遇到問題就急著修改業務程式碼（打地鼠）。每一項調整都必須著眼於「如何讓未來的軟體資產更好、百年可重現、全域可免疫」。即便完全重啟對話，本流程亦必須強制執行！**

1. **第一階：有問題先討論 (Stage 1: Root Cause & HCI Alignment)**：
   - 嚴禁直接開分支動代碼。回歸第一性原則、認知心理學、社會心理學、行為經濟學、跨國貿易經濟學與反脆弱架構哲學，深入釐清本質原因，杜絕打地鼠。
2. **第二階：調整規範 (Stage 2: Spec & Governance Codification)**：
   - 將共識 100% 寫入 `UI_SPEC.md`, `SD_SPEC.md`, `ENGINEERING_STANDARDS.md`, `TASK_EXECUTION_RULES.md` 與 SDK 原語。
   - 清除歷史「打地鼠條款」，通過 `scripts/audit-specs.py` 驗證並提交至 `reinsurance-contracts:dev`。
3. **第三階：產生任務 (Stage 3: Contract-Driven Task Synthesis)**：
   - 合成標準 6 位數任務包 (`tasks/TASK-{06d}/`) 與 Task-IR 字節碼，明確定界 `target_files` 與驗收閘門。
4. **第四階：確認執行 (Stage 4: Explicit Confirmation & Sentry Execution)**：
   - **未獲人類明確指示前，絕對不修改業務代碼！** 獲得確認後始得建立分支並按 TDD 嚴格落地。
5. **第五階：驗收覆盤與反脆弱自閉環 (Stage 5: Verify, Reconcile & Retro)**：
   - 客觀神諭驗收、主規格回寫、問題聚類沉澱 (Pattern Clustering & Rule of Three)，同類問題達 3 次強制提煉 SDK 原語，達成全系統永久免疫。

---

## 【核心心法】AI 認知自省決策協定 (AI Cognitive Self-Audit Protocol)
在執行任何程式碼撰寫、修改或結案提交前，AI 代理人必須在思考鏈 (Thought Chain) 中主動啟動「四大不變量自檢心法」，進行全域語意推理，嚴禁依賴打地鼠式微觀清單：

1. **【文字與呈現邊界 (Presentation Invariant)】**：
   - 我是否在 Service / Domain / Repository / API Client 中寫入了任何終端可見的自然語言字串（包含中/英/日文）？
   - 報表表頭、異常訊息、審計原因是否全數使用規範機器代碼 (Canonical Keys) 並透過 `MessageSource` / `next-intl` 動態解析？
2. **【契約真理源與 SDK 原語 (Contract SSOT & Agent SDK)】**：
   - 此修改是否與 OpenAPI 契約 1:1 對齊？我是否在手刻可以由 `Agent SDK`（如 `GenericExcelExportEngine`、`<MasterDataMaintenanceView>`）代勞的輪子？
3. **【兄弟同構與對稱性 (Homomorphic Sibling Parity)】**：
   - 此模組所屬的原型，其兄弟切片（如 Country, Region, Currency）是否有一併納入視野？是否存在「修了 A 卻讓 B 保持缺陷」的局部性盲點？
4. **【確定性防禦與神諭 (Deterministic Resilience & Verification Oracles)】**：
   - 所有按鈕、端點、併發寫入是否有確定的防禦機制（防連點 / 樂觀鎖 409 / 降級 Tooltip）？我的 TDD 測試是否斷言了真實的可觀測指標，而非假 Mock？

---

1. **多庫實體邊界與三庫串行合併順序 (Tri-Repo Promotion Pipeline)**：
   - **後端任務 (`_Backend.md`)**：僅限於後端倉庫 (`reinsurance-core-service`) 之獨立分支 `feature/<TASK_NAME>` 開發，修改範圍限定於 `src/` 下檔案，`target_files` 嚴禁跨庫或包含舊版 monorepo 前綴。
   - **前端任務 (`_Frontend.md`)**：僅限於前端倉庫 (`reinsurance-web-portal`) 之獨立分支 `feature/<TASK_NAME>` 開發，修改範圍限定於 `src/` 下檔案。
   - **三庫串行發布順序**：
     * 步驟 1：`reinsurance-contracts` 的 `task/<TASK_ID>` PR 預審就緒（暫不合併）。
     * 步驟 2：後端代碼 PR 測試全綠，合併入 `core-service:dev`。
     * 步驟 3：前端代碼 PR 本地聯調通過，合併入 `web-portal:dev`。
     * 步驟 4：Contracts 庫由結案 Agent 完成主規格回寫檢驗，最終合併入 `contracts:dev`。
   - **嚴禁私自合併生產線**：無論 Tier-1 或 Tier-2，**絕對禁止擅自執行 `git merge main`**。

2. **基礎工程基線、Seed Data 同源與嚴格 i18n 架構分界 (Strict i18n & Baseline)**：
   - **配置外部化與強型別**：可變參數提取至 `application.yml` 或 `.env`，後端強制使用 `@ConfigurationProperties`。
   - **種子資料同源**：後端 Flyway 具備 `V999__dev_seed_data.sql`，前端 Mock Fixture (`currencies.json`) 採用完全相同之業務代碼與識別碼，杜絕聯調資料斷層。
   - **全語言零自然語言寫死鐵律 (Zero Hardcoded Natural Language Strings in Any Language)**：
     * 無論中文、英文、日文或任何人類語言，**嚴格禁止在非 Presentation 層硬編碼自然語言常值**。
     * **傳輸層 (API Client) 純機器代碼**：前端 API Client 嚴禁構造自然語言句子（英文如 `'Export failed'` 或中文皆屬違規），僅允許傳遞 HTTP 狀態與機器錯誤代碼 (`errorCode` / `code`)。
     * **持久審計層 (DB Audit) 規範代碼**：審計日誌之 `change_reason` 與欄位名稱一律儲存 **Canonical Identifiers / Standard Keys**（例如 `SYSTEM_DEFAULT_UPDATE`, `NAME_ZH`），嚴禁存入自然語言文字。
     * **呈現層 (UI Presentation) 多語系動態映射**：UI 層以 `t('errors.' + errorCode)` 解析錯誤提示，以 `t('audit.reasons.' + changeReason)` 解析審計原因。
     * **報表匯出動態在地化 (Excel/Report Export)**：表頭與列舉名稱必須透過動態注入之 `MessageSource` 根據 `LocaleContextHolder.getLocale()` 解析，嚴格禁止寫死靜態字串陣列。
   - **高精度金融與 UTC**：金額一律使用 `BigDecimal` (搭配 Banker's Rounding `HALF_EVEN`)，時間一律使用 UTC ISO 8601。

3. **架構防線與 CQRS 領域約束 (Domain-Bounded CQRS - Meta-ADR 2)**：
   - **領域內 CQRS**：領域內部開放使用資料庫 View 與 SQL JOIN 提升統計查詢效能。
   - **跨領域零實體 JOIN**：跨領域引用嚴禁建立 DB Foreign Key，嚴禁跨領域資料表 SQL JOIN，一律應用層組裝或建檔保存快照。
   - **Package-Private 封閉性**：後端內部 Entity、DAO/Repository 與實作類別宣告為 Package-Private，公開出口僅能透過公開介面。
   - **前端 Feature-Sliced 垂直內聚**：組織於 `src/features/<domain>/<subdomain>/` 內，外部僅能透過 `index.ts` 引用。
   - **引用防禦與軟刪除**：被引用實體提供 `GET /references` 檢核端點；嚴禁物理刪除，一律業務軟刪除 (`is_disabled = true`)。

4. **OpenAPI Code-Gen 純投影目錄與 Extension Pattern (Meta-ADR 1)**：
   - **純投影隔離**：前端 TypeScript Client/Type (`src/shared/generated/api.d.ts`) 與後端 Java DTO 全由 `contracts/openapi.yaml` 自動 Code-Gen 生成，嚴禁在生成目錄中手寫業務代碼。
   - **Extension Pattern**：業務邏輯與輔助函式一律寫於專屬手寫類別中進行封裝裝飾。
   - **職責切分**：API 欄位定義以 OpenAPI 為單一真理源，`SD_SPEC.md` 專注於時序圖與交易邊界，嚴禁手抄 JSON 字典。

5. **防禦性 UX、深入 AST 零死按鈕與 Mock 接軌時機 (The Handshake Moment)**：
   - **零死按鈕深度檢查**：所有按鈕必須具備實質點擊事件處理。Babel AST 強制檢查函式體，空 Block `{}` 或純 `console.log` 一律紅燈阻斷！次期功能必須顯式標記 `disabled={true}` 搭配 Tooltip 預留。
   - **Mock 接軌時機**：
     * 平行開發期：前端 `NEXT_PUBLIC_ENABLE_MOCK=true` 打 Mock Server。
     * 本地真機聯調期 (The Handshake Moment)：提 PR 前夕切換 `NEXT_PUBLIC_ENABLE_MOCK=false` 直連 `http://localhost:8080`，執行真實 HTTP 請求與 Playwright E2E 走查。
   - **表單三道防呆機制**：送出前客戶端必填阻擋、輸入時即時清除錯誤、樂觀鎖 409 衝突跳出引導提示。

6. **自動化品質閘門 (Quality Gates - 四大客觀檢驗)**：
   - **閘門 1**：`python3 scripts/audit-specs.py` 規格治理與領域標籤 100% 通過。
   - **閘門 2**：前端 `npx tsc --noEmit` 0 TypeScript 型別錯誤。
   - **閘門 3**：前端 `npm test`（`validate-i18n.js` 0 缺失與英文無中文洩漏、`audit-buttons.js` 0 死按鈕）。
   - **閘門 4**：後端 `mvn test` 100% 綠燈（0 失敗、0 錯誤）。

7. **資訊安全與防禦基線 (Cybersecurity Baselines)**：
   - 嚴格禁止字串拼接 SQL，防止 SQL 注入。
   - 校驗物件存取權限 (IDOR 防護)，敏感端點配置權限限制。
   - 前端嚴格禁止 `dangerouslySetInnerHTML`。
   - 零密鑰進倉庫，敏感 PII 個資日誌脫敏。

8. **條款保鮮與合規檢視 (Living Governance Compliance)**：
   - 凡修改核心規範，同步更新 `last_reviewed` 與 `next_review_due`（90 天循環）。
   - 任務提交前確保 `python3 scripts/audit-specs.py` 之條款保鮮閘門 100% 通過。

9. **Tier-1 規格繼承與極簡 Delta 差量單 (Tier-1 Spec Inheritance & Delta Spec)**：
   - **規格繼承**：若該模組在全局 `docs/specs/` 已存在完整規格，Tier-1 輕量任務**無須重複產出 6 大 Living Spec 目錄**。
   - **極簡 Delta 單**：Manifest 標註 `spec_mode: "lightweight"` 與 `base_spec_ref`，任務卡強制包含 15 行極簡 Delta 單（引用來源 + 變更差量 + 1 個可執行 BDD 場景）。
   - **防偷渡降級**：若任務宣告 Tier-1 但修改到 Flyway 遷移檔 (`V*.sql`) 或實體 Schema，門禁強制阻斷升級為 Tier-2。

10. **主規格語意錨點回寫與現行法調閱位階 (Semantic Anchor Reconciliation & Active Truth)**：
    - **語意錨點回寫 (DoD)**：代碼合併入庫時，DoD 強制將增量變更以局部 Diff 替換寫回 `docs/specs/` 對應章節錨點（`<!-- SECTION: ... -->`），嚴禁全篇覆寫。
    - **現行法優先律**：AI 規劃與開發時默認**只調閱現行法 (`docs/specs/` 與 `openapi.yaml`)**，嚴禁將歷史 `tasks/` 中的舊規格當作現行真理。

11. **技術棧 Tier-1 Approved BOM 優先與套件自動擴充協定 (Tier-1 BOM & Dependency Bootstrap - 破除依賴悖論)**：
    - **拒絕手刻低效輪子原則**：
      * 後端強制採用 Tier-1 BOM：Lombok (`@RequiredArgsConstructor`, `@Getter`, `@Setter`, `@Builder`, `@Slf4j`)、MapStruct (實體/DTO 高性能映射)、Flyway/Liquibase、Spring Data JPA Auditing、JaVers/Hibernate Envers (實體差量自動審計)、EasyExcel (註解驅動流式 Excel 匯出)、springdoc-openapi (契約驗證)、ArchUnit、Testcontainers。
      * 前端強制採用 Tier-1 BOM：`lucide-react`（全面取代手寫 inline SVG）、`sonner`（全域 Toast 提示，消除 Prop-drilling）、`react-hook-form` + `zod`（宣告式強型別表單狀態管理，淘汰 10 個 useState）、`@tanstack/react-query`、`@tanstack/react-table`。
    - **執行端自動引進自舉 (Step 0 Dependency Bootstrap)**：
      * Runner Agent 啟動時檢核 Manifest 之 `authorized_dependencies`，若套件未包含於 `pom.xml` 或 `package.json`，**強制且自動地將其注入項目配置並執行安裝**，驗證通過後直接使用，**嚴禁手刻已有成熟方案之基礎建設**。
    - **白名單邊界防禦**：所有授權套件必須嚴格隸屬於 Meta-ADR 3 規範之「Tier-1 Approved BOM」清單，嚴禁引入未經審核之高風險未知套件。

12. **資料庫遷移管線安全與 Hibernate DDL 嚴格禁令**：
    - **`hibernate.ddl-auto` 嚴格禁令**：在企業級生產與測試環境中，`spring.jpa.hibernate.ddl-auto` 僅允許配置為 `validate` 或 `none`，嚴格禁止 `update`。所有 Schema 變更一律由 Flyway / Liquibase 管理。
    - **鎖定逾時防護 (Lock Timeout)**：遷移腳本開頭強制宣告 `SET lock_timeout = '5s';`，保障併發高可用與連線池安全。

13. **結構化日誌、全鏈路追蹤、樂觀鎖與冪等防護**：
    - **SLF4J 參數化日誌**：使用佔位符 `log.info("...", arg)`，嚴禁字串拼接。
    - **MDC 鏈路追蹤**：全請求鏈路綁定 `traceId`, `spanId`, `operatorId`, `domain`。
    - **樂觀鎖併發控制**：核心實體標註 `@Version private Long version;`，衝突時回傳 409 Conflict。
    - **冪等性防護**：變更與匯出端點支援 `X-Idempotency-Key` 請求標頭防重複提交。

14. **前端企業級架構與強制基線標準 (Frontend Architecture Baselines)**：
    - **RSC 與 `'use client'` 嚴格邊界**：頁面入口與佈局預設 Server Components（零客戶端 Bundle、極速首屏）；`'use client'` 嚴格限制於末端互動葉節點（按鈕、彈窗、表單），嚴禁在頂層濫用。
    - **三層狀態管理標準**：非同步 API 請求強制採用 `@tanstack/react-query`；全域會話/佈局狀態強制採用 `zustand`；表單狀態與驗證強制採用 `react-hook-form` + `zod`。
    - **網路傳輸攔截器標準**：集中式 Client 內建 JWT Bearer 自動注入、401 無感 Token 輪轉、`X-Trace-ID` 鏈路追蹤、`AbortController` 請求防競爭與 RFC 7807 錯誤規範化。
    - **Design Tokens 與零 Inline Style 禁令**：所有樣式必須基於 `tokens.css` 與 CSS Modules，**嚴格禁止在 JSX 中寫死 `style={{ ... }}` 行內樣式**。
    - **無障礙性與 Headless 原語 (WCAG 2.1 AA)**：彈窗、下拉選單與 Tooltip 強制基於 Radix UI Primitives 封裝，內建 Focus Trap 焦點陷阱與全鍵盤操作。
    - **大數據虛擬滾動**：表格資料量 > 100 筆強制啟用 `@tanstack/react-virtual` 虛擬滾動。
    - **錯誤邊界與骨架屏**：核心視圖配置 `react-error-boundary` 本地兜底與 Suspense 骨架屏；重型組件採用 `next/dynamic` 延遲載入。

15. **常規提交、語意化版本與 API 日落標準 (Commits, SemVer & API Sunset)**：
    - **Conventional Commits 提交鐵律**：所有 Git Commit 訊息必須具備標準前綴（`feat:`, `fix:`, `refactor:`, `docs:`, `test:`, `chore:`, `perf:`）。
    - **二元解耦與平滑替代律 (Dual-Prism Decoupling & Progressive Sunset)**：
      * 規格與任務編號（Spec / Task ID）：零向下相容包袱，嚴格 6 位數與單一真理。
      * 運行時代碼（Runtime Code）：前後端 API、DTO、參數函數與資料庫變更**強制提供向下相容機制**（雙軌路由 `@RequestMapping({"/new", "/old"})`、`@JsonAlias`、方法多載與 Expand-Contract）。
      * 實體拔除門禁：舊端點標註 RFC 8594 日落標頭，嚴禁在修改當場實體拔除，必須待線上監控客觀確認流量歸零 (`QPS == 0`) 後方可安全 Contract 拔除。

16. **架構自適應升級與踩坑程式化自閉環 (Rules-as-Tests Pipeline - 永不犯第二次錯)**：
    - **雙軌自主演化與規碼對偶鐵律 (Spec-to-Primitive Duality)**：
      * **主動感知原則**：機器探針 (PROBE-01 ~ PROBE-09) 主動掃描架構不變量缺口，任何通用工程政策強制 100% 提煉為 Agent SDK 原語，嚴禁「只寫手冊文字、不造 SDK 原語」的文檔自滿。
      * **探針漏檢故障定性**：若人類使用者指出任何架構盲點（如「為什麼向下相容沒寫入 SDK？」），立即判定為【感知探針漏檢】，處置順序為：
        1. 依據 5 Whys 記入 `docs/governance/RETROSPECTIVE.md`。
        2. 首先建立新感知探針，使同類盲點未來由機器自主發現。
        3. 實體化為 Agent SDK 原生原語（RFC + Template + ArchUnit）。
        4. 回寫標準手冊與規範，形成自閉環。
17. **業務原型自動認領與同構差異比對協定 (Archetype Claiming & Horizontal Parity Protocol)**：
    - **原型先行與功能分區不變性 (Functional Zone Invariance)**：
      * 開發者/代理人接收任何 UI/全端任務時，必須先識別業務原型（如 `MasterDataMaintenance`）。
      * 任何主檔維護模組必須映射為標準的六大功能分區（Zone 1: HeaderActions、Zone 2: SearchForm、Zone 3: Toolbar、Zone 4: DataTable、Zone 5: Pagination、Zone 6: Drawer/Modal）。
    - **兄弟模組橫向差異比對 (Horizontal Sibling Parity Diff)**：
      * 任務驗收前，AI 必須主動遍歷同原型目錄下的所有兄弟切片（如 `countries`、`regions`、`currencies`），比對各分區之組件引用一致性。
      * **禁止區域孤島 hand-rolled 代碼**：凡同家族已有成員抽成共用原語（如 `<MasterDataPagination>`、`<MasterDataTableToolbar>`、`<MasterDataHeaderActions>`、`<MasterDataDeleteConfirmModal>`），所有兄弟模組在該分區必須 100% 同步引用，嚴格禁止遺留手刻私有實作。
    - **零未用引用 (Zero Dead Imports) 與編譯層防假重構**：
      * 前端 TypeScript 編譯器強制開啟 `noUnusedLocals: true` 與 `noUnusedParameters: true`。
      * 嚴格禁止「只在檔頭宣告 import 共用樣板，但 JSX 內未實際替換」之假重構行為，未使用的 import 將被編譯器視為 Compile Error 立即中斷。
    - **主檔樣板強制契約與防塌陷保護 (MasterDataPagination Contract)**：
      * `MasterDataPaginationProps` 中的 `pageSize` 與 `onPageSizeChange` 為強制必填（Required），禁止宣告為 optional。
      * 父層頁面（`page.tsx`）必須妥善管理 `pageSize` 狀態並傳遞給表格，嚴禁寫死分頁筆數。
      * 即便資料為 0 筆或只有單頁，左右兩側控制列均必須完整保留並優雅 disabled，嚴格禁止組件消失或居中錯位。
    - **自適應 Token 與佈局標準 (Adaptive Tokens vs Rigid Literals)**：
      * 元件尺寸與樣式必須基於 Design Tokens（`tokens.layout.*`、`tokens.color.*`）自適應宣告，**嚴格禁止在業務代碼寫死個別像素（如 672px, 768px）或色碼（如 #374151）**，確保系統多端自適應與可演進性。

18. **後端 BaseAuditableEntity 與 API Namespace 鐵律**：
    - **禁止手寫審計欄位**：所有新增之 JPA Entity 必須繼承 `BaseAuditableEntity`，由 JPA Auditing 自動維護時間戳與人員標記，嚴格禁止手動重複宣告。
    - **統一 API 命名空間**：所有主檔維護端點必須嚴格前綴 `/api/v1/system/<resource>`，嚴禁省略 `/system` 或在 Controller 與 `openapi.yaml` 出現路由歧異。

19. **嚴格測試驅動開發 (Strict TDD: Red-Green-Refactor) 鐵律**：
    - **嚴禁測試後置補票 (Test-Last Verification Ban)**：
      * 嚴格禁止「先寫業務程式碼、最後才補跑測試驗收」之反向操作。代理人不得在沒有測試引導之情況下盲目堆疊實作。
    - **三步執行留痕協定**：
      * 凡新增業務功能、提煉共用模組或重構基礎設施，任務執行日誌必須清晰呈現三步軌跡：
        * **Step 1 (Red)**：先撰寫單元/整合/元件測試，執行確認處於失敗狀態（編譯失敗、元件不存在或斷言紅燈）。
        * **Step 2 (Green)**：撰寫僅足以讓測試通過之最小實作程式碼，執行見證翻轉為綠燈。
        * **Step 3 (Refactor)**：在測試保護下優化代碼架構，確保全量迴歸測試 100% 綠燈。
    - **關鍵品質屬性強制測試**：
      * JPA Auditing 自動留痕、樂觀鎖併發衝突、主檔分頁防塌陷、多語系解析等核心規範，必須具備專屬 TDD 測試，嚴禁僅以人工口頭保證。

20. **架構現代化與防幽靈依賴鐵律 (Architectural Realization & Anti-Phantom Mandate)**：
    - **禁止形式化合規 (Ban on Surface Compliance)**：
      * 代理人嚴禁以「保持既有測試綠燈」為藉口避重就輕。
      * 當任務規格要求「引入某能力以取代/簡化某機制」時，執行流程必須強制包含完整的【三階落地】：
        1. 【宣告階段】：於 BOM / Config 正確引入依賴。
        2. 【業務替換階段】：將受影響模組中的手刻舊實作全面剔除，交由新機制接管（嚴禁保留新舊雙軌冗餘）。
        3. 【架構測試固化】：編寫通用架構適應度測試（如 ArchUnit / AST Linter），將架構約束轉為代碼，杜絕死灰復燃。
    - **變更輪廓自我檢核 (Diff Profile Self-Check)**：
      * 提 PR 前，代理人必須自主檢視 Git Diff：若任務目標包含重構，但核心業務代碼變更為 0，直接判定為未完工，不得發起驗收。
    - **零幽靈依賴 (Zero Phantom Dependencies)**：
      * 任何宣告之依賴項，在受影響業務範圍內之呼叫點計數嚴格禁止為 0。


21. **AI 標準函式庫 (Agent SDK) 與修復第一法則 (Patch the Archetype, NOT the Rulebook)**：
    - **三振成庫芽裂**：同質性模式出現第 3 次時，強制抽象並提煉至 `Agent SDK`（後端 `agent-sdk-spring`、前端 `@agent-sdk/react`）。
    - **修復原型而非手冊追加條款**：發現通用缺陷時，直接升級 `Agent SDK` 對應原語，所有業務模組自動免疫，嚴禁在手冊追加瑣碎防禦條款。

22. **多年期領域原型全覆蓋與常青適性守門人 (Longitudinal Archetypes & Architecture Sentry Protocol)**：
    - **完整領域與互動原型強制綁定 (Enterprise Archetype Mandate - RFC-001 ~ RFC-017)**：
      * 新增業務功能時，AI 與開發者必須主動對齊 `Agent SDK` 之 12 大核心領域、人因互動與持久化原型族系：
        1. **主檔資料維護 (`MasterDataArchetype` - RFC-002)**：統一 6 區佈局、動態多語系匯出 (RFC-003)、樂觀鎖 (RFC-004)。
        2. **工作流狀態機 (`WorkflowStateMachineArchetype` - RFC-007)**：強制宣告不可變狀態移轉矩陣，內建樂觀鎖衝突防禦與事務性審計留痕。
        3. **複式財務帳務 (`FinancialLedgerArchetype` - RFC-008)**：嚴格執行零浮點數 (BigDecimal)、銀行家捨入 (HALF_EVEN) 與借貸絕對平衡方程式。
        4. **巨量批次處理 (`BatchIngestionArchetype` - RFC-009)**：強制執行分塊事務提交 (Chunk-Based)、單行錯誤隔離與冪等 JobKey。
        5. **常青適性守門人 (`ArchitectureFitnessSentry` - RFC-010)**：ArchUnit 架構門禁、AST 死按鈕防禦、源碼 ASCII 純淨度。
        6. **平滑演進日落防衛 (`GracefulSunsetGuard` - RFC-011)**：雙軌相容路由別名、RFC 8594 日落標頭、Zero-QPS 遙測門禁。
        7. **零位移平滑過渡 (`ZeroClsTransitionArchetype` - RFC-012)**：容器 min-h 保全、微抖動消解、非塌陷淡入淡出。
        8. **雙模態檢驗畫布 (`DualModeInspectionCanvasArchetype` - RFC-013)**：雙系統思維分離、禁 disabled input、未儲存髒檢查阻尼。
        9. **現代底線頁籤 (`ModernUnderlineTabsArchetype` - RFC-014)**：減法美學、除 Windows 檔案夾樣式、滑動品牌指示條。
        10. **引用防禦阻尼 (`ReferenceDefenseDamperArchetype` - RFC-015)**：共有地悲劇治理、全域引用計數聚合、引用數 > 0 物理禁刪。
        11. **即時試算預覽 (`RealtimeCalculationPreviewArchetype` - RFC-016)**：寇斯交易成本消除、特斯勒複雜度守恆、原位雙向試算範例。
        12. **欄位級異動審計 (`FieldDiffAuditArchetype` - RFC-017)**：霍桑效應、雙時態真相溯源、反射式欄位差異留痕、必填 5 字理由。
      * 嚴格禁止在 Service 內部私自手寫狀態機 if-else、自寫浮點數貨幣計算、手刻批次匯入迴圈或前端隨意使用 disabled input。
    - **規碼對偶律 (Spec-to-Primitive Duality Law - 嚴禁孤兒規範)**：
      * 任何寫入規範之原則，嚴禁僅停留於文字宣導；必須 1:1 對偶對應到 Agent SDK RFC 規格與樣板代碼。
    - **常青適性守門人物理阻斷 (RFC-010: Architecture Fitness Sentry)**：
      * 將 Meta-ADR 與四大核心不變量（表現層外部化、契約唯一真實源、同構模組對稱性、確定性彈性）100% 轉化為可執行之 `ArchitectureFitnessTest` (ArchUnit) 與 AST 門禁。
      * 任何非呈現層硬編碼中文、實體遺漏 `@Version`、跨層依賴或浮點數金額違規，CI/Maven 編譯直接中斷，物理阻斷合併。
    - **開源無方言中立性 (Dialect-Agnostic Substrate)**：
      * Agent SDK 程式碼與原語嚴格杜絕業務名詞污染（如 Reinsurance），依賴 SPI Adapter 隔離資料庫與 CSS 工具庫，確保未來可開源性。

23. **百年架構保鮮與宿主解耦鐵律 (Centennial Host Decoupling & Invariant Preservation)**：
    - **可拋棄宿主意識 (Disposable Host Awareness)**：
      * AI 代理人與開發者必須將當前的 Spring Boot 與 React 實作視為「當代臨時宿主（Layer 2）」。
      * 核心領域邏輯、狀態機與會計計算嚴禁與框架 API 深度纏繞，必須完全依賴 Layer 0 永恆代數與 Layer 1 Task-IR 字節碼，確保 20 年後系統可隨時由 AI 重新編譯為全新世代宿主。
    - **雙時態不可變審計不變性 (Bi-Temporal Audit Invariant)**：
      * 凡涉及金融、帳務、再保合約條款與理賠之實體，嚴格禁止原位覆寫（In-Place UPDATE/DELETE）。
      * 每一筆變更必須同時保留業務有效日 (Valid Time) 與系統記錄日 (Transaction Time)，任何更正一律透過紅字沖銷與版本追加，確保 20 年後可重現任意歷史秒點之真實狀態。
    - **證明義務與數學不變量自檢 (Proof Obligations)**：
      * 關鍵領域邏輯必須附帶明確的不變量定理（如借貸恆平、狀態機無死鎖、呈現文字無洩漏），使 Task-IR 能被形式化證明驗證。
    - **負熵自合成協定 (Negative Entropy Protocol)**：
      * 提 PR 時，若發現同質性模式出現第 3 次，優先提煉回 `Agent SDK`，並實施業務模組舊代碼之實質拔除，以「淨代碼消除」維持系統負熵演進。


24. **百年 6 位數 Task ID 純粹規格 (Centennial 6-Digit Task ID Schema)**：
    - **6 位數百萬級編碼**：任務目錄命名嚴格採用 6 位數 `tasks/TASK-{06d}/`（如 `tasks/TASK-000009/`, `tasks/TASK-000011/`），子任務採 3 位數 `TASK-{06d}-{03d}_{Role}.md`。
    - **無須向下相容**：全專案任務一律以 6 位數標準重新分析與拆分，徹底消滅 3 位數過渡期語法與兼容包袱。

25. **任務歷程確定性重現與時空膠囊義務 (Deterministic Replay & Temporal Task Capsules)**：
    - **全歷程不可篡改留痕**：嚴禁刪除任何歷史任務目錄。
    - **時空膠囊自洽性**：每一任務目錄提交前，必須確保 `task.ir.yaml`、`manifest.yaml` 與 Living Specs 齊全自洽，使未來的 AI 虛擬機能夠單憑字節碼從頭重放並 100% 還原該任務之所有功能與架構狀態。

26. **自我演化週期與自動防熵自檢 (Evolution Cadence & Anti-Drift Protocol)**：
    - **季度防熵與新鮮度**：每次執行任務時，主動檢查關聯規格之 `governance_metadata.review_cadence`，逾期時主動於 PR 提醒更新。
    - **年度負熵自覺**：發現重複代碼模式達 3 次時，嚴格禁止再次手刻拷貝，必須主動提煉至 `Agent SDK`。
28. **全域文檔漣漪同步鐵律 (The Synchronous Documentation Ripple Mandate)**：
    - **拒絕局部產物定勢 (Anti-Local Artifact Fixation)**：
      * 當 AI 代理人新增、修改或重構任何架構原語（RFC）、領域原型或核心設計模式時，嚴禁僅在單一目錄（如 `agent-sdk/specs/`）完成工作即告完工。
    - **強制執行 10 點漣漪檢核清單 (10-Point Ripple Checklist)**：
      1. `agent-sdk/specs/RFC-xxx.yaml`（RFC 規格）
      2. `agent-sdk/templates/`（Spring / React 物理樣板）
      3. `agent-sdk/catalog.yaml`（符號表登錄）
      4. `agent-sdk/README.md`（頂層規格列表、12 大原型矩陣與完整目錄樹）
      5. `agent-sdk/ROADMAP.md`（演進藍圖與棄用生命週期）
      6. `.agents/skills/agent-sdk/SKILL.md`（AI 代理人技能速查矩陣）
      7. `docs/specs/*.md`（Living Specs 雙向對偶綁定，嚴禁孤兒規範）
      8. `docs/adr/ADR-004` 與 `docs/ENGINEERING_STANDARDS.md`（核心決策與工程標準）
      9. `scripts/audit-specs.py` Gate 5（跨文檔一致性物理門禁驗證）
      10. `docs/governance/RETROSPECTIVE.md`（覆盤經驗沉澱）
    - 任何一次提交若漏掉上述漣漪鏈條中任一環節，視為「未完工半成品」，CI Gate 5 將自動物理阻斷。

29. **互動經驗轉化為永久資產協議 (Continuous Experiential Learning & Self-Evolution Protocol)**：
    - **反脆弱經驗吸納原則 (Anti-Fragile Learning Axiom)**：
      * 人類使用者的每一次糾偏、質疑與流程建議，皆為系統自主演化的最高級養分。
      * 遭遇遺漏或認知盲區時，嚴禁停留在「口頭認錯」或「針對當前代碼打地鼠修補」，必須立即執行四步經驗閉環：
        1. **記錄覆盤 (Document in RETROSPECTIVE.md)**：精準分析 5 Whys 與根本原因。
        2. **調整規範 (Update Standards & Rules)**：將人類指導昇華為 SOP 步驟或工程不變量。
        3. **原語沉澱 (Codify into SDK Primitives)**：將通用解法抽象為 Agent SDK RFC 與樣板。
        4. **門禁代碼化 (Automate as CI Check)**：編寫自動化校驗探針，使機器永遠代替人類記憶。
    - **跨會話記憶保鮮**：
      * AI 在開展任何規劃或審查前，必須調閱歷史經驗記錄，確保過去對話累積之養分在全新的會話與世代中完整發揮效力。

30. **分支合併與人機放行安全閥鐵律 (Strict Human-in-the-Loop Branch Promotion & Anti-Premature Merge Mandate)**：
    - **執行邊界 (Execution Boundary)**：
      * Agent 執行任何任務的常態交付終點恆為：「在 feature/task 分支完成代碼實作 ➔ 本地所有測試與品質門禁全綠 ➔ 提交 Git ➔ 產出詳細驗收報告 ➔ **主動停止工具調用，等待人類檢閱與確認指令**」。
    - **嚴格禁令 (Absolute Merge Prohibition)**：
      * 嚴格禁止 Agent 在未經人類使用者明確回覆同意前，自行切換分支並執行 `git merge dev` 或 `git merge main`。
      * 任何「自作主張替主管簽核、把交付物直接打入共享主幹」之行為，一律判定為「一級安全閥越權違規 (Level-1 Safety Valve Violation)」。
    - **唯一放行條件與語意意圖辨識 (Sole Authorization Condition & Semantic Intent Recognition)**：
      * 任務完成後，Agent **一律強制止步於 feature 分支**並出示驗收報告。
      * **語意意圖辨識原則 (Semantic Intent Recognition - 嚴禁死板字串匹配)**：只要人類使用者在語意上表達了明確的合併指示（例如：`請合併 TASK-XXXX`、`合併 TASK-XXXX`、`幫我將 TASK-XXXX 合併到 dev`、`把 TASK-XXXX merge 回 dev`、`同意合併` 等自然語言表達），即視為取得正式授權。核心在於「人類明確給出推進受保護主幹的意圖授權」，而非拘泥於固定文字。
    - **自適應整合策略自決權 (Autonomous Strategy Selection: Merge vs Rebase)**：
      * 接獲人類合併意圖指令後，Agent **具備自主裁量權，依據當前分支拓撲與 Commit 品質自行決定最適技術策略**（無須再次中斷詢問）：
        1. **Fast-Forward / Rebase (首選線性歷史)**：當 feature 分支代碼已高度精煉為單一或極少數語意完整的原子 Commit，且基於最新 `dev` 時，直接採用 `git merge --ff-only` 或 `git rebase`，維護百年主幹的極致線性與零雜訊。
        2. **Explicit Merge (`git merge --no-ff` - 任務膠囊審計留痕)**：當任務涉及大型多階段重構（包含多個清晰子任務 Commit），且需要明確保留任務起訖的封閉拓撲邊界時，採用 `--no-ff` 產生結構化 Merge Commit。
        3. **Squash Merge (細碎提交壓平)**：若 feature 分支在開發過程中產生大量試錯補丁或 WIP commit，強制使用 `merge --squash` 壓平成單一標準語意 Commit 後再行入庫。

31. **嚴禁遭遇問題直接修改代碼與任務規格先行鐵律 (Anti-Adhoc Patching & Spec-Task Primacy Mandate)**：
    - **第一性硬約束 (Code is Merely an Artifact; Specs & Tasks are Truth)**：
      * 在規格驅動 (Spec-Driven) 與時空膠囊確定性重現 (Deterministic Replay) 體系中，嚴格禁止任何「未經 Task 規格定義、跳過人類審批、遭遇問題直接修改工作區代碼」的私自修補 (Ad-hoc Patching) 行為。
      * 任何程式碼變更，其背後必須具備不可篡改、可溯源的 Task 規格與任務字節碼作為法理依據。若脫離 Task 直接改代碼，將導致未來全新環境重放任務時無法再現該修復，引發百年架構歷史漂移。
    - **任務顆粒度自評與三階決策啟發式 (Task Granularity Assessment & Decision Heuristic)**：
      * **微粒度變更 (Micro-Granularity - 實用主義敏捷修復)**：
        對於如未實作頁面防禦性佔位路由、非業務型樣式微調、型別補齊、文字錯字微調等極小問題，允許實作修改後**隨即回頭調整關聯既有 Task 之時空膠囊（如回溯 TASK-000010 的 manifest 與 specs）**，既保證工程敏捷，又維護任務重放（Deterministic Replay）的自洽性。
      * **中/大粒度變更 (Medium/Macro-Granularity - 嚴格規格先行)**：
        凡涉及領域實體結構異動、新業務功能、狀態機重構或 cross-service API，強制開立全新 6 位數 Task（如 `TASK-000016`），備齊 `manifest.yaml`、`task.ir.yaml` 與完整規格子任務，呈報人類審批後方可動工。
      * **顆粒度邊界模糊時之雙安全閥 (Two Safety Fallbacks)**：
        若 AI 無法確信變更屬於微粒度或中粒度，**最安全之作法強制二選一**：
        1. **開立全新獨立任務** (Create New Task 備查)。
        2. **主動發起對話互動介面 (`ask_question`)** 立即向人類架構師請示執行路徑，嚴格杜絕私自冒進。
    - **標準協作推進五階閉環 (Mandatory 5-Step Closed Loop)**：
      `確認問題 ➔ 深入討論 ➔ 任務規劃（顆粒度自評：回溯舊任務 vs 開立新任務） ➔ 人類審批確認 ➔ 建立/切換分支 ➔ 執行代碼修改`。

32. **操作閉環與系統狀態確定性第一性原則 (Principle of Operational Closure & Deterministic System State)**：
    - **第一性本質定義 (First-Principles Definition)**：
      * 介面上任何可被使用者看見之互動意符（按鈕、頁籤、卡片、側邊欄項目、超連結、表單動作），在系統狀態機中皆為「狀態轉移觸發事件 (Transition Trigger)」。
      * **核心不變量**：系統對外暴露之任何互動入口，其對應的狀態轉移必須是**有界、受控且封閉自洽的 (Bounded, Controlled & Closed Transition)**。嚴格禁止在呈現層暴露任何會導向未定義狀態或崩潰的入口。
    - **意符與能力誠實對等律 (Signifier-Affordance Honesty)**：
      * 視覺意符必須與系統當前具備的真實能力 100% 誠實對齊。嚴禁給予使用者「看起來能點、點了卻引發錯誤或找不到頁面」的**虛假可供性 (False Affordance)**。
      * 若某項能力尚未就緒（未實作、依賴缺失、排程迭代中、權限未開通），必須嚴格遵循三態降級階梯：
        1. **第一態：不露出 (Hidden)**：未開通即不予渲染入口。
        2. **第二態：顯式抑制 (Disabled with Tooltip)**：標記 `disabled={true}` 並以 Tooltip 誠實說明未就緒原因與預期時程。
        3. **第三態：規範化降級著陸 (Resilient Landing)**：若為漸進式導航或佔位（如 6 大選單頁籤），著陸點必須具備同構框架（如 `<ComingSoonPlaceholder>`）、清楚標示排程任務與規格錨點，並提供返回基準工作區之安全逃生門。
    - **狀態轉移無未定義行為 (Zero Undefined Behavior)**：
      * 嚴格禁止任何操作將底層框架之技術未捕獲異常（如原生 HTTP 404, 500, Unhandled Promise Rejection, React 白屏）直接暴露給使用者。
    - **操作死胡同零容忍 (Ubiquitous Escape Hatch)**：
      * 任何非預期、降級或錯誤狀態，系統必須維持操作脈絡恆常性，提供業務上下文、追溯識別碼，以及「一鍵安全返回基準工作區」的逃生出口，絕不允許讓使用者陷入無路可走的孤島死胡同。

33. **反打地鼠與修復原語元治理鐵律 (Anti-Whack-a-Mole & Archetype-Level Remedy Mandate)**：
    - **拒絕症狀驅動列舉條文 (Anti-Symptom Listing)**：
      * 嚴禁面對介面缺陷時，採取「就事論事追加微觀列舉條文」之打地鼠模式（例如：不可因選單出錯就立「選單 404 鐵律」，不可因麵包屑出錯就立「麵包屑 500 鐵律」）。
    - **修復原型原語，而非手冊追加規則 (Patch the Archetype, NOT the Rulebook)**：
      * 遭遇任何介面或系統異常時，AI 代理人必須將問題向上提煉為第一性原則與通用原語。
      * 治理責任在於修復底層原型組件（如通用 `ComingSoonPlaceholder`、統一 `ErrorBoundary`、通用 API Client 攔截器）與自動化門禁（如 `audit-routes.js`），使全系統所有兄弟模組自動繼承全域免疫力。

34. **時空膠囊規格純淨與防補丁污染鐵律 (Time-Capsule Spec Purity & Anti-Patch-Pollution Mandate)**：
    - **第一性本質定義 (First-Principles Definition)**：
      * 任務規格書（Task Specs / Subtask Markdown）是軟體工廠可確定性重放（Deterministic Replay from Scratch）的終態藍圖。
      * 若任務從 TASK-001 開始從頭執行，規格描述必須是「該功能第一天就應該被正確建構的樣貌」，產生出完全相同的正確畫面與行為。
    - **嚴格禁令 (Strict Prohibitions)**：
      1. 嚴格禁止在任務規格書中寫入任何運行期維護補丁記錄、維護分支名稱或事後補償敘述（例如 `（維護分支 ...）`、`（修復分支 ...）`、`（覆盤案 ... 補全）`、`臨時分支`、`補丁`）。
      2. 嚴格禁止將暫態的 Git 修復分支資訊（如 `fix/TASK-000012-UI`）污染至靜態規格書的 `分支指引` 中。規格書的分支指引恆為標準的初始任務分支（如 `feature/TASK-000012-002-UI`）。
    - **職責與留痕邊界劃分**：
      * **任務規格書 (`tasks/**/*.md`)**：純淨目標態陳述式藍圖（Declarative Blueprint）。
      * **Git 維護分支 (`fix/<TASK_ID>-<ROLE>`)**：僅作為當前發布補丁進入 `dev` 的傳輸載具。
      * **歷史事故留痕 (`RETROSPECTIVE.md`)**：專門記錄維護案由、5 Whys 根因分析與制度化改進。

35. **多庫分支分類與修復命名零冗餘鐵律 (Tri-Repo Branch Taxonomy & Zero-Redundancy Invariant)**：
    - **分支分類唯一標準 (Branch Taxonomy Standards)**：
      * **契約庫 (`reinsurance-contracts`)**：任務分支唯一使用 `task/<TASK_ID>`（例如 `task/TASK-000013`）。
      * **雙端專庫之新功能分支**：唯一使用 `feature/<TASK_ID>-<ROLE>`（後端 `feature/<TASK>-API`，前端 `feature/<TASK>-UI`）。
      * **雙端專庫之修復分支**：唯一使用 `fix/<TASK_ID>-<ROLE>`（後端 `fix/<TASK>-API`，前端 `fix/<TASK>-UI`）。
    - **嚴格禁令 (Strict Prohibitions)**：
      1. 雙端專庫嚴格禁止使用 `task/` 作為分支前綴（如 `task/TASK-000013-ui`、`task/TASK-000012-fix` 均屬違規）。
      2. 嚴格禁止在已經帶有修復語意的前綴下追加冗餘尾綴（如 `fix/TASK-000012-fix`、`task/...-fix`）。
    - **機器門禁強制阻斷 (Machine Audit Gate Enforcement)**：
      * `scripts/audit-specs.py` Gate 4 全面掃描 `manifest*.yaml`、`tasks/**/*.md` 與本地 Git 多庫分支，違者直接 Exit 1 阻斷 CI 與發布。

36. **人機協作意圖提煉與架構昇華鐵律 (Human Intent Distillation & Architectural Elevation Mandate)**：
    - **人機分工定位 (Core Division of Labor)**：
      * **人類架構師 / 使用者 (Human Partner)**：扮演最前線的敏銳感知者，負責捕捉視覺異常、操作違和感、流程斷點或提出直覺疑問。人類的回饋往往以微觀症狀呈現，其真實核心在於「期望系統具備根本性原則與長期確定性」。
      * **AI 代理人 (AI Architect Agent)**：嚴禁把自己降格為「單點修復的打地鼠工讀生 (Ad-hoc Mole-Whacker)」。AI 的第一天職是作為**「原則提煉器與制度化架構師 (Principle Distiller & Institutional Architect)」**。
    - **三階昇華反射協議 (Three-Stage Elevation Reflex Protocol)**：
      每當接獲人類的疑問、糾偏或缺陷回饋時，AI 嚴禁直接反射性修改代碼，必須自動觸發三階昇華：
      1. **第一階：症狀向下紮根 (Root-Cause Exploration - 5 Whys)**：探究單點症狀所暴露的底層架構斷裂或通用模式缺失。
      2. **第二階：痛點向上提煉第一性原則 (Principle Abstraction & Invariant Formulation)**：
         * 幫助人類將直覺與痛點精煉為普適性的「系統不變量（System Invariants）」。
         * 劃清「目標態時空膠囊規格藍圖」與「運行期暫態發布載具」的純淨邊界。
      3. **第三階：橫向閉環機器自動化門禁 (Machine Verification & Immune Codification)**：
         * 永不依賴口頭承諾或追加瑣碎手冊條文。
         * 強制將提煉出的原則實體化為客觀代碼檢驗閘門（如 AST Linter、正則檢查器、CI Gatekeeper），使全系統所有模組自動繼承全域免疫力。
