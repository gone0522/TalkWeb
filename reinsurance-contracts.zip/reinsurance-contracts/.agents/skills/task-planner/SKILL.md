---
name: task-planner
description: 全域需求分析師與架構師，專門將業務需求與 UI Mockup 拆解為模組化任務目錄 (tasks/TASK-{模組編號}/)，嚴格依據 Meta-ADR 1 ~ 3 (ADR-001 ~ ADR-003) 雙軌規格、OpenAPI Code-Gen 職責分離、三庫串行合併順序與 Tier 1 規格繼承閉環體系，產出人類 Living Specs 與機器可執行雙軌 manifest，並落實全資產領域標籤 (Domain Tagging)。
last_reviewed: 2026-10-13
review_cadence: QUARTERLY
next_review_due: 2027-01-13
governance_status: ACTIVE
---

# Task Planner Skill - 全域需求拆解與高質量規格書庫架構師

本技能專門負責在新需求注入時，依據跨專案通用框架 (`docs/framework/`)、領域規範 (`docs/domain/`)、三大統合架構決策 (Meta-ADR 1 ~ 3) 與工程實作準則 (`docs/ENGINEERING_STANDARDS.md`)，產出高內聚、自包含之模組化任務包。

---

## 核心工作流程 (Core SDLC Workflow)

### 步驟 0：主動記憶檢索、現狀盤點與 QoS 啟動問卷
1. **主動記憶檢索 (Memory Recall Protocol)**：開工前強制檢索 `docs/governance/RETROSPECTIVE.md`、Meta-ADRs (`docs/adr/ADR-001 ~ 003`) 與通用框架 (`docs/framework/AI_SOFTWARE_FACTORY_BLUEPRINT.md`)。
2. **現行法調閱位階**：規格盤點默認**只調閱 `docs/specs/` 與 `contracts/openapi.yaml`**，嚴禁將歷史 `tasks/` 中的舊規格視為現行真理。
3. **S / M / L 系統自適應等級判定 (Meta-ADR 3)**：預設判定為 **M 級 (1,000 QPS 基準，P95 < 100ms)**。
4. **QoS & NFR 問卷快速確認**：吞吐量、延遲、可用性、資料精度、災難復原、相依性預檢。

### 步驟 1：動態掃描輸入來源與模組編號
1. **動態輸入識別**：支援對話文字或任意目錄。
2. **自動決定模組代碼與百年 6 位數標識 (Centennial 6-Digit Task ID)**：
   - 掃描 `tasks/` 內既有最大模組編號，接續遞增。
   - 任務全面採用 **6 位數百萬級編碼** `TASK-{06d}`（如 `tasks/TASK-000012/`），容量達 1,000,000 任務，百年之內永不溢出。
   - 子任務全面採用 **3 位數編碼** `TASK-{06d}-{03d}_{Role}.md`（如 `TASK-000012-001_Backend.md`）。
   - 無須向下相容：所有任務統一以 6 位數全新分析規格產出，杜絕歷史 3 位數混用。
3. **建立內聚模組目錄**：建立 `tasks/TASK-{模組編號}/`。

### 步驟 2：產出雙軌規格體系 (Dual-Track Spec Generation)

#### 規格產出分級機制 (Spec Tiering)
在產生規格前，先依據任務性質決定產出模式：
- **模式 A：全量規格模式 (Full Living Spec Suite - Tier-2 / 全新領域模組)**：
  * 在 `tasks/TASK-{模組編號}/specs/` 建立完整 6 大 Living Specs (`SA`, `DBA`, `SD`, `UI`, `USE_CASE`, `QA`)。
  * `contracts/openapi.yaml` 宣告端點結構，`SD_SPEC.md` 專注於 Mermaid 時序圖與交易邊界，嚴禁手抄 JSON 字典。
- **模式 B：Tier-1 規格繼承模式 (Lightweight Spec Inheritance - Tier-1 輕量任務)**：
  * 若任務為低風險修復、展示型調整、欄位微調，且全局 `docs/specs/` 既有完整活體主規格，**嚴禁重複複製 6 大規格目錄**。
  * Manifest 標註 `spec_mode: "lightweight"` 與 `base_spec_ref: "docs/specs/..."`。
  * 任務卡強制包含 15 行極簡 Delta 單（引用來源 + 變更差量 + 1 個可執行 BDD 場景）。
  * 任務卡結尾必須標註：「【DoD 提醒】：本任務代碼合併入庫時，必須將增量變更回寫同步至 `docs/specs/` 主規格」。


### 步驟 2.2：全域文檔漣漪同步檢核 (The Synchronous Ripple Check)
若任務牽涉架構原語 (RFC)、通用元件或規範升級，Planner 必須主動依據 **10 點漣漪清單 (10-Point Ripple Checklist)** 檢視影響範圍：
1. `specs/RFC-xxx` ➔ 2. `templates/` ➔ 3. `catalog.yaml` ➔ 4. `README.md` ➔ 5. `ROADMAP.md` ➔ 6. `SKILL.md` ➔ 7. `docs/specs/*.md` (雙向對偶) ➔ 8. ADR-004 & Standards ➔ 9. Gate 5 CI 門禁 ➔ 10. RETROSPECTIVE.md。
杜絕僅改局部代碼或局部文檔的「斷鏈」現象，確保整廠規格資產 100% 齒輪咬合。

### 步驟 2.1：套件授權宣告與規範鍵值定義 (Dependency Authorization & Canonical Keys - 破除依賴悖論)
1. **Tier-1 Approved BOM 套件授權宣告 (`authorized_dependencies`)**：
   - Planner 在分析任務需求時，若需特定技術能力，**必須**主動在 `manifest-api.yaml` 或 `manifest-ui.yaml` 宣告授權套件（嚴格限於 Meta-ADR 3 之 Tier-1 Approved BOM）：
     * 後端：Lombok, MapStruct, EasyExcel, JaVers/Envers, springdoc-openapi, ArchUnit, Testcontainers。
     * 前端：lucide-react, sonner, react-hook-form, zod, @tanstack/react-query, @tanstack/react-table。
   - 宣告範例：
     ```yaml
     authorized_dependencies:
       maven:
         - groupId: "org.mapstruct"
           artifactId: "mapstruct"
           purpose: "Entity to DTO compile-time mapping"
       npm:
         - package: "sonner"
           purpose: "Global declarative toast notifications"
         - package: "lucide-react"
           purpose: "Enterprise SVG icons"
     ```
2. **全語言零自然語言硬編碼與規範代碼規劃 (Canonical Keys & Machine Error Codes)**：
   - 審計表規劃：`change_reason` 欄位與異動識別必須定義 **Canonical Keys**（如 `SYSTEM_DEFAULT_UPDATE`），嚴禁規劃自然語言文字入庫。
   - API 契約規劃：所有異常回應必須定義枚舉型機器錯誤代碼 (`errorCode`)。
   - 報表匯出規劃：表頭與列舉名稱必須規劃為經由 `MessageSource` 動態多語系解析。

### 步驟 3：微任務切片與 API 依賴追溯表 (Vertical Slice & Traceability Table)
1. **解耦切片標準 (Meta-ADR 2)**：
   - 後端任務：`TASK-{模組編號}-01_Backend.md`，由後端倉庫 `dev` 切出 `feature/TASK-{模組編號}-API`。
   - 前端任務：`TASK-{模組編號}-02_Frontend.md`，由前端倉庫 `dev` 切出 `feature/TASK-{模組編號}-UI`（以 OpenAPI Mock 獨立並行開發）。
2. **聯調與合併順序指引 (Tri-Repo Promotion Guide)**：
   - 明確標示：提 PR 前夕前端切換 `MOCK=false` 進行本地真機聯調 (The Handshake Moment)；合併順序遵循「Contracts PR 預審 -> 後端合入 -> 前端合入 -> Contracts 回寫結案合入」。

### 步驟 4：五大自動化品質閘門稽核 (Quality Gate Audit - Gate 1 ~ Gate 5)
在提交任務前，強制執行規格治理、領域標籤與同構防漂移稽核：
```bash
python3 scripts/audit-specs.py
```
**必須 100% Passed 通過，否則視為無效任務包，嚴禁發布！**
- **Archetype Homomorphic Parity & Sibling Diff Gate (同構原型橫向差異與自適應樣板門禁)**:
  * 規劃與執行前必須辨識業務原型 (如 `MasterDataMaintenance`)，並自動檢索同一原型目錄下的兄弟模組（如 `src/components/menus/*`）進行橫向差異比對 (Sibling Horizontal Parity Diff)。
  * 主檔畫面強制映射為 6 大功能分區，100% 引用家族共用原語（`<MasterDataHeaderActions>`、`<MasterDataTableToolbar>`、`<MasterDataPagination>`、`<MasterDataDeleteConfirmModal>`），嚴禁在各模組留存手刻私有實作。
  * 元件尺寸與配色全面綁定自適應 Design Tokens（`tokens.layout.*`、`tokens.color.*`），嚴格禁止寫死固定像素（如 `672px`, `768px`）或特定色碼（如 `#374151`），具備多端與主題自適應彈性。
  * 若專案出現第 3 個同質模組，觸發「三振重構法則 (Rule of Three)」，強制先規劃「提煉共用樣板模組」。
  * 核心實體必須繼承 `BaseAuditableEntity`，API 路徑必須符合 `/api/v1/system/*` 命名空間。


### 步驟 2.3：標準庫符號連結與任務字節碼編譯 (Agent SDK Linking & Task-IR Generation)
1. **意圖編譯器 (Intent Compiler) 角色**：
   - Planner 作為軟體工廠的 `javac`，負責將高階人類規格書 (`.spec.md`) 編譯為機器可執行的任務字節碼 (**Task-IR**, `task.ir.yaml`)。
2. **標準庫符號連結 (Agent SDK Linking)**：
   - 檢索 `Agent SDK` 能力清單。若需求具備 Master Data、動態報表匯出、審計日誌或樂觀鎖特徵，**直接宣告連結 `Agent SDK` 原語**（如 `DynamicLocalizedExporter`, `<MasterDataMaintenanceView>`），嚴禁在 Bytecode 指示 Runner 手寫底層輪子。
3. **任務字節碼輸出 (Task-IR Schema)**：
   - 輸出具備自包含性的 `task.ir.backend.yaml` 與 `task.ir.frontend.yaml`，內建環境前置神諭 (Pre-flight Contract)、狀態不變量約束與行為驗收神諭 (Verification Oracles)。
