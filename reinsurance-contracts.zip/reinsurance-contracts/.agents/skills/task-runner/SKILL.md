---
name: task-runner
description: 自動化執行需求開發任務 (tasks/TASK-{模組編號}/TASK-*.md)，嚴格依據 Meta-ADR 1 ~ 3 (ADR-001 ~ ADR-003) 與精簡工程規範 (ENGINEERING_STANDARDS.md)，落實 OpenAPI Code-Gen 純投影隔離、軟性外鍵零跨領域 JOIN、Package-Private 封閉性、Feature-Sliced 目錄對齊、本地真機聯調切換 (The Handshake Moment)、三庫串行發布順序與主規格語意錨點回寫閉環。
last_reviewed: 2026-10-13
review_cadence: QUARTERLY
next_review_due: 2027-01-13
governance_status: ACTIVE
---

# Task Runner Skill - 任務執行與品質驗收核心技能

本技能專門用於執行 `tasks/TASK-{模組編號}/` 下之任務，遵循「雙軌規格 (Meta-ADR 1)」、「零死按鈕深度 AST 禁令」、「三庫串行發布 (Meta-ADR 2)」與「主規格語意錨點回寫閉環」嚴格交付。

---

## 核心執行流程與品質閘門

### 0. 相依性自動引進開通 (Step 0: Dependency Bootstrap - 破除依賴悖論)
- **檢核授權清單**：讀取 Task Manifest 中的 `authorized_dependencies` 區塊。
- **自動引入自舉**：
  * 若宣告 Maven 套件且 `pom.xml` 尚未包含，**自動將其加入 `pom.xml` 並驗證編譯**。
  * 若宣告 NPM 套件且 `package.json` 尚未安裝，**自動執行 `npm install <package>`**。
- **嚴禁手刻輪子**：驗證通過後，強制採用 Tier-1 Approved BOM 套件實現功能（例如用 MapStruct 做映射、用 EasyExcel 匯出、用 sonner 發 Toast、用 react-hook-form 管理表單、用 lucide-react 提供圖示），嚴禁倒退手刻低效代碼！

### 1. 任務上下文與雙軌契約加載 (Step 1: Grounding & Contract Binding)
- **讀取機器契約**：優先讀取 `tasks/TASK-{模組編號}/manifest.yaml`（或雙軌切片 `manifest-api.yaml` / `manifest-ui.yaml`），確認領域標籤、系統等級 (`tier_level`)、風險等級 (`risk_tier`) 與限定範圍 `target_files`。
- **載入人類 Living Specs 或繼承主規格**：
  * 若為全量規格任務：讀取模組 `specs/`（`SA_SPEC.md`、`DBA_SPEC/`、`SD_SPEC/`、`UI_SPEC/`、`QA_SPEC/`）。
  * 若宣告 `spec_mode: "lightweight"` 或 `base_spec_ref`：讀取 `base_spec_ref` 指定之主規格（如 `docs/specs/`），並結合任務卡之極簡 Delta 單執行。
- **現行法優先**：嚴禁將歷史任務目錄視為規格真理源。

### 2. 分支生命週期管理 (Step 2: Branching Protocol - Meta-ADR 2)
- **獨立分支切出（嚴禁跨倉庫切分支）**：
  * 後端任務：強制從後端倉庫 (`reinsurance-core-service`) 之 `dev` 切出 `git checkout -b feature/<TASK_NAME>`。
  * 前端任務：強制從前端倉庫 (`reinsurance-web-portal`) 之 `dev` 切出 `git checkout -b feature/<TASK_NAME>`（以 OpenAPI Mock 獨立並行開發）。
- **三庫串行發布順序鐵律**：
  * 步驟 1：Contracts PR 預審就緒（保持 PR 開啟暫不合入 dev）。
  * 步驟 2：後端 PR 測試全綠，合併入 `core-service:dev`。
  * 步驟 3：前端真機聯調通過，PR 合併入 `web-portal:dev`。
  * 步驟 4：Contracts 庫由結案 Agent 完成主規格回寫檢驗，最終合併入 `contracts:dev`。

### 3. 相依性事前檢核與優雅降級 (Step 3: Pre-flight Check & Degradation Protocol - Meta-ADR 1)
- **核心主流程 API 缺失**：立即將任務標記為 `BLOCKED`，終止開發並向負責人報告阻斷。
- **非核心附加功能缺失**：啟動確定性優雅降級，按鈕必須設置 `disabled={true}` 並包裹 Tooltip，交付清單標記 `[UI-Placeholder]`，嚴禁放置無事件之假按鈕充數！

### 4. 後端實作與品質閘門 (Step 4: Backend Implementation & Quality Gate - Meta-ADR 2 & 3)
- **Tier-1 Approved BOM 優先實作**：全面採用 Lombok (`@RequiredArgsConstructor` 等)、MapStruct (DTO 映射)、Spring Data JPA Auditing、JaVers/Envers、EasyExcel、springdoc-openapi，杜絕手寫樣板。
- **全語言零自然語言硬編碼與規範鍵值存儲**：
  * 資料庫審計表 `change_reason` 必須存入 **Canonical Identifiers / Standard Keys**（如 `SYSTEM_DEFAULT_UPDATE`），嚴格禁止存入自然語言文字。
  * Excel / CSV 匯出表頭與列舉名稱必須動態注入 `MessageSource`，依據 `LocaleContextHolder.getLocale()` 動態在地化，嚴禁寫死靜態字串陣列。
- **資料庫遷移管線安全**：`spring.jpa.hibernate.ddl-auto` 嚴格禁止 `update`（只允許 `validate` 或 `none`）；遷移腳本開頭強制宣告 `SET lock_timeout = '5s';`。
- **種子資料同源**：Flyway 維護 `V999__dev_seed_data.sql`，提供標準測試資料。
- **領域內 vs 跨領域 CQRS**：領域內開放 View / JOIN；跨領域嚴格禁止實體 JOIN，一律應用層組裝或快照模式。
- **Package-Private 封閉性**：DAO/Repository/Service 實作設為 Package-Private，公開介面唯一導出。
- **引用防禦與軟刪除**：提供 `GET /references` 摘要端點；嚴禁物理刪除，一律 `is_disabled = true`。
- **Expand/Contract 雙相遷移**：欄位變更採雙相無感遷移，防止滾動部署 500 錯誤。
- **後端驗收閘門**：`mvn test` 必須 100% 通過（0 Failures, 0 Errors）。

### 5. 前端實作、真機聯調與品質雙重閘門 (Step 5: Frontend Implementation, Handshake & Dual Gates)
- **Tier-1 Approved BOM 與前端強制架構基線**：
  * RSC 與 Client Component 嚴格邊界：頁面/佈局預設 Server Components；`'use client'` 僅限末端互動葉節點。
  * 三層狀態管理：`@tanstack/react-query` (非同步 API 快取與去重), `zustand` (全域會話/彈窗狀態), `react-hook-form` + `zod` (表單校驗)。
  * 集中式 Client 攔截器：JWT 自動注入、401 無感 Token 輪轉、`X-Trace-ID` 鏈路追蹤、`AbortController` 請求防競爭、RFC 7807 錯誤規範化。
  * Design Tokens 與零 Inline Style 禁令：基於 `tokens.css` 與 CSS Modules，**嚴格禁止 JSX 內寫死 `style={{ ... }}`**。
  * 無障礙 Headless 原語：Radix UI Primitives 封裝，內建 Focus Trap 與全鍵盤操作。
  * 大數據虛擬滾動：資料量 > 100 筆強制啟用 `@tanstack/react-virtual`。
  * 容錯防線：`react-error-boundary` 本地兜底與 Suspense 骨架屏；重型組件採用 `next/dynamic` 延遲載入。
  * 圖示與提示：全面使用 `lucide-react`（零手寫 inline SVG）與 `sonner`（全域 Toast 提示）。
- **傳輸層純機器代碼與多語系呈現解析**：
  * API Client 嚴禁構造面向人類的自然語言句子（英文如 `'Export failed'` 亦屬違規），僅能傳遞機器錯誤代碼 (`errorCode`) 與 HTTP 狀態。
  * 錯誤呈現由 UI 層透過 `t('errors.' + errorCode)` 解析多語系；審計原因由 `t('audit.reasons.' + changeReason)` 動態渲染。
- **Feature-Sliced 垂直內聚**：代碼組織於 `src/features/<domain>/<subdomain>/` 內，對外僅透過 `index.ts` 匯出。
- **Code-Gen 純投影隔離**：前端 API Client/Type 由 `contracts/openapi.yaml` 自動生成，手寫邏輯採 Extension Pattern 封裝。
- **真機聯調接軌 (The Handshake Moment)**：
  * 平行開發時以 `NEXT_PUBLIC_ENABLE_MOCK=true` 打 Mock Server。
  * 提 PR 前夕切換 `NEXT_PUBLIC_ENABLE_MOCK=false` 直連 `http://localhost:8080`，進行真實 HTTP 連線與 Playwright E2E 走查。
- **前端型別門禁**：`npx tsc --noEmit` 0 錯誤。
- **深入 AST 死按鈕與全語言零寫死門禁**：`npm test` 執行 `audit-buttons.js`（深入函式體掃描，空函式一律紅燈）與 `validate-i18n.js`（0 缺失且英文無中文洩漏）。
- **AI 輔助兄弟模組橫向差異自檢 (Pre-PR Sibling Horizontal Parity Diff)**：Runner 在完成某一切片實作或重構時，**必須主動審查同家族兄弟切片**（如 `src/components/menus/*`）。若發現任一兄弟切片存在手刻代碼（例如手刻分頁、手刻工具列、手刻彈窗），強制即時進行同構換裝，嚴禁遺留手刻私有實作。

### 6. 人工審查提請與主規格語意錨點回寫 (Step 6: Review Gate & Semantic Anchor DoD)
- **結構化審查報告**：出示代碼變更清單、測試綠燈數據與降級說明。
- **主規格語意錨點回寫 (Mandatory DoD)**：
  * 任何任務合併入庫時，DoD 強制將增量欄位與時序更新回寫至全局主規格庫 (`docs/specs/`) 對應章節錨點（`<!-- SECTION: ... -->`）。
  * 採行局部 Diff 替換，嚴禁全篇覆寫，杜絕規格漂移。
- **三庫串行結案合併**：後端合入 ➔ 前端合入 ➔ Contracts 完成主規格回寫最終合入。
- **踩坑程式化自閉環 (Rules-as-Tests DoD)**：任務中遭遇之缺陷或審查糾正，強制記入 `RETROSPECTIVE.md` 並編寫門禁腳本，回寫規範閉環。
- **Archetype Homomorphic Parity & Sibling Diff Gate (同構原型橫向差異與自適應樣板門禁)**:
  * 嚴格核對主檔畫面是否達成 6 大功能分區 1:1 同構映射（HeaderActions、SearchForm、Toolbar、DataTable、Pagination、Drawer/Modal）。
  * 透過 AI 輔助橫向差異比對 (Sibling Horizontal Diff)，檢查同原型目錄下所有兄弟切片是否統一引用家族共用原語（`<MasterDataPagination>`、`<MasterDataTableToolbar>`、`<MasterDataHeaderActions>`、`<MasterDataDeleteConfirmModal>`）。
  * 元件尺寸與配色全面綁定自適應 Design Tokens（`tokens.layout.*`、`tokens.color.*`），嚴格禁止寫死固定像素（如 `672px`, `768px`）或特定色碼（如 `#374151`），具備多端與主題自適應彈性。
  * 若專案出現第 3 個同質模組，觸發「三振重構法則 (Rule of Three)」，強制先完成共用抽象並收斂同質模組。
  * 核心實體必須繼承 `BaseAuditableEntity`，API 路徑必須符合 `/api/v1/system/*` 命名空間。


### 6. AI 虛擬機執行協議與認知自省 (AI-VM Runtime & Cognitive Self-Audit)
- **AI 虛擬機角色**：
  * Runner Agent 作為跨模型、跨平台的 AI-JVM，嚴格解譯 Task-IR 字節碼，優先調用 `Agent SDK`（後端 `agent-sdk-spring`、前端 `@agent-sdk/react`）原語實現功能。
- **四大架構不變量自主推理 (The 4 Core Invariants)**：
  * 在撰寫代碼與結案前，自動執行思考鏈自檢：
    1. 【文字邊界】：非 Presentation 層嚴禁任何終端自然語言（全數走 `MessageSource` / `next-intl`）。
    2. 【契約真理】：100% 綁定 OpenAPI 契約與 Agent SDK 原語，零手寫私有輪子。
    3. 【兄弟對稱】：遍歷 Sibling Modules，確保原型結構與行為 100% 對稱。
    4. 【確定防禦】：具備樂觀鎖 409、防連點、骨架屏，TDD 斷言真實可觀測性指標。
- **修復原型而非手冊追加規則 (Patch the Archetype, NOT the Rulebook)**：
  * 遭遇通用性缺陷時，直接提 PR 修復 `Agent SDK` 底層原語，使全體模組自動免疫。
