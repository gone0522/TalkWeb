---
name: agent-sdk
description: 企業級 AI 標準函式庫 (Agent SDK) 權威指南與原型原語速查手冊。提供任務字節碼協議 (RFC-001)、4 大通用架構原語 (RFC-003 ~ RFC-006)、12 大領域與人機互動原型 (RFC-002, RFC-007 ~ RFC-017)、規碼對偶律、二十年三層不朽基底與後端 Spring / 前端 React 原語規範。在規劃新任務、進行架構審查或編寫程式碼時啟動。
last_reviewed: 2026-10-14
review_cadence: QUARTERLY
next_review_due: 2027-01-14
governance_status: ACTIVE
---

# Agent SDK Skill - 企業級 AI 原生軟體工程標準庫指南

本技能為所有 AI 代理人（Planner, Runner, Reviewer）在執行任務時使用 **Agent SDK** 原型原語與任務字節碼 (Task-IR) 的核心操作手冊。

---

## 核心願景與百年公理 (Vision & Centennial Axiom)

> **最原始的目的**：將**「人類意圖」**精準無損地轉換為**「機器語言」**，而且機器可以確實無誤、零歧義、零妥協地執行，幾乎 100% 依照人類想要的樣子去落地實作。  
> **百年公理**：將視角拉伸至**一百年（Centennial Horizon: 2026 ~ 2126+）**，原則與代數不變量如同太陽升起一般永恆不變；隨時代更迭的，僅僅是運作的模型與具體的計算機器。

---

## 核心哲學：軟體工廠的標準 JDK 與百年不朽基底

1. **拒絕手刻低效輪子**：凡屬通用性架構設施（Excel 匯出、分頁排版、JPA 審計、樂觀鎖衝突、狀態機、複式記帳、批次匯入、零位移容器、雙模態畫布），**一律強制引用 Agent SDK 原語**，嚴禁業務 Service 或頁面從零手寫。
2. **修復原型而非手冊追加規則 (Patch the Archetype, NOT the Rulebook)**：
   - 遭遇全域性缺陷（如表頭缺少多語系、409 衝突缺少刷新引導、版面抖動），直接提 PR 修復 `Agent SDK` 對應原語。
   - 底層原語修復後，所有引用該 SDK 的業務模組自動免疫，徹底終結打地鼠。
3. **規碼對偶律 (Spec-to-Primitive Duality Law - 嚴禁孤兒規範)**：
   - 任何寫入 Living Specs（如 `UI_SPEC.md`）的設計模式、架構原則與跨學科底座，**嚴禁僅停留於 Markdown 文字宣導**。
   - 每項原則必須 1:1 對偶沉澱為 Agent SDK RFC 契約與 Physical Template Spec，並由 AST / ArchUnit 門禁執法。
4. **常青適性守門人 (Architecture Sentry Invariant)**：
   - 核心不變量 100% 轉化為代碼化 ArchUnit 與 AST 測試，CI 編譯期自動執法，拒絕人工防堵。
5. **二十年可拋棄宿主意識 (Disposable Host Awareness)**：
   - Spring Boot 與 React 僅為當代消耗性宿主（Layer 2）。核心業務只依賴 Layer 0 永恆代數與 Layer 1 Task-IR 字節碼，隨時可由 AI 重新編譯為新世代語言。

---

## 一、 通用架構與韌性基礎原語索引 (Core Architecture & Resilience Primitives)

| 協議編號 | 原語名稱 (Primitive) | 核心規範與宿主實作 | 核心不變量與防線 |
| :--- | :--- | :--- | :--- |
| **[RFC-001](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-001-task-ir-bytecode.schema.yaml)** | **任務字節碼協議** | `task.ir.yaml` Schema / AST Compiler | 機器語言單元、平台無關、攜帶形式化證明義務 |
| **[RFC-003](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-003-dynamic-localized-export.yaml)** | **動態在地化串流匯出** | `GenericExcelExportEngine` / SXSSF | 零內存溢出、動態 MessageSource、表現層文字絕對隔離 |
| **[RFC-004](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-004-concurrency-resilience-guard.yaml)** | **樂觀鎖併發衝突防禦** | `OptimisticLockGuard` / `@Version` | 409 Conflict 攔截、防止覆寫他人編輯、版本欄位物理強制 |
| **[RFC-005](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-005-audit-trail-canonical.yaml)** | **規範代碼審計留痕** | `BaseAuditableEntity` / Spring Auditing | 雙時態追溯、建立人/時間與更新人/時間不可篡改 |
| **[RFC-006](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-006-telemetry-qos-metrics.yaml)** | **QoS 可觀測性度量** | Micrometer Counter / Timer / SLA | 納入 S/M/L QoS 基線、P95 延遲監控、Zero-QPS 日落依據 |

---

## 二、 完整領域與互動原型族系索引 (Enterprise Archetype Taxonomy)

| 原型族系 | 規格 (RFC) | 後端原語 (`agent-sdk-spring`) | 前端原語 (`@agent-sdk/react`) |
| :--- | :--- | :--- | :--- |
| **1. 主檔資料維護** | [RFC-002](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-002-master-data-archetype.yaml) | `GenericExcelExportEngine`<br>`BaseAuditableEntity`<br>`OptimisticLockGuard` | `<MasterDataMaintenanceView>`<br>`<MasterDataPagination>`<br>`<GracefulActionButton>` |
| **2. 狀態機與審批流** | [RFC-007](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-007-workflow-state-machine-archetype.yaml) | `GenericWorkflowStateMachine` | `<WorkflowActionBar>`<br>`<StateTimeline>` |
| **3. 複式財務帳務** | [RFC-008](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-008-financial-ledger-archetype.yaml) | `GenericFinancialLedgerEngine` | `<VoucherBalancedGrid>` |
| **4. 巨量批次處理** | [RFC-009](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-009-batch-ingestion-archetype.yaml) | `GenericBatchIngestionEngine` | `<BatchProgressDrawer>` |
| **5. 常青適性守門人** | [RFC-010](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-010-architecture-fitness-sentry.yaml) | `ArchitectureFitnessTest`<br>`ZeroHardcodedNaturalLanguageTest` | `@agent-sdk/lint:FitnessRules` |
| **6. 平滑演進日落防衛** | [RFC-011](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-011-graceful-evolution-sunset-guard.yaml) | `GracefulSunsetRoute`<br>`GracefulSunsetInterceptor` | `createResilientApiAdapter` |
| **7. 零位移平滑過渡** | [RFC-012](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-012-frontend-zero-cls-smooth-transition.yaml) | *(表現層保全)* | `<SmoothDataTableContainer>` |
| **8. 雙模態檢驗畫布** | [RFC-013](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-013-dual-mode-inspection-canvas.yaml) | *(防誤觸阻尼)* | `<DualModeInspectionCanvas>`<br>`useDirtyStateGuard` |
| **9. 現代底線頁籤** | [RFC-014](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-014-modern-underline-tabs.yaml) | *(導航無關)* | `<UnderlineTabs>` |
| **10. 引用防禦阻尼** | [RFC-015](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-015-reference-defense-damper.yaml) | *(關聯保護)* | `<ReferenceDefenseCard>`<br>`useReferenceGuard` |
| **11. 即時試算預覽** | [RFC-016](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-016-realtime-calculation-preview.yaml) | *(試算端點)* | `<CalculationPreviewCard>` |
| **12. 欄位級異動審計** | [RFC-017](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-017-field-diff-audit-engine.yaml) | `GenericFieldDiffAuditor`<br>`BaseAuditableEntity` | `<AuditHistoryDrawer>` |
| **13. 分散式上下文透傳** | [RFC-018](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-018-distributed-context-propagator.yaml) | `DistributedTracingFilter`<br>`FeignContextInterceptor` | `TraceContextDecorator` |
| **14. 消費者契約守門** | [RFC-019](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-019-consumer-driven-contract-sentry.yaml) | `PactProviderVerifier`<br>`OpenApiDiffSentry` | `PactConsumerTester` |
| **15. RPC 斷路降級** | [RFC-020](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-020-resilience-circuit-breaker.yaml) | `@DistributedCall`<br>`CircuitBreakerAspect` | `LocalResilienceCache` |
| **16. 事務發件箱事件** | [RFC-021](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-021-transactional-outbox-mesh.yaml) | `TransactionalOutboxPublisher`<br>`OutboxMessage` | `IdempotentConsumer` |
| **17. Client SDK 生成** | [RFC-022](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/RFC-022-microservice-client-generator.yaml) | `OpenApiGeneratorCli`<br>`SemanticRelease` | `@reinsurance/contracts-sdk` |

---

## 三、 四大架構不變量自檢 (The 4 Core Invariants)

在編譯 Task-IR 或落庫代碼前，AI 必須在思考鏈中主動驗證以下四大不變量：

1. **【文字與呈現邊界】(Presentation Externalization - RFC-003, RFC-010)**：
   - 核心業務層（Domain/Service/Repo/Client）嚴禁出現終端自然語言字串。
   - 報表表頭使用 `@ExportColumn(key = "...")` + `GenericExcelExportEngine` 動態解析 `MessageSource`。
2. **【契約真理源】(Contract SSOT & Primitives Linking - RFC-001)**：
   - 100% 對齊 `contracts/openapi.yaml`。
   - 優先從 `agent-sdk/catalog.yaml` 鏈結既有原語，輸出結構化 Task-IR。
3. **【兄弟同構對稱】(Homomorphic Sibling Parity - RFC-002, RFC-013, RFC-015)**：
   - 相同原型家族（如 Country, Region, Currency）結構、分區與行為必須高度對稱。
4. **【確定性防禦】(Deterministic Resilience & Oracles - RFC-004, RFC-010, RFC-011)**：
   - 併發更新具備 `@Version` 與 409 Conflict 攔截；未就緒功能顯式 `disabled` 與 Tooltip；Strict TDD 斷言真實可觀測性指標。

---

## 四、 任務編譯流程 (Spec-to-Bytecode Workflow)

1. **輸入**：人類高階規格書 (`tasks/TASK-xxx/TASK-*.md` 或 `.spec.md`)。
2. **檢索**：調閱 `agent-sdk/catalog.yaml` 比對可用原語。
3. **輸出**：產生符合 `agent-sdk/specs/RFC-001-task-ir-bytecode.schema.yaml` 規範之 `task.ir.yaml`。
4. **驗收**：執行 `scripts/audit-specs.py` 與 `ArchitectureFitnessTest`，保證 100% 合規。

---

## 五、 二十年長程演化心法 (20-Year Long-Horizon Guidelines)

1. **雙時態不可變審計 (Bi-Temporal Immutability - RFC-005, RFC-017)**：
   - 金融與合約數據嚴格禁止原位覆寫（In-Place UPDATE/DELETE）。
   - 保留業務生效日 (Valid Time) 與系統記錄日 (Transaction Time)，任何更正透過版本追加與紅字沖銷記錄。
2. **證明義務 (Proof Obligations - RFC-001, RFC-007, RFC-008)**：
   - 關鍵狀態機與會計記帳必須附帶可由 SMT 求解器檢驗之數學不變量，超越範例測試。
3. **系統負熵 (Negative Entropy - RFC-010)**：
   - 遵循三振法則提煉共用原語，以淨代碼消除率為核心指標，模組越演進代碼越精練。
