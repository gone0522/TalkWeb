# Reinsurance Contracts & Living Specifications Repository

> **定位**：全再保險系統之 API 通訊契約 (OpenAPI)、六大活體規格書 (SA, USE_CASE, UI, DBA, SD, QA) 與工程治理標準之**唯一真實真理 (Single Source of Truth)**。

## 目錄說明
- `contracts/`: `openapi.yaml` (前後端通訊唯一標準)
- `specs/`: 全域活體規格
- `tasks/`: 模組任務與驗收清單 (TASK-006 ~ TASK-009)
- `docs/`: 架構標準、ADR (ADR-001 ~ ADR-008) 與治理回顧
- `scripts/`: `audit-specs.py` 規格完整性檢核工具
