$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$MasterCompose = Join-Path $ScriptDir "..\..\docker-compose.yml"
docker compose -f $MasterCompose stop core-service
Write-Host "🛑 後端容器已停止！" -ForegroundColor Red
