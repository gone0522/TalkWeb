$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$MasterCompose = Join-Path $ScriptDir "..\..\docker-compose.yml"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "🚀 [Cockpit Bridge] 正在啟動全端服務 (後端 + 前端 + 微服務)..." -ForegroundColor Green
Write-Host "==========================================================" -ForegroundColor Cyan

docker compose -f $MasterCompose up -d

Write-Host ""
Write-Host "✅ 全端服務已於背景啟動！" -ForegroundColor Green
Write-Host "🌐 前端門戶: http://localhost:3000 (預設直連後端 8080)" -ForegroundColor Yellow
Write-Host "☕ 後端核心: http://localhost:8080" -ForegroundColor Yellow
