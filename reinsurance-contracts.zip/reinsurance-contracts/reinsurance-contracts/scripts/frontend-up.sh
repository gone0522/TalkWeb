#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MASTER_COMPOSE="${SCRIPT_DIR}/../../docker-compose.yml"

if [ "$1" == "--mock" ]; then
    echo "=========================================================="
    echo "🚀 [Frontend Standalone] 啟動前端容器 (模式: MOCK SERVER 4010 埠)..."
    echo "=========================================================="
    NEXT_PUBLIC_API_BASE_URL="http://localhost:4010" API_BASE_URL="http://host.docker.internal:4010" \
      docker compose -f "${MASTER_COMPOSE}" up -d web-portal
    echo ""
    echo "✅ 前端容器已啟動 (Mock 模式)！"
    echo "🌐 前端門戶: http://localhost:3000"
    echo "🎯 連線目標: Mock Server (http://localhost:4010)"
else
    echo "=========================================================="
    echo "🚀 [Frontend Standalone] 啟動前端容器 (模式: 正式後端 API 8080 埠)..."
    echo "=========================================================="
    NEXT_PUBLIC_API_BASE_URL="http://localhost:8080" API_BASE_URL="http://host.docker.internal:8080" \
      docker compose -f "${MASTER_COMPOSE}" up -d web-portal
    echo ""
    echo "✅ 前端容器已啟動 (正式 API 模式)！"
    echo "🌐 前端門戶: http://localhost:3000"
    echo "🎯 連線目標: 正式後端 API (http://localhost:8080)"
    echo "💡 提示: 若需切換為 Mock 模式，請執行: ./scripts/frontend-up.sh --mock"
fi
