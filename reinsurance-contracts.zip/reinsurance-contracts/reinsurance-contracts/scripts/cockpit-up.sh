#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MASTER_COMPOSE="${SCRIPT_DIR}/../../docker-compose.yml"

if [ ! -f "${MASTER_COMPOSE}" ]; then
    echo "❌ 找不到母艦 docker-compose.yml: ${MASTER_COMPOSE}"
    exit 1
fi

echo "=========================================================="
echo "🚀 [Cockpit Bridge] 正在啟動全端服務 (後端 + 前端 + 微服務)..."
echo "=========================================================="
docker compose -f "${MASTER_COMPOSE}" up -d

echo ""
echo "✅ 全端服務已於背景啟動！"
echo "🌐 前端門戶: http://localhost:3000 (預設直連後端 8080)"
echo "☕ 後端核心: http://localhost:8080"
echo "=========================================================="
