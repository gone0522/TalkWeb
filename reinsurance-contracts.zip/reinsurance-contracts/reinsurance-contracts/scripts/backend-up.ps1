$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$MasterCompose = Join-Path $ScriptDir "..\..\docker-compose.yml"

Write-Host "==========================================================" -ForegroundColor Cyan
Write-Host "🚀 [Backend Standalone] 正在單獨啟動後端核心容器 (Spring Boot)..." -ForegroundColor Green
Write-Host "==========================================================" -ForegroundColor Cyan

docker compose -f $MasterCompose up -d core-service

Write-Host "`n✅ 後端核心容器已成功啟動！" -ForegroundColor Green
Write-Host "☕ 後端 API:   http://localhost:8080" -ForegroundColor Yellow
Write-Host "🐞 遠端除錯埠: localhost:5005" -ForegroundColor Yellow
