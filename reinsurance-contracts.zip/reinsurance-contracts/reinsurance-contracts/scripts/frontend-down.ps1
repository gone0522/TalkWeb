$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$MasterCompose = Join-Path $ScriptDir "..\..\docker-compose.yml"
docker compose -f $MasterCompose stop web-portal
Write-Host "🛑 前端容器已停止！" -ForegroundColor Red
