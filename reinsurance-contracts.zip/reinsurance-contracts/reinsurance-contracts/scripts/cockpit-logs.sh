#!/usr/bin/env bash
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MASTER_COMPOSE="${SCRIPT_DIR}/../../docker-compose.yml"
docker compose -f "${MASTER_COMPOSE}" logs -f "$@"
