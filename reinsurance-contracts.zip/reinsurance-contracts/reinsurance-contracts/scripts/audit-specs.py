#!/usr/bin/env python3
import os
import sys
import glob
import yaml
import datetime
import re

REQUIRED_SPECS = [
    ("SA_SPEC.md", "file"),
    ("USE_CASE_SPEC", "dir"),
    ("UI_SPEC", "dir"),
    ("DBA_SPEC", "dir"),
    ("SD_SPEC", "dir"),
    ("QA_SPEC", "dir"),
]

REQUIRED_META_ADRS = [
    "ADR-001-spec-driven-ai-software-factory.md",
    "ADR-002-decoupled-multi-repo-and-evolvable-slices.md",
    "ADR-003-enterprise-quality-resilience-and-audit-baseline.md",
    "ADR-004-agent-sdk-longitudinal-evolution-governance.md",
]

GOVERNANCE_FILES_TO_CHECK = [
    ("docs/adr/ADR-001-spec-driven-ai-software-factory.md", "Meta-ADR 1"),
    ("docs/adr/ADR-002-decoupled-multi-repo-and-evolvable-slices.md", "Meta-ADR 2"),
    ("docs/adr/ADR-003-enterprise-quality-resilience-and-audit-baseline.md", "Meta-ADR 3"),
    ("docs/adr/ADR-004-agent-sdk-longitudinal-evolution-governance.md", "Meta-ADR 4"),
    ("docs/ENGINEERING_STANDARDS.md", "Engineering Standards"),
    (".agents/rules/task_execution.md", "Task Execution Rules"),
    (".agents/skills/task-planner/SKILL.md", "Task Planner Skill"),
    (".agents/skills/task-runner/SKILL.md", "Task Runner Skill"),
    (".agents/skills/agent-sdk/SKILL.md", "Agent SDK Skill"),
    ("docs/specs/SA_SPEC.md", "Master SA Spec"),
    ("docs/specs/DBA_SPEC.md", "Master DBA Spec"),
    ("docs/specs/SD_SPEC.md", "Master SD Spec"),
    ("docs/specs/UI_SPEC.md", "Master UI Spec"),
    ("docs/specs/USE_CASE_SPEC.md", "Master Use Case Spec"),
    ("docs/specs/QA_SPEC.md", "Master QA Spec"),
]

def check_governance_framework(repo_root):
    """
    Validates presence of consolidated Meta-ADRs, Universal Framework, and Reinsurance Domain standards.
    """
    errors = []
    adr_dir = os.path.join(repo_root, "docs", "adr")
    for adr in REQUIRED_META_ADRS:
        if not os.path.isfile(os.path.join(adr_dir, adr)):
            errors.append(f"Missing core Meta-ADR: docs/adr/{adr}")

    framework_file = os.path.join(repo_root, "docs", "framework", "AI_SOFTWARE_FACTORY_BLUEPRINT.md")
    if not os.path.isfile(framework_file):
        errors.append("Missing universal framework: docs/framework/AI_SOFTWARE_FACTORY_BLUEPRINT.md")

    domain_file = os.path.join(repo_root, "docs", "domain", "REINSURANCE_DOMAIN_STANDARDS.md")
    if not os.path.isfile(domain_file):
        errors.append("Missing domain standards: docs/domain/REINSURANCE_DOMAIN_STANDARDS.md")

    return len(errors) == 0, errors

def check_governance_freshness(repo_root):
    """
    Validates that all governance documents, rules, and skills possess active governance_metadata
    and have not expired past their quarterly review due date (Living Architecture Fitness Function).
    """
    today = datetime.date.today()
    errors = []
    warnings = []
    details = []

    for rel_path, label in GOVERNANCE_FILES_TO_CHECK:
        full_path = os.path.join(repo_root, rel_path)
        if not os.path.isfile(full_path):
            errors.append(f"{label} ({rel_path}): File missing!")
            continue

        try:
            with open(full_path, "r", encoding="utf-8") as f:
                content = f.read()
        except Exception as e:
            errors.append(f"{label} ({rel_path}): Read error ({e})")
            continue

        m_due = re.search(r'next_review_due:\s*["\']?(\d{4}-\d{2}-\d{2})["\']?', content)
        m_rev = re.search(r'last_reviewed:\s*["\']?(\d{4}-\d{2}-\d{2})["\']?', content)
        m_status = re.search(r'governance_status:\s*["\']?(\w+)["\']?', content)

        if not m_due or not m_rev:
            errors.append(f"{label} ({rel_path}): Missing governance metadata (last_reviewed / next_review_due)")
            continue

        last_rev = datetime.date.fromisoformat(m_rev.group(1))
        next_due = datetime.date.fromisoformat(m_due.group(1))
        status = m_status.group(1) if m_status else "ACTIVE"

        if status == "DEPRECATED":
            warnings.append(f"{label}: Marked as DEPRECATED (Review archive plan)")
        elif next_due < today:
            errors.append(f"{label} ({rel_path}): Governance expired! next_review_due was {next_due}. Quarterly review required!")
        else:
            days_left = (next_due - today).days
            details.append(f"{label}: Fresh (Reviewed {last_rev}, due in {days_left}d on {next_due})")

    return len(errors) == 0, errors, warnings, details

def check_task_specs(task_dir, repo_root):
    # Check manifests to see if any declares base_spec_ref or lightweight mode
    manifest_files = sorted(glob.glob(os.path.join(task_dir, "manifest*.yaml")))
    is_lightweight = False
    base_spec_refs = []

    for mf in manifest_files:
        try:
            with open(mf, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
                if data and isinstance(data, dict):
                    if data.get("spec_mode") == "lightweight" or data.get("base_spec_ref"):
                        is_lightweight = True
                        ref = data.get("base_spec_ref")
                        if ref:
                            if isinstance(ref, list):
                                base_spec_refs.extend(ref)
                            else:
                                base_spec_refs.append(ref)
        except Exception:
            pass

    if is_lightweight:
        if not base_spec_refs:
            return False, ["Tier-1 lightweight task must specify 'base_spec_ref' in manifest"], None
        errors = []
        for ref in base_spec_refs:
            full_ref_path = os.path.join(repo_root, ref)
            if not os.path.exists(full_ref_path):
                errors.append(f"Referenced base_spec_ref not found: '{ref}'")
        return len(errors) == 0, errors, base_spec_refs

    # Full spec mode
    specs_dir = os.path.join(task_dir, "specs")
    if not os.path.exists(specs_dir):
        return False, ["Missing specs/ directory and no 'base_spec_ref' specified in manifest"], None

    errors = []
    for spec_name, spec_type in REQUIRED_SPECS:
        target_path = os.path.join(specs_dir, spec_name)
        if spec_type == "file":
            if not os.path.isfile(target_path):
                errors.append(f"Missing required file: specs/{spec_name}")
        elif spec_type == "dir":
            if not os.path.isdir(target_path):
                errors.append(f"Missing required directory: specs/{spec_name}/")
            else:
                md_files = glob.glob(os.path.join(target_path, "*.md"))
                if len(md_files) == 0:
                    errors.append(f"Directory specs/{spec_name}/ is empty (must contain at least one .md specification)")

    return len(errors) == 0, errors, None

def check_task_manifests(task_dir):
    """
    Validates machine-executable manifests against Meta-ADR 1, 2, 3 invariants.
    """
    manifest_files = sorted(glob.glob(os.path.join(task_dir, "manifest*.yaml")))
    if not manifest_files:
        return False, ["Missing required machine manifest (manifest.yaml / manifest-*.yaml)"]

    errors = []
    for mf in manifest_files:
        basename = os.path.basename(mf)
        try:
            with open(mf, "r", encoding="utf-8") as f:
                data = yaml.safe_load(f)
        except Exception as e:
            errors.append(f"{basename}: Invalid YAML format ({e})")
            continue

        if not data:
            errors.append(f"{basename}: Empty manifest file")
            continue

        # 1. Manifest version
        if data.get("manifest_version") != "2.0":
            errors.append(f"{basename}: Missing or invalid manifest_version (must be '2.0')")

        # 2. Domain tagging protocol (Meta-ADR 2 §3.2)
        domain = data.get("domain")
        if not domain or not isinstance(domain, dict):
            errors.append(f"{basename}: Missing domain block")
        else:
            if not domain.get("name"):
                errors.append(f"{basename}: 'domain.name' is required")
            if not domain.get("subdomain"):
                errors.append(f"{basename}: 'domain.subdomain' is required")

        # 3. System adaptive tier (Meta-ADR 3 §3.2)
        if not data.get("tier_level"):
            errors.append(f"{basename}: Missing 'tier_level' (S/M/L)")

        # 4. Multi-repo path cleanliness (no stale monorepo prefixes in standalone manifests)
        if "manifest-api" in basename or "manifest-ui" in basename:
            target_files = data.get("target_files", [])
            for tf in target_files:
                if tf.startswith("apps/web-portal/") or tf.startswith("services/core-service/"):
                    errors.append(f"{basename}: Stale path prefix detected in target_files: '{tf}'")

        # 5. Dependency Authorization & Tier-1 BOM Whitelist Validation (Meta-ADR 1 §3.8, Meta-ADR 3 §3.3)
        auth_deps = data.get("authorized_dependencies")
        if auth_deps:
            if not isinstance(auth_deps, dict):
                errors.append(f"{basename}: 'authorized_dependencies' must be a mapping (dict)")
            else:
                maven_deps = auth_deps.get("maven", [])
                if not isinstance(maven_deps, list):
                    errors.append(f"{basename}: 'authorized_dependencies.maven' must be a list")
                else:
                    for md in maven_deps:
                        if not isinstance(md, dict) or not md.get("groupId") or not md.get("artifactId"):
                            errors.append(f"{basename}: Invalid maven dependency entry in authorized_dependencies: {md}")
                npm_deps = auth_deps.get("npm", [])
                if not isinstance(npm_deps, list):
                    errors.append(f"{basename}: 'authorized_dependencies.npm' must be a list")
                else:
                    for nd in npm_deps:
                        if not isinstance(nd, dict) or not nd.get("package"):
                            errors.append(f"{basename}: Invalid npm dependency entry in authorized_dependencies: {nd}")

                # Anti-Phantom Invariant: If new dependencies are authorized, target_files must contain implementation source files
                has_new_deps = len(maven_deps) > 0 or len(npm_deps) > 0
                if has_new_deps:
                    target_files = data.get("target_files", [])
                    source_exts = ('.java', '.ts', '.tsx', '.js', '.jsx', '.py', '.kt')
                    has_source_targets = any(tf.endswith(source_exts) for tf in target_files)
                    if not has_source_targets:
                        errors.append(f"{basename}: Anti-Phantom violation: authorized_dependencies declared without implementation source target_files (only config/build files found)")

        # 6. Branch Naming Standard (ADR-002 §3.1, ENGINEERING_STANDARDS §1.2 & §7.3)
        branch_name = data.get("branch_name")
        if not branch_name:
            errors.append(f"{basename}: Missing required 'branch_name'")
        else:
            if "manifest-api" in basename:
                if not re.match(r"^(feature|fix)/TASK-[A-Za-z0-9_-]+-API$", branch_name):
                    errors.append(f"{basename}: Branch naming violation '{branch_name}'. Backend manifests must strictly follow 'feature/<TASK_ID>-API' or 'fix/<TASK_ID>-API' (ADR-002 §3.1)")
            elif "manifest-ui" in basename:
                if not re.match(r"^(feature|fix)/TASK-[A-Za-z0-9_-]+(?:-[0-9]{3})?-UI$", branch_name):
                    errors.append(f"{basename}: Branch naming violation '{branch_name}'. Frontend manifests must strictly follow 'feature/<TASK_ID>-UI' or 'fix/<TASK_ID>-UI' (ADR-002 §3.1)")
            elif basename == "manifest.yaml":
                if not re.match(r"^(task|feature)/TASK-[A-Za-z0-9_-]+$", branch_name):
                    errors.append(f"{basename}: Branch naming violation '{branch_name}'. Contracts manifest must follow 'task/<TASK_ID>' or 'feature/<TASK_ID>' (ADR-002 §3.2)")

    return len(errors) == 0, errors

def check_task_markdown_purity(task_dir):
    """
    Validates that task markdown specifications remain pure deterministic blueprints (Rule 34 Time-Capsule Invariant).
    Bans runtime maintenance notes (e.g., '維護分支', '修復分支', '覆盤補全', non-standard branch names, or -fix suffixes).
    """
    errors = []
    banned_patterns = [
        (r"[（(]維護分支", "維護分支標註"),
        (r"[（(]修復分支", "修復分支標註"),
        (r"覆盤案.*補全", "覆盤補全標註"),
        (r"臨時分支", "臨時分支標註"),
        (r"補丁分支", "補丁分支標註"),
        (r"task/TASK-[A-Za-z0-9_-]+-(ui|api|fix)", "非標準 task/ 前綴分支引用 (ADR-002 §3.1)"),
        (r"(?:feature|fix)/TASK-[A-Za-z0-9_-]+-fix", "雙重 -fix 冗餘後綴 (Rule 35)"),
    ]
    md_files = glob.glob(os.path.join(task_dir, "**/*.md"), recursive=True)
    for mf in md_files:
        rel_path = os.path.relpath(mf, task_dir)
        try:
            with open(mf, "r", encoding="utf-8") as f:
                text = f.read()
        except Exception:
            continue
        for pat, desc in banned_patterns:
            m = re.search(pat, text)
            if m:
                errors.append(f"{rel_path}: Time-Capsule Spec Pollution: Found '{m.group(0)}' ({desc}). Task specs must remain pure deterministic blueprints (Rule 34).")
    return len(errors) == 0, errors

def check_multi_repo_git_branches(repo_root):
    """
    Validates that local git branches across connected multi-repositories strictly adhere
    to ADR-002 §3.1 & Rule 35 Tri-Repo Branch Taxonomy.
    """
    import subprocess
    errors = []
    repo_rules = {
        "reinsurance-contracts": (
            repo_root,
            r"^(main|dev|master|(task|feature|fix)/TASK-[A-Za-z0-9_-]+|governance/.*)$",
            "Contracts repository branches must follow 'main', 'dev', 'task/<TASK_ID>' or 'governance/*'"
        ),
        "reinsurance-core-service": (
            os.path.abspath(os.path.join(repo_root, "..", "reinsurance-core-service")),
            r"^(main|dev|master|(feature|fix)/TASK-[A-Za-z0-9_-]+-API)$",
            "Backend repository branches must strictly follow 'feature/<TASK_ID>-API' or 'fix/<TASK_ID>-API' (ADR-002 §3.1, Rule 35)"
        ),
        "reinsurance-web-portal": (
            os.path.abspath(os.path.join(repo_root, "..", "reinsurance-web-portal")),
            r"^(main|dev|master|(feature|fix)/TASK-[A-Za-z0-9_-]+(?:-[0-9]{3})?-UI|infra/.*)$",
            "Frontend repository branches must strictly follow 'feature/<TASK_ID>-UI' or 'fix/<TASK_ID>-UI' (ADR-002 §3.1, Rule 35)"
        ),
    }

    for repo_name, (repo_path, pattern, rule_msg) in repo_rules.items():
        if not os.path.exists(repo_path) or not os.path.isdir(os.path.join(repo_path, ".git")):
            continue
        try:
            res = subprocess.run(["git", "branch"], cwd=repo_path, capture_output=True, text=True, check=True)
            branches = [line.strip().replace("* ", "") for line in res.stdout.splitlines() if line.strip()]
            for b in branches:
                if not re.match(pattern, b):
                    errors.append(f"[{repo_name}] Branch naming violation '{b}'. {rule_msg}")
        except Exception:
            pass

    return len(errors) == 0, errors

def check_openapi_domain_tags(repo_root):
    """
    Verifies that all operations in contracts/openapi.yaml are tagged with domain:<name> (Meta-ADR 2 §3.2).
    """
    openapi_path = os.path.join(repo_root, "contracts", "openapi.yaml")
    if not os.path.exists(openapi_path):
        return False, ["Missing contracts/openapi.yaml"]

    try:
        with open(openapi_path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f)
    except Exception as e:
        return False, [f"Failed to parse contracts/openapi.yaml: {e}"]

    paths = data.get("paths", {})
    untagged_ops = []
    http_methods = {"get", "post", "put", "delete", "patch", "options", "head"}

    for path, path_item in paths.items():
        if not isinstance(path_item, dict):
            continue
        for method, operation in path_item.items():
            if method.lower() not in http_methods or not isinstance(operation, dict):
                continue
            tags = operation.get("tags", [])
            has_domain_tag = any(isinstance(t, str) and t.startswith("domain:") for t in tags)
            if not has_domain_tag:
                untagged_ops.append(f"{method.upper()} {path} lacks 'domain:<name>' tag")

    return len(untagged_ops) == 0, untagged_ops

def main():
    repo_root = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
    tasks_root = os.path.join(repo_root, "tasks")
    task_dirs = sorted([d for d in glob.glob(os.path.join(tasks_root, "TASK-*")) if os.path.isdir(d)])

    print("======================================================================")
    print("[audit-specs] Starting Consolidated Architecture & Governance Audit...")
    print(f"[audit-specs] Scanning {len(task_dirs)} task directories in tasks/")
    print("======================================================================")

    all_passed = True
    audited_count = 0

    # Gate 1: Governance Framework, Meta-ADRs & Freshness Audit
    print("─── [Gate 1/5] Governance Baseline & Living Freshness Audit ───")
    gov_passed, gov_errors = check_governance_framework(repo_root)
    fresh_passed, fresh_errors, fresh_warns, fresh_details = check_governance_freshness(repo_root)

    if gov_passed and fresh_passed:
        print("  [PASS] Meta-ADRs (ADR-001 ~ 004), Universal Framework & Domain Standards verified.")
        print(f"  [PASS] Living Governance Freshness: All {len(GOVERNANCE_FILES_TO_CHECK)} core standards/rules/skills within valid review period.")
        for det in fresh_details:
            print(f"         ├── {det}")
    else:
        all_passed = False
        print("  [FAIL] Governance framework or freshness violation!")
        for err in gov_errors + fresh_errors:
            print(f"         └── {err}")

    for warn in fresh_warns:
        print(f"  [WARN] {warn}")

    # Gate 2: OpenAPI Domain Tagging Audit
    print("─── [Gate 2/5] OpenAPI Domain Tagging Audit (Meta-ADR 2) ───")
    openapi_passed, openapi_errors = check_openapi_domain_tags(repo_root)
    if openapi_passed:
        print("  [PASS] contracts/openapi.yaml: All endpoints strictly tagged with 'domain:<name>'.")
    else:
        all_passed = False
        print("  [FAIL] contracts/openapi.yaml: Found untagged operations!")
        for err in openapi_errors[:10]:
            print(f"         └── {err}")

    # Gate 3 & 4: Living Specs & Machine Manifests Audit
    print("─── [Gate 3/5 & 4/5] Living Spec Suite & Normalized Manifest Audits ───")
    for td in task_dirs:
        task_name = os.path.basename(td)
        specs_dir = os.path.join(td, "specs")
        has_manifests = len(glob.glob(os.path.join(td, "manifest*.yaml"))) > 0
        if not os.path.exists(specs_dir) and not has_manifests:
            continue

        audited_count += 1
        specs_passed, specs_errors, inherited_refs = check_task_specs(td, repo_root)
        manifest_passed, manifest_errors = check_task_manifests(td)
        purity_passed, purity_errors = check_task_markdown_purity(td)

        if specs_passed and manifest_passed and purity_passed:
            if inherited_refs:
                ref_str = ", ".join(inherited_refs)
                print(f"  [PASS] {task_name}: Tier-1 Spec Inheritance validated (Inherits: {ref_str}) & normalized manifests validated.")
            else:
                print(f"  [PASS] {task_name}: All 6 spec suites verified & normalized manifests validated.")
        else:
            all_passed = False
            print(f"  [FAIL] {task_name}: Specification or manifest governance violation!")
            for err in specs_errors:
                print(f"         └── [SPEC] {err}")
            for err in manifest_errors:
                print(f"         └── [MANIFEST] {err}")
            for err in purity_errors:
                print(f"         └── [TIME-CAPSULE-PURITY] {err}")

    # Gate 4 Sub-gate: Multi-Repo Git Branch Taxonomy Audit (Rule 35)
    branches_passed, branch_errors = check_multi_repo_git_branches(repo_root)
    if branches_passed:
        print("  [PASS] Multi-Repo Git Branch Taxonomy validated across all connected repositories.")
    else:
        all_passed = False
        print("  [FAIL] Multi-Repo Git Branch Taxonomy violation detected!")
        for err in branch_errors:
            print(f"         └── [BRANCH-TAXONOMY] {err}")

    # Gate 5: Archetype Autonomous Evolution & Anti-Drift Audit
    print("─── [Gate 5/5] Autonomous Archetype & Anti-Drift Architecture Audit ───")
    gate5_passed = True
    gate5_errors = []

    # Check 1: AI_SOFTWARE_FACTORY_BLUEPRINT.md contains Archetype Claiming, Rule of Three & Intent-Realization Parity
    bp_file = os.path.join(repo_root, "docs/framework/AI_SOFTWARE_FACTORY_BLUEPRINT.md")
    if os.path.exists(bp_file):
        with open(bp_file, "r", encoding="utf-8") as f:
            bp_text = f.read()
        if "Archetype Claiming" not in bp_text or "Rule of Three" not in bp_text or "Intent-Realization Parity" not in bp_text:
            gate5_passed = False
            gate5_errors.append("AI_SOFTWARE_FACTORY_BLUEPRINT.md missing Archetype Claiming, Rule of Three or Intent-Realization Parity")
    else:
        gate5_passed = False
        gate5_errors.append("AI_SOFTWARE_FACTORY_BLUEPRINT.md not found")

    # Check 2: ENGINEERING_STANDARDS.md contains BaseAuditableEntity, API Namespace, Master Data, Strict TDD & Anti-Phantom Mandate
    eng_file = os.path.join(repo_root, "docs/ENGINEERING_STANDARDS.md")
    if os.path.exists(eng_file):
        with open(eng_file, "r", encoding="utf-8") as f:
            eng_text = f.read()
        if "BaseAuditableEntity" not in eng_text or "API Namespace" not in eng_text or "Master Data" not in eng_text or "Strict TDD" not in eng_text or "Anti-Phantom" not in eng_text:
            gate5_passed = False
            gate5_errors.append("ENGINEERING_STANDARDS.md missing BaseAuditableEntity, API Namespace, Strict TDD or Anti-Phantom Mandate")
    else:
        gate5_passed = False
        gate5_errors.append("ENGINEERING_STANDARDS.md not found")

    # Check 3: task_execution.md contains Archetype, BaseAuditableEntity, Strict TDD, and Architectural Realization (Rule 20)
    rules_file = os.path.join(repo_root, ".agents/rules/task_execution.md")
    if os.path.exists(rules_file):
        with open(rules_file, "r", encoding="utf-8") as f:
            rules_text = f.read()
        if "Archetype Claiming" not in rules_text or "BaseAuditableEntity" not in rules_text or "嚴格測試驅動開發" not in rules_text or "架構現代化與防幽靈依賴鐵律" not in rules_text:
            gate5_passed = False
            gate5_errors.append(".agents/rules/task_execution.md missing Archetype, Strict TDD, or Architectural Realization Rule")
    else:
        gate5_passed = False
        gate5_errors.append(".agents/rules/task_execution.md not found")

    # Check 4: Agent SDK Standard Library & Bytecode Schema Integrity
    sdk_catalog = os.path.join(repo_root, "agent-sdk/catalog.yaml")
    sdk_rfc001 = os.path.join(repo_root, "agent-sdk/specs/RFC-001-task-ir-bytecode.schema.yaml")
    sdk_rfc002 = os.path.join(repo_root, "agent-sdk/specs/RFC-002-master-data-archetype.yaml")
    sdk_rfc003 = os.path.join(repo_root, "agent-sdk/specs/RFC-003-dynamic-localized-export.yaml")
    sdk_spring_export = os.path.join(repo_root, "agent-sdk/templates/spring/GenericExcelExportEngine.java.spec")
    sdk_react_view = os.path.join(repo_root, "agent-sdk/templates/react/MasterDataMaintenanceView.tsx.spec")

    required_sdk_files = [
        (sdk_catalog, "agent-sdk/catalog.yaml"),
        (os.path.join(repo_root, "agent-sdk/LICENSE"), "agent-sdk/LICENSE"),
        (os.path.join(repo_root, "agent-sdk/ROADMAP.md"), "agent-sdk/ROADMAP.md"),
        (sdk_rfc001, "agent-sdk/specs/RFC-001-task-ir-bytecode.schema.yaml"),
        (sdk_rfc002, "agent-sdk/specs/RFC-002-master-data-archetype.yaml"),
        (sdk_rfc003, "agent-sdk/specs/RFC-003-dynamic-localized-export.yaml"),
        (os.path.join(repo_root, "agent-sdk/specs/RFC-004-concurrency-resilience-guard.yaml"), "agent-sdk/specs/RFC-004-concurrency-resilience-guard.yaml"),
        (os.path.join(repo_root, "agent-sdk/specs/RFC-005-audit-trail-canonical.yaml"), "agent-sdk/specs/RFC-005-audit-trail-canonical.yaml"),
        (os.path.join(repo_root, "agent-sdk/specs/RFC-006-telemetry-qos-metrics.yaml"), "agent-sdk/specs/RFC-006-telemetry-qos-metrics.yaml"),
        (os.path.join(repo_root, "agent-sdk/specs/RFC-007-workflow-state-machine-archetype.yaml"), "agent-sdk/specs/RFC-007-workflow-state-machine-archetype.yaml"),
        (os.path.join(repo_root, "agent-sdk/specs/RFC-008-financial-ledger-archetype.yaml"), "agent-sdk/specs/RFC-008-financial-ledger-archetype.yaml"),
        (os.path.join(repo_root, "agent-sdk/specs/RFC-009-batch-ingestion-archetype.yaml"), "agent-sdk/specs/RFC-009-batch-ingestion-archetype.yaml"),
        (os.path.join(repo_root, "agent-sdk/specs/RFC-010-architecture-fitness-sentry.yaml"), "agent-sdk/specs/RFC-010-architecture-fitness-sentry.yaml"),
        (os.path.join(repo_root, "agent-sdk/specs/RFC-011-graceful-evolution-sunset-guard.yaml"), "agent-sdk/specs/RFC-011-graceful-evolution-sunset-guard.yaml"),
        (os.path.join(repo_root, "agent-sdk/specs/RFC-012-frontend-zero-cls-smooth-transition.yaml"), "agent-sdk/specs/RFC-012-frontend-zero-cls-smooth-transition.yaml"),
        (os.path.join(repo_root, "agent-sdk/templates/spring/GracefulSunsetRoute.java.spec"), "agent-sdk/templates/spring/GracefulSunsetRoute.java.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/spring/GracefulSunsetInterceptor.java.spec"), "agent-sdk/templates/spring/GracefulSunsetInterceptor.java.spec"),
        (sdk_spring_export, "agent-sdk/templates/spring/GenericExcelExportEngine.java.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/spring/BaseAuditableEntity.java.spec"), "agent-sdk/templates/spring/BaseAuditableEntity.java.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/spring/OptimisticLockGuard.java.spec"), "agent-sdk/templates/spring/OptimisticLockGuard.java.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/spring/GenericWorkflowStateMachine.java.spec"), "agent-sdk/templates/spring/GenericWorkflowStateMachine.java.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/spring/GenericFinancialLedgerEngine.java.spec"), "agent-sdk/templates/spring/GenericFinancialLedgerEngine.java.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/spring/GenericBatchIngestionEngine.java.spec"), "agent-sdk/templates/spring/GenericBatchIngestionEngine.java.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/spring/ArchitectureFitnessTest.java.spec"), "agent-sdk/templates/spring/ArchitectureFitnessTest.java.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/spring/ZeroHardcodedNaturalLanguageTest.java.spec"), "agent-sdk/templates/spring/ZeroHardcodedNaturalLanguageTest.java.spec"),
        (sdk_react_view, "agent-sdk/templates/react/MasterDataMaintenanceView.tsx.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/react/MasterDataPagination.tsx.spec"), "agent-sdk/templates/react/MasterDataPagination.tsx.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/react/GracefulActionButton.tsx.spec"), "agent-sdk/templates/react/GracefulActionButton.tsx.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/react/SmoothDataTableContainer.tsx.spec"), "agent-sdk/templates/react/SmoothDataTableContainer.tsx.spec"),
        (os.path.join(repo_root, "agent-sdk/specs/RFC-013-dual-mode-inspection-canvas.yaml"), "agent-sdk/specs/RFC-013-dual-mode-inspection-canvas.yaml"),
        (os.path.join(repo_root, "agent-sdk/specs/RFC-014-modern-underline-tabs.yaml"), "agent-sdk/specs/RFC-014-modern-underline-tabs.yaml"),
        (os.path.join(repo_root, "agent-sdk/specs/RFC-015-reference-defense-damper.yaml"), "agent-sdk/specs/RFC-015-reference-defense-damper.yaml"),
        (os.path.join(repo_root, "agent-sdk/specs/RFC-016-realtime-calculation-preview.yaml"), "agent-sdk/specs/RFC-016-realtime-calculation-preview.yaml"),
        (os.path.join(repo_root, "agent-sdk/specs/RFC-017-field-diff-audit-engine.yaml"), "agent-sdk/specs/RFC-017-field-diff-audit-engine.yaml"),
        (os.path.join(repo_root, "agent-sdk/templates/react/DualModeInspectionCanvas.tsx.spec"), "agent-sdk/templates/react/DualModeInspectionCanvas.tsx.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/react/UnderlineTabs.tsx.spec"), "agent-sdk/templates/react/UnderlineTabs.tsx.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/react/ReferenceDefenseCard.tsx.spec"), "agent-sdk/templates/react/ReferenceDefenseCard.tsx.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/react/CalculationPreviewCard.tsx.spec"), "agent-sdk/templates/react/CalculationPreviewCard.tsx.spec"),
        (os.path.join(repo_root, "agent-sdk/templates/spring/GenericFieldDiffAuditor.java.spec"), "agent-sdk/templates/spring/GenericFieldDiffAuditor.java.spec"),
    ]

    for fpath, flabel in required_sdk_files:
        if not os.path.exists(fpath):
            gate5_passed = False
            gate5_errors.append(f"Agent SDK core asset missing: {flabel}")
        elif fpath.endswith(('.yaml', '.yml')):
            try:
                with open(fpath, "r", encoding="utf-8") as yf:
                    ydata = yaml.safe_load(yf)
                if not ydata:
                    gate5_passed = False
                    gate5_errors.append(f"Agent SDK asset is empty: {flabel}")
            except Exception as ye:
                gate5_passed = False
                gate5_errors.append(f"Agent SDK asset YAML parse error in {flabel}: {ye}")

    # Check 5: Cross-Document Spec-to-Catalog-to-Readme Synchronization Audit
    specs_dir = os.path.join(repo_root, "agent-sdk/specs")
    readme_path = os.path.join(repo_root, "agent-sdk/README.md")
    skill_path = os.path.join(repo_root, ".agents/skills/agent-sdk/SKILL.md")
    catalog_path = os.path.join(repo_root, "agent-sdk/catalog.yaml")

    with open(readme_path, "r", encoding="utf-8") as rf:
        readme_txt = rf.read()
    with open(skill_path, "r", encoding="utf-8") as sf:
        skill_txt = sf.read()
    with open(catalog_path, "r", encoding="utf-8") as cf:
        catalog_txt = cf.read()

    # Find all RFC-xxx in specs/
    for fname in os.listdir(specs_dir):
        m = re.match(r"(RFC-\d{3})", fname)
        if m:
            rfc_id = m.group(1)
            # Verify presence in catalog.yaml
            if rfc_id not in catalog_txt:
                gate5_passed = False
                gate5_errors.append(f"Gate 5 Coherence Failure: {rfc_id} is missing from agent-sdk/catalog.yaml")
            # Verify presence in README.md
            if rfc_id not in readme_txt:
                gate5_passed = False
                gate5_errors.append(f"Gate 5 Coherence Failure: {rfc_id} is missing from agent-sdk/README.md")
            # Verify presence in SKILL.md
            if rfc_id not in skill_txt:
                gate5_passed = False
                gate5_errors.append(f"Gate 5 Coherence Failure: {rfc_id} is missing from .agents/skills/agent-sdk/SKILL.md")

    if gate5_passed:
        print("  [PASS] Autonomous Archetype, Cross-Doc Coherence & Anti-Drift Architecture standards verified across Framework, Standards & Rules.")
    else:
        all_passed = False
        print("  [FAIL] Autonomous Archetype & Anti-Drift Architecture violation!")
        for err in gate5_errors:
            print(f"         └── [ANTI-DRIFT] {err}")
    print("======================================================================")
    if all_passed and audited_count > 0:
        print(f"✅ [audit-specs] 100% Passed! All {audited_count} modular tasks & living governance assets comply with Meta-ADRs.")
        print("======================================================================")
        sys.exit(0)
    elif audited_count == 0:
        print("⚠️ [audit-specs] No modular task specs found to audit.")
        sys.exit(0)
    else:
        print(f"❌ [audit-specs] FAILED! Spec incompleteness detected. Please review violations above.")
        print("======================================================================")
        sys.exit(1)

if __name__ == "__main__":
    main()
