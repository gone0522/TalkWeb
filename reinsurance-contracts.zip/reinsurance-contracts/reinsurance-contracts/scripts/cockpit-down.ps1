$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$MasterCompose = Join-Path $ScriptDir "..\..\docker-compose.yml"
docker compose -f $MasterCompose down
Write-Host "🛑 全端服務已停止！" -ForegroundColor Red
