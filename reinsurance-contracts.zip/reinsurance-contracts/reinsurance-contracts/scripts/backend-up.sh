#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MASTER_COMPOSE="${SCRIPT_DIR}/../../docker-compose.yml"

echo "=========================================================="
echo "🚀 [Backend Standalone] 正在單獨啟動後端核心容器 (Spring Boot)..."
echo "=========================================================="
docker compose -f "${MASTER_COMPOSE}" up -d core-service

echo ""
echo "✅ 後端核心容器已成功啟動！"
echo "☕ 後端 API:   http://localhost:8080"
echo "🐞 遠端除錯埠: localhost:5005"
echo "🐘 資料庫連線: localhost:5432 (app_db)"
