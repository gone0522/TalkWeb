#!/usr/bin/env bash
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MASTER_COMPOSE="${SCRIPT_DIR}/../../docker-compose.yml"
docker compose -f "${MASTER_COMPOSE}" stop web-portal
echo "🛑 前端容器已停止！"
