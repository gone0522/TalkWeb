param(
    [switch]$Mock
)
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$MasterCompose = Join-Path $ScriptDir "..\..\docker-compose.yml"

if ($Mock) {
    Write-Host "==========================================================" -ForegroundColor Cyan
    Write-Host "🚀 [Frontend Standalone] 啟動前端容器 (模式: MOCK SERVER 4010 埠)..." -ForegroundColor Yellow
    Write-Host "==========================================================" -ForegroundColor Cyan
    $env:NEXT_PUBLIC_API_BASE_URL = "http://localhost:4010"
    $env:API_BASE_URL = "http://host.docker.internal:4010"
    docker compose -f $MasterCompose up -d web-portal
    Write-Host "`n✅ 前端容器已啟動 (Mock 模式)！目標: http://localhost:4010" -ForegroundColor Green
} else {
    Write-Host "==========================================================" -ForegroundColor Cyan
    Write-Host "🚀 [Frontend Standalone] 啟動前端容器 (模式: 正式後端 API 8080 埠)..." -ForegroundColor Green
    Write-Host "==========================================================" -ForegroundColor Cyan
    $env:NEXT_PUBLIC_API_BASE_URL = "http://localhost:8080"
    $env:API_BASE_URL = "http://host.docker.internal:8080"
    docker compose -f $MasterCompose up -d web-portal
    Write-Host "`n✅ 前端容器已啟動 (正式 API 模式)！目標: http://localhost:8080" -ForegroundColor Green
    Write-Host "💡 提示: 若需切換為 Mock 模式，請執行: .\scripts\frontend-up.ps1 -Mock" -ForegroundColor Gray
}
