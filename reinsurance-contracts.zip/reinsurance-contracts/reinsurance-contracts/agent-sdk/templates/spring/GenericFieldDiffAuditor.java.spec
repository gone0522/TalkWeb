package com.reinsurance.core.audit;

import java.lang.reflect.Field;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * GenericFieldDiffAuditor (RFC-017)
 * Automated reflective field difference comparator for bi-temporal immutable audit logging.
 */
public class GenericFieldDiffAuditor {

    public record DiffEntry(
        String fieldName,
        String beforeValue,
        String afterValue,
        String changeReason,
        String changedBy,
        Instant changedAt
    ) {}

    public static <T> List<DiffEntry> computeDiff(T previous, T current, String reason, String operator) {
        List<DiffEntry> diffs = new ArrayList<>();
        if (previous == null || current == null) {
            return diffs;
        }

        Class<?> clazz = current.getClass();
        for (Field field : clazz.getDeclaredFields()) {
            if (java.lang.reflect.Modifier.isStatic(field.getModifiers())) {
                continue;
            }
            field.setAccessible(true);
            try {
                Object valPrev = field.get(previous);
                Object valCurr = field.get(current);

                if (!Objects.equals(valPrev, valCurr)) {
                    diffs.add(new DiffEntry(
                        field.getName(),
                        valPrev != null ? valPrev.toString() : null,
                        valCurr != null ? valCurr.toString() : null,
                        reason != null ? reason : "基本資料維護更新",
                        operator != null ? operator : "SYSTEM",
                        Instant.now()
                    ));
                }
            } catch (IllegalAccessException e) {
                // Ignore inaccessible fields
            }
        }
        return diffs;
    }
}
