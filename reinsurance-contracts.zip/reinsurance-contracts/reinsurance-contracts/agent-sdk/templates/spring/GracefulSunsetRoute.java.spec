package com.agentsdk.evolution;

import java.lang.annotation.*;

/**
 * Agent SDK: 平滑日落路由外觀註解 (RFC-011)
 * 宣告端點之向下相容歷史路徑、日落日期與繼任規範端點。
 * 配合 GracefulSunsetInterceptor 自動注入 RFC 8594 標頭與 Micrometer QPS 計數器。
 */
@Target({ElementType.METHOD, ElementType.TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Documented
public @interface GracefulSunsetRoute {

    /**
     * 支援向下相容之歷史舊路徑清單 (例如 {"/api/v1/currencies"})
     */
    String[] legacyPaths();

    /**
     * 繼任之新標準 API 路徑 (例如 "/api/v1/system/currencies")
     */
    String successorPath();

    /**
     * RFC 8594 宣告之最終移除日期 (ISO-8601 或 HTTP Date)
     */
    String sunsetDate();

    /**
     * Micrometer 遙測計數器名稱
     */
    String metricName() default "api.deprecated.requests";
}
