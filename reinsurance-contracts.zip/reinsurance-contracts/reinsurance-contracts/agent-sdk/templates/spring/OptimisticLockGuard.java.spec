package com.agentsdk.resilience;

import org.springframework.dao.OptimisticLockingFailureException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ProblemDetail;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.net.URI;
import java.time.Instant;

/**
 * Agent SDK: 樂觀鎖衝突統一攔截器 (OptimisticLockGuard)
 * 自動將 JPA OptimisticLockingFailureException 映射為 RFC 7807 409 Conflict，
 * 並輸出標準機器錯誤代碼與語意型 Detail，引導客戶端刷新狀態。
 */
@RestControllerAdvice
public class OptimisticLockGuard {

    @ExceptionHandler(OptimisticLockingFailureException.class)
    public ResponseEntity<ProblemDetail> handleOptimisticLockConflict(OptimisticLockingFailureException ex) {
        ProblemDetail problem = ProblemDetail.forStatusAndDetail(
                HttpStatus.CONFLICT,
                "The requested resource was modified concurrently by another transaction. Please reload the latest version and retry."
        );
        problem.setType(URI.create("https://api.agentsdk.com/errors/optimistic-lock-conflict"));
        problem.setTitle("Optimistic Locking Conflict");
        problem.setProperty("errorCode", "OPTIMISTIC_LOCKING_FAILURE");
        problem.setProperty("timestamp", Instant.now().toString());

        return ResponseEntity.status(HttpStatus.CONFLICT).body(problem);
    }
}
