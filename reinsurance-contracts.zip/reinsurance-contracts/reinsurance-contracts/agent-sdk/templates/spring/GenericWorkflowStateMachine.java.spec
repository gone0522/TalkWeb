package com.agentsdk.workflow;

import org.springframework.transaction.annotation.Transactional;

import java.util.Collections;
import java.util.Map;
import java.util.Set;

/**
 * Agent SDK Generic State Machine & Workflow Engine (RFC-007)
 * Enforces deterministic state transitions and prevents ad-hoc if-else assignment.
 *
 * @param <S> State enum type
 * @param <E> Event / Action enum type
 * @param <C> Context DTO type
 */
public abstract class GenericWorkflowStateMachine<S extends Enum<S>, E extends Enum<E>, C> {

    private final Map<S, Map<E, S>> transitionMatrix;
    private final Map<S, Map<E, Set<String>>> rolePermissions;

    protected GenericWorkflowStateMachine(
            Map<S, Map<E, S>> transitionMatrix,
            Map<S, Map<E, Set<String>>> rolePermissions) {
        this.transitionMatrix = Collections.unmodifiableMap(transitionMatrix);
        this.rolePermissions = Collections.unmodifiableMap(rolePermissions);
    }

    /**
     * Executes state transition with validation, permission check, and optimistic lock verification.
     */
    @Transactional
    public S executeTransition(S currentState, E event, C context, Set<String> operatorRoles) {
        // 1. Validate transition existence
        Map<E, S> allowedEvents = transitionMatrix.get(currentState);
        if (allowedEvents == null || !allowedEvents.containsKey(event)) {
            throw new IllegalStateException(
                String.format("Invalid state transition from [%s] via event [%s]", currentState, event));
        }

        // 2. Validate role permission
        Map<E, Set<String>> permissions = rolePermissions.get(currentState);
        if (permissions != null && permissions.containsKey(event)) {
            Set<String> requiredRoles = permissions.get(event);
            if (Collections.disjoint(requiredRoles, operatorRoles)) {
                throw new SecurityException(
                    String.format("Operator roles %s lack permission for transition [%s -> %s]",
                        operatorRoles, currentState, event));
            }
        }

        S nextState = allowedEvents.get(event);
        onTransition(currentState, event, nextState, context);
        return nextState;
    }

    /**
     * Hook invoked within the same transaction to record audit trails or publish outbox events.
     */
    protected abstract void onTransition(S from, E event, S to, C context);
}
