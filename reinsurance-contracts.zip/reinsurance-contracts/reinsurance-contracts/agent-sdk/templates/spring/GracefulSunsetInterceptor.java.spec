package com.agentsdk.evolution;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;
import io.micrometer.core.instrument.MeterRegistry;

/**
 * Agent SDK: 平滑日落攔截器 (RFC-011)
 * 自動識別舊路由請求，注入 RFC 8594 標準標頭，並遞增 Micrometer 遙測指標。
 */
public class GracefulSunsetInterceptor implements HandlerInterceptor {

    private final MeterRegistry meterRegistry;

    public GracefulSunsetInterceptor(MeterRegistry meterRegistry) {
        this.meterRegistry = meterRegistry;
    }

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) {
        if (handler instanceof HandlerMethod handlerMethod) {
            GracefulSunsetRoute route = handlerMethod.getMethodAnnotation(GracefulSunsetRoute.class);
            if (route != null) {
                String requestUri = request.getRequestURI();
                for (String legacyPath : route.legacyPaths()) {
                    if (requestUri.equals(legacyPath)) {
                        // 1. 注入 RFC 8594 日落與廢棄標頭
                        response.setHeader("Deprecation", "true");
                        response.setHeader("Sunset", route.sunsetDate());
                        response.setHeader("Link", "<" + route.successorPath() + ">; rel=\"successor-version\"");

                        // 2. 遞增 Micrometer 廢棄調用遙測計數器
                        if (meterRegistry != null) {
                            meterRegistry.counter(route.metricName(),
                                    "path", legacyPath,
                                    "successor", route.successorPath()
                            ).increment();
                        }
                        break;
                    }
                }
            }
        }
        return true;
    }
}
