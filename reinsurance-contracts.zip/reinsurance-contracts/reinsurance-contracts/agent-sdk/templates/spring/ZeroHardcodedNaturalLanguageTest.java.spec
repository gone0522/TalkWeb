package com.agentsdk.governance;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Stream;

import static org.assertj.core.api.Assertions.assertThat;

/**
 * Agent SDK: 零自然語言硬編碼與多語系物理阻斷守門人 (RFC-003 / RFC-010 Presentation Externalization Sentry)
 * 語言無關 (Language-Agnostic): 法文、日文、德文、中文、甚至英文自然語言句子，一律依語法結構、字元級編碼與例外語意規則物理阻斷。
 */
@DisplayName("架構防衛: 語言無關的零硬編碼與多語系模板物理阻斷審計")
public class ZeroHardcodedNaturalLanguageTest {

    // 匹配 Bean Validation 的 message 屬性: message = "..."
    private static final Pattern VALIDATION_MESSAGE_PATTERN = Pattern.compile("message\\s*=\\s*\"([^\"]+)\"");

    // 合法 i18n 機器鍵值模板格式: 必須為 {a.b.c} 結構，嚴禁包含任何自然語言單詞或空格
    private static final Pattern VALID_I18N_KEY_TEMPLATE = Pattern.compile("^\\{[a-zA-Z0-9_.-]+\\}$");

    // 匹配 new *Exception("...") 或 throw new *Exception("...")
    private static final Pattern EXCEPTION_WITH_STRING_LITERAL = Pattern.compile("new\\s+([A-Za-z0-9_]*Exception)\\s*\\(\\s*\"([^\"]+)\"");

    @Test
    @DisplayName("鐵律 1: 所有 Bean Validation 註解之 message 屬性必須嚴格為 i18n 模板鍵值 (如 {validation.*})，嚴禁任何自然語言 (英文、法文、日文、中文)")
    void validationMessages_MustBeStrictlyI18nKeyTemplates() throws IOException {
        Path srcMainJava = Paths.get("src/main/java");
        if (!Files.exists(srcMainJava)) {
            return;
        }
        List<String> violations = new ArrayList<>();

        try (Stream<Path> stream = Files.walk(srcMainJava)) {
            stream.filter(Files::isRegularFile)
                    .filter(p -> p.toString().endsWith(".java"))
                    .forEach(file -> {
                        try {
                            List<String> lines = Files.readAllLines(file);
                            for (int i = 0; i < lines.size(); i++) {
                                String line = lines.get(i).trim();
                                if (line.startsWith("//") || line.startsWith("/*") || line.startsWith("*")) {
                                    continue;
                                }
                                Matcher matcher = VALIDATION_MESSAGE_PATTERN.matcher(line);
                                while (matcher.find()) {
                                    String messageValue = matcher.group(1);
                                    if (!VALID_I18N_KEY_TEMPLATE.matcher(messageValue).matches()) {
                                        violations.add(String.format("%s:%d -> message = \"%s\" (未以 {key} 模板外部化)",
                                                file, i + 1, messageValue));
                                    }
                                }
                            }
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    });
        }

        assertThat(violations)
                .withFailMessage("發現非機器模板鍵值之硬編碼驗證訊息 (違反 RFC-003 / RFC-010):\n" + String.join("\n", violations))
                .isEmpty();
    }

    @Test
    @DisplayName("鐵律 2: 業務源碼行嚴禁包含非 ASCII 字元 (徹底阻斷中、法、日、韓、德等任何未經 ResourceBundle 外部化的自然語言)")
    void sourceCode_MustNotContainNonAsciiCharacters() throws IOException {
        Path srcMainJava = Paths.get("src/main/java");
        if (!Files.exists(srcMainJava)) {
            return;
        }
        List<String> violations = new ArrayList<>();

        try (Stream<Path> stream = Files.walk(srcMainJava)) {
            stream.filter(Files::isRegularFile)
                    .filter(p -> p.toString().endsWith(".java"))
                    .forEach(file -> {
                        String filename = file.toString();
                        // 僅排除資料庫 Seeder 與不可變之常數定義
                        if (filename.contains("DataSeeder") || filename.contains("Seeder")) {
                            return;
                        }
                        try {
                            List<String> lines = Files.readAllLines(file);
                            for (int i = 0; i < lines.size(); i++) {
                                String line = lines.get(i).trim();
                                if (line.startsWith("//") || line.startsWith("/*") || line.startsWith("*")) {
                                    continue;
                                }
                                boolean hasNonAscii = line.chars().anyMatch(c -> c > 127);
                                if (hasNonAscii) {
                                    violations.add(String.format("%s:%d -> %s", file, i + 1, line));
                                }
                            }
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    });
        }

        assertThat(violations)
                .withFailMessage("發現未外部化至 properties 之非 ASCII 字串/文字 (中/法/日/德等自然語言):\n" + String.join("\n", violations))
                .isEmpty();
    }

    @Test
    @DisplayName("鐵律 3: 例外類別構造函式嚴禁傳入帶空格之自然語言句子 (徹底阻斷中、英、法、日等任何寫死之人類語言句子)")
    void exceptionConstructors_MustNotContainSpaceSeparatedNaturalLanguageSentences() throws IOException {
        Path srcMainJava = Paths.get("src/main/java");
        if (!Files.exists(srcMainJava)) {
            return;
        }
        List<String> violations = new ArrayList<>();

        try (Stream<Path> stream = Files.walk(srcMainJava)) {
            stream.filter(Files::isRegularFile)
                    .filter(p -> p.toString().endsWith(".java"))
                    .forEach(file -> {
                        try {
                            List<String> lines = Files.readAllLines(file);
                            for (int i = 0; i < lines.size(); i++) {
                                String line = lines.get(i).trim();
                                if (line.startsWith("//") || line.startsWith("/*") || line.startsWith("*")) {
                                    continue;
                                }
                                Matcher matcher = EXCEPTION_WITH_STRING_LITERAL.matcher(line);
                                while (matcher.find()) {
                                    String exceptionClass = matcher.group(1);
                                    String rawArg = matcher.group(2);
                                    // 若傳入字串包含空格，代表是硬編碼自然語言句子 (如 "Currency not found with id: ")
                                    if (rawArg.contains(" ")) {
                                        violations.add(String.format("%s:%d -> new %s(\"%s\") (嚴禁傳入帶空格自然語言句子，必須使用 ErrorCode 或標準機器鍵值)",
                                                file, i + 1, exceptionClass, rawArg));
                                    }
                                }
                            }
                        } catch (IOException e) {
                            throw new RuntimeException(e);
                        }
                    });
        }

        assertThat(violations)
                .withFailMessage("發現例外類別硬編碼自然語言句子 (違反 RFC-003 / RFC-010):\n" + String.join("\n", violations))
                .isEmpty();
    }
}
