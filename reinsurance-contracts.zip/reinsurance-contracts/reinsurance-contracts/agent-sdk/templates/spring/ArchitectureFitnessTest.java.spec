package com.agentsdk.governance;

import com.tngtech.archunit.core.domain.JavaClass;
import com.tngtech.archunit.core.domain.JavaField;
import com.tngtech.archunit.core.domain.JavaMethod;
import com.tngtech.archunit.core.importer.ImportOption;
import com.tngtech.archunit.junit.AnalyzeClasses;
import com.tngtech.archunit.junit.ArchTest;
import com.tngtech.archunit.lang.ArchCondition;
import com.tngtech.archunit.lang.ArchRule;
import com.tngtech.archunit.lang.ConditionEvents;
import com.tngtech.archunit.lang.SimpleConditionEvent;
import jakarta.persistence.Entity;
import jakarta.persistence.Version;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;

import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.classes;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.fields;
import static com.tngtech.archunit.lang.syntax.ArchRuleDefinition.noClasses;

/**
 * Agent SDK: 常青架構適性守門人 (Architecture Fitness Sentry - RFC-010)
 * 100% 代碼化執法 Meta-ADR 與四大核心不變量，物理阻斷任何架構退化或語意漂移。
 */
@AnalyzeClasses(packages = "com.company.project", importOptions = ImportOption.DoNotIncludeTests.class)
public class ArchitectureFitnessTest {

    // INVARIANT-1: 表現層文字隔離 (Services 與 Domain 嚴禁定義靜態 UI 表頭 String[] 字串)
    @ArchTest
    public static final ArchRule services_must_not_contain_raw_ui_header_arrays =
            classes().that().resideInAnyPackage("..service..", "..domain..")
                    .should(new ArchCondition<JavaClass>("not declare hardcoded UI header arrays (use GenericExcelExportEngine)") {
                        @Override
                        public void check(JavaClass javaClass, ConditionEvents events) {
                            for (JavaField field : javaClass.getAllFields()) {
                                if (field.isStatic() && field.getRawType().equivalentTo(String[].class)) {
                                    if (field.getName().toUpperCase().contains("HEADER")) {
                                        events.add(SimpleConditionEvent.violated(field,
                                                "Field " + field.getFullName() + " contains hardcoded UI headers! Must route through MessageSource."));
                                    }
                                }
                            }
                        }
                    });

    // INVARIANT-2: 控制器不可直接跨層存取 Repository (嚴格分層架構)
    @ArchTest
    public static final ArchRule controllers_must_not_access_repositories_directly =
            noClasses().that().areAnnotatedWith(RestController.class)
                    .or().areAnnotatedWith(Controller.class)
                    .should().dependOnClassesThat().resideInAPackage("..repository..");

    // INVARIANT-2: 控制器不可跨控制器相互呼叫
    @ArchTest
    public static final ArchRule controllers_must_not_cross_depend =
            noClasses().that().areAnnotatedWith(RestController.class)
                    .should().dependOnClassesThat().areAnnotatedWith(RestController.class);

    // INVARIANT-2: 服務層不可依賴 Servlet / Web 容器 API (保持領域無宿主純粹性)
    @ArchTest
    public static final ArchRule services_must_be_web_agnostic =
            noClasses().that().areAnnotatedWith(Service.class)
                    .should().dependOnClassesThat().resideInAPackage("jakarta.servlet..");

    // INVARIANT-4: 樂觀鎖併發防衛 (所有可變實體必須宣告 @Version 欄位)
    @ArchTest
    public static final ArchRule entities_must_have_version_field =
            classes().that().resideInAPackage("..domain..")
                    .and().areAnnotatedWith(Entity.class)
                    .and().haveSimpleNameNotEndingWith("AuditLog")
                    .and().haveSimpleNameNotEndingWith("View")
                    .should(new ArchCondition<JavaClass>("declare an @Version field for optimistic concurrency control") {
                        @Override
                        public void check(JavaClass javaClass, ConditionEvents events) {
                            boolean hasVersion = javaClass.getAllFields().stream()
                                    .anyMatch(field -> field.isAnnotatedWith(Version.class));
                            if (!hasVersion) {
                                events.add(SimpleConditionEvent.violated(javaClass,
                                        "Entity " + javaClass.getName() + " lacks @Version field for optimistic locking!"));
                            }
                        }
                    });

    // RFC-008: 零浮點數財務不變量 (貨幣金額與費率必須為 BigDecimal)
    @ArchTest
    public static final ArchRule financial_amounts_must_use_big_decimal =
            fields().that().haveNameMatching(".*Amount|.*Rate|.*Balance|.*Premium")
                    .should().haveRawType(BigDecimal.class);

    // 百年公理: 雙時態帳務與審計實體嚴禁破壞性刪除方法
    @ArchTest
    public static final ArchRule immutable_entities_must_not_have_delete_methods =
            classes().that().haveSimpleNameEndingWith("Voucher")
                    .or().haveSimpleNameEndingWith("AuditLog")
                    .should(new ArchCondition<JavaClass>("not declare public delete or remove methods (append-only ledger)") {
                        @Override
                        public void check(JavaClass javaClass, ConditionEvents events) {
                            for (JavaMethod method : javaClass.getMethods()) {
                                if (method.getName().startsWith("delete") || method.getName().startsWith("remove")) {
                                    events.add(SimpleConditionEvent.violated(method,
                                            "Destructive delete method " + method.getFullName() + " violates Append-Only Bi-Temporal Invariant!"));
                                }
                            }
                        }
                    });
}
