package com.agentsdk.export;

import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;
import org.springframework.context.MessageSource;
import org.springframework.lang.Nullable;
import org.springframework.stereotype.Component;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.*;

/**
 * Agent SDK: 通用動態在地化串流 Excel 匯出引擎 (GenericExcelExportEngine)
 * 徹底終結業務 Service 內部寫死 String[] EXCEL_HEADERS 的打地鼠反模式。
 */
@Component
public class GenericExcelExportEngine {

    private final MessageSource messageSource;

    public GenericExcelExportEngine(MessageSource messageSource) {
        this.messageSource = messageSource;
    }

    /**
     * 依據 @ExportColumn 註解與當前請求語系，動態生成 Excel 二進制資料
     */
    public <T> byte[] exportToExcel(List<T> data, Class<T> clazz, Locale locale) throws IOException {
        List<ExportColumnMeta> columns = resolveColumns(clazz, locale);

        try (SXSSFWorkbook workbook = new SXSSFWorkbook(500);
             ByteArrayOutputStream out = new ByteArrayOutputStream()) {

            Sheet sheet = workbook.createSheet("Sheet1");
            createHeaderRow(workbook, sheet, columns);
            createDataRows(workbook, sheet, columns, data);

            workbook.write(out);
            return out.toByteArray();
        }
    }

    private <T> List<ExportColumnMeta> resolveColumns(Class<T> clazz, Locale locale) {
        List<ExportColumnMeta> list = new ArrayList<>();
        for (Field field : clazz.getDeclaredFields()) {
            ExportColumn ann = field.getAnnotation(ExportColumn.class);
            if (ann != null) {
                field.setAccessible(true);
                // 100% 透過 MessageSource 解析多語系表頭，嚴禁硬編碼任何語言文字
                String localizedHeader = messageSource.getMessage(ann.key(), null, ann.key(), locale);
                list.add(new ExportColumnMeta(ann.order(), localizedHeader, ann.width(), field));
            }
        }
        list.sort(Comparator.comparingInt(ExportColumnMeta::order));
        return list;
    }

    private void createHeaderRow(Workbook wb, Sheet sheet, List<ExportColumnMeta> columns) {
        Row row = sheet.createRow(0);
        CellStyle style = createHeaderStyle(wb);
        for (int i = 0; i < columns.size(); i++) {
            Cell cell = row.createCell(i);
            cell.setCellValue(columns.get(i).header());
            cell.setCellStyle(style);
            sheet.setColumnWidth(i, columns.get(i).width() * 256);
        }
    }

    private <T> void createDataRows(Workbook wb, Sheet sheet, List<ExportColumnMeta> columns, List<T> data) {
        int rowIdx = 1;
        for (T item : data) {
            Row row = sheet.createRow(rowIdx++);
            for (int colIdx = 0; colIdx < columns.size(); colIdx++) {
                Cell cell = row.createCell(colIdx);
                try {
                    Object val = columns.get(colIdx).field().get(item);
                    cell.setCellValue(val != null ? val.toString() : "");
                } catch (IllegalAccessException e) {
                    cell.setCellValue("");
                }
            }
        }
    }

    private CellStyle createHeaderStyle(Workbook wb) {
        CellStyle style = wb.createCellStyle();
        Font font = wb.createFont();
        font.setBold(true);
        style.setFont(font);
        style.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        style.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        return style;
    }

    public record ExportColumnMeta(int order, String header, int width, Field field) {}
}
