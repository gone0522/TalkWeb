package com.agentsdk.finance;

import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;

/**
 * Agent SDK Double-Entry Financial Ledger Engine (RFC-008)
 * Enforces Zero-Float arithmetic, Banker's Rounding (HALF_EVEN), and debit-credit balance equation.
 */
public class GenericFinancialLedgerEngine {

    public static final RoundingMode STANDARD_ROUNDING = RoundingMode.HALF_EVEN;
    public static final int STANDARD_SCALE = 4;

    public record LedgerLine(
        String accountCode,
        BigDecimal debitAmount,
        BigDecimal creditAmount,
        String currencyCode
    ) {
        public LedgerLine {
            if (debitAmount == null || creditAmount == null) {
                throw new IllegalArgumentException("Amounts cannot be null");
            }
            if (debitAmount.signum() < 0 || creditAmount.signum() < 0) {
                throw new IllegalArgumentException("Negative ledger lines prohibited; use reversal vouchers");
            }
        }
    }

    /**
     * Validates and posts a balanced journal voucher.
     */
    @Transactional
    public void postJournalVoucher(String voucherId, List<LedgerLine> entries) {
        if (entries == null || entries.isEmpty()) {
            throw new IllegalArgumentException("Voucher must contain at least one debit and credit line");
        }

        BigDecimal totalDebits = entries.stream()
                .map(LedgerLine::debitAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(STANDARD_SCALE, STANDARD_ROUNDING);

        BigDecimal totalCredits = entries.stream()
                .map(LedgerLine::creditAmount)
                .reduce(BigDecimal.ZERO, BigDecimal::add)
                .setScale(STANDARD_SCALE, STANDARD_ROUNDING);

        if (totalDebits.compareTo(totalCredits) != 0) {
            throw new IllegalStateException(
                String.format("Unbalanced journal voucher [%s]: Debits=%s, Credits=%s, Diff=%s",
                    voucherId, totalDebits, totalCredits, totalDebits.subtract(totalCredits)));
        }

        // Persist entries to immutable append-only ledger table...
    }
}
