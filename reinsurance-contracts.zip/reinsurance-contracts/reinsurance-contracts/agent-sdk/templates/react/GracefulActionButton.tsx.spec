import React, { useState, useCallback, ReactNode, ButtonHTMLAttributes } from 'react';

export type ActionButtonVariant = 'primary' | 'secondary' | 'danger' | 'ghost';

export interface GracefulActionButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'onClick'> {
  onClick?: (e: React.MouseEvent<HTMLButtonElement>) => void | Promise<void>;
  variant?: ActionButtonVariant;
  isLoading?: boolean;
  disabledTooltip?: string;
  debounceMs?: number;
  icon?: ReactNode;
  children: ReactNode;
}

/**
 * Agent SDK: 防禦型防連點與降級引導按鈕 (GracefulActionButton)
 * 嚴格杜絕死按鈕、空事件欺騙，內建異步防連點 (Debounce) 與禁用原因 Tooltip。
 */
export function GracefulActionButton({
  onClick,
  variant = 'primary',
  isLoading = false,
  disabled = false,
  disabledTooltip,
  debounceMs = 500,
  icon,
  children,
  className = '',
  ...rest
}: GracefulActionButtonProps) {
  const [isPending, setIsPending] = useState(false);
  const [lastClickTime, setLastClickTime] = useState(0);

  const handleClick = useCallback(
    async (e: React.MouseEvent<HTMLButtonElement>) => {
      if (disabled || isLoading || isPending) return;

      const now = Date.now();
      if (now - lastClickTime < debounceMs) return;
      setLastClickTime(now);

      if (onClick) {
        try {
          const result = onClick(e);
          if (result instanceof Promise) {
            setIsPending(true);
            await result;
          }
        } finally {
          setIsPending(false);
        }
      }
    },
    [disabled, isLoading, isPending, lastClickTime, debounceMs, onClick]
  );

  const variantStyles: Record<ActionButtonVariant, string> = {
    primary: 'bg-blue-600 text-white hover:bg-blue-700 active:bg-blue-800 disabled:bg-blue-300',
    secondary: 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50 active:bg-gray-100 disabled:bg-gray-100',
    danger: 'bg-red-600 text-white hover:bg-red-700 active:bg-red-800 disabled:bg-red-300',
    ghost: 'bg-transparent text-gray-600 hover:bg-gray-100 active:bg-gray-200 disabled:text-gray-300',
  };

  const buttonElement = (
    <button
      type="button"
      disabled={disabled || isLoading || isPending}
      onClick={handleClick}
      className={`inline-flex items-center justify-center px-3.5 py-1.5 text-xs font-medium rounded-md shadow-xs transition-colors duration-150 focus:outline-none focus:ring-2 focus:ring-offset-1 focus:ring-blue-500 disabled:cursor-not-allowed ${variantStyles[variant]} ${className}`}
      {...rest}
    >
      {(isLoading || isPending) && (
        <svg
          className="animate-spin -ml-0.5 mr-1.5 h-3.5 w-3.5 text-current"
          xmlns="http://www.w3.org/2000/svg"
          fill="none"
          viewBox="0 0 24 24"
        >
          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
          <path
            className="opacity-75"
            fill="currentColor"
            d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"
          />
        </svg>
      )}
      {!isLoading && !isPending && icon && <span className="mr-1.5 -ml-0.5">{icon}</span>}
      <span>{children}</span>
    </button>
  );

  if (disabled && disabledTooltip) {
    return (
      <span className="inline-block" title={disabledTooltip}>
        {buttonElement}
      </span>
    );
  }

  return buttonElement;
}
