import React from 'react';

export interface MasterDataPaginationProps {
  currentPage: number;
  totalPages: number;
  totalElements: number;
  pageSize: number;
  onPageChange?: (page: number) => void;
  onPageSizeChange?: (pageSize: number) => void;
  pageSizeOptions?: number[];
  disabled?: boolean;
}

/**
 * Agent SDK: 雙側對稱主檔分頁原語組件 (MasterDataPagination)
 * 強制保障零崩塌 (Anti-Collapse)、單頁不隱藏與每頁筆數切換。
 */
export function MasterDataPagination({
  currentPage,
  totalPages,
  totalElements,
  pageSize,
  onPageChange,
  onPageSizeChange,
  pageSizeOptions = [10, 20, 50, 100],
  disabled = false,
}: MasterDataPaginationProps) {
  const isFirst = currentPage === 0;
  const isLast = totalPages <= 1 || currentPage >= totalPages - 1;

  return (
    <div className="flex items-center justify-between px-4 py-3 bg-white border-t border-gray-100 text-xs text-gray-700">
      {/* 左側：每頁筆數選擇 */}
      <div className="flex items-center space-x-2">
        <span>每頁顯示</span>
        <select
          value={pageSize}
          disabled={disabled || totalElements === 0}
          onChange={(e) => onPageSizeChange?.(Number(e.target.value))}
          className="h-7 px-2 border border-gray-300 rounded bg-white text-xs focus:outline-none focus:border-blue-500 disabled:opacity-50 disabled:bg-gray-50"
        >
          {pageSizeOptions.map((opt) => (
            <option key={opt} value={opt}>
              {opt} 筆
            </option>
          ))}
        </select>
        <span>筆資料，共 {totalElements} 筆</span>
      </div>

      {/* 右側：頁碼跳轉控制 */}
      <div className="flex items-center space-x-1">
        <button
          type="button"
          disabled={disabled || isFirst}
          onClick={() => onPageChange?.(0)}
          className="h-7 px-2 border border-gray-300 rounded hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          «
        </button>
        <button
          type="button"
          disabled={disabled || isFirst}
          onClick={() => onPageChange?.(currentPage - 1)}
          className="h-7 px-2.5 border border-gray-300 rounded hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          ‹ 上一頁
        </button>
        <span className="px-3 py-1 font-mono font-medium">
          {totalPages === 0 ? 0 : currentPage + 1} / {Math.max(1, totalPages)}
        </span>
        <button
          type="button"
          disabled={disabled || isLast}
          onClick={() => onPageChange?.(currentPage + 1)}
          className="h-7 px-2.5 border border-gray-300 rounded hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          下一頁 ›
        </button>
        <button
          type="button"
          disabled={disabled || isLast}
          onClick={() => onPageChange?.(Math.max(0, totalPages - 1))}
          className="h-7 px-2 border border-gray-300 rounded hover:bg-gray-50 disabled:opacity-40 disabled:cursor-not-allowed"
        >
          »
        </button>
      </div>
    </div>
  );
}
