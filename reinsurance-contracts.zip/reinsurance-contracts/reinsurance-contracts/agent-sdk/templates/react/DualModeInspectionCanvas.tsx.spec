import React, { useState } from 'react';
import { Lock, Copy, Check } from 'lucide-react';

export interface InspectionFieldProps {
  label: string;
  value: React.ReactNode;
  rawValue?: string;
  isReadOnlyKey?: boolean;
  lockTooltip?: string;
  required?: boolean;
  isEditMode?: boolean;
  children?: React.ReactNode;
}

export function InspectionField({
  label,
  value,
  rawValue,
  isReadOnlyKey,
  lockTooltip = '此欄位已被引用，鎖定為唯讀',
  required,
  isEditMode,
  children
}: InspectionFieldProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    if (rawValue || typeof value === 'string') {
      navigator.clipboard.writeText(rawValue || String(value));
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="space-y-1.5">
      <div className="flex items-center gap-1.5">
        <label className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
          {label}
        </label>
        {isEditMode && required && (
          <span className="text-red-500 font-bold">*</span>
        )}
        {isReadOnlyKey && (
          <span title={lockTooltip} className="text-slate-400 hover:text-slate-600 transition-colors">
            <Lock className="w-3.5 h-3.5" />
          </span>
        )}
      </div>

      {isEditMode ? (
        children
      ) : (
        <div className="group relative flex items-center justify-between py-1.5 px-3 bg-slate-50/50 rounded-lg border border-transparent hover:border-slate-200 transition-all">
          <span className="text-sm font-medium text-slate-900 select-text">
            {value !== undefined && value !== null && value !== '' ? value : '—'}
          </span>
          {(rawValue || typeof value === 'string') && (
            <button
              type="button"
              onClick={handleCopy}
              className="opacity-0 group-hover:opacity-100 text-slate-400 hover:text-slate-700 transition-opacity p-1 rounded"
              title="複製內容"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          )}
        </div>
      )}
    </div>
  );
}

export function useDirtyStateGuard(isDirty: boolean, onDiscardConfirm: () => void) {
  const [showConfirmModal, setShowConfirmModal] = useState(false);

  const guardedAction = (action: () => void) => {
    if (isDirty) {
      setShowConfirmModal(true);
    } else {
      action();
    }
  };

  const confirmDiscard = () => {
    setShowConfirmModal(false);
    onDiscardConfirm();
  };

  const cancelDiscard = () => {
    setShowConfirmModal(false);
  };

  return {
    showConfirmModal,
    guardedAction,
    confirmDiscard,
    cancelDiscard,
  };
}
