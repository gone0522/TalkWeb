import React from 'react';
import { AlertTriangle, ShieldCheck } from 'lucide-react';

export interface ReferenceModuleItem {
  moduleName: string;
  count: number;
}

export interface ReferenceDefenseCardProps {
  title?: string;
  items: ReferenceModuleItem[];
  totalReferences: number;
  className?: string;
}

export function ReferenceDefenseCard({
  title = '系統關聯與引用統計',
  items,
  totalReferences,
  className = ''
}: ReferenceDefenseCardProps) {
  const isReferenced = totalReferences > 0;

  return (
    <div
      className={`rounded-xl p-4 border transition-colors ${
        isReferenced
          ? 'bg-amber-50/70 border-amber-200/80 text-amber-900'
          : 'bg-slate-50/70 border-slate-200/80 text-slate-800'
      } ${className}`}
    >
      <div className="flex items-center gap-2 mb-2 font-semibold text-sm">
        {isReferenced ? (
          <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0" />
        ) : (
          <ShieldCheck className="w-4 h-4 text-emerald-600 shrink-0" />
        )}
        <span>{title}</span>
        <span
          className={`ml-auto text-xs font-bold px-2 py-0.5 rounded-full ${
            isReferenced
              ? 'bg-amber-200/60 text-amber-800'
              : 'bg-slate-200/60 text-slate-700'
          }`}
        >
          {totalReferences} 筆引用
        </span>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs">
        {items.map((item, idx) => (
          <div key={idx} className="flex justify-between py-1 px-2 rounded bg-white/60 border border-black/5">
            <span className="text-slate-600">{item.moduleName}</span>
            <span className="font-semibold text-slate-900">{item.count}</span>
          </div>
        ))}
      </div>

      {isReferenced && (
        <p className="mt-2 text-xs text-amber-700">
          * 提醒：此資料已被外部模組引用，受保護無法直接刪除；如不再使用請改為設為停用/作廢。
        </p>
      )}
    </div>
  );
}
