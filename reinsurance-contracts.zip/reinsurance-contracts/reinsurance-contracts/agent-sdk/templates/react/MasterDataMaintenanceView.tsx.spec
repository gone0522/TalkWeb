import React, { ReactNode } from 'react';

export interface MasterDataMaintenanceViewProps {
  title: string;
  screenCode?: string;
  headerActions?: ReactNode;
  searchForm?: ReactNode;
  toolbar?: ReactNode;
  dataGrid: ReactNode;
  pagination?: ReactNode;
  detailDrawer?: ReactNode;
}

/**
 * Agent SDK: 主檔維護標準 6 功能分區容器組件 (MasterDataMaintenanceView)
 * 嚴格保證 Zone 1 ~ Zone 6 的響應式排版、Design Tokens 色彩與雙側邊距對稱性。
 */
export function MasterDataMaintenanceView({
  title,
  screenCode,
  headerActions,
  searchForm,
  toolbar,
  dataGrid,
  pagination,
  detailDrawer,
}: MasterDataMaintenanceViewProps) {
  return (
    <div className="w-full min-h-screen bg-gray-50/50 p-6 space-y-4">
      {/* Zone 1: Header & Primary Actions */}
      <div className="flex items-center justify-between bg-white p-4 rounded-lg border border-gray-200 shadow-xs">
        <div>
          <h1 className="text-lg font-bold text-gray-900 tracking-tight">{title}</h1>
          {screenCode && <p className="text-xs font-mono text-gray-400 mt-0.5">{screenCode}</p>}
        </div>
        {headerActions && <div className="flex items-center space-x-2">{headerActions}</div>}
      </div>

      {/* Zone 2: Search Filters */}
      {searchForm && (
        <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-xs">
          {searchForm}
        </div>
      )}

      {/* Zone 3 & 4 & 5: Data Table Container */}
      <div className="bg-white p-4 rounded-lg border border-gray-200 shadow-xs space-y-4">
        {/* Zone 3: Toolbar */}
        {toolbar && <div className="border-b border-gray-100 pb-3">{toolbar}</div>}

        {/* Zone 4: Data Grid */}
        <div className="overflow-x-auto">{dataGrid}</div>

        {/* Zone 5: Pagination */}
        {pagination && <div className="pt-2">{pagination}</div>}
      </div>

      {/* Zone 6: Detail Drawer */}
      {detailDrawer}
    </div>
  );
}
