import React from 'react';
import { ArrowRight, Calculator } from 'lucide-react';

export interface CalculationPreviewCardProps {
  positiveExample: string;
  positiveResult: string;
  negativeExample: string;
  negativeResult: string;
  ruleDescription: string;
  decimalPlaces: number;
  className?: string;
}

export function CalculationPreviewCard({
  positiveExample = '1,234.5678',
  positiveResult,
  negativeExample = '-1,234.5678',
  negativeResult,
  ruleDescription,
  decimalPlaces,
  className = ''
}: CalculationPreviewCardProps) {
  return (
    <div className={`bg-slate-50/80 border border-slate-200/80 rounded-xl p-4 space-y-3 ${className}`}>
      <div className="flex items-center gap-2 text-xs font-semibold text-slate-600">
        <Calculator className="w-4 h-4 text-slate-500" />
        <span>即時進位演算範例預覽 (小數點後 {decimalPlaces} 位)</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
        <div className="flex items-center justify-between p-2 rounded-lg bg-white border border-slate-200/60 shadow-2xs">
          <span className="text-slate-500 font-mono">{positiveExample}</span>
          <ArrowRight className="w-3.5 h-3.5 text-slate-400 mx-2" />
          <span className="font-mono font-bold text-slate-900">{positiveResult}</span>
        </div>

        <div className="flex items-center justify-between p-2 rounded-lg bg-white border border-slate-200/60 shadow-2xs">
          <span className="text-slate-500 font-mono">{negativeExample}</span>
          <ArrowRight className="w-3.5 h-3.5 text-slate-400 mx-2" />
          <span className="font-mono font-bold text-slate-900">{negativeResult}</span>
        </div>
      </div>

      <p className="text-2xs text-slate-500 leading-relaxed">
        {ruleDescription}
      </p>
    </div>
  );
}
