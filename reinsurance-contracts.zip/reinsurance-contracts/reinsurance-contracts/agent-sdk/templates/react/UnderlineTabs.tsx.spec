import React from 'react';

export interface TabItem {
  id: string;
  label: string;
  badge?: number | string;
  disabled?: boolean;
}

export interface UnderlineTabsProps {
  tabs: TabItem[];
  activeTab: string;
  onTabChange: (id: string) => void;
  className?: string;
}

export function UnderlineTabs({
  tabs,
  activeTab,
  onTabChange,
  className = ''
}: UnderlineTabsProps) {
  return (
    <div className={`border-b border-slate-200/80 ${className}`}>
      <nav className="flex space-x-6" role="tablist" aria-orientation="horizontal">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              role="tab"
              aria-selected={isActive}
              disabled={tab.disabled}
              onClick={() => onTabChange(tab.id)}
              className={`relative py-3 px-1 text-sm font-medium transition-all duration-200 ease-out focus:outline-none ${
                isActive
                  ? 'text-slate-900 font-semibold'
                  : 'text-slate-500 hover:text-slate-700 hover:border-slate-300'
              } ${tab.disabled ? 'opacity-40 cursor-not-allowed' : 'cursor-pointer'}`}
            >
              <span className="flex items-center gap-2">
                {tab.label}
                {tab.badge !== undefined && (
                  <span
                    className={`inline-flex items-center px-1.5 py-0.5 rounded-full text-xs font-semibold ${
                      isActive
                        ? 'bg-orange-100 text-orange-700'
                        : 'bg-slate-100 text-slate-600'
                    }`}
                  >
                    {tab.badge}
                  </span>
                )}
              </span>
              {isActive && (
                <span
                  className="absolute bottom-0 left-0 right-0 h-0.5 bg-orange-500 rounded-full transition-all duration-300 ease-out"
                  layoutId="activeUnderline"
                />
              )}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
