import React, { ReactNode } from 'react';

export interface SmoothDataTableContainerProps {
  isLoading: boolean;
  isEmpty: boolean;
  minHeightPx?: number;
  topIndicator?: boolean;
  loadingLabel?: string;
  skeletonRows?: ReactNode;
  emptyState?: ReactNode;
  children: ReactNode;
  className?: string;
}

/**
 * Agent SDK: 前端防抖動零位移穩定容器原型組件 (SmoothDataTableContainer)
 * 遵循 RFC-012 與 ENGINEERING_STANDARDS.md §11.8。
 * 徹底根絕極速本機資料讀取與行數差量造成的「上下晃動」與「快閃跳動」：
 * 1. 高度容器保全 (Height Containment, 預設 min-h-[420px])：
 *    無論資料是 0 筆、1 筆還是 20 筆，表格框底緣與下方分頁工具列永遠固定，垂直位移嚴格為 0 (CLS = 0)。
 * 2. 既有資料不卸載平滑交接 (Non-Collapsing Opacity Cross-Fade)：
 *    更新時保持現有列排版，套用 opacity-40 平滑漸層動畫，不產生空白幀。
 * 3. 頂部細緻光條指示器 (2px Top Edge Pulse Bar)：
 *    微秒級即時狀態指示，不佔據額外垂直空間。
 */
export function SmoothDataTableContainer({
  isLoading,
  isEmpty,
  minHeightPx = 420,
  topIndicator = true,
  loadingLabel = '載入中...',
  skeletonRows,
  emptyState,
  children,
  className = '',
}: SmoothDataTableContainerProps) {
  return (
    <div
      className={`relative border border-gray-200 rounded overflow-hidden bg-white flex flex-col ${className}`}
      style={{ minHeight: `${minHeightPx}px` }}
    >
      {/* 1. 頂部細緻光條指示器 (不改變高度的 0px 疊加層) */}
      {topIndicator && (
        <div
          className={`absolute top-0 left-0 right-0 h-0.5 bg-gradient-to-r from-orange-400 via-orange-500 to-amber-400 z-20 transition-opacity duration-300 ${
            isLoading ? 'opacity-100 animate-pulse' : 'opacity-0'
          }`}
        />
      )}

      {/* 2. 既有資料平滑載入中浮動 Badge (居中毛玻璃懸浮) */}
      {isLoading && !isEmpty && (
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none z-10">
          <div className="bg-white/95 backdrop-blur-xs px-4 py-2 rounded-full shadow-md border border-gray-200 text-xs font-medium text-gray-700 flex items-center space-x-2 animate-in fade-in duration-150">
            <svg
              className="animate-spin h-3.5 w-3.5 text-[#FF5A1F]"
              fill="none"
              viewBox="0 0 24 24"
            >
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="3" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8v8H4z" />
            </svg>
            <span>{loadingLabel}</span>
          </div>
        </div>
      )}

      {/* 3. 內容渲染區 (保持彈性伸展撐滿最小高度) */}
      <div className="flex-1 flex flex-col justify-between">
        {isLoading && isEmpty ? (
          skeletonRows
        ) : isEmpty ? (
          <div className="flex-1 flex items-center justify-center py-16">
            {emptyState}
          </div>
        ) : (
          <div
            className={`transition-opacity duration-200 flex-1 ${
              isLoading ? 'opacity-40 pointer-events-none' : 'opacity-100'
            }`}
          >
            {children}
          </div>
        )}
      </div>
    </div>
  );
}
