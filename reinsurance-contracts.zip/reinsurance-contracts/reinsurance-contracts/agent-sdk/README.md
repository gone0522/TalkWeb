# Agent SDK (v0.1.0-alpha) - 企業級 AI 原生軟體工程標準庫

> **核心定位**：跨專案、跨模型、跨時代之企業級 AI 軟體工程標準庫（The Standard Library for Spec-Driven AI Software Factories）。  
> **最原始使命**：將**「人類商業意圖」**精準無損地轉換為**「機器語言」**，且由機器確實無誤、零歧義、零妥協地執行，幾乎 100% 依照人類想要的樣子落地實作。  
> **百年公理**：將視角拉伸至**一百年（Centennial Horizon: 2026 ~ 2126+）**，原則與不變量如同日升日落般亙古不變；隨時代更迭的，僅僅是運作的模型與執行的計算機器。  
> **授權協議**：[Apache License 2.0](LICENSE)  
> **長期藍圖**：[Centennial Architecture Horizon (2026 ~ 2126+)](ROADMAP.md)

---

## 一、 架構願景與核心定位 (Vision & Charter) - 百年不變的人機意圖契約

軟體工程半個世紀以來最根本的痛點，在於**「人類腦中的商業意圖」**在經過多層人員傳遞、轉譯與撰寫代碼後，產生了嚴重的語意丟失與認知衰減，最終導致代碼偏離、偷工減料或假完工（如空按鈕、寫死字串）。

**`Agent SDK` 的最原始定位，就是軟體工廠的標準基礎建設與意圖翻譯器**：
- **將人類意圖轉換為機器語言**：人類架構師與產品負責人（PO）只需專注表達商業目標與價值邏輯；系統透過編譯器，將高階意圖編譯為機器能完全理解的結構化任務字節碼（Task-IR）。
- **確實無誤的落庫執行**：任何當代 AI 模型解譯此字節碼時，皆能依照人類期望的精確樣貌實作代碼，無任何妥協空間。
- **原則永恆，模型與機器常新**：**原則如太陽升起一樣不會改變**——數學的借貸平衡、資訊的呈現邊界、不可篡改的審計留痕皆為公理；無論未來 50 年、100 年底層使用的是 Claude、Gemini、GPT 還是新型超級神經計算機，這套標準庫與字節碼契約永遠有效。

```text
┌────────────────────────────────────────────────────────────────────────┐
│                        高階人類活體規格 (.spec.md)                     │
│               (人類架構師 / PO 表達真實商業意圖與領域規則)             │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ 【意圖編譯器 (Intent Compiler / Planner)】
                                    ▼ 讀取 Agent SDK 符號表 (catalog.yaml)
┌────────────────────────────────────────────────────────────────────────┐
│                    任務字節碼 (Task-IR / task.ir.yaml)                 │
│         (跨模型、跨平台、高密度機器語言，攜帶形式化證明義務)           │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ 【AI 虛擬機 (AI Virtual Machine / Runner)】
                                    ▼ 鏈結 Agent SDK 原型原語 (Archetype Primitives)
┌───────────────────────────────────┴────────────────────────────────────┐
│                       確實無誤的落地實作 (Tested Code)                 │
│       幾乎 100% 依照人類想要的樣子實作，且由客觀適性測試驗證           │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 二、 二十年終極架構三層劃分 (The 3-Layer Immortal Substrate)

在長程維度下，所有具體的程式語言、第三方框架與資料庫（Java 21, Spring Boot 3, React 19, PostgreSQL）皆為**具備 10~15 年半衰期之可拋棄宿主 (Disposable Hosts)**。
為防止系統隨框架一同老化，Agent SDK 在物理上徹底實行三層解耦架構：

```text
┌────────────────────────────────────────────────────────────────────────┐
│  Layer 0: 永恆代數核心 (The Eternal Algebraic Core - 永生層)           │
│  - 500 年不變之代數律：借貸平衡方程式 (ΣDebits ≡ ΣCredits)             │
│  - 不可變有限狀態機移轉矩陣 (State Transition Matrix)                  │
│  - 雙時態有效性代數 (Valid Time ✕ Transaction Time)                     │
│  - 零浮點數純量模型 (Arbitrary-Precision Decimal)                     │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ 【形式化編譯與證明映射】
                                    ▼ 
┌────────────────────────────────────────────────────────────────────────┐
│  Layer 1: 通用中介字節碼 (Task-IR v1.0 ~ v3.0 - 跨代穩定層)            │
│  - 平台無關、模型無關的語意本體圖譜 (Semantic Merkle DAG)              │
│  - 嚴格向前相容 (Append-Only Optional Schema)                          │
│  - 攜帶數學證明義務 (Proof-Carrying Bytecode)                          │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ 【AI 虛擬機 (AI-VM) 投影至當前時代】
                                    ▼ 
┌────────────────────────────────────────────────────────────────────────┐
│  Layer 2: 可拋棄宿主適配器 (Disposable Host Adapters - 消耗品層)       │
│  - 2026~2030 宿主: Spring Boot 3.x Starter + Next.js 15 React 19       │
│  - 2030~2038 宿主: Rust Actix / WebAssembly + Spatial Canvas UI        │
│  - 2038~2046 宿主: 神經執行網路 (Neural-Execution Mesh) / 全自主合成   │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 三、 雙子星套件結構 (Twin-Star Architecture)

Agent SDK 由三大核心部分組成：

1. **核心規格層 (`specs/`) - `agent-sdk-specs`**：
   - 以 RFC 與 YAML/JSON Schema 定義標準通訊協議、跨領域架構原語與形式化驗收約束。
   - 包含完整 17 項核心 RFC 契約：
     * **基礎字節碼**：任務字節碼協議 ([RFC-001](specs/RFC-001-task-ir-bytecode.schema.yaml))
     * **主檔領域**：主檔維護標準契約 ([RFC-002](specs/RFC-002-master-data-archetype.yaml))、動態在地化串流匯出 ([RFC-003](specs/RFC-003-dynamic-localized-export.yaml))、樂觀鎖併發衝突防禦 ([RFC-004](specs/RFC-004-concurrency-resilience-guard.yaml))
     * **核心領域**：規範代碼審計留痕 ([RFC-005](specs/RFC-005-audit-trail-canonical.yaml))、QoS 可觀測性度量 ([RFC-006](specs/RFC-006-telemetry-qos-metrics.yaml))、工作流狀態機原型 ([RFC-007](specs/RFC-007-workflow-state-machine-archetype.yaml))、複式財務帳務原型 ([RFC-008](specs/RFC-008-financial-ledger-archetype.yaml))、巨量批次排程匯入 ([RFC-009](specs/RFC-009-batch-ingestion-archetype.yaml))
     * **治理與演進**：常青架構適性守門人 ([RFC-010](specs/RFC-010-architecture-fitness-sentry.yaml))、平滑演進與日落防衛 ([RFC-011](specs/RFC-011-graceful-evolution-sunset-guard.yaml))
     * **現代人因與 UI 互動**：零累計版面位移與平滑過渡 ([RFC-012](specs/RFC-012-frontend-zero-cls-smooth-transition.yaml))、雙模態人因檢驗畫布 ([RFC-013](specs/RFC-013-dual-mode-inspection-canvas.yaml))、現代底線導航頁籤 ([RFC-014](specs/RFC-014-modern-underline-tabs.yaml))、全域被引用防禦阻尼 ([RFC-015](specs/RFC-015-reference-defense-damper.yaml))、即時試算回饋預覽卡 ([RFC-016](specs/RFC-016-realtime-calculation-preview.yaml))
     * **持久化審計**：欄位級異動差異審計引擎 ([RFC-017](specs/RFC-017-field-diff-audit-engine.yaml))

2. **後端原語庫 (`templates/spring/`) - `agent-sdk-spring`**：
   - Spring Boot 3.x 企業級 Starter 與原語基底（當前時代之宿主）。
   - 包含 11 項可執行原語樣板：
     * `ArchitectureFitnessTest.java.spec` (ArchUnit 架構不變量守護)
     * `ZeroHardcodedNaturalLanguageTest.java.spec` (語言無關零硬編碼文字物理守門人)
     * `BaseAuditableEntity.java.spec` (規範代碼雙時態審計實體基底)
     * `OptimisticLockGuard.java.spec` (樂觀鎖版本衝突攔截器)
     * `GenericExcelExportEngine.java.spec` (動態 MessageSource 串流匯出引擎)
     * `GenericFieldDiffAuditor.java.spec` (反射式欄位級異動審計引擎)
     * `GenericWorkflowStateMachine.java.spec` (不可變有限狀態移轉機)
     * `GenericFinancialLedgerEngine.java.spec` (零浮點數複式記帳引擎)
     * `GenericBatchIngestionEngine.java.spec` (分塊事務批次排程匯入引擎)
     * `GracefulSunsetRoute.java.spec` (雙軌相容路由外觀註解)
     * `GracefulSunsetInterceptor.java.spec` (RFC 8594 日落標頭注入與遙測攔截器)

3. **前端原語庫 (`templates/react/`) - `@agent-sdk/react`**：
   - Next.js 15 / React 19 元件庫與原語樣板（當前時代之宿主）。
   - 包含 8 項無死按鈕、零 CLS 人因原語樣板：
     * `<MasterDataMaintenanceView>` (標準 6 區響應式主檔骨幹視圖)
     * `<MasterDataPagination>` (防塌陷對稱分頁排版元件)
     * `<GracefulActionButton>` (AST 驗證防連點與 Tooltip 引導按鈕)
     * `<SmoothDataTableContainer>` (保全高度 min-h 與淡入淡出零 CLS 容器)
     * `<DualModeInspectionCanvas>` (檢視/編輯雙模態分離人因畫布)
     * `<UnderlineTabs>` (現代品牌底線滑動指示頁籤)
     * `<ReferenceDefenseCard>` (琥珀色全域公共資源引用防禦資訊卡)
     * `<CalculationPreviewCard>` (原地進位試算與交易成本消除卡)

---

## 四、 企業級領域與互動原型族系 (Enterprise Archetype Taxonomy)

為了應對企業系統從 3 個模組擴展到 50 個模組的演進，Agent SDK 確立完整 12 大領域、互動與治理原型族系：

| 原型族系 (Archetype Family) | 代表規格 (RFC) | 核心原語 (Primitive) | 跨學科底座與核心不變量 (Invariant) |
| :--- | :--- | :--- | :--- |
| **1. 主檔資料維護** | [RFC-002](specs/RFC-002-master-data-archetype.yaml) | `MasterDataMaintenanceView`, `GenericExcelExportEngine` | 6 區響應式結構、動態 MessageSource 外部化、0 死按鈕 |
| **2. 狀態機與審批流** | [RFC-007](specs/RFC-007-workflow-state-machine-archetype.yaml) | `GenericWorkflowStateMachine` | 不可變狀態移轉矩陣、RBAC 權限、交易內審計留痕 |
| **3. 複式財務帳務** | [RFC-008](specs/RFC-008-financial-ledger-archetype.yaml) | `GenericFinancialLedgerEngine` | 零浮點數 (BigDecimal)、銀行家捨入、借貸絕對平衡方程式 |
| **4. 巨量批次處理** | [RFC-009](specs/RFC-009-batch-ingestion-archetype.yaml) | `GenericBatchIngestionEngine` | 分塊事務隔離 (Chunk-Based)、單行錯誤隔離、冪等 JobKey |
| **5. 常青架構守門人** | [RFC-010](specs/RFC-010-architecture-fitness-sentry.yaml) | `ArchitectureFitnessTest`, `ZeroHardcodedNaturalLanguageTest` | 編譯期 ArchUnit 物理門禁、AST 死按鈕防禦、源碼 ASCII 純淨度 |
| **6. 平滑演進日落防衛** | [RFC-011](specs/RFC-011-graceful-evolution-sunset-guard.yaml) | `GracefulSunsetRoute`, `GracefulSunsetInterceptor` | 雙軌路由別名、RFC 8594 日落標頭、Zero-QPS 遙測門禁 |
| **7. 零位移平滑過渡** | [RFC-012](specs/RFC-012-frontend-zero-cls-smooth-transition.yaml) | `<SmoothDataTableContainer>` | 完形連續律、容器 min-h 保全、微抖動消解、非塌陷淡入淡出 |
| **8. 雙模態檢驗畫布** | [RFC-013](specs/RFC-013-dual-mode-inspection-canvas.yaml) | `<DualModeInspectionCanvas>`, `useDirtyStateGuard` | 雙系統思維 (快思閱覽/慢想操作)、禁 disabled input、未儲存髒檢查 |
| **9. 現代底線頁籤** | [RFC-014](specs/RFC-014-modern-underline-tabs.yaml) | `<UnderlineTabs>` | 減法美學、除 Windows 檔案夾樣式、滑動品牌指示條、WCAG AA |
| **10. 引用防禦阻尼** | [RFC-015](specs/RFC-015-reference-defense-damper.yaml) | `<ReferenceDefenseCard>`, `useReferenceGuard` | 共有地悲劇治理、全域引用計數聚合、引用數 > 0 物理禁刪阻尼 |
| **11. 即時試算預覽** | [RFC-016](specs/RFC-016-realtime-calculation-preview.yaml) | `<CalculationPreviewCard>` | 寇斯交易成本消除、特斯勒複雜度守恆、原位雙向試算範例 |
| **12. 欄位級異動審計** | [RFC-017](specs/RFC-017-field-diff-audit-engine.yaml) | `GenericFieldDiffAuditor`, `BaseAuditableEntity` | 霍桑效應、雙時態真相溯源、反射式欄位差異留痕、必填 5 字理由 |

---

## 五、 演化與修復法則 (Patch the Archetype & Spec-to-Primitive Duality)

### 5.1 修復原型而非手冊追加規則 (Patch the Archetype, NOT the Rulebook)
- **拒絕打地鼠**：當系統發現通用性品質缺陷（例如：報表表頭未多語系化、併發衝突缺少刷新提示、版面跳動 CLS）時，**嚴禁在規範手冊中無休止地追加微觀列舉條款**。
- **直擊原型**：架構師與 AI 唯一的修復職責，是**直接升級 `Agent SDK` 內部對應的原型原語**。
- **全域免疫**：底層標準庫一旦升級修復並通過測試，所有使用該 SDK 的業務模組在下次編譯建構時自動免疫。
- **常青守門人 (RFC-010)**：所有核心不變量皆轉化為 `ArchitectureFitnessTest` (ArchUnit)，CI 物理阻斷任何違規提交，徹底打破「人亡政息」的軟體老化詛咒。
- **負熵引擎**：工廠持續監控全系統 AST 相似度，自主執行三振法則，自動將重複邏輯提煉回 SDK，越演進代碼越少、抽象層次越高。

### 5.2 規碼對偶律 (Spec-to-Primitive Duality Law - 嚴禁孤兒規範)
- **拒絕孤兒規範 (No Orphan Specs)**：任何寫入 Living Specs（如 `UI_SPEC.md`, `DBA_SPEC.md`）或工程標準（`ENGINEERING_STANDARDS.md`）之架構不變量、人因互動模式與跨學科原則（反脆弱、推力、認知負荷、交易成本），**嚴禁僅停留於 Markdown 文字宣導**。
- **一對一投影義務**：每一條強制性規範，必須 1:1 對偶對應到 `Agent SDK` 的 RFC 規格與物理樣板代碼（Physical Template Spec），並註冊於 `catalog.yaml`。
- **主動自我昇華**：若規範中存在原則但 SDK 尚未具備對應原語，AI 與架構師必須主動發起 RFC 提案並實作樣板，不得等待人類提出才被動納入。

---

## 六、 完整目錄結構

```text
agent-sdk/
├── LICENSE                            # Apache License 2.0
├── README.md                          # 本說明文件 (願景、定位、契約與規碼對偶律)
├── ROADMAP.md                         # 百年演化藍圖與 LTS 棄用生命週期 (2026 ~ 2126+)
├── catalog.yaml                       # 符號清單與能力索引 (Symbol Table - 18 項原語)
├── specs/                             # 跨平台標準契約與 17 項 RFCs
│   ├── RFC-001-task-ir-bytecode.schema.yaml         # 任務字節碼 Task-IR Schema
│   ├── RFC-002-master-data-archetype.yaml            # 主檔原型標準契約 (Zone 1~6)
│   ├── RFC-003-dynamic-localized-export.yaml         # 動態在地化串流匯出原語
│   ├── RFC-004-concurrency-resilience-guard.yaml     # 樂觀鎖併發衝突防禦原語
│   ├── RFC-005-audit-trail-canonical.yaml            # 規範代碼審計留痕原語
│   ├── RFC-006-telemetry-qos-metrics.yaml            # QoS 與可觀測性計數器原語
│   ├── RFC-007-workflow-state-machine-archetype.yaml # 狀態機審批流原型
│   ├── RFC-008-financial-ledger-archetype.yaml       # 複式財務分錄原型
│   ├── RFC-009-batch-ingestion-archetype.yaml        # 批次排程匯入原型
│   ├── RFC-010-architecture-fitness-sentry.yaml      # 常青適性守門人規範
│   ├── RFC-011-graceful-evolution-sunset-guard.yaml  # 平滑演進日落防衛規範
│   ├── RFC-012-frontend-zero-cls-smooth-transition.yaml # 前端零位移平滑過渡容器規範
│   ├── RFC-013-dual-mode-inspection-canvas.yaml      # 雙模態人因檢驗畫布規範
│   ├── RFC-014-modern-underline-tabs.yaml            # 現代底線導航頁籤規範
│   ├── RFC-015-reference-defense-damper.yaml         # 全域被引用防禦阻尼規範
│   ├── RFC-016-realtime-calculation-preview.yaml     # 即時試算回饋預覽卡規範
│   ├── RFC-017-field-diff-audit-engine.yaml          # 欄位級異動差異審計引擎規範
│   ├── RFC-018-distributed-context-propagator.yaml   # 分散式上下文與 TraceId 透傳原語規範
│   ├── RFC-019-consumer-driven-contract-sentry.yaml  # 消費者驅動契約測試與破壞性變更守門規範
│   ├── RFC-020-resilience-circuit-breaker.yaml       # 宣告式 RPC 斷路器與超時降級原語規範
│   ├── RFC-021-transactional-outbox-mesh.yaml       # 事務發件箱與跨服務可靠事件網格規範
│   └── RFC-022-microservice-client-generator.yaml     # 契約驅動多語言 Client SDK 自動發布規範
└── templates/                         # 19 項原語合約與實作規範
    ├── spring/                        # 後端 Spring Boot 原語 (當前時代宿主 - 11 項)
    │   ├── ArchitectureFitnessTest.java.spec
    │   ├── BaseAuditableEntity.java.spec
    │   ├── GenericBatchIngestionEngine.java.spec
    │   ├── GenericExcelExportEngine.java.spec
    │   ├── GenericFieldDiffAuditor.java.spec
    │   ├── GenericFinancialLedgerEngine.java.spec
    │   ├── GenericWorkflowStateMachine.java.spec
    │   ├── GracefulSunsetInterceptor.java.spec
    │   ├── GracefulSunsetRoute.java.spec
    │   ├── OptimisticLockGuard.java.spec
    │   └── ZeroHardcodedNaturalLanguageTest.java.spec
    └── react/                         # 前端 React 原語 (當前時代宿主 - 8 項)
        ├── CalculationPreviewCard.tsx.spec
        ├── DualModeInspectionCanvas.tsx.spec
        ├── GracefulActionButton.tsx.spec
        ├── MasterDataMaintenanceView.tsx.spec
        ├── MasterDataPagination.tsx.spec
        ├── ReferenceDefenseCard.tsx.spec
        ├── SmoothDataTableContainer.tsx.spec
        └── UnderlineTabs.tsx.spec
```
