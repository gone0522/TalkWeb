# 再保險核心業務領域規範 (Reinsurance Domain Standards)

> **定位**：本文件為**本專案專屬**之再保險核心商業邏輯、金融監管合規與資料字典規範。

---

## 1. 資料庫領域族譜命名規範 (Reinsurance Table Prefixes)
為確保未來資料庫能夠按業務領域自然芽裂，所有資料表必須具備業務前綴：
- **主檔類 (Master Data)**：`md_*`（例如幣別 `md_currency`、國家 `md_country`、區域 `md_region`、機構 `md_financial_institution`）。
- **合約類 (Treaty & Facultative)**：`tr_*`（例如合約主檔 `tr_treaty`、險位分保 `tr_facultative`、分保比例 `tr_share`）。
- **理賠類 (Claims)**：`cl_*`（例如理賠立案 `cl_claim`、理賠攤回 `cl_recovery`）。
- **計費與結算類 (Billing & Settlement)**：`bl_*`（例如帳單 `bl_bill`、結算單 `bl_settlement`）。
- **標準實體表與演化演進協議 (Evolutionary Table Mapping Protocol)**：
  * **當前聚合期 (Phase 1 In-Process Monolith)**：現有實體表包含 `system_menu`, `system_country`, `system_regions`, `currencies`, `country_audit_logs`, `region_audit_logs`, `currency_audit_logs`。
  * **微服務物理芽裂期 (Phase 2 Microservice Sprouting - Year 1 目標)**：當核心主檔服務抽離為 `masterdata-service` 時，透過 Flyway 遷移指令檔（含零停機 PostgreSQL VIEW 相容別名）全面對齊為 `md_*` 規範表名：
    - `system_country` ➔ `md_country`
    - `system_regions` ➔ `md_region`
    - `currencies` ➔ `md_currency`
    - `system_menu` ➔ `md_menu`
    - `country_audit_logs` ➔ `md_country_audit_log`
    - `region_audit_logs` ➔ `md_region_audit_log`
    - `currency_audit_logs` ➔ `md_currency_audit_log`

---

## 2. 金融監管全欄位變更審計標準 (Financial Audit Compliance)
1. **全欄位留痕**：
   - 任何涉及幣別、國家制裁狀態、合約金額、分保費率之異動，必須在同一個資料庫交易內寫入審計日誌。
   - 審計欄位強制要求：變更時間 (`changed_at`)、操作人 (`changed_by`)、所屬部門 (`department`，如「財會部」、「核保部」)、欄位名稱 (`field_name`)、變更前值 (`before_value`)、變更後值 (`after_value`) 與異動原因 (`change_reason`)。
2. **原因長度驗證**：
   - 核心設定（如計算規則、制裁生效日）變更時，`change_reason` 長度必須 $\ge 5$ 個字元，嚴禁空原因或敷衍字元。

---

## 3. 結算幣別與精算進位控制規範 (Currency & Actuarial Precision)
1. **進位控制規則**：
   - `ROUND_HALF_UP` (四捨五入)
   - `ROUND_DOWN` (無條件捨去)
   - `ROUND_HALF_EVEN` (四捨六入五成雙 - 金融精算標準 Banker's Rounding)
2. **精度約束**：
   - 小數位數 (`decimal_places`) 必須介於 0 至 4 之間（例如日圓 0 位，新台幣 0 或 2 位，美元 2 位，特種外幣最高 4 位）。
3. **格式化呈現**：
   - 金額呈現強制具備符號、小數位數與千分位（例如 `$ 1,234.56`）。

---

## 4. 引用防禦業務邏輯 (Referential Guard Logic)
1. **幣別引用鏈檢核**：
   - 幣別變更為 `INACTIVE` 或刪除前，系統必須檢核：
     * 是否有關聯之生效中合約 (`treatyCount`)。
     * 是否有關聯之未平倉帳單 (`transactionCount`)。
     * 是否有關聯之銀行帳戶設定 (`bankSettingCount`)。
   - 若 `totalCount > 0`，系統強制阻擋停用/刪除，並回傳明確業務提示：「因已被引用，本筆資料不可刪除，僅可標記作廢。」

---

## 5. 再保險專業術語字典 (Reinsurance Terminology)
- **Treaty Reinsurance**：合約再保險
- **Facultative Reinsurance**：臨分再保險 (臨時再保險)
- **Retention**：自留額
- **Cession / Ceded**：分保 / 分出
- **Settlement Currency**：結算幣別
- **Sanction Compliance**：法遵制裁
