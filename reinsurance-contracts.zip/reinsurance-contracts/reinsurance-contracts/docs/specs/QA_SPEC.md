<!--
governance_metadata:
  last_reviewed: "2026-10-14"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-14"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# 專案全局品質保證與驗收標準規格書 (QA & Test Master Spec)

> **專案代號**：Reinsurance Core Platform  
> **品質門檻**：後端 `mvn test` 100% 通過、前端 `tsc` 0 錯誤、100% i18n 字典覆蓋  
> **文件版本**：v1.2 (Living Master Spec)  
> **負責角色**：QA Lead / SDET  

---

## 1. 核心品質驗收閘門 (Quality Gates)
1. **後端單元、整合與架構適性門檻 (對偶 Agent SDK RFC-010: ArchitectureFitnessSentry)**:
   - 執行 `mvn clean test` 必須 100% 通過（0 Failures, 0 Errors），包含 `ArchitectureFitnessTest` 與 `ZeroHardcodedNaturalLanguageTest`。
   - 包含領域 Service 邏輯、Controller 端點、Jakarta Validation、RFC 7807 錯誤模型與 JPA 交易復原。
2. **前端型別與建置門檻**:
   - `npx tsc --noEmit` 型別檢查 0 錯誤。
   - `npm run build` 成功構建無 Type 或 Next.js 頁面路由錯誤。
   - 嚴格遵循 `next-intl` 雙語字典，禁止 JSX 硬編碼文字。
3. **契約一致性 (Contract Parity)**:
   - 後端暴露的 RESTful API 與 `contracts/openapi.yaml` 契約 100% 對齊。
4. **消費者驅動契約測試與破壞性變更守門 (Consumer-Driven Contract Testing Gate - 對偶 Agent SDK RFC-019)**:
   - 微服務間調用必須撰寫 Pact 契約測試；被引用端 (Provider) CI 必須驗證所有下游 Active Consumer Contracts (`mvn test-compile pact:verify`)。
   - CI 門禁執行 `can-i-deploy` 檢查，破壞性變更未經下游適配前禁止合併。
5. **平滑退役日落遙測驗證 (Sunset Telemetry Oracle - 對偶 Agent SDK RFC-011)**:
   - 帶有 RFC 8594 `Sunset` 標頭之廢棄端點，物理代碼移除前必須通過 `/actuator/sunset-audit` 零 QPS 斷言（連續 30 天存取流量為 0）。

---

## 2. 全局需求與測試追溯矩陣 (Master Traceability Matrix - RTM)

### 2.1 區域管理模組 (Regions)
| 測試編號 | 業務規則 | 測試情境說明 | 自動化層級 | 預期結果 |
| :--- | :--- | :--- | :--- | :--- |
| **`TC-REG-01`** | `BR-REG-01` | 分頁檢索區域清單依 sortOrder 排序 | Service / Controller | 回傳分頁結構，清單嚴格依升冪排序 |
| **`TC-REG-02`** | `BR-REG-02` | 新增區域未填順序自動指派最大值 + 10 | Service Unit Test | 自動推算指派 `max + 10`，回傳 201 Created |
| **`TC-REG-03`** | `BR-REG-01` | 重複區域代碼建立衝突阻擋 | Controller / Service | 拋出 DuplicateResourceException, 409 Conflict |
| **`TC-REG-04`** | `BR-REG-04` | 更新區域名稱與自訂排序 | Service Unit Test | 名稱與排序更新，version 自增 |
| **`TC-REG-05`** | `BR-REG-04` | 切換區域作廢狀態 | Service Unit Test | `is_disabled` 狀態正確翻轉 |
| **`TC-REG-06`** | `BR-REG-04` | 無國家引用之區域安全物理刪除 | Service Unit Test | 實體成功移除，回傳 204 No Content |
| **`TC-REG-07`** | `BR-REG-04` | 有國家引用之區域禁止刪除阻擋 | Service Unit Test | 拋出 InvalidReferenceException, 400 Bad Request |
| **`TC-REG-08`** | `BR-REG-04` | 區域主檔全欄位異動審計日誌 (`region_audit_logs`) 留痕與歷程查詢 | Integration / Service | 全欄位變更審計記錄成功落庫並正確展示 |

### 2.2 國家管理模組 (Countries)
| 測試編號 | 業務規則 | 測試情境說明 | 自動化層級 | 預期結果 |
| :--- | :--- | :--- | :--- | :--- |
| **`TC-CTY-01`** | `BR-CTY-01` | 多維條件篩選國家清單 | Service / Controller | 關鍵字、區域代碼、制裁與作廢過濾正確 |
| **`TC-CTY-02`** | `BR-CTY-02` | 關聯有效區域成功建立國家主檔 | Controller Integration | 建立成功，回傳 201 Created |
| **`TC-CTY-03`** | `BR-CTY-01` | 重複國家代碼建立衝突阻擋 | Controller / Service | 拋出 DuplicateResourceException, 409 Conflict |
| **`TC-CTY-04`** | `BR-CTY-02` | 關聯不存在之區域代碼建立阻擋 | Service Unit Test | 拋出 InvalidReferenceException, 400 Bad Request |
| **`TC-CTY-05`** | `BR-CTY-02` | 關聯已作廢/停用區域建立阻擋 | Service Unit Test | 拋出 InvalidReferenceException, 400 Bad Request |
| **`TC-CTY-06`** | `BR-CTY-03` | 更新法遵制裁狀態與生效日期 | Service Unit Test | 制裁旗標與生效日期成功更新 |
| **`TC-CTY-07`** | `BR-CTY-04` | 無外部引用之國家安全物理刪除 | Service Unit Test | 實體成功自資料庫移除，回傳 204 No Content |
| **`TC-CTY-08`** | `BR-CTY-04` | 被金融機構引用之國家禁止刪除阻擋 | Service Unit Test | 拋出 InvalidReferenceException, 400 Bad Request |
| **`TC-CTY-09`** | `BR-CTY-04` | 查詢單筆國家詳情與外部引用計數 | Controller / Service | 正確回傳各模組引用統計結構 |
| **`TC-CTY-10`** | `BR-CTY-01` | 國家代碼格式不符 (非 2~3 碼大寫英文) | Bean Validation | 阻擋並回傳 400 ERR_VALIDATION_FAILED |
| **`TC-CTY-11`** | `BR-CTY-04` | 國家主檔全欄位異動審計日誌 (`country_audit_logs`) 留痕與歷程查詢 | Integration / Service | 全欄位變更審計記錄成功落庫並正確展示 |

---

### 2.3 結算幣別管理模組 (Currencies - TASK-007)
| 測試編號 | 業務規則 | 測試情境說明 | 自動化層級 | 預期結果 |
| :--- | :--- | :--- | :--- | :--- |
| **`TC-CUR-01`** | `BR-CUR-01` | ISO 4217 三碼正則檢核、重複代碼 409 Conflict | Unit / Integration | 非三碼阻擋 400，重複代碼 409 |
| **`TC-CUR-02`** | `BR-CUR-02` | 編輯模式下幣別代碼鎖定唯讀與 🔒 圖示渲染 | Component / E2E | 代碼輸入框鎖定 readOnly，渲染 🔒 |
| **`TC-CUR-03`** | `BR-CUR-03` | 已引用幣別禁止刪除；零引用幣別安全刪除二次確認 | Unit / Integration | 引用數 > 0 阻擋 409；零引用成功物理刪除 |
| **`TC-CUR-04`** | `BR-CUR-04` | 作廢狀態切換，作廢後排除於下拉選單 | Integration | 狀態正確切換為 INACTIVE |
| **`TC-CUR-05`** | `BR-CUR-05` | 四種進位設定 (HALF_UP, UP, DOWN, HALF_EVEN) 金額演算 | Unit Test (TDD) | 正負數四種進位規則計算完全符合規範 |
| **`TC-CUR-06`** | `BR-CUR-06` | 小數位數 0~4 邊界值驗證，<0 或 >4 阻擋報錯 | Unit / Integration | 0~4 通過，超出範圍回傳 400 |
| **`TC-CUR-07`** | `BR-CUR-07` | 計算設定變更強制要求原因，未填寫阻擋送出 | Integration / E2E | 未達 5 字前端阻擋與後端 400 |
| **`TC-CUR-08`** | `BR-CUR-08` | 全欄位異動審計矩陣測試 (計算設定、中文名、英文名、排序、狀態)，且抽屜正確渲染 | Integration | 全欄位變更審計日誌均成功落庫並正確展示 |
| **`TC-CUR-09`** | `BR-CUR-09` | 新增時建議排序自動推算 (Max + 10) | Unit Test | 正確取得最大值 + 10 序號 |
| **`TC-CUR-10`** | `BR-EXCEL`  | 依查詢條件匯出 Excel 欄位與格式正確性 | Integration | 成功下載 .xlsx 檔案 |

---

## 3. 邊界條件與負面測試矩陣 (Boundary Test Cases)
- **區域代碼極端長度**: 輸入超過 20 字元代碼立即被 Bean Validation 攔截。
- **並發衝突防護 (Optimistic Locking)**: 更新時版本號不符拋出 `OptimisticLockingFailureException`，回傳 409 Conflict。
- **刪除引用防護**: 引用計數大於 0 時強制鎖定，嚴防資料庫孤島產生。
