<!--
governance_metadata:
  last_reviewed: "2026-10-14"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-14"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# 專案全局前端介面與架構設計規格書 (Frontend Architecture - Master)

> **專案代號**：Reinsurance Core Platform  
> **畫面代碼**：`SC-0101-01-01` ~ `SC-0101-01-06`  
> **文件版本**：v1.2 (Living Master Spec)  
> **負責角色**：Lead Frontend Architect / UI Designer  

---

## 1. 前端企業級強制技術棧與架構標準 (Frontend Enterprise Architecture & BOM)
- **核心框架與渲染邊界**: Next.js 15+ (App Router) + React 19+ + TypeScript 5+ (嚴格模式)。
  * 頁面入口 (`page.tsx`) 與佈局 (`layout.tsx`) 預設 Server Components (零 Bundle、高速首屏、SEO 支援)。
  * `'use client'` 嚴格限制於最末端互動葉節點（按鈕、彈窗、表單、資料表格），禁止頂層濫用。
- **三層狀態管理拓撲**:
  * 伺服器狀態：`@tanstack/react-query`（強制用於所有非同步 API 請求、快取、自動重試、去重、樂觀更新）。
  * 全域客戶端狀態：`zustand`（輕量極速狀態庫，管理會話、全域彈窗佇列、佈局主題，取代 Context Provider 地獄）。
  * 表單狀態：`react-hook-form` + `zod` (`@hookform/resolvers/zod`) 宣告式校驗，淘汰多個 `useState`。
- **樣式與設計系統**: 集中化 Design Tokens (`src/styles/tokens.css` 4px 網格系統、HSL 色彩、陰影層級) + CSS Modules / Vanilla CSS，**全面嚴格禁止在 JSX 內寫死 `style={{ ... }}` 行內樣式**。
- **無障礙 Headless 原語與 UI 組件 (WCAG 2.1 AA)**:
  * 彈窗與下拉：Radix UI Primitives 封裝，內建 Focus Trap 焦點陷阱與全鍵盤操作。
  * 圖示庫：`lucide-react`（現代主流向量圖示，全面取代手寫 inline SVG）。
  * 全域通知：`sonner`（現代宣告式 Toast，消除 Prop-drilling 傳遞 `showToast` 回呼）。
- **表格與大數據虛擬滾動**: `@tanstack/react-table` 搭配 `@tanstack/react-virtual`（> 100 筆資料強制虛擬滾動）。
- **網路傳輸層與攔截器**: 集中式 Client，內建 JWT 自動注入、401 無感 Token 輪轉、`X-Trace-ID` 鏈路追蹤、`AbortController` 請求主動取消防競爭、RFC 7807 錯誤規範化。
- **容錯與性能基線**: `react-error-boundary` 錯誤邊界兜底、Suspense 骨架屏、重型組件 `next/dynamic` 延遲載入 (Web Vitals: LCP < 2.5s, INP < 200ms, CLS < 0.1)。
- **全生命週期國際化 (Strict i18n)**: next-intl 官方框架；API Client 僅能傳遞機器錯誤碼，UI 層以 `t('errors.' + errorCode)` 解析多語系；審計日誌以 `t('audit.reasons.' + changeReason)` 渲染 Canonical Keys。

---

## 2. 現代企業級介面與人機互動第一性原則 (Modern Enterprise UI & HCI Principles)

本系統揚棄傳統 2000 年代早期「Windows 資料夾頁籤、收據式破折虛線、粗暴死黑按鈕、灰底 disabled 唯讀表單」等老骨董反模式，全面確立以人為本 (Human-Centered)、借鑑現代頂級原生 APP (Apple HIG / Android Material 3) 與現代頂級 SaaS (Linear / Stripe / Vercel) 的**現代企業級人機互動第一性原則**：

### 2.0 跨學科人因、行為科學與現代貿易經濟學哲學基底 (Multidisciplinary Behavioral & Economic Foundations)
現代金融與跨國再保險系統的終端使用者，是有情緒、有壓力、有心理偏誤且認知預算極度有限的人類。介面架構必須深度立足於以下九大跨學科基礎學門：

1. **塔雷伯《反脆弱》(Antifragility, Convexity & Barbell Strategy - Nassim Nicholas Taleb)**:
   - **混亂與錯誤作為演進養分**：脆弱系統在波動下崩塌，強韌系統在壓力下抵抗，**反脆弱系統則從波動、壓力、質疑與錯誤中獲益並進化**。
   - **架構凸性效益 (Convexity)**：每一次使用者對介面的困惑、每一次版面抖動 (CLS) 的波動，都不應只是打地鼠修補，而必須昇華為 Agent SDK 的全域免疫原語（如 <SmoothDataTableContainer> 零累計版面位移容器、雙模態閱覽畫布）與永久門禁探針，使系統在經歷每次質疑後都比先前更智慧、更強壯。
   - **槓鈴策略 (Barbell Strategy)**：一端是極度保守、追求數學真實與不可篡改的領域基底（雙時態不可篡改審計、零浮點數複式記帳、強約束引用防禦）；另一端則是極度靈活、輕盈、可隨時重構與替換的呈現層（解耦可拋棄的 UI 組件、柔性微動態、自適應響應式佈局）。
   - **杜絕醫源性損傷 (Anti-Iatrogenics)**：嚴禁「過度治療」式的局部打地鼠修補（隨意手寫 CSS hack、setTimeout 延遲補丁、或在手冊中無限追加微觀小規則）。任何修復必須直擊原型原語（Patch the Archetype, NOT the Rulebook），防止產生二次技術負債。
2. **《蘋果橘子經濟學》(Freakonomics & Incentive Alignment - Levitt & Dubner)**:
   - **誘因三元結構 (Incentive Triad)**：經濟誘因、社會制度誘因與道德信賴誘因。介面設計與流程治理必須使「做好事（依循規範、落實 TDD、填寫真實變更理由）」成為心智阻力最小的路徑。
   - **古德哈特定律與眼鏡蛇效應防禦 (Goodhart's Law & Cobra Effect)**：當指標變成目標時將引發投機造假。系統在自動化審計中導入 Babel AST 函式體深度檢查，徹底消滅無實質處理的 onClick={() => console.log()}「空殼假按鈕」，瓦解形式主義偽合規誘因。
   - **打破傳統常識偏見 (Overcoming Conventional Wisdom)**：敢於推翻二十年來「唯讀畫面就該用 disabled input 灰底」與「收據式破折虛線」的陳腐陋習，以實證人因數據確立結構化閱覽畫布與減法美學。
3. **跨國貿易與再保險資訊經濟學 (Global Trade & Reinsurance Information Economics)**:
   - **檸檬市場與資訊不對稱 (Akerlof's Market for Lemons)**：再保業務的核心風險在於逆向選擇 (Adverse Selection)。介面必須將 OFAC / 聯合國國際制裁標籤與合約計算影響橫幅以第一優先級透明化，消除資訊黑箱。
   - **寇斯交易成本理論 (Ronald Coase: Transaction Cost Economics)**：組織效率取決於資訊檢索成本、協商成本與監督成本。減法美學、移除收據虛線與內嵌即時進位試算卡 (CalculationPreviewCard)，旨在將使用者的「心智檢索與決策摩擦成本」在介面內原地降至趨近於零。
   - **共有地悲劇與公共治理 (Tragedy of the Commons - Elinor Ostrom)**：幣別與國家是跨合約、跨保單、跨機構的「全域公共資源」。系統實施強約束引用防禦（引用數 > 0 物理禁刪），徹底防止單一管理員誤刪公共主檔導致千萬合約癱瘓。
   - **代理人問題與機制設計 (Principal-Agent Problem & Mechanism Design)**：操作者與治理層利益存在摩擦。系統透過「雙時態不可篡改審計 (Bi-Temporal Audit)」與異動進位時強制輸入 5 字理由的「建設性阻尼」，在機制上鎖定受託責任。
4. **知覺完形心理學 (Gestalt Psychology - Wertheimer, Koffka, Kohler)**:
   - **接近律 (Proximity) 與相似律 (Similarity)**：以微色調卡片 (g-slate-50/80 rounded-xl) 與空間留白取代生硬虛線，大腦無須辨識線條即可自動完成語意完形。
   - **圖底關係 (Figure-Ground)**：側邊抽屜以磨砂半透明遮罩 (ackdrop-blur-xs) 建立立體景深，既聚焦前景操作，又保留背景脈絡之空間方位感。
   - **良好連續律 (Good Continuation) 與閉合律 (Closure)**：維持介面空間物理恆常性 (Zero-CLS)，分頁控制列位置絕對靜止，骨架屏與真實資料列 1:1 幾何等高，消除視覺斷裂。
5. **康納曼雙系統思維模型 (Daniel Kahneman: Thinking, Fast and Slow)**:
   - **系統 1 (快思 - 直覺、感官、低耗能)**：檢視模態作為閱覽畫布，提供高對比字階與語意狀態膠囊 (Pill Badges)，支援 200ms 快速掃描。
   - **系統 2 (慢想 - 審慎、計算、高耗能)**：編輯模態作為操作表單，自動聚焦並提供 Halo 光暈；徹底杜絕無效雜訊（檢視模式必填星號、無效灰框），將珍貴的系統 2 能量保留給核心再保商業決策。
6. **塞勒推力理論與選擇架構 (Richard Thaler: Nudge & Choice Architecture)**:
   - **預設值效應 (Default Effect)**：序號自動推算 (Max + 10)、狀態預設有效、幣別小數預設 2 位，以軟性架構推力引導資料庫走向一致。
   - **建設性阻尼 vs. 污泥 (Constructive Friction vs. Sludge)**：清除 disabled input 等無效「污泥」；在高風險合約影響處保留強制輸入原因之「建設性阻尼」。
7. **決策認知偏誤防禦 (Cognitive Bias Guards - Kahneman & Tversky)**:
   - **沉沒成本謬誤 (Sunk Cost Fallacy)**：以未儲存髒檢查 (Dirty State Guard) 保護使用者已投入的心智投資，避免誤觸遮罩清空表單引發巨大挫折。
   - **雙曲貼現 (Hyperbolic Discounting)**：人類渴望即時反饋。系統提供 < 100ms 物理微動態 (ctive:scale-[0.98]) 與即時 Toast，建立掌控感。
   - **展望理論與損失厭惡 (Prospect Theory & Loss Aversion)**：二次確認對話框精準框架資料損失邊界，消除盲目誤點。
   - **錨定效應與框架效應 (Anchoring & Framing)**：數值呈現時給予標準參照基準（如進位運算範例卡 1234.5678 ➔ 1234.57），消除抽象公式的歧義感。
8. **社會心理學與組織協同動力學 (Social Psychology & Organizational Dynamics)**:
   - **霍桑效應 (Hawthorne Effect & Observational Accountability)**：介面處處可見雙時態不可篡改審計 (Bi-Temporal Audit) 與操作者標記，當使用者感知到自身的作業處於可溯源的專業觀察下，疏失與道德風險顯著降低。
   - **心理安全感 (Psychological Safety - Amy Edmondson)**：優雅容錯與非懲罰性 UI 反饋 (Non-punitive UI feedback)。介面絕不出現冰冷無由的報錯或指責性彈窗，校驗阻擋時提供明確的指引與原位復原途徑。
   - **社會惰化與責任擴散防禦 (Social Loafing & Diffusion of Responsibility - Latané)**：全域主檔變更強制要求責任人標記與語意化變更理由，防止多人維護時的群體責任模糊。
9. **工作記憶與認知負荷理論 (Cognitive Load Theory - Sweller / Miller's Law 7±2)**:
   - **外在認知負荷 (Extraneous Cognitive Load) 最小化**：掃除一切介面干擾與雜訊（破折虛線、無效 disabled 外框、檢視模式必填紅星號）。
   - **內在認知負荷 (Intrinsic Cognitive Load) 資訊分塊 (Chunking)**：遵循米勒法則 (7±2)，將複雜主檔欄位分解為 3~4 個高內聚微色調容器（基本識別、業務設定、審計記錄），防止工作記憶超載。
   - **相關認知負荷 (Germane Cognitive Load) 最大化**：系統主動吸收繁複運算（即時試算預覽卡、關聯影響分析），將使用者的大腦注意力引導至核心商業與風險決策。

### 2.1 古典人因工程與認知定律 (Classical HCI Laws)
1. **費茨法則 (Fitts's Law - 移動時間與目標尺寸、距離的函數)**:
   - 桌面端點擊熱區高度嚴格 >= 36px ~ 40px，行動端/觸控目標嚴格 >= 44px * 44px。
   - 抽屜與彈窗主要動作固定於頂部與底部邊緣（無限寬邊界效應），降低滑鼠瞄準負荷。
   - 危險動作（刪除）與安全動作（返回列表、編輯）必須具有足夠的物理空間隔離。
2. **席克-海曼法則 (Hick-Hyman Law - 決策時間隨選項數量對數增長)**:
   - 嚴格實施**漸進式揭露 (Progressive Disclosure)**：高頻檢索與關鍵資訊優先可見，進階條件平滑展開，消除使用者認知癱瘓。
   - 導入**智慧預設值 (Smart Defaults)**：序號自動推算 (`Max + 10`)、狀態預設有效、幣別小數預設 2 位。
3. **雅各布法則 (Jakob's Law - 心智模型慣性與通用習慣)**:
   - 尊重全球使用者之肌肉記憶：`Esc` 關閉抽屜/彈窗、`Enter` 觸發表單檢索、`Tab` 自然跳轉焦點、紅/琥珀/綠遵循通用語意色彩。
4. **多爾蒂門檻 (Doherty Threshold - 400ms 心流響應極限)**:
   - 微互動（Hover、Active 點擊微縮放 `active:scale-[0.98]`）嚴格在 < 100ms 內提供物理回饋。
   - 極速本地或快取資料交接（100ms ~ 300ms）採用平滑透明度淡入 (200ms Cross-fade)，嚴禁閃爍出 1 幀的 Spinner 或 Skeleton 又瞬間消失。
   - 長時間非同步處理 (> 400ms) 必須呈現與真實資料 1:1 等高之骨架屏。
5. **特斯勒複雜度守恆法則 (Tesler's Law - 軟體主動吸收複雜度 - 對偶 Agent SDK RFC-016: CalculationPreviewCard)**:
   - 系統主動承擔進位範例即時試算、關聯合約引用數即時聚合、主鍵唯讀鎖定與衝突防護，將使用者的認知能量釋放給核心商業決策。
6. **波斯泰爾健壯法則 (Postel's Law - 寬鬆接收，嚴格結構化輸出)**:
   - 表單輸入自動修剪空白 (Auto-trim)、容忍數字格式微差，後端嚴格校驗與結構化儲存。

### 2.2 唐·諾曼 (Don Norman) 人機互動六大核心支柱
1. **可供性 (Affordance) 與意符 (Signifiers)**:
   - 元件本質必須直覺傳達其功能：可點擊的按鈕具有微立體陰影與懸浮暈光，純閱覽文字不加多餘干擾線框。
   - 主鍵代碼旁配備精緻向量鎖頭圖示 (`lucide-react: Lock`)，懸浮呈現「已被引用，鎖定為唯讀」意符。
2. **空間映射 (Mapping)**:
   - 空間拓撲與心智方向一致：上一頁 `<` 在左、下一頁 `>` 在右；「取消」在左、「儲存」在右。
3. **閉環因果反饋 (Closed Feedback Loop)**:
   - 任何使用者操作均給出明確的狀態確立：觸發 (微縮放) -> 處理中 (按鈕內嵌 Spinner 並防重送) -> 成果 (現代 Toast 自動淡出) -> 異常 (409 精準欄位紅框與聚焦)。
4. **物理與邏輯約束 (Constraints)**:
   - 引用數 > 0 時，刪除按鈕直接鎖定 Disabled 並提供上下文說明 Tooltip，引導「設為作廢」；引用數 = 0 時觸發二次確認彈窗。
5. **心智模型一致性 (Mental Model Coherence)**:
   - 使用者開啟主檔維護抽屜的心智預期是「閱讀、查驗並核對該筆資料」，而非「面對一張被禁用的空白資料庫表單」。

### 2.3 雙模態分離人因學 (Dual-Mode Ergonomics: Inspection vs. Manipulation - 對偶 Agent SDK RFC-013: DualModeInspectionCanvas)
- **檢視模態 (Inspection Canvas - 結構化審計閱覽畫布)**:
  - 核心價值：**極致清晰度、高易讀性、無干擾閱讀**。
  - 排版規格：高對比清晰字階 (`text-slate-900`)、簡潔鍵值對 (Key-Value) 排版。
  - **嚴格禁令**：**嚴禁使用 `<input disabled>` 呈現唯讀資料**；**嚴禁出現禁用滑鼠游標 (`cursor-not-allowed`)**；**嚴禁在檢視標籤旁標註必填紅星號 (`*`)**。
  - 互動增強：代碼與數值支援滑鼠懸浮顯現的一鍵微縮複製按鈕。
- **編輯模態 (Manipulation Canvas - 高聚焦互動表單)**:
  - 核心價值：**明確邊界、輸入流暢、即時輔助**。
  - 排版規格：點擊「編輯」後，畫布平滑展開輸入框外框 (`border-slate-300`) 與焦點 Halo (`focus:ring-2 focus:ring-orange-500/20 focus:border-orange-500`)。
  - 焦點流動：自動將游標聚焦於首個可編輯欄位。
  - 髒檢查防誤觸 (Dirty State Guard)：若表單已被修改且尚未儲存，使用者點擊背景遮罩或「返回列表」時，系統觸發防禦性確認阻尼。

### 2.4 減法美學與現代材質層級 (Subtraction Aesthetics & Tonal Surfaces - 對偶 Agent SDK RFC-014: UnderlineTabs 與 RFC-012: ZeroClsSmoothTransition)
- **淘汰 Windows 資料夾頁籤**：
  - 徹底移除 1998 年 Windows 資料夾頁籤樣式（灰底凸起塊、黑框、圓角），全面升級為現代**底線導航頁籤 (Modern Underline Tabs)**，配備平滑品牌橘底線滑動指示條；或**懸浮膠囊分段控制器 (Segmented Control)**。
- **淘汰收據式破折虛線 (`border-dashed`)**：
  - 徹底清除破折虛線，資訊區塊改以「空間留白節奏」、「極淡實線 (`border-slate-100`)」或「微底色圓角卡片容器 (`bg-slate-50/70 rounded-xl p-4 border border-slate-100`)」收納。
- **色彩階調與微立體度 (Slate Palette & Subtle Elevation)**:
  - 淘汰死黑按鈕 (`#374151`)，改採現代企業 Slate 色階搭配細緻微陰影 (`shadow-xs` / `shadow-sm`)。
- **空間物理恆常性 (Spatial Permanence & Zero-CLS)**:
  - 表格容器強制施加高度保全 (`min-h-[420px]`)，無論筆數多寡，下方分頁控制列在空間中絕對靜止。
  - 骨架屏與真實資料列保持 1:1 幾何等高，交接時採用透明度淡入 (200ms Cross-fade)。

### 2.5 兄弟親和同構律 (Sibling Homomorphism across Country, Region, Currency - 對偶 Agent SDK RFC-015: ReferenceDefenseCard)
國家、區域、結算幣別三個模組在抽屜維護架構上必須遵循 100% 相同 DNA：
1. **抽屜統一寬度**：一律為 `max-w-2xl`，具備流暢進出動態 (`duration-200 ease-out`)。
2. **頂部標題與徽章標準**：
   - 標題結構：`[模組名稱] - [檢視/編輯]` + `<span className="badge-screencode">SC-XXXX-XX-XX</span>` + `<span className="badge-mode">檢視模式/編輯模式</span>`。
   - 嚴格禁止生硬文字括號（如 `[ 檢視模式 ]`）。
3. **右上角動作按鈕階調**：
   `[ 返回列表 (次要白底) ]` | `[ 刪除 (紅字/防呆 Tooltip) ]` | `[ 設為作廢/啟用 (白底灰框) ]` | `[ 編輯 (主動作) ]`。
4. **主鍵鎖頭標準**：
   代碼旁配備向量鎖頭圖示 (`Lock`)，懸浮呈現標準 Tooltip。
5. **引用防護資訊卡**：
   統一採用琥珀色微底容器卡片 (`bg-amber-50/70 border border-amber-200/80 rounded-xl p-4`) 呈現外部模組引用統計。
6. **系統資訊微卡片**：
   統一採用雙欄微卡片 (`bg-slate-50/80 rounded-xl p-4 border border-slate-100`)，以清晰字階呈現建立人/時間、更新人/時間與版本號。
7. **頁籤與 Tab 1 純粹性**：
   Tab 1 專注於基本資料，Tab 2 專注於異動紀錄。嚴格禁止在國家 Tab 1 內嵌 6 欄審計預覽表。

---

## 3. 選單管理多頁籤導航架構與路由拓撲 (Tab Navigation Topology)

選單管理涵蓋六大主檔模組，頂部採用現代底線指示頁籤 (`MenuHeaderTabs`)，子路由嚴格映射：
- **選單入口路徑**: `/settings/menus`
  - `/settings/menus/countries`：國家選單管理 (`SC-0101-01-01` ~ `SC-0101-01-03`, 已上線)
  - `/settings/menus/regions`：區域選單管理 (`SC-0101-01-04` ~ `SC-0101-01-06`, 已上線)
  - `/settings/menus/currencies`：結算幣別選單管理 (`SC-0101-02-01` ~ `SC-0101-02-03`, 已上線)
  - `/settings/menus/financial-institutions`：金融機構選單 (`SC-0101-03-01`, ComingSoon 優雅降級 / TASK-000013 實作中)
  - `/settings/menus/rating-agencies`：信用評等機構選單 (`SC-0101-04-01`, ComingSoon 優雅降級 / TASK-000014 排程)
  - `/settings/menus/lines-of-business`：險別選單 (`SC-0101-05-01`, ComingSoon 優雅降級 / TASK-000015 排程)

### 3.1 操作閉環、虛假可供性杜絕與韌性著陸不變量 (Operational Closure, Anti-False-Affordance & Resilient Landing Invariant)
- **第一性原理 (First-Principles Foundation)**：
  依據唐·諾曼人機工程學 (Don Norman HCI) 與狀態機封閉性定理，介面所呈現的任何可操作意符（按鈕、頁籤、卡片、超連結），其對應的系統狀態轉移必須是有界、受控且封閉自洽的。**嚴禁呈現出任何會導向「未定義狀態 (Undefined State)」或底層技術錯誤（如原生 HTTP 404 / 500 / 白屏）的虛假可供性 (False Affordance)**。
- **未就緒功能之三態降級階梯 (Three-State Degradation Ladder)**：
  凡功能尚未具備可用條件（排程中、依賴未就緒、環境不滿足），介面嚴格遵循三態階梯處置，禁止裸奔：
  1. **第一態：不露出 (Hidden)**：無此功能時徹底不渲染入口。
  2. **第二態：顯式抑制 (Disabled with Tooltip)**：渲染禁用態 (`disabled={true}`) 搭配懸浮 Tooltip 說明規劃中。
  3. **第三態：規範化降級著陸 (Resilient Landing)**：若為全域導航（如 6 大選單頁籤），進入未就緒路由段必須配置標準 `<ComingSoonPlaceholder>` 進行確定性優雅降級：
     - **外框恆常性**：繼承 `<MenuCardFrame>`，維持頂部現代底線頁籤切換無障礙流暢性，頁籤指標與麵包屑即時同態高亮。
     - **語意透明度**：顯示橘色 Sparkles 徽章、呈現「模組規劃建置中」脈衝膠囊、即將推出標題與功能簡述。
     - **追溯性中繼資料**：清楚列示「排程任務編號」（如 `TASK-000013`）、「活體架構規範錨點」與「排程進度」。
     - **防呆逃生路徑**：右上角提供次要白底「返回安全頁面（如國家選單）」按鈕，徹底消除使用者迷航感。
- **同構審查工具豁免支援**：
  CI 與品質探針（如 `audit-master-data-standards.js`）自動辨識 `ComingSoonPlaceholder`，對降級佔位頁給予分頁與查詢表單檢查豁免，確保 CI 正常放行。

```mermaid
graph TD
    Parent[MenuCardFrame 頂部現代底線頁籤導航]
    Parent --> TabCountry[國家選單 Tab: /settings/menus/countries]
    Parent --> TabRegion[區域選單 Tab: /settings/menus/regions]
    Parent --> TabCurrency[結算幣別選單 Tab: /settings/menus/currencies]
    Parent --> TabFI[金融機構選單 Tab: /settings/menus/financial-institutions]
    Parent --> TabRating[信用評等機構選單 Tab: /settings/menus/rating-agencies]
    Parent --> TabLOB[險別選單 Tab: /settings/menus/lines-of-business]
    
    TabCountry --> C_Search[CountrySearchForm 多維檢索列]
    TabCountry --> C_Table[CountryListTable 零位移清單表格]
    TabCountry --> C_Modal[CountryFormModal 新增彈窗]
    TabCountry --> C_Drawer[CountryDetailDrawer 雙模態詳情抽屜]
    C_Drawer --> C_Banner[SanctionAlertBanner 制裁橫幅]
    C_Drawer --> C_RefCard[ReferenceDefenseCard 引用防護卡]

    TabRegion --> R_Search[RegionSearchForm 關鍵字檢索列]
    TabRegion --> R_Table[RegionListTable 零位移清單表格]
    TabRegion --> R_Modal[RegionFormModal 新增彈窗]
    TabRegion --> R_Drawer[RegionDetailDrawer 雙模態詳情抽屜]
    R_Drawer --> R_RefCard[ReferenceDefenseCard 引用防護卡]

    TabCurrency --> Cur_Search[CurrencySearchForm 4欄多維檢索列]
    TabCurrency --> Cur_Table[CurrencyListTable 零位移清單表格]
    TabCurrency --> Cur_Modal[CurrencyFormModal 新增彈窗]
    TabCurrency --> Cur_Drawer[CurrencyDetailDrawer 雙模態詳情抽屜]
    Cur_Drawer --> Cur_Banner[CalculationImpactBanner 計算變更警告]
    Cur_Drawer --> Cur_RefCard[ReferenceDefenseCard 引用防護卡]

    TabFI --> FI_Place[ComingSoonPlaceholder 模組規劃建置中卡片 - TASK-000013 實作中]
    TabRating --> Rat_Place[ComingSoonPlaceholder 模組規劃建置中卡片 - TASK-000014 排程交付]
    TabLOB --> LOB_Place[ComingSoonPlaceholder 模組規劃建置中卡片 - TASK-000015 排程交付]
```


---


### 3.2 表格平滑過渡與零閃動鐵律 (Stale-While-Revalidate & Zero-Strobe Table Invariant)
依據覆盤案 009 與 RFC-012，為徹底消滅高速網路/快取情境下清單表格的「白閃頻抽（Strobe Flash Artifact）」與版面高度坍塌，所有主檔及業務清單表格必須嚴格遵從 **三層過渡架構 (Three-Tier Transition Architecture)**：

```mermaid
graph TD
    Trigger[觸發查詢 / 篩選 / 翻頁 / 排序] --> CheckData{表格是否有既有資料? data.length > 0}
    
    CheckData -- 是 (重新檢索) --> SWR[Stale-While-Revalidate 樂觀留存]
    SWR --> SWR_Visual[1. 舊資料原地保留不拔除<br/>2. 容器柔和淡化 opacity-60 + pointer-events-none<br/>3. 頂部 Shimmer 漸層脈衝呼吸線流動]
    SWR_Visual --> SWR_Arrive[新資料返抵]
    SWR_Arrive --> SWR_Fade[250ms 平滑交叉淡入 Cross-fade 更新內容]

    CheckData -- 否 (首次掛載 / 初始載入) --> Skel[1:1 仿真骨架屏 Skeleton Mesh]
    Skel --> Skel_Visual[渲染欄位寬度、對齊與列數 1:1 一致之淺灰脈衝骨架，零高度位移]
    Skel_Visual --> Skel_Done[資料返抵替換為真實內容]
```

#### 核心不變量 (Core Invariants):
1. **嚴禁命令式清空已呈現資料 (Forbidden Row Wiping)**：
   當清單已有資料（`data.length > 0`）時，任何查詢、篩選、防抖與分頁事件，**嚴禁**將 `<tbody>` 清空並換成單行旋轉菊花 Loading。舊資料必須維持在 DOM 中，由外層容器透過柔和透明度與頂部微光脈衝線吸收非同步等待。
2. **首屏 1:1 仿真骨架屏 (1:1 Skeleton Mesh)**：
   單行「資料載入中...」文字或置中旋轉菊花已被全面廢止。完全無資料且加載中情境必須使用與正式欄位完全同構之骨架屏。
3. **容器保底高度 (Minimum Substrate Height)**：
   所有清單表格容器一律由 `SmoothDataTableContainer` 包裹，預設最小高度保底（`min-h-[380px]`），杜絕任何內容筆數波動引發的累計佈局位移（CLS）。

## 4. 畫面詳細規格與 Wireframes 對齊標準

### 4.1 國家管理介面 (Wireframes 1, 2, 3)
1. **國家清單頁面 (`SC-0101-01-01`, 對齊 Wireframe 1)**:
   - 包含多維檢索列：300ms 防抖關鍵字輸入框、所屬區域下拉選單、制裁狀態快選標籤（全部 / 僅制裁 / 正常）、作廢狀態過濾。
   - 國家清單表格：8 欄位、制裁脈衝 Badge、作廢狀態開關 Toggle、操作按鈕 (檢視詳情、編輯、刪除)。
2. **新增國家彈窗 (`SC-0101-01-02`, 對齊 Wireframe 2)**:
   - 具備表單防呆三道防線：空值送出前紅框聚焦 (`border-red-400 focus:ring-red-200`)、打字即時清錯、409 代碼重複反紅提示。
   - 制裁連動：勾選「是否受制裁」後解鎖「制裁生效日」輸入框並強制必填。
   - 支援「儲存」與「儲存並繼續新增」雙按鈕操作。
3. **國家詳情與維護抽屜 (`SC-0101-01-03`, 對齊 Wireframe 3)**:
   - 頁籤切換：`基本資料` 與 `異動紀錄`。
   - 受制裁頂部渲染 `SanctionAlertBanner`。
   - 國家代碼鎖定唯讀 (🔒 圖示)。
   - 底部渲染 `ReferenceSummaryCard` 顯示外部模組（金融機構、再保人、合約）引用筆數。
   - 防刪保護：引用數 > 0 刪除按鈕鎖定 Disabled 並提供防呆 Tooltip；零引用支援二次確認安全刪除。

### 4.2 區域管理介面 (Wireframes 4, 5, 6)
1. **區域清單頁面 (`SC-0101-01-04`, 對齊 Wireframe 4)**:
   - 關鍵字檢索、作廢狀態過濾、清單呈現所屬國家總數 (`countryCount`)、排序號與狀態開關。
2. **新增區域彈窗 (`SC-0101-01-05`, 對齊 Wireframe 5)**:
   - 代碼唯一性檢核、中文名稱、英文名稱、顯示順序（未填自動帶入 `max + 10`）。
3. **區域詳情與維護抽屜 (`SC-0101-01-06`, 對齊 Wireframe 6)**:
   - 樣式、頁籤與按鈕排版與國家抽屜 100% 和諧一致。
   - 呈現所屬國家筆數引用卡片，關聯國家數 > 0 時禁用刪除按鈕並引導切換為作廢。

### 4.3 結算幣別管理介面 (Wireframes mockups 1, 2, 3 - TASK-007)
1. **結算幣別選單主畫面 (`SC-0101-02-01`, mockups/1.jpg)**:
   - 4 欄多維條件檢索列：代碼、中文名稱、英文名稱、進位設定、資料狀態 (Radio)。
   - 清單表格呈現 8 欄位：顯示順序、代碼、名稱、進位、小數、金額範例 (依規則即時演算)、狀態 Badge、操作 (檢視/編輯)。
   - 提供 [匯出 Excel] 報表下載功能與 [批次匯入] / [+ 新增幣別] 按鈕。
2. **新增幣別彈窗 (`SC-0101-02-02`, mockups/2.jpg)**:
   - 右上按鈕配置：[ 取消 ] (次要按鈕) | [ 儲存並繼續新增 ] (強調外框) | [ 儲存 ] (主按鈕，綁定 `tokens.color.primary`)。
   - 顯示順序自動推算 (Max + 10)。
   - 即時試算預覽組件 (`CalculationPreviewCard`)：正負數基準值 (1,234.5678 與 -1,234.5678) 套用進位設定與小數位數即時格式化。
   - 「儲存並繼續新增」連動：維持彈窗開啟、序號累加 + 10、清空其餘欄位、自動聚焦代碼框。
   - 代碼重複 409 Conflict 精準紅框與橫幅提示。
3. **結算幣別雙模態檢視/維護抽屜 (`SC-0101-02-03`, mockups/3.jpg, 遵循 §2 現代架構)**:
   - **抽屜規格統一**：寬度標準化為 `max-w-2xl`，進出過渡動畫 `duration-200 ease-out`。
   - **Header 結構對齊**：呈現 `結算幣別選單 - 檢視/編輯`、`SC-0101-02-03` 代碼徽章與 `檢視模式`/`編輯模式` 膠囊徽章 (Pill Badge)，移除生硬文字括號。
   - **右上角動作按鈕**：`[ 返回列表 ] | [ 刪除 (帶防呆 Tooltip) ] | [ 設為作廢/啟用 ] | [ 編輯 ]`。
   - **頁籤設計現代化**：現代底線指示標籤 `[ 基本資料 ] | [ 異動紀錄 ]`，淘汰資料夾樣式。
   - **雙模態人因呈現**：
     * 檢視模式：純文字高對比度 Key-Value 呈現，徹底移除 `<input disabled>` 與必填紅星號 (`*`)。
     * 幣別代碼旁掛載向量鎖頭圖示 (`Lock`)，懸浮提示「已被引用，鎖定為唯讀」。
     * 編輯模式：平滑切換為具備 Focus Halo 之輸入框，游標自動聚焦首個編輯欄位。
   - **引用防護資訊卡**：採用標準琥珀色微底容器卡片 (`bg-amber-50/70 border border-amber-200/80 rounded-xl p-4`) 呈現合約、交易與銀行設定引用統計。
   - **計算設定變更確認彈窗 (`CurrencyRuleChangeModal`)**：異動進位或小數時強制輸入至少 5 字原因。
   - **系統資訊微卡片**：標準雙欄卡片呈現建立與更新稽核資訊。


<!-- SECTION: UI_SPEC -->
### 4.4 國家與區域 Excel 匯出與審計歷程表格規格 (TASK-008)
1. **清單工具列「匯出 Excel」規格 (`CountryListTable.tsx` & `RegionListTable.tsx`)**:
   - 點擊觸發真實 API 調用 (`GET /api/v1/countries/export`, `GET /api/v1/regions/export`)。
   - 具有防連點保護：匯出期間按鈕文字轉換為「匯出中...」並帶有旋轉 Loading Spinner，按鈕設置 `disabled={isExporting}` 防止伺服器負載。
   - 匯出完成後彈出綠色 Toast 提示訊息「檔案匯出成功」。
2. **詳情抽屜真實審計歷程表格 (`CountryDetailDrawer.tsx` & `RegionDetailDrawer.tsx`)**:
   - 抽屜「異動紀錄」頁籤真實渲染 `AuditLogResponse[]` 歷程。
   - 表格包含 7 大標準欄位：異動時間 (`changedAt`)、操作人 (`changedBy`)、部門/單位 (`department`)、變更欄位 (`fieldName`, 由 `t('audit.fields.' + fieldName)` 解析)、異動前值 (`beforeValue`, 刪除線紅字)、異動後值 (`afterValue`, 粗體綠字)、異動原因 (`changeReason`, 由 `t('audit.reasons.' + changeReason)` 解析)。
   - 具備資料載入中動畫與查無異動紀錄空狀態優雅降級。
   - **Tier-1 Approved BOM 元件防線**：
     * 全域提示使用 `sonner` (`toast.success()`, `toast.error()`)，消除 Prop-drilling。
     * 工具列與表格操作圖示全面使用 `lucide-react`，嚴禁手寫行內 SVG。
     * 抽屜編輯表單全面採用 `react-hook-form` + `zod`，淘汰宣告 10 個 `useState`。
<!-- /SECTION: UI_SPEC -->

<!-- SECTION: MASTER_DATA_PAGE_PATTERN -->
## 5. 主檔業務原型同構對齊與自適應樣板架構 (Master Data Archetype Homomorphic Parity & Adaptive Primitives)
為徹底消除微前端或垂直功能切片（如國家、區域、幣別、機構等）間的視覺漂移與行為不一致，同時避免「手寫死規則、寫死像素色碼」的微觀打地鼠模式，所有主檔選單頁面全面實施**原型同構對齊 (Homomorphic Parity) 與自適應樣板架構**：

### 5.1 原型六大功能分區與家族共用原語契約 (Six Functional Zones & Shared Primitives)
凡屬主檔維護原型 (`MasterDataMaintenance`) 之模組，其畫面一律映射為六大標準功能分區，並由家族共用原語統一承載：

1. **Zone 1: 頂部操作區 (`<MasterDataHeaderActions>`)**：
   - 負責頁面頂部主動作按鈕。支援 `onAdd` 主按鈕與 `extraActions`（如批次匯入等次要按鈕）。
   - 按鈕文字由多國語系純文字解析，圖示由 Lucide 原語統一封裝，嚴禁在業務程式碼或翻譯字典手動拼接 `+` 等裝飾字元。
2. **Zone 2: 條件查詢區 (SearchForm)**：
   - 統一包含關鍵字與狀態過濾，動作按鈕為 [重設]（次要按鈕，白底灰框）與 [查詢]（主要按鈕，深炭灰），支援 Enter 鍵快捷查詢與 300ms 防抖。
   - 樣式參數綁定自適應 Token，確保表單在不同螢幕寬度下自動折行適配。
3. **Zone 3: 表格工具列 (`<MasterDataTableToolbar>`)**：
   - 左側渲染查詢筆數提示（`totalElements`），右側整合標準 [匯出 Excel] 動作按鈕。
   - 內建防連點安全防護：匯出進行中自動切換為 Loading 旋轉圖示與 Disabled 狀態，匯出完成自動以 `sonner` 提示結果。
4. **Zone 4: 核心資料表格 (DataTable)**：
   - 標準化呈現業務欄位、狀態 Badge（啟用/停用）與操作欄。
   - 操作欄位固定右側，提供「檢視/編輯」動作按鈕與狀態切換開關。
5. **Zone 5: 雙側自適應分頁列 (`<MasterDataPagination>`)**：
   - **雙側佈局標準**：左側展示「查詢結果：共 {totalElements} 筆」，右側整合「每頁筆數」下拉選單（10 / 20 / 50 筆）與「‹ 當前頁 / 總頁數 ›」翻頁導航。
   - **型別強制必填**：`pageSize` 與 `onPageSizeChange` 為強制必填，嚴禁寫死筆數。
   - **防塌陷防護 (Anti-Collapse)**：即便只有 1 頁或 0 筆資料，元件亦完整保留雙側空間結構（按鈕 Disabled），嚴禁單頁隱藏導致版面高寬跳動。
6. **Zone 6: 詳情抽屜與刪除防呆對話框 (`<MasterDataDetailDrawer>` & `<MasterDataDeleteConfirmModal>`)**：
   - 抽屜整合「基本資料」與「異動紀錄」現代底線頁籤 (Modern Underline Tabs)，主檔業務代碼唯讀鎖定。
   - 資料被引用時鎖定刪除並提供 Tooltip 說明；零引用支援安全刪除。
   - 刪除確認全面由獨立對話框原語封裝，嚴禁使用 `window.confirm()` 或將彈窗 JSX 雜揉於抽屜檔案內。

### 5.2 自適應 Design Tokens 規範 (Adaptive Tokens vs Hardcoded Literals)
為維護全系統在多端設備與主題下的自適應響應能力，所有共用原語與業務切片必須遵守以下自適應樣式標準：
- **尺寸自適應**：
  * 抽屜寬度綁定 `tokens.layout.drawerWidth`（桌面端依斷點自適應調配，行動端自動滿屏 100vw），**嚴禁在業務代碼寫死固定像素（如 672px, 896px）**。
  * 彈窗尺寸綁定 `tokens.layout.modalWidth`（依內容多寡自適應伸縮），**嚴禁硬編碼 768px**。
- **配色語意化**：
  * 主動作按鈕綁定 `tokens.color.primary`（企業深炭灰），強調按鈕綁定 `tokens.color.accent`（活力橘），次要按鈕綁定 `tokens.color.secondary`（白底灰框）。
  * **嚴禁硬編碼 Hex 色碼（如 `#374151`, `#FF5A1F`）於業務 JSX 中**。

### 5.3 AI 輔助同構原型橫向差異自檢協定 (AI-Assisted Sibling Diff Protocol)
- **破除打地鼠微規律**：架構規範禁止針對個別頁面寫死瑣碎微觀限制。改由代理人與 CI 門禁共同執行「兄弟切片橫向差異比對 (Sibling Horizontal Parity Diff)」：
  1. 代理人接收任何主檔維護任務時，自動檢索同一原型目錄下的兄弟模組（如 `src/components/menus/*`）。
  2. 橫向比對 6 大功能分區之組件依賴；凡兄弟家族已有共用原語（如分頁列、工具列、刪除彈窗），當前任務模組必須 100% 同步引用。
  3. 嚴禁在單一模組遺留 hand-rolled 私有實現，確保任何同質畫面在行為、佈局與視覺上達到天然一致。
<!-- /SECTION: MASTER_DATA_PAGE_PATTERN -->
