<!--
governance_metadata:
  last_reviewed: "2026-10-14"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-14"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# 專案全局資料庫架構與實體模型規格書 (Database Architecture - Master)

> **專案代號**：Reinsurance Core Platform  
> **關聯資料表**：`system_menus`, `system_regions`, `system_countries`, `system_currency`, `system_financial_institution`, `system_rating_agency`  
> **目標資料庫**：PostgreSQL 16  
> **文件版本**：v1.2 (Living Master Spec)  
> **負責角色**：Lead DBA / Data Architect  

---

## 1. 資料庫技術規範
- **RDBMS**: PostgreSQL 16
- **資料庫遷移工具**: Flyway (`src/main/resources/db/migration/`)
- **字元集與時區**: UTF-8, UTC (時間欄位一律使用 `TIMESTAMP WITH TIME ZONE`)
- **命名約定**: 表名與欄位一律小寫下劃線 (`snake_case`)，內部流水主鍵為 `id` (BIGSERIAL / BIGINT)。
- **資料庫領域前綴與兩階段演化協議 (ADR-002 & REINSURANCE_DOMAIN_STANDARDS §1)**：
  * **當前聚合期 (Phase 1 In-Process Monolith)**：實體表包含 `system_menu`, `system_country`, `system_regions`, `currencies`, `country_audit_logs`, `region_audit_logs`, `currency_audit_logs`。
  * **微服務物理芽裂期 (Phase 2 Microservice Sprouting - Year 1 目標)**：抽離為 `masterdata-service` 獨立資料庫時，透過 Flyway 遷移（含零停機 PostgreSQL VIEW 相容別名）全面對齊為 `md_*` 規範表名 (`md_country`, `md_region`, `md_currency`, `md_menu`, `md_country_audit_log` 等)。

---

## 2. 全局實體關聯模型 (Master ERD)

```mermaid
erDiagram
    system_menus ||--o{ system_menus : "parent_code"
    system_regions ||--o{ system_countries : "region_code"
    system_countries ||--o{ system_financial_institution : "country_code"
    system_countries ||--o{ country_audit_logs : "country_id"
    system_regions ||--o{ region_audit_logs : "region_id"
    currencies ||--o{ currency_audit_logs : "currency_code"
    
    system_regions {
        bigserial id PK "內部流水號"
        varchar region_code UK "區域代碼 (業務唯一鍵, 最大20字元)"
        varchar name_zh "區域名稱 (繁體中文)"
        varchar name_en "區域名稱 (英文)"
        int sort_order "顯示順序 (越小越前)"
        boolean is_disabled "是否停用作廢"
        bigint version "樂觀鎖版本號"
        timestamp created_at "建立時間 (UTC)"
        varchar created_by "建立人員"
        timestamp updated_at "最後異動時間 (UTC)"
        varchar updated_by "最後異動人員"
    }

    system_countries {
        bigserial id PK "內部流水號"
        varchar country_code UK "國家代碼 (ISO 3166-1, 2~3碼大寫英文)"
        varchar name_zh "國家中文名稱"
        varchar name_en "國家英文名稱"
        varchar region_code FK "所屬區域代碼 (關聯 system_regions)"
        boolean is_sanctioned "是否受法遵制裁"
        date sanction_date "制裁生效日期"
        int sort_order "顯示順序"
        boolean is_disabled "是否作廢"
        bigint version "樂觀鎖版本號"
        timestamp created_at "建立時間 (UTC)"
        varchar created_by "建立人員"
        timestamp updated_at "最後異動時間 (UTC)"
        varchar updated_by "最後異動人員"
    }

    system_financial_institution {
        bigserial id PK "機構流水號"
        varchar code UK "金融機構代碼"
        varchar name "機構名稱"
        varchar swift_code "SWIFT 代碼"
        varchar country_code FK "所屬國家代碼"
        int sort_order "排序"
        varchar status "狀態"
    }
```

---

## 3. 現有核心資料表資料字典 (Data Dictionary)

### 3.1 區域主檔表 (`system_regions`)

| 欄位名稱 (Physical Name) | 資料型別 (Type) | 允許空值 | 預設值 | 業務定義與規範說明 |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `BIGSERIAL` | NO | — | 系統內部主鍵。 |
| `region_code` | `VARCHAR(20)` | NO | — | **業務主鍵**。全域唯一索引，大寫英數字與下底線。 |
| `name_zh` | `VARCHAR(100)` | NO | — | 區域名稱（中文）。 |
| `name_en` | `VARCHAR(100)` | NO | — | 區域名稱（英文）。 |
| `sort_order` | `INT` | NO | `0` | 下拉選單顯示順序，數值越小排序越前。 |
| `is_disabled` | `BOOLEAN` | NO | `FALSE` | 作廢標記：`FALSE` (有效), `TRUE` (作廢)。 |
| `version` | `BIGINT` | NO | `0` | JPA 樂觀鎖版本號。 |
| `created_by` | `VARCHAR(50)` | NO | `'SYSTEM'` | 記錄初始建立帳號。 |
| `created_at` | `TIMESTAMP WITH TIME ZONE` | NO | `CURRENT_TIMESTAMP` | 記錄初始建立時間（UTC）。 |
| `updated_by` | `VARCHAR(50)` | NO | `'SYSTEM'` | 記錄最後更新帳號。 |
| `updated_at` | `TIMESTAMP WITH TIME ZONE` | NO | `CURRENT_TIMESTAMP` | 記錄最後更新時間（UTC）。 |

---

### 3.2 國家主檔表 (`system_countries`)

| 欄位名稱 (Physical Name) | 資料型別 (Type) | 允許空值 | 預設值 | 業務定義與規範說明 |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `BIGSERIAL` | NO | — | 系統內部主鍵。 |
| `country_code` | `VARCHAR(10)` | NO | — | **業務主鍵**。ISO 3166-1 (2~3碼大寫英文，如 `TW`, `US`, `JPN`)。全域唯一。 |
| `name_zh` | `VARCHAR(100)` | NO | — | 國家中文名稱（如 `台灣`, `美國`）。 |
| `name_en` | `VARCHAR(100)` | NO | — | 國家英文名稱（如 `Taiwan`, `United States`）。 |
| `region_code` | `VARCHAR(20)` | NO | — | 所屬風險區域代碼，邏輯參照 `system_regions.region_code`。 |
| `is_sanctioned` | `BOOLEAN` | NO | `FALSE` | 是否受國際組織或本國法遵制裁註記。 |
| `sanction_date` | `DATE` | YES | `NULL` | 制裁生效日期。勾選受制裁時建議填寫。 |
| `sort_order` | `INT` | NO | `0` | 顯示排序值。 |
| `is_disabled` | `BOOLEAN` | NO | `FALSE` | 作廢標記：`FALSE` (有效), `TRUE` (已作廢)。 |
| `version` | `BIGINT` | NO | `0` | JPA 樂觀鎖版本號。 |
| `created_by` | `VARCHAR(50)` | NO | `'SYSTEM'` | 記錄初始建立帳號。 |
| `created_at` | `TIMESTAMP WITH TIME ZONE` | NO | `CURRENT_TIMESTAMP` | 記錄初始建立時間（UTC）。 |
| `updated_by` | `VARCHAR(50)` | NO | `'SYSTEM'` | 記錄最後更新帳號。 |
| `updated_at` | `TIMESTAMP WITH TIME ZONE` | NO | `CURRENT_TIMESTAMP` | 記錄最後更新時間（UTC）。 |

---

### 3.3 結算幣別主檔 (`currencies`)
```sql
CREATE TABLE IF NOT EXISTS currencies (
    id BIGSERIAL PRIMARY KEY,
    code VARCHAR(3) NOT NULL,
    name_zh VARCHAR(50) NOT NULL,
    name_en VARCHAR(100) NOT NULL,
    sort_order INT NOT NULL DEFAULT 10,
    rounding_rule VARCHAR(30) NOT NULL DEFAULT 'ROUND_HALF_UP',
    decimal_places INT NOT NULL DEFAULT 2,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    last_calc_rule_changed_at TIMESTAMP WITH TIME ZONE,
    version BIGINT NOT NULL DEFAULT 0,
    created_by VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT uk_currencies_code UNIQUE (code),
    CONSTRAINT chk_currencies_decimal_places CHECK (decimal_places BETWEEN 0 AND 4),
    CONSTRAINT chk_currencies_status CHECK (status IN ('ACTIVE', 'INACTIVE')),
    CONSTRAINT chk_currencies_rounding_rule CHECK (rounding_rule IN ('ROUND_HALF_UP', 'ROUND_UP', 'ROUND_DOWN', 'ROUND_HALF_EVEN'))
);
```

### 3.4 結算幣別審計日誌檔 (`currency_audit_logs` - 對偶 Agent SDK RFC-005: Audit Trail Canonical 與 RFC-017: GenericFieldDiffAuditor)
```sql
CREATE TABLE IF NOT EXISTS currency_audit_logs (
    id BIGSERIAL PRIMARY KEY,
    currency_code VARCHAR(3) NOT NULL,
    changed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    changed_by VARCHAR(50) NOT NULL,
    department VARCHAR(50) DEFAULT '財會部',
    field_name VARCHAR(50) NOT NULL,
    before_value VARCHAR(255),
    after_value VARCHAR(255) NOT NULL,
    change_reason TEXT NOT NULL
);
```

---

## 4. 全局索引與完整性約束 (Indexes & Constraints)
```sql
-- 區域主檔索引
CREATE UNIQUE INDEX IF NOT EXISTS uk_system_regions_code ON system_regions(region_code);
CREATE INDEX IF NOT EXISTS idx_system_regions_sort ON system_regions(sort_order);
CREATE INDEX IF NOT EXISTS idx_system_regions_disabled ON system_regions(is_disabled);

-- 國家主檔索引與約束
CREATE UNIQUE INDEX IF NOT EXISTS uk_system_countries_code ON system_countries(country_code);
CREATE INDEX IF NOT EXISTS idx_country_region_code ON system_countries(region_code);
CREATE INDEX IF NOT EXISTS idx_country_sanctioned ON system_countries(is_sanctioned);
CREATE INDEX IF NOT EXISTS idx_country_disabled ON system_countries(is_disabled);
CREATE INDEX IF NOT EXISTS idx_country_sort_order ON system_countries(sort_order);

-- 外部模組外鍵參照索引
CREATE INDEX IF NOT EXISTS idx_fin_inst_country ON system_financial_institution(country_code);

-- 結算幣別主檔與審計日誌索引 (1,000 QPS 覆蓋索引 - ADR-003)
CREATE UNIQUE INDEX IF NOT EXISTS uk_currencies_code ON currencies(code);
CREATE INDEX IF NOT EXISTS idx_currencies_sort_order ON currencies(sort_order);
CREATE INDEX IF NOT EXISTS idx_currencies_status ON currencies(status);
CREATE INDEX IF NOT EXISTS idx_currencies_name_zh ON currencies(name_zh);
CREATE INDEX IF NOT EXISTS idx_currency_audit_code_time ON currency_audit_logs(currency_code, changed_at DESC);

---

## 5. 服務品質與資料庫容量規劃 (QoS & Capacity Baseline - 1,000 QPS)

1. **連線池容量規劃 (HikariCP)**:
   - 伺服器規格基準：4 Core CPU, 8GB RAM。
   - 資料庫連線池上限：`maximum-pool-size: 20`，最小閒置 `minimum-idle: 10`。
   - 連線逾時設定：`connection-timeout: 3000ms`（快速失敗，避免連線堆疊引發雪崩）。
2. **查詢索引覆蓋率**:
   - 所有下拉選單、清單篩選與外鍵關聯查詢 100% 由 B-Tree 索引覆蓋，杜絕全表掃描 (Seq Scan)。
3. **資料分區規劃 (Partitioning Strategy)**:
   - 歷史異動日誌 (`currency_audit_logs`, `sys_audit_logs`) 超過 100 萬筆時，啟用 PostgreSQL `PARTITION BY RANGE (changed_at)` 按月分區，維持熱表查詢 P95 < 50ms。

```


<!-- SECTION: DATA_MODEL -->
### 2.7 國家審計日誌表 (`country_audit_logs` - TASK-008 - 對偶 Agent SDK RFC-005 & RFC-017)
- **用途**：記錄國家主檔欄位異動（中文名稱、英文名稱、所屬區域、顯示順序、制裁標記、資料狀態）之全歷程軌跡。
- **欄位規範**：
  | 欄位名稱 | 類型 | 限制 / 預設值 | 說明 |
  |:---|:---|:---|:---|
  | `id` | BIGSERIAL | PK | 流水主鍵 |
  | `country_id` | BIGINT | NOT NULL | 關聯國家主鍵 (FK 語意) |
  | `country_code` | VARCHAR(10) | NOT NULL | 國家代碼 (如 TW, US) |
  | `field_name` | VARCHAR(100) | NOT NULL | 變更欄位中文名稱 |
  | `before_value` | TEXT | NULL | 異動前值 |
  | `after_value` | TEXT | NULL | 異動後值 |
  | `change_reason` | VARCHAR(500) | NULL | 異動原因 (強制 >= 5 字元) |
  | `department` | VARCHAR(100) | DEFAULT '合規風險部' | 操作人員所屬部門 |
  | `changed_by` | VARCHAR(50) | NOT NULL, DEFAULT 'SYSTEM' | 操作帳號 |
  | `changed_at` | TIMESTAMP WITH TIME ZONE | NOT NULL, DEFAULT CURRENT_TIMESTAMP | 異動時間 (UTC) |
- **索引**：
  - `idx_country_audit_logs_cid` (`country_id`)
  - `idx_country_audit_time` (`country_id`, `changed_at DESC`)

### 2.8 區域審計日誌表 (`region_audit_logs` - TASK-008)
- **用途**：記錄區域主檔欄位異動（中文名稱、英文名稱、顯示順序、資料狀態）之全歷程軌跡。
- **欄位規範**：
  | 欄位名稱 | 類型 | 限制 / 預設值 | 說明 |
  |:---|:---|:---|:---|
  | `id` | BIGSERIAL | PK | 流水主鍵 |
  | `region_id` | BIGINT | NOT NULL | 關聯區域主鍵 (FK 語意) |
  | `region_code` | VARCHAR(10) | NOT NULL | 區域代碼 (如 ASIA, EU) |
  | `field_name` | VARCHAR(100) | NOT NULL | 變更欄位中文名稱 |
  | `before_value` | TEXT | NULL | 異動前值 |
  | `after_value` | TEXT | NULL | 異動後值 |
  | `change_reason` | VARCHAR(500) | NULL | 異動原因 (強制 >= 5 字元) |
  | `department` | VARCHAR(100) | DEFAULT '合規風險部' | 操作人員所屬部門 |
  | `changed_by` | VARCHAR(50) | NOT NULL, DEFAULT 'SYSTEM' | 操作帳號 |
  | `changed_at` | TIMESTAMP WITH TIME ZONE | NOT NULL, DEFAULT CURRENT_TIMESTAMP | 異動時間 (UTC) |
- **索引**：
  - `idx_region_audit_logs_rid` (`region_id`)
  - `idx_region_audit_time` (`region_id`, `changed_at DESC`)
<!-- /SECTION: DATA_MODEL -->
