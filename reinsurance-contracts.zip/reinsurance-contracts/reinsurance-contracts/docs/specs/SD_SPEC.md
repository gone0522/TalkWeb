<!--
governance_metadata:
  last_reviewed: "2026-10-14"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-14"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# 專案全局系統設計與 API 契約規格書 (System Design & API Spec - Master)

> **專案代號**：Reinsurance Core Platform  
> **API 基礎路徑**：`/api/v1`  
> **文件版本**：v2.0 (Living Master Spec - 對齊雙軌架構、M 級 1,000 QPS QoS、6 大 NFR 與死按鈕禁令)  
> **負責角色**：Software Architect / Tech Lead  
> **關聯架構決策**：`Meta-ADR 1 ~ 3 (docs/adr/ADR-001 ~ 003)`, `docs/ENGINEERING_STANDARDS.md`  

---

## 1. 系統架構風格、服務品質與責任邊界 (Architectural Blueprint & QoS Baseline)

### 1.1 架構拓撲與防禦攔截層
```mermaid
flowchart LR
    subgraph Client [Web Portal - Next.js 14 App Router]
        CountryUI[Country Page & Components]
        RegionUI[Region Page & Components]
        CurrencyUI[Currency Page & Components]
        SafeBtn[SafeActionButton / Dummy Guard]
        APIClient[Generated SDK / Axios Client]
    end

    subgraph Filters [Security & Observability Filters]
        TraceFilter[TraceId & MDC Filter (X-Trace-Id)]
        IdemFilter[Idempotency Guard (X-Request-Id)]
    end

    subgraph Backend [Core Service - Spring Boot 3]
        CountryCtrl[CountryController]
        RegionCtrl[RegionController]
        CurrencyCtrl[CurrencyController / CurrencyExportController]
        AuditCtrl[CurrencyAuditController]
        Services[Services: Country / Region / Currency / Audit]
        Repos[Repositories with B-Tree Indexes & Optimistic Lock]
    end

    subgraph Database [PostgreSQL 16]
        DB[(system_countries / system_regions / currencies / currency_audit_logs)]
    end

    Client -->|X-Trace-Id / X-Request-Id| Filters
    Filters --> Backend
    Backend --> Repos
    Repos --> DB
```

### 1.2 服務品質基準 (SLA / QoS Budget - M 級企業核心主檔基準)
依據 `ADR-003`，本專案所有微服務與主檔模組必須符合以下品質指標：
- **吞吐量目標**：常態承載 300~500 QPS，尖峰承載 **1,000 QPS** 併發查詢。
- **讀取延遲預算**：**P95 < 100ms**，P99 < 200ms。
- **寫入延遲預算**：**P95 < 250ms**，P99 < 500ms（含樂觀鎖版本校驗與審計日誌持久化）。
- **前端繪製效能**：首次內容繪製 (FCP) < 1.0s，最大內容繪製 (LCP) < 2.0s。
- **連線池配置 (HikariCP)**：`maximum-pool-size: 20`, `minimum-idle: 10`, `connection-timeout: 3000ms`。
- **萬級擴展預留**：查詢方法採用 Spring `@Cacheable`，支援無縫切換 Redis 快取。

---

## 2. API 通用設計標準與企業級六大 NFR (RESTful Guidelines & NFRs)
- **基礎路徑**: `/api/v1/...`
- **分頁規格**: 支援 Spring Data `Pageable` (`page`, `size`, `sort`)。
  - 統一分頁回應包裝:
    ```json
    {
      "content": [ ... ],
      "totalElements": 100,
      "totalPages": 10,
      "size": 10,
      "number": 0
    }
    ```
- **統一錯誤回應規範 (RFC 7807 Problem Details)**:
  - 錯誤格式統一包含 `errorCode`, `error`, `message`, `status`, `timestamp`, `details`。

### 2.1 企業級六大 NFR 規範 (ADR-003, ENGINEERING_STANDARDS §29, Agent SDK RFCs)
1. **冪等性保護 (Idempotency - 對偶 Agent SDK RFC-018 & RFC-021)**：關鍵寫入請求 (`POST`, `PUT`) 支援請求頭 `X-Request-Id: <UUID>` 與異步發件箱 `TransactionalOutboxMesh`，5 秒內重複提交攔截回傳 409。前端表單送出強制防連點節流。
2. **樂觀鎖併發衝突 (Optimistic Locking - 對偶 Agent SDK RFC-004: OptimisticLockGuard)**：主檔資料表與 DTO 包含 `version: Long`。版本衝突時統一回傳 HTTP 409 Conflict (`ERR_OPTIMISTIC_LOCK_CONFLICT`)。
3. **可觀測性與分散式鏈路追蹤 (Observability & Distributed Tracing - 對偶 Agent SDK RFC-006 & RFC-018)**：請求透傳 W3C `traceparent` 與 `X-Trace-Id`，日誌整合 MDC 輸出 `[traceId]`，納入 P95 延遲與 Micrometer 度量監控。
4. **機密脫敏與安全 (PII & Security - 對偶 Agent SDK RFC-018)**：日誌嚴禁打印敏感個資；微服務間透傳簽章內部 JWT Token 或 mTLS；錯誤訊息遮蔽 Java Exception 堆疊。
5. **容錯與分散式斷路 (Resilience & Circuit Breaking - 對偶 Agent SDK RFC-020: ResilienceCircuitBreaker)**：微服務跨服務呼叫強制設定 500ms 連線 / 1000ms 讀取超時、滑動窗口斷路器降級與 Caffeine 本地快取 Fallback。
6. **平滑演進與日落防線 (Graceful Evolution & Sunset - 對偶 Agent SDK RFC-011 & RFC-019)**：廢棄 API 端點自動注入 IETF RFC 8594 `Deprecation`, `Sunset`, `Link` 標頭；被引用服務更新前透過 Pact 契約驗證防範非相容變更。

---

## 3. 按鈕真實性矩陣與死按鈕禁令 (Action Button Delivery Matrix - ADR-001)

頁面上任何渲染之按鈕嚴禁無事件空殼按鈕；未就緒功能必須設定 `disabled` 搭配 Tooltip 提示「即將推出」：

| 模組 | 畫面代碼 | 按鈕名稱 | 交付型態 | 規格與端點綁定 |
| :--- | :--- | :--- | :--- | :--- |
| **區域選單** | `SC-0101-01-01` | **「查詢 / 重設」** | `[完整交付 (Full-Delivery)]` | 發出 `GET /api/v1/system/regions` |
| **區域選單** | `SC-0101-01-01` | **「新增區域」** | `[完整交付 (Full-Delivery)]` | 彈窗並發出 `POST /api/v1/system/regions` |
| **國家選單** | `SC-0101-01-02` | **「查詢 / 重設」** | `[完整交付 (Full-Delivery)]` | 發出 `GET /api/v1/system/countries` |
| **國家選單** | `SC-0101-01-02` | **「新增國家」** | `[完整交付 (Full-Delivery)]` | 彈窗並發出 `POST /api/v1/system/countries` |
| **幣別選單** | `SC-0101-02-01` | **「查詢 / 重設」** | `[完整交付 (Full-Delivery)]` | 發出 `GET /api/v1/currencies` |
| **幣別選單** | `SC-0101-02-01` | **「新增幣別」** | `[完整交付 (Full-Delivery)]` | 彈窗並發出 `POST /api/v1/currencies` |
| **幣別選單** | `SC-0101-02-01` | **「匯出 Excel」** | `[完整交付 (Full-Delivery)]` | 發出 `GET /api/v1/currencies/export` 真實下載 .xlsx |
| **幣別選單** | `SC-0101-02-01` | **「批次匯入」** | `[介面預留 (UI-Placeholder)]` | **disabled={true}，hover 提示「功能即將推出」，嚴禁死按鈕** |
| **國家選單** | `SC-0101-01-02` | **「匯出 Excel」** | `[完整交付 (Full-Delivery)]` | 發出 `GET /api/v1/countries/export` 真實下載 .xlsx (TASK-008) |
| **區域選單** | `SC-0101-01-01` | **「匯出 Excel」** | `[完整交付 (Full-Delivery)]` | 發出 `GET /api/v1/regions/export` 真實下載 .xlsx (TASK-008) |

---

## 4. 現有核心 API 端點清單 (API Catalog)

> **雙軌相容路由外觀 (Graceful Dual-Route Mapping - RFC-011)**:
> 為遵循 ENGINEERING_STANDARDS §5.5 命名空間規範並相容早期端點，主檔維護端點均由 Controller 註冊雙軌路徑映射：
> - `{"/api/v1/system/countries", "/api/v1/countries"}`
> - `{"/api/v1/system/regions", "/api/v1/regions"}`
> - `{"/api/v1/system/currencies", "/api/v1/currencies"}`


### 4.1 區域管理模組 (`/api/v1/system/regions`)
| HTTP Method | Endpoint | 說明 |
| :--- | :--- | :--- |
| `GET` | `/api/v1/system/regions` | 分頁查詢區域清單 (支援 keyword 關鍵字與狀態篩選) |
| `GET` | `/api/v1/system/regions/{id}` | 查詢單筆區域詳情 (包含所屬國家筆數 `countryCount`) |
| `POST` | `/api/v1/system/regions` | 新增區域主檔 (未傳 `sortOrder` 自動推算 `MAX+10`) |
| `PUT` | `/api/v1/system/regions/{id}` | 修改區域主檔 (支援樂觀鎖 `version` 檢查) |
| `PATCH` | `/api/v1/system/regions/{id}/status` | 快速切換作廢狀態 (`is_disabled`) |
| `DELETE` | `/api/v1/system/regions/{id}` | 刪除區域 (所屬國家數 > 0 時阻擋 400，零引用 204) |

### 4.2 國家管理模組 (`/api/v1/system/countries`)
| HTTP Method | Endpoint | 說明 |
| :--- | :--- | :--- |
| `GET` | `/api/v1/system/countries` | 多維篩選分頁查詢國家 (keyword, regionCode, isSanctioned, status) |
| `GET` | `/api/v1/system/countries/{id}` | 查詢單筆國家詳情 (含外部金融機構等引用計數 `referenceCount`) |
| `POST` | `/api/v1/system/countries` | 新增國家主檔 (ISO 2~3 碼、區域有效性檢核、制裁日期連動) |
| `PUT` | `/api/v1/system/countries/{id}` | 修改國家主檔 (代碼鎖定唯讀、樂觀鎖保護) |
| `PATCH` | `/api/v1/system/countries/{id}/status` | 快速切換國家作廢狀態 |
| `DELETE` | `/api/v1/system/countries/{id}` | 刪除國家主檔 (外部引用計數 > 0 阻擋 400，零引用 204) |

### 4.3 結算幣別管理 API (`/api/v1/currencies` - TASK-007)
| Method | Endpoint | 說明 |
| :--- | :--- | :--- |
| `GET` | `/api/v1/currencies` | 多維條件分頁查詢 (代碼/中英文名稱/進位/狀態/排序) |
| `GET` | `/api/v1/currencies/{code}` | 查詢單筆詳情 (含合約/交易/銀行多模組引用統計與最近 5 筆審計) |
| `GET` | `/api/v1/currencies/next-sort-order` | 取得建議下一筆顯示順序 (現有最大值 + 10) |
| `POST` | `/api/v1/currencies` | 新增結算幣別 (ISO 3 碼驗證、防呆、小數 0~4、冪等性支援) |
| `PUT` | `/api/v1/currencies/{code}` | 更新幣別 (全欄位異動自動寫入審計日誌、變更計算設定強制附帶原因、樂觀鎖保護) |
| `PATCH` | `/api/v1/currencies/{code}/status` | 快速切換狀態 (ACTIVE / INACTIVE) |
| `DELETE` | `/api/v1/currencies/{code}` | 安全刪除 (零引用成功刪除，已被引用 409 阻擋) |
| `GET` | `/api/v1/currencies/{code}/audit-logs` | 查詢最近異動審計紀錄 (預設 5 筆) |
| `GET` | `/api/v1/currencies/export` | 依查詢條件真實匯出 Excel 報表 (.xlsx) |

---

## 5. 業務錯誤代碼映射表 (Machine-readable Error Codes)

| 錯誤代碼 (ErrorCode) | HTTP Status | 觸發業務條件 | 繁體中文錯誤訊息 |
| :--- | :--- | :--- | :--- |
| `ERR_DUPLICATE_COUNTRY_CODE` | 409 Conflict | 建立國家時代碼已存在 | 國家代碼 ''{0}'' 已存在 |
| `ERR_REGION_INACTIVE_CANNOT_ASSIGN` | 400 Bad Request | 關聯之區域已作廢或不存在 | 指定之所屬區域已停用作廢或不存在: {0} |
| `ERR_SANCTION_DATE_REQUIRED` | 400 Bad Request | 勾選受制裁未填生效日期 | 勾選受制裁時必須填寫制裁生效日期 |
| `ERR_COUNTRY_REFERENCED_CANNOT_DELETE` | 400 Bad Request | 國家存在外部業務模組引用 | 該國家已被 {0} 筆外部業務資料引用，禁止實體刪除，僅允許切換為作廢 |
| `ERR_DUPLICATE_REGION_CODE` | 409 Conflict | 建立區域時代碼已存在 | Region code already exists: {0} |
| `ERR_REGION_REFERENCED_CANNOT_DELETE` | 400 Bad Request | 區域所屬國家筆數 > 0 | 該區域已被國家資料引用，不可刪除，僅可標記作廢 |
| `ERR_DUPLICATE_CURRENCY_CODE` | 409 Conflict | 建立幣別時代碼已存在 | 幣別代碼 ''{0}'' 已被使用，請更換代碼 |
| `ERR_CHANGE_REASON_REQUIRED` | 400 Bad Request | 變更進位設定或小數未填原因 | 變更進位設定或小數位數必須填寫至少 5 個字之異動原因 |
| `ERR_CURRENCY_REFERENCED` | 409 Conflict | 幣別已被外部模組引用時刪除 | 本幣別已被業務模組引用，不可刪除，僅可標記作廢 |
| `ERR_OPTIMISTIC_LOCK_CONFLICT` | 409 Conflict | 併發更新版本不符 | 資料已被其他使用者修改，請重新整理後再試 |
| `ERR_OPTIMISTIC_LOCK` | 409 Conflict | 併發編輯版本衝突 | 資料已被其他使用者修改，請重新整理後再試 |


<!-- SECTION: API_CONTRACT -->
### 2.5 國家與區域 Excel 匯出與審計端點 (TASK-008 - 對偶 Agent SDK RFC-003, RFC-005 與 RFC-017)
| HTTP Method | 端點路徑 | 領域標籤 | 權限要求 | 說明 | 回傳格式 |
|:---|:---|:---|:---|:---|:---|
| `GET` | `/api/v1/countries/export` | `domain:masterdata` | `ROLE_ADMIN` / `ROLE_USER` | 匯出國家清單為 Excel (.xlsx) | Binary Stream (`application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`) |
| `GET` | `/api/v1/countries/{id}/audit-logs` | `domain:masterdata` | `ROLE_ADMIN` / `ROLE_USER` | 查詢指定國家全欄位異動審計紀錄 | JSON `List<AuditLogResponse>` |
| `GET` | `/api/v1/regions/export` | `domain:masterdata` | `ROLE_ADMIN` / `ROLE_USER` | 匯出區域清單為 Excel (.xlsx) | Binary Stream (`application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`) |
| `GET` | `/api/v1/regions/{id}/audit-logs` | `domain:masterdata` | `ROLE_ADMIN` / `ROLE_USER` | 查詢指定區域全欄位異動審計紀錄 | JSON `List<AuditLogResponse>` |

#### 2.5.1 AuditLogResponse 結構定義
```typescript
interface AuditLogResponse {
  id: number;
  targetId?: number;
  code?: string;
  changedAt: string;
  changedBy: string;
  department?: string;
  fieldName: string;
  beforeValue?: string;
  afterValue: string;
  changeReason: string;
}
```
<!-- /SECTION: API_CONTRACT -->
