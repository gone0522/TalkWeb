<!--
governance_metadata:
  last_reviewed: "2026-10-14"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-14"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# 專案全局系統分析與需求規格書 (System Analysis Specification - Master)

> **專案代號**：Reinsurance Core Platform  
> **關聯模組**：系統選單、基礎代碼、風險累積區域 (TASK-0101)、國家主檔與法遵制裁 (TASK-006)  
> **文件版本**：v1.2 (Living Master Spec)  
> **負責角色**：Lead System Analyst / Solution Architect  

---

## 1. 系統願景與業務架構 (System Vision)
本系統為「再保險核心管理平台 (Reinsurance Core Platform)」，負責管理再保險核心業務流程、組織主檔、選單架構、基礎代碼 (Lookups) 與風險累積區域/國家資料。

### 1.1 核心業務痛點與升級目標
1. **多維地理風險累計**：巨災再保險合約依據地理分區進行風險敞口（Accumulation Risk）限額控管，區域主檔必須能動態建立、調整顯示順序並即時統計所屬國家數。
2. **法遵制裁（Sanction Compliance）即時控管**：國際洗錢防制（AML）與跨國制裁清單（OFAC、聯合國等）頻繁變動，系統需在國家主檔層級原生記錄制裁狀態、生效日與醒目警示，防止合規違規簽單。
3. **企業級引用完整性防護網 (對偶 Agent SDK RFC-015: ReferenceDefenseDamper)**：區域若有國家引用、國家若被金融機構或再保合約引用，嚴格禁止實體物理刪除，僅允許切換為軟作廢 (`status: INACTIVE`)，徹底杜絕資料孤島。

---

## 2. 系統角色與權限矩陣 (RBAC Matrix)

| 角色名稱 | 角色代碼 | 業務責任與使用情境 | 存取與操作權限 |
| :--- | :--- | :--- | :--- |
| **系統管理員** | `ROLE_ADMIN` | 負責全系統基礎參數配置、主檔維護與資料清理 | 具備區域與國家之完整新增、修改、作廢與刪除（受引用防護約束）權限。 |
| **法遵主管** | `ROLE_COMPLIANCE`| 監控全球制裁風險名單，即時維護各國制裁註記與生效日 | 具備國家主檔之制裁狀態修改、檢視詳情與全域清單匯出權限。 |
| **核保主管/分析師**| `ROLE_UNDERWRITER`| 評估各區域業務風險累積量，查詢合約所屬國家之合規性 | 具備區域與國家之檢索、檢視詳情與關聯國家統計檢視權限。 |
| **一般使用者/審計員**| `ROLE_VIEWER` | 系統一般檢視者，核對資料代碼 | 僅具備清單分頁檢索與唯讀檢視權限。 |

---

## 3. 現有功能模組總覽 (Feature Modules)

### 3.1 系統選單模組 (System Menus)
- 維護系統頂部導航與側邊欄樹狀功能結構 (`system_menus`)。
- 支援層級結構 (Parent-Child)、路徑路由對應、顯示順序與作廢切換。

### 3.2 基礎代碼維護模組 (Lookups Management)
- **幣別代碼 (Currencies)**：ISO 貨幣代碼、符號、小數位數、狀態。
- **評等機構 (Rating Agencies)**：S&P, Moody's, AM Best 等評等機構名稱與狀態。
- **金融機構 (Financial Institutions)**：銀行/保險公司名錄、SWIFT 代碼、所屬國家與評等。

### 3.3 風險累積區域模組 (Regions - TASK-0101 / TASK-006)
- 維護業務自訂風險區 (`system_regions`)，具備唯一代碼、顯示排序、作廢狀態與防刪除防護。
- 提供所屬國家數量動態計數與直覺性增修抽屜。

### 3.4 國家選單與法遵制裁模組 (Countries - TASK-006)
- 維護國際標準國家主檔 (`system_countries`)，支援 ISO 2~3 碼代碼、中英文名稱與所屬風險區域。
- **法遵制裁機制**：提供受制裁旗標與生效日期維護，於清單、詳情抽屜與下游合約提供醒目琥珀色/紅底警示橫幅。
- **多模組引用防護**：與金融機構主檔、再保人主檔、再保合約連動，若有引用則鎖定代碼唯讀並禁止實體刪除。
- **選單共用一級框架**：與區域主檔整合於 `/settings/menus`，提供高一致性雙頁籤導航與操作體驗。

---

### 3.3 結算幣別主檔與計算設定模組 (Currencies Management - TASK-007)
- **ISO 4217 幣別代碼主鍵**：標準 3 碼大寫英文字母，建立後永久鎖定唯讀。
- **再保金額進位規則與精度**：支援四種運算進位規則 (`ROUND_HALF_UP`, `ROUND_UP`, `ROUND_DOWN`, `ROUND_HALF_EVEN`) 與小數位數 (0 ~ 4)，並提供金額即時試算預覽。
- **計算設定變更衝擊控制**：進位規則或小數更動僅適用於後續新交易，歷史交易不重算；變更時強制跳出確認並要求至少 5 字之異動原因，完整存入審計歷程日誌。
- **多模組引用完整性保護**：即時聚合統計再保合約、交易資料 (保費/佣金/賠款)、金融機構收付款設定之引用筆數；引用筆數 > 0 時嚴禁刪除，僅可切換為作廢。
- **報表匯出**：支援依多維檢索條件匯出 Excel 報表。

---

## 4. 核心端到端業務旅程 (End-to-End Business Journeys)

```mermaid
flowchart TD
    Start([使用者進入選單管理 /settings/menus]) --> TabDecision{選擇維護維度}
    
    TabDecision -->|區域選單 Tab| RegionFlow[區域管理流程]
    TabDecision -->|國家選單 Tab| CountryFlow[國家管理流程]
    
    subgraph Region_Workflow [區域維護業務旅程]
        RegionFlow --> R_Search[分頁檢索區域清單]
        R_Search --> R_Action{選擇操作}
        R_Action -->|新增區域| R_Create[輸入代碼與中英文名稱]
        R_Create --> R_SortCheck[系統自動計算順序 max + 10]
        R_SortCheck --> R_Save[儲存並建立區域主檔]
        R_Action -->|點擊刪除| R_DelCheck{查詢關聯國家數量}
        R_DelCheck -->|國家數 > 0| R_Block[阻擋實體刪除! 提示僅可設為作廢]
        R_DelCheck -->|國家數 = 0| R_DelSuccess[二次確認安全物理刪除]
    end
    
    subgraph Country_Workflow [國家維護業務旅程]
        CountryFlow --> C_Filter[多維度檢索: 關鍵字/區域下拉/制裁快選]
        C_Filter --> C_Action{選擇操作}
        C_Action -->|新增國家| C_Input[輸入 2~3 碼代碼、名稱與選擇所屬區域]
        C_Input --> C_Sanction[勾選法遵制裁並指定生效日期]
        C_Sanction --> C_Validate{檢核區域有效性}
        C_Validate -->|所屬區域已作廢或不存在| C_Err[拒絕儲存! 提示區域無效]
        C_Validate -->|所屬區域有效| C_CreateOK[成功建立國家主檔]
        C_Action -->|編輯/檢視| C_Drawer[開啟側邊抽屜: 顯示制裁橫幅與引用統計]
        C_Drawer --> C_RefCheck{外部業務引用數 > 0?}
        C_RefCheck -->|是| C_Lock[鎖定國家代碼, 禁用刪除按鈕]
        C_RefCheck -->|否| C_AllowEdit[允許編輯與二次確認刪除]
    end
```

---

## 5. 詳細業務規則矩陣 (Business Rules Matrix)

### 5.1 區域管理業務規則 (Region Business Rules)
- **`BR-REG-01 (代碼唯一性)`**：區域代碼 (`code`) 必須全域唯一，不分大小寫比對，長度上限 20 字元，允許大寫英數字與下底線。若重複則拒絕儲存並回傳 409 Conflict (`ERR_DUPLICATE_REGION_CODE`)。
- **`BR-REG-02 (順序預設邏輯)`**：若使用者於新增表單未指定 `sortOrder`，系統自動抓取目前最大之 `sort_order` 並加 10 作為預設值。
- **`BR-REG-03 (關聯國家計數)`**：區域清單中必須即時呈現該區域所屬的國家總數（含有效與作廢國家）。
- **`BR-REG-04 (刪除防護與狀態切換)`**：已被任何國家引用的區域（關聯數 > 0），嚴禁實體刪除（回傳 400 Bad Request，`ERR_REGION_REFERENCED_CANNOT_DELETE`），僅允許透過狀態開關切換為作廢 (`is_disabled = true`)。

### 5.2 國家管理業務規則 (Country Business Rules)
- **`BR-CTY-01 (國家代碼規範)`**：國家代碼 (`code`) 必須遵循 ISO 3166-1（2 或 3 碼大寫英文，`^[A-Z]{2,3}$`），全域唯一。新增成功後代碼永久鎖定不可修改。
- **`BR-CTY-02 (區域關聯完整性)`**：新增或修改國家時，所選之所屬區域 (`regionCode`) 必須存在於 `system_regions` 且其狀態必須為有效 (`is_disabled = false`)。若所選區域已停用或不存在，系統拒絕儲存並拋出 400 Bad Request (`ERR_REGION_INACTIVE_CANNOT_ASSIGN`)。
- **`BR-CTY-03 (法遵制裁連動)`**：若勾選受制裁 (`isSanctioned = true`)，必須填寫制裁生效日期 (`sanctionDate`)。在清單與抽屜以琥珀色/紅底警示標籤高亮標記。
- **`BR-CTY-04 (外部引用防護與鎖定)`**：國家若已被金融機構、再保人、合約等外部模組引用（`referenceCount > 0`），其國家代碼輸入框強制 Disabled，實體刪除功能強制鎖定，僅允許變更為作廢狀態。

### 5.3 結算幣別業務規則 (Currency Business Rules - TASK-007)
- **`BR-CUR-01 (ISO 4217 代碼規範)`**：幣別代碼 (`code`) 必須為 3 碼大寫英文字母 (`^[A-Z]{3}$`)，全域唯一。新增後鎖定為唯讀。
- **`BR-CUR-02 (代碼唯讀鎖定)`**：檢視與編輯模式下幣別代碼均鎖定為唯讀，右側展示 🔒 圖示。
- **`BR-CUR-03 (引用完整性與防刪除)`**：若已被再保合約、交易資料或金融機構設定引用 (`references.totalCount > 0`)，禁止刪除，刪除按鈕鎖定 Disabled 帶 Tooltip，後端拒絕刪除 (409 Conflict)；零引用允許二次確認安全刪除。
- **`BR-CUR-04 (軟作廢狀態)`**：狀態切換為已作廢 (`INACTIVE`) 後，排除於新增業務之下拉選單，歷史交易與既有合約仍可正常查詢續用。
- **`BR-CUR-05 (進位規則演算)`**：支援四捨五入 (`ROUND_HALF_UP`)、無條件進位 (`ROUND_UP`)、無條件捨去 (`ROUND_DOWN`)、銀行家捨入 (`ROUND_HALF_EVEN`)，金額正負數皆對稱演算。
- **`BR-CUR-06 (小數位數範圍)`**：小數位數嚴格限定 0 ~ 4，小於 0 或大於 4 拒絕儲存。
- **`BR-CUR-07 (計算設定變更強制原因)`**：更動進位設定或小數位數時，必須提供至少 5 個字之異動原因或法令依據。
- **`BR-CUR-08 (審計日誌追溯)`**：所有計算設定與主要欄位異動自動存入 `currency_audit_logs`，並在抽屜展示最近 5 筆歷程。
- **`BR-CUR-09 (新增建議排序)`**：新增幣別時，顯示順序自動預設為現有最大序號 + 10；儲存並繼續新增時自動累加 + 10。

### 5.4 全局通用業務規則 (Global Governance Rules)
1. **代碼唯一性 (Code Uniqueness)**：全域所有業務主鍵一律具有唯一約束。
2. **軟作廢優先 (Soft-delete Preferred)**：具備業務引用的主檔禁止物理移除，確保歷史合約審計追溯性。
3. **審計軌跡 (Audit Traceability)**：所有異動統一自動記錄 `createdAt`, `createdBy`, `updatedAt`, `updatedBy`。
4. **樂觀並發鎖定 (Optimistic Concurrency Control)**：核心主檔均配置 `version` 欄位防禦髒寫覆蓋。

---

## 6. 業務名詞定義 (Glossary)

| 名詞術語 | 英文對應 | 業務定義與解說 |
| :--- | :--- | :--- |
| **自訂累積區域** | Accumulation Region | 再保險公司基於自身承保胃納與巨災模型自訂之地理分區（如「亞洲及太平洋區」）。 |
| **法遵制裁國家** | Sanctioned Country | 受到國際組織（聯合國、OFAC）金融制裁或貿易禁運之國家/司法管轄區。 |
| **外部引用計數** | Reference Count | 該主檔被下游金融機構代碼、再保合約、理賠案等關聯使用的累計總筆數。 |
| **軟作廢狀態** | Inactive / Disabled Status | 資料保留於資料庫但不參與業務下拉選單的停用狀態，提供資料歷史完整性追溯。 |
