<!--
governance_metadata:
  last_reviewed: "2026-10-14"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-14"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# 專案全局業務使用案例規格書 (Use Case Master Specification)

> **專案代號**：Reinsurance Core Platform  
> **關聯模組**：系統選單、基礎代碼、區域管理 (TASK-0101)、國家主檔 (TASK-006)  
> **文件版本**：v1.2 (Living Master Spec)  
> **負責角色**：Lead Business Analyst  

---

## 1. 系統使用者角色與通用操作邊界
- `ROLE_ADMIN`: 具備全域選單、基礎代碼表、區域與國家之建立、修改、作廢與刪除（受引用防護約束）權限。
- `ROLE_COMPLIANCE`: 專職維護各國法遵制裁註記與生效日。
- `ROLE_UNDERWRITER`: 具備所有主檔之檢索、詳情查閱與風險累計分析權限。
- `ROLE_VIEWER`: 唯讀查詢權限。

---

## 2. 區域管理使用案例 (Region Use Cases - TASK-0101 / TASK-006)

- **`UC-REG-01 (分頁檢索區域清單)`**:
  - 前置條件: 使用者具備 `ROLE_VIEWER` 以上權限。
  - 主要流程: 支援關鍵字搜尋代碼或名稱、狀態過濾，回傳依 `sort_order` 排序之區域清單，每筆資料包含所屬國家筆數。
- **`UC-REG-02 (新增自訂風險區域)`**:
  - 主要流程: 使用者輸入代碼、中英文名稱；若未指定排序號，系統自動計算指派為最大值 `+ 10`。
  - 異常流程: 代碼重複拋出 409 Conflict (`ERR_DUPLICATE_REGION_CODE`)。
- **`UC-REG-03 (編輯區域主檔)`**:
  - 主要流程: 編輯區域名稱與排序，代碼鎖定唯讀，支援樂觀鎖並發檢查 (對偶 Agent SDK RFC-004: OptimisticLockGuard)。
- **`UC-REG-04 (切換區域作廢狀態)`**:
  - 主要流程: 透過狀態開關快速翻轉 `is_disabled`。
- **`UC-REG-05 (安全刪除區域)`**:
  - 主要流程: 若所屬國家數為 0，彈出二次確認後執行物理刪除 (204 No Content)。
  - 異常流程: 若所屬國家數 > 0，系統阻擋刪除並拋出 400 Bad Request (`ERR_REGION_REFERENCED_CANNOT_DELETE`，對偶 Agent SDK RFC-015: ReferenceDefenseDamper)。

---

## 3. 國家管理使用案例 (Country Use Cases - TASK-006)

- **`UC-CTY-01 (多維條件檢索國家清單)`**:
  - 主要流程: 支援關鍵字防抖 (300ms)、所屬區域下拉、制裁標籤 (全部/僅制裁/正常)、作廢狀態篩選，清單呈現琥珀色制裁 Badge。
- **`UC-CTY-02 (查詢國家詳情與引用統計)`**:
  - 主要流程: 開啟側邊抽屜，展示國家完整欄位、受制裁橫幅 (`SanctionAlertBanner`) 與多模組（金融機構、合約等）引用統計。
- **`UC-CTY-03 (新增國家主檔)`**:
  - 主要流程: 輸入 2~3 碼 ISO 代碼、中英文名稱、所屬區域代碼、制裁旗標與生效日期。
  - 異常流程:
    - 國家代碼格式不符或重複拋出錯誤 (400 / 409)。
    - 所屬區域不存在或已作廢拋出 400 Bad Request (`ERR_REGION_INACTIVE_CANNOT_ASSIGN`)。
    - 勾選受制裁未填生效日期拋出 400 Bad Request (`ERR_SANCTION_DATE_REQUIRED`)。
- **`UC-CTY-04 (修改國家主檔)`**:
  - 主要流程: 代碼永久鎖定不可修改，支援名稱、所屬區域、制裁狀態與排序號更新，支援樂觀鎖並發防護。
- **`UC-CTY-05 (切換國家作廢狀態)`**:
  - 主要流程: 快速切換 `is_disabled`，作廢後排除於下拉選單。
- **`UC-CTY-06 (引用防刪除保護)`**:
  - 主要流程: 
    - 外部引用計數 > 0: 抽屜內刪除按鈕鎖定 Disabled，後端直接拒絕刪除 (400 `ERR_COUNTRY_REFERENCED_CANNOT_DELETE`)。
    - 外部引用計數 = 0: 二次確認後實體刪除 (204 No Content)。

---

## 4. 結算幣別管理使用案例 (Currency Use Cases - TASK-007)

- **`UC-CUR-01 (多維條件檢索結算幣別清單)`**:
  - 主要流程: 支援代碼、中英文名稱、進位規則、狀態篩選，清單即時顯示範例金額與狀態 Badge。
- **`UC-CUR-02 (即時金額演算預覽)`**:
  - 主要流程: 依據選定之進位設定與小數位數 (0~4)，針對基準正值 (1,234.5678) 與負值 (-1,234.5678) 進行即時格式化演算。
- **`UC-CUR-03 (新增結算幣別主檔)`**:
  - 主要流程: 輸入 3 碼 ISO 代碼、中英文名稱、進位設定、小數位數與建議排序。支援「儲存」與「儲存並繼續新增」雙模式。
  - 異常流程: 代碼重複拋出 409 Conflict (`ERR_DUPLICATE_CURRENCY_CODE`)。
- **`UC-CUR-04 (修改結算幣別主檔與全欄位異動審計)`**:
  - 主要流程: 代碼永久鎖定唯讀，支援名稱與排序修改。異動成功後，後端自動比對差異並於 `currency_audit_logs` 針對變更欄位（中文名稱、英文名稱、顯示順序）寫入審計留痕，使用使用者提供原因或預設「基本資料維護更新」。
- **`UC-CUR-05 (計算設定變更強制原因與審計紀錄)`**:
  - 主要流程: 變更進位設定或小數位數時，系統彈出確認對話框並強制填寫至少 5 字之異動原因，變更完成自動寫入 `currency_audit_logs` 紀錄，既有歷史合約不重算。
- **`UC-CUR-06 (切換幣別作廢狀態與審計記錄)`**:
  - 主要流程: 快速切換 `ACTIVE` / `INACTIVE`，作廢後排除於新增業務下拉選單。狀態翻轉自動寫入 `currency_audit_logs`（欄位：資料狀態）。
- **`UC-CUR-07 (多模組引用防刪除保護)`**:
  - 主要流程:
    - 外部引用數 > 0: 抽屜內刪除按鈕鎖定 Disabled 帶 Tooltip，後端拋出 409 (`ERR_CURRENCY_REFERENCED`)。
    - 外部引用數 = 0: 二次確認對話框確認後實體刪除 (204 No Content)。
- **`UC-CUR-08 (匯出結算幣別 Excel 報表)`**:
  - 主要流程: 點擊 [匯出 Excel] 下載包含當前篩選條件之幣別主檔報表。
