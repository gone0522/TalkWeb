# 前後端多倉庫分離架構藍圖 (Multi-Repo Architecture & Separation Blueprint)

> **目標**：確立前端 (UI) 與後端 (API) 在不同 Git 倉庫中獨立分支、獨立 Commit 與獨立部署之架構體系。  
> **依據**：`docs/adr/ADR-002`, `docs/ENGINEERING_STANDARDS.md §15.3, §28`

---

## 1. 三庫拓撲架構總覽 (Three-Repository Topology)

系統實體切分為三個獨立的 Git 倉庫：

```text
                               ┌────────────────────────────────────────────────────────┐
                               │ 🏛️ 倉庫 1: reinsurance-contracts                       │
                               │ (全域契約與活體規格庫 - Single Source of Truth)        │
                               │ • contracts/openapi.yaml                               │
                               │ • specs/ (六大活體規格庫 SA, UC, UI, DBA, SD, QA)      │
                               │ • tasks/TASK-*/specs/ & manifest templates             │
                               │ • docs/ENGINEERING_STANDARDS.md & ADRs                 │
                               │ • scripts/audit-specs.py                               │
                               └───────────────────────────┬────────────────────────────┘
                                                           │
                                ┌──────────────────────────┴──────────────────────────┐
                   Git Submodule│掛載 (鎖定 SHA)                         Git Submodule│掛載 (鎖定 SHA)
                                ▼                                                     ▼
┌────────────────────────────────────────────────────────┐  ┌────────────────────────────────────────────────────────┐
│ 🎨 倉庫 2: reinsurance-web-portal (前端 UI 獨立庫)     │  │ ⚙️ 倉庫 3: reinsurance-core-service (後端 API 獨立庫)   │
│                                                        │  │                                                        │
│ • 專屬路徑：apps/web-portal/ 程式碼 (升格為根目錄)     │  │ • 專屬路徑：services/core-service/ 程式碼 (升格為根目錄)│
│ • 專屬構建：package.json, tsconfig.json, Next.js       │  │ • 專屬構建：pom.xml, Java 21, Spring Boot              │
│ • 專屬遷移：無資料庫 DDL                               │  │ • 專屬遷移：src/main/resources/db/migration/ (Flyway)  │
│ • 專屬門禁：tsc --noEmit && npm test (i18n + buttons)  │  │ • 專屬門禁：mvn test (100% 通過)                        │
│ • 獨立分支：dev, main, feature/TASK-xxxx-UI            │  │ • 獨立分支：dev, main, feature/TASK-xxxx-API           │
│ • 依賴模式：MSW / Prism Mock Server (依契約開工)       │  │ • 依賴模式：JPA / Testcontainers / Local DB             │
└────────────────────────────────────────────────────────┘  └────────────────────────────────────────────────────────┘
```

---

## 2. 獨立倉庫內部目錄結構標準 (Repository Layouts)

### 2.1 倉庫 1: `reinsurance-contracts` (規格與治理庫)
```text
reinsurance-contracts/
├── contracts/
│   └── openapi.yaml               # 唯一的 API 契約事實真理
├── specs/                         # 全域活體規格
├── tasks/                         # 各模組歷史與當前任務包 (TASK-006 ~ TASK-009)
│   └── TASK-xxxx/
│       ├── manifest-api.yaml      # 後端機器契約
│       ├── manifest-ui.yaml       # 前端機器契約
│       ├── TASK-xxxx-01_API.md    # 後端微任務卡
│       ├── TASK-xxxx-02_UI.md     # 前端微任務卡
│       └── specs/ (6 大套件)
├── docs/                          # 架構規範 (ENGINEERING_STANDARDS.md, ADRs)
└── scripts/
    └── audit-specs.py             # 規格完整性檢核腳本
```

### 2.2 倉庫 2: `reinsurance-web-portal` (前端 UI 庫)
```text
reinsurance-web-portal/
├── src/                           # 獨立前端源碼根目錄
│   ├── app/                       # 路由頁面入口 (僅透過 @/features/ 引入元件)
│   ├── features/                  # ADR-002: 垂直內聚領域切片 (src/features/<domain>/<subdomain>/)
│   ├── components/                # 共用基礎 UI 元件
│   ├── services/                  # API Clients
│   └── locales/                   # 多國語系字典 (zh-TW, en-US)
├── public/
├── package.json
├── tsconfig.json
├── next.config.mjs
├── scripts/
│   ├── validate-i18n.js
│   └── audit-buttons.js
└── contracts/                     # 🔗 Git Submodule: 指向 reinsurance-contracts 的 contracts/ 與 specs/
    ├── openapi.yaml
    └── specs/
```

### 2.3 倉庫 3: `reinsurance-core-service` (後端 API 庫)
```text
reinsurance-core-service/
├── src/
│   ├── main/java/
│   ├── main/resources/db/migration/
│   └── test/java/
├── pom.xml
├── Dockerfile
└── contracts/                     # 🔗 Git Submodule: 指向 reinsurance-contracts 的 contracts/ 與 specs/
    ├── openapi.yaml
    └── specs/
```

---

## 3. 跨倉庫解耦分支與 Commit 標準作業程序 (Decoupled Git Flow SOP)

### 3.1 後端團隊開發流程 (API Workflow)
1. **開立分支**：在 `reinsurance-core-service` 倉庫中，由後端 `dev` 切出：
   ```bash
   git checkout dev && git pull origin dev
   git checkout -b feature/TASK-008-API
   ```
2. **實作與驗收**：實作 DDL、Entity、Service、Controller 與單元測試。
3. **品質閘門**：
   ```bash
   mvn test   # 100% 通過
   ```
4. **獨立提交**：
   ```bash
   git commit -m "feat(api): implement country audit logs and export endpoints"
   git push origin feature/TASK-008-API
   ```

### 3.3 契約依賴現代化：從 Git Submodule 升級至 Versioned Package Registry (ADR-002 §3.4)
在微服務規模下，為避免 Git Submodule 在多分支、CI/CD 構建與容器映像製作時產生的 detached HEAD 與遞迴拉取風險，契約採用版本化套件發布體系：
1. **CI 自動化編譯發布**：`reinsurance-contracts` 的 `openapi.yaml` 變更合併至 `main` 後，GitHub Actions 自動觸發代碼生成：
   - 前端 TypeScript SDK 發布至私有 NPM Registry：`@reinsurance/contracts-sdk@1.x.x`
   - 後端 Java DTO 與介面發布至內部 Maven / Nexus：`com.reinsurance:contracts-sdk:1.x.x`
2. **依賴自動感知與升級 (Renovate Bot)**：下游微服務（Web Portal, Treaty, Billing）配置 Renovate Bot，新版 SDK 發布後自動向各微服務發起升級 PR。
3. **消費者驅動契約保護 (Pact)**：引用端在 CI 中註冊 Pact 需求，被引用端合併前強制校驗 (`can-i-deploy`)，杜絕未經協商的破壞性變更。

### 3.2 前端團隊開發流程 (UI Workflow - 零依賴後端)
1. **開立分支**：在 `reinsurance-web-portal` 倉庫中，由前端 `dev` 切出：
   ```bash
   git checkout dev && git pull origin dev
   git checkout -b feature/TASK-008-UI
   ```
2. **Mock 驅動實作**：以 Submodule 中的 `openapi.yaml` 啟動 Mock 伺服器，實作畫面元件、按鈕事件與 Table 渲染。
3. **品質閘門**：
   ```bash
   npx tsc --noEmit && npm test   # 0 型別錯誤、0 漏翻譯、0 死按鈕
   ```
4. **獨立提交**：
   ```bash
   git commit -m "feat(ui): implement country export download and audit drawer tab"
   git push origin feature/TASK-008-UI
   ```

---

## 4. 遷移執行指南 (Migration Execution Steps)
當團隊正式決定拆分實體 Git 倉庫時，依序執行：
1. **建立共用規格庫**：建立 `reinsurance-contracts`，匯入 `contracts/`, `specs/`, `tasks/`, `docs/`, `scripts/`。
2. **拆分前端庫**：將 `apps/web-portal/` 內容提取至 `reinsurance-web-portal`，並以 Submodule 引入 `contracts`。
3. **拆分後端庫**：將 `services/core-service/` 內容提取至 `reinsurance-core-service`，並以 Submodule 引入 `contracts`。
4. **CI 分離**：將 GitHub Actions / GitLab CI 分別配置於各倉庫根目錄。


---

## 5. 邁向 Level 3 垂直領域切片之自然芽裂協議 (The Sprouting Protocol - ADR-002 §3.3)

在專案演進過程中，系統遵循 **MonolithFirst** 原則：
1. **邏輯聚合期 (Level 2 聚合運行)**：
   - 代碼集中於當前前後端兩大獨立倉庫中，享受極速編譯、秒級除錯與單一環境運行的紅利。
   - 但透過五大防線（領域標籤、軟性外鍵、零跨庫 JOIN、Package-Private、Feature-Sliced UI）維持軟性邊界。
2. **物理芽裂期 (Level 3 Domain Pods)**：
   - 當某一領域模組（如 `masterdata`）代碼規模超過 3,000 行或業務要求獨立發版時，正式觸發芽裂。
   - 使用標準 Git Subtree 指令在 1 秒內無損攜帶完整 Git 歷史抽離為獨立 Domain Pod：
     ```bash
     # 前端微模組無損抽離
     git subtree split -P src/features/masterdata -b pod-masterdata-ui
     ```
   - 舊系統與新抽離之 Pod 均無需修改任何業務程式碼，實現真正可演進架構。
