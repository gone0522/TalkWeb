<!--
governance_metadata:
  last_reviewed: "2026-10-13"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-13"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# ADR-002: 多庫契約先行與可演進垂直切片架構 (Decoupled Multi-Repo & Evolvable Slices)

## 1. 狀態 (Status)
**已批准 (Accepted - 統合基石決策)** - 2026-10-12
*(整合並昇華歷史決策：ADR-008 多庫獨立契約先行分支治理、ADR-009 可演進式模組邊界與自然芽裂架構)*

## 2. 背景與問題意識 (Context)
微服務與垂直切片 (Domain Pods) 的劃分常常面臨「兩難困境」：
- **過早物理拆分 (Premature Splitting)**：在業務初期將系統切分為大量微服務或微前端，會導致嚴重的跨庫重構摩擦、網路 RPC 延遲與環境維護成本暴增。
- **傳統單體大泥球 (Big Ball of Mud)**：若將所有代碼混寫在單一倉庫而不設防線，模組間會迅速產生跨表狂 JOIN、私有類別跨模組注入與前端深層穿透，未來根本無法拆分。

## 3. 架構決策 (Decisions)

### 3.1 契約先行與多庫解耦分支生命週期 (Contract-First Branching)
- 系統採用獨立的三庫拓撲（契約庫 `reinsurance-contracts`、前端庫 `reinsurance-web-portal`、後端庫 `reinsurance-core-service`）。
- **零跨庫分支依賴鐵律**：
  * 後端任務僅從後端倉庫之 `dev` 切出 `feature/<TASK>-API`。
  * 前端任務僅從前端倉庫之 `dev` 切出 `feature/<TASK>-UI`，依據 OpenAPI 契約使用 Mock Server 平行獨立開發。
  * 嚴禁跨倉庫切分支，嚴禁依賴未合併之對方代碼。

### 3.2 三庫串行合併順序協議 (Tri-Repo Promotion Pipeline)
跨庫發布嚴格遵循不可逆的四步流水線，徹底杜絕規格與代碼脫節死鎖：
1. **Contracts PR 預審就緒**：`reinsurance-contracts` 切出 `task/<TASK_ID>` PR，通過規格與語法審核，保持 PR 開啟暫不合入 dev。
2. **後端代碼合入 dev**：`reinsurance-core-service` 通過單元測試，PR 合併入後端 `dev`。
3. **前端真機聯調合入 dev**：`reinsurance-web-portal` 本地切換 `MOCK=false` 直連後端通過 E2E 走查，PR 合併入前端 `dev`。
4. **Contracts 主權庫結案合入 dev**：確認雙端代碼均已就緒，於 Contracts PR 完成主規格回寫，最終合併入 `contracts:dev`。

### 3.3 領域內 vs 跨領域 CQRS 分級架構 (Domain-Bounded CQRS Architecture)
- **領域內部 (Intra-Domain CQRS)**：在單一業務領域內部（如合約主檔與合約條款），全面開放資料庫 View 與多表 SQL JOIN，解決複雜統計報表與 N+1 查詢效能問題。
- **跨領域邊界 (Cross-Domain Strict Isolation)**：嚴格禁止資料庫跨領域實體 JOIN！跨領域資料組合僅允許兩種合法模式：
  * **應用層組裝 (BFF Pattern)**：由後端在記憶體中平行調用各領域 Public API 組裝。
  * **快照記錄 (Snapshot Pattern)**：寫入交易時保存關聯主檔之名稱與代碼快照，查詢單表直出。
- 兼顧極致報表效能，同時 100% 守護未來微服務芽裂之自由度。

### 3.4 Expand/Contract 雙相無感資料庫遷移鐵律 (Zero-Downtime Migration)
- 任何欄位更名或型別變更，嚴禁一次性物理刪除或更名，防止滾動更新引發舊版 Pod 500 錯誤風暴：
  * **Phase 1 (Expand)**：Flyway 腳本只准新增欄位，保留舊欄位，後端雙寫或視圖向下相容。
  * **Phase 2 (Contract)**：全站 Pod 100% 升級穩定運行一週後，於下個維護版本 Flyway 腳本才安全移除舊欄位。

### 3.5 可演進架構之五大抗耦合防線 (Five Anti-Coupling Invariants)
代碼在單體內邏輯聚合時，必須植入五大抗耦合基因：
1. **全資產領域標籤鐵律 (Domain Tagging Protocol)**：
   * OpenAPI 端點必須標註 `tags: ["domain:<name>"]`。
   * Task Manifest 必須宣告 `domain: { name: "<domain>", subdomain: "<subdomain>" }`。
   * 資料表強制使用領域族譜前綴（主檔 `md_*`、合約 `tr_*`、理賠 `cl_*`、計費 `bl_*`）。
2. **軟性外鍵與跨庫 SQL 零 JOIN (Soft FK & Zero Cross-Domain Joins)**：
   * 跨領域引用僅儲存邏輯代碼，資料庫實體層嚴禁建立 `FOREIGN KEY` 約束。
   * Repository / DAO 嚴禁跨領域資料表 SQL JOIN，一律於應用層組合。
3. **引用防禦協議與軟刪除 (Referential Guard & Soft-Delete Invariant)**：
   * 被引用實體必須提供 `GET /api/v1/{entity}/{id}/references` 端點，變更狀態前必須檢核引用計數。
   * 嚴禁物理 `DELETE FROM`，核心資料一律軟刪除 (`is_disabled = true`)。
4. **後端 Package-Private 封閉性 (Backend Boundary Encapsulation)**：
   * 領域內部 DAO、Entity 與 Service 實作宣告為 Package-Private，僅開放 `PublicQueryApi` 或事件通道。
5. **前端 Feature-Sliced 垂直內聚目錄規範 (Feature-Sliced Directory)**：
   * 畫面與業務邏輯強制組織於 `src/features/<domain>/<subdomain>/`。
   * 對外唯一出口為 `index.ts`，外部路由禁止私有路徑深層穿透。

### 3.6 自然芽裂協議 (The Sprouting Protocol)
- **芽裂閾值**：當某一領域模組代碼規模超過 3,000 行或業務要求獨立發版時觸發。
- **無損抽離**：使用 `git subtree split -P src/features/<domain> -b pod-<domain>-ui` 在 1 秒內無損攜帶完整 Git Commit 歷史抽離為獨立 Domain Pod。舊系統與新 Pod 均不需改寫任何業務程式碼。


### 3.7 雙子星對稱庫架構與多庫解耦編譯單元 (Dual-Star Symmetric Architecture & Modular Compilation Units)
- **跨平台多語系標準庫架構 (Polyglot Agent SDK)**：
  * **核心契約層 (`agent-sdk-spec`)**：以 JSON Schema / RFC 形式定義通訊與互動協議（分頁、審計、錯誤模型 RFC 7807、死按鈕防護、骨架屏微互動）。
  * **後端原語庫 (`agent-sdk-spring`)**：Spring Boot 企業級 Starter，封裝動態在地化匯出引擎 (`GenericExcelExportEngine`)、JPA 審計基底、樂觀鎖與 QoS 計數器。
  * **前端原語庫 (`@agent-sdk/react`)**：Next.js / React 元件庫，封裝 MasterData 原型視圖、宣告式 Toast、防呆按鈕與虛擬化表格。
- **任務字節碼多庫模組化 (Modular Compilation Units)**：
  * 意圖編譯器 (Planner) 不產出龐大單體 IR，而是針對多庫產出獨立編譯單元：
    - `task.ir.backend.yaml`（後端專屬 Bytecode）
    - `task.ir.frontend.yaml`（前端專屬 Bytecode）
  * 兩端由不同的 AI 虛擬機（Runner Agent）平行獨立執行，依循 OpenAPI 契約在「本地真機聯調期 (The Handshake Moment)」自動接軌，達成最高維度的時間與空間解耦。
