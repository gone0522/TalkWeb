# ADR-007: 軟體工廠五階段流、確定性優雅降級與超大規模抗熵增防線 (Autonomous Software Factory Loop, Graceful Degradation, and Ultra-Scale Anti-Entropy Defenses)

- **狀態**：`ACCEPTED (已採納)`
- **日期**：2026-10-12
- **負責人**：Lead Architect / Fullstack AI Agent Team
- **影響範圍**：全端敏捷生命週期、CI 測試管線、跨模組發布、任務拆解與結案審查

---

## 1. 背景與長青推演暗坑 (Context & Multi-Cycle Pitfalls)

在系統累積百次敏捷循環與萬級 QPS 推演中（STEP 4951~4957、STEP 5011 推演 35~95、STEP 5025），揭露出六大威脅系統持續運作的架構暗坑：

1. **依賴缺失時的執行者暗中降級或全盤終止矛盾**：
   - 當前端任務需要匯出 Excel 但後端缺少 API 端點時，工程師/Agent 若暗中降級做假按鈕，會引發驗收詐欺；若直接整張票崩潰終止，則會阻礙其他 95% 正確功能的交付。
2. **規格膨脹與 Token 認知超載 (Master Spec Bloat)**：
   - 單一規格文件膨脹至數萬行，Agent 載入時消耗過量 Token 並引發上下文注意力稀釋 (Context Decay)。
3. **多機並行測試資料庫踩踏 (Test DB Cross-Contamination)**：
   - 多 Agent 或 CI 容器同時跑測試，共用資料庫引發髒讀與唯一鍵衝突，產生薛丁格的測試 (Flaky Tests)。
4. **模組發布相依死鎖 (Release Dependency Deadlock)**：
   - 跨模組資料結構變更時，下游消費者對欄位過度敏感，導致無法獨立發布。
5. **人類審查形式主義與疲勞 (Rubber-Stamping Fatigue)**：
   - 結案報告表格密密麻麻，每筆都顯示 100%，人類審查者產生大腦麻木，最終盲目按 Approve，防線名存實亡。
6. **微服務拆分交易撕裂 (Distributed Saga Fracture)**：
   - 單體拆分時本地交易失效，導致跨服務扣款與主檔異動不一致。

---

## 2. 核心決策內容 (Decisions & Architecture Specifications)

### 2.1 全自動軟體工廠 5 階段循環流程 (The 5-Stage Software Factory Loop)
```text
┌────────────────────┐     ┌────────────────────┐     ┌────────────────────┐     ┌────────────────────┐     ┌────────────────────┐
│ 階段 1：規格凍結   │ ──> │ 階段 2：多機並行   │ ──> │ 階段 3：全自動審計 │ ──> │ 階段 4：分級裁決   │ ──> │ 階段 5：敏捷自癒   │
│ Spec Linter & 合約 │     │ 無人平行推進       │     │ 紅轉綠 + DOM 覆蓋  │     │ 例外高亮 + PO 審核 │     │ 教訓轉代碼與追蹤   │
└────────────────────┘     └────────────────────┘     └────────────────────┘     └────────────────────┘     └────────────────────┘
```

### 2.2 確定性自主優雅降級協議 (Graceful Degradation Protocol)
- **規則 A (核心依賴缺失)**：若清單查詢或主保存端點缺失，判定為 Blocker，立即暫停並在對話框提供**【決策選單】**（A.補開後端任務 / B.終止拆解）由負責人定奪。
- **規則 B (非核心附加依賴缺失)**：若僅缺少非核心附加功能（如匯出 Excel），**啟動確定性自主降級**：
  - 前端元件強制渲染為 `disabled` 搭配 `<Tooltip title="此功能規劃中，即將推出">`；
  - 任務履約報告顯式標註 `[介面預留 (UI-Placeholder)]`，並自動記入次期 Backlog，嚴禁產生無事件空按鈕。

### 2.3 模組規格物理隔離 (Modular Spec Isolation)
- 規格庫嚴格物理分割：`docs/specs/core/` (全域核心) 與 `docs/specs/modules/{module_name}/` (模組私有)。
- Agent 派發任務時，**僅載入 core + target module**，Token 消耗嚴格壓制於 3,000 Tokens 內。

### 2.4 測試資料庫瞬態即焚與 Schema 隔離 (Ephemeral Test DB)
- 單元測試強制 `@Transactional` 交易回滾；
- CI 多機並行測試使用動態隔離 Schema (`schema_worker_{pid}`) 或 Testcontainers 瞬態容器，測試完畢即刻拋棄。

### 2.5 容錯消費者模式 (Tolerant Reader Pattern)
- 後端 Jackson 配置 `DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES = false`；
- 前端 Zod / DTO 解析採用容錯寬鬆模式（忽略未宣告新欄位），打破模組間步調一致發布的鎖定死結。

### 2.6 例外高亮與審查疲勞消除 (Exception-Only Reporting & Diff Highlighting)
- 《專案結案發布報告書》落實**例外高亮原則**：
  - 常規 100% 綠燈指標預設摺疊 (`<details>`)；
  - **任何降級功能、次期預留、延遲警告或相容性差異，強制以黃紅高亮區塊置頂展示**，保護人類注意力。

### 2.7 事務性發件箱與 Saga 最終一致性 (Transactional Outbox & Saga)
- 任何跨模組變更於本地資料庫同事務寫入 `outbox_events` 表；
- 透過訊息佇列實現異步重試與補償交易，為未來拆分微服務提供天然免疫力。
