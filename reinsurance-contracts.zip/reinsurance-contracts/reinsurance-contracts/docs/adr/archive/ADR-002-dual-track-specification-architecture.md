# ADR-002: 雙軌規格分離架構：人類專案治理軌 vs AI 機器執行軌 (Dual-Track Specification Architecture)

- **狀態**：`ACCEPTED (已採納)`
- **日期**：`2026-10-12`
- **決策者**：`Lead Architect, Product Owner (Kenny)`
- **技術範圍**：`Architecture, Workflow, Automation Tools, Documentation`

---

## 1. 背景與問題 (Context)

在引入 AI 輔助軟體開發後，過去傳統軟體工程將所有內容撰寫在單一長篇 Markdown 規格書的做法顯露出兩大根本矛盾：
1. **AI 機器受自然語言散文干擾 (Attention Dilution & Noise)**：
   - AI 在閱讀動輒 2,000~3,000 行包含業務背景、名詞解釋、時序圖、排版說明的規格書時，容易產生長文本注意力稀釋，忽略關鍵驗收邊界，甚至自行臆測 API 介面。
2. **人類治理與專案驗收資產匱乏 (Rubber-Stamping & Lack of Formal Dossier)**：
   - 專案由多個微任務平行推進後，專案經理 (PO) 與主管在驗收時，面對的是瑣碎的 Git Diff 與零散的對話紀錄，缺乏一份結構化、可供主管簽核、客戶交付、合規查核的《專案階段結案與發布報告書》。

如果強制要求 AI 每次都閱讀人類報告，會浪費大量 Token 且容易失焦；若只保留 AI 看的 JSON/YAML，人類則失去對專案架構的掌控感。

---

## 2. 決策內容 (Decisions)

全面落實**雙軌規格分離架構 (Dual-Track Specification Architecture)**，將文件依據受眾與目標徹底解耦為兩條平行的專門軌道：

```text
┌────────────────────────────────────────────────────────────────────────┐
│ 軌道一：人類專案與治理軌 (Human & Project Governance Track)             │
├─────────────────┬──────────────────────────────────────────────────────┤
│ 受眾目標        │ 產品負責人 (PO)、架構師、稽核合規人員、業務主管      │
│ 核心訴求        │ 商業意圖傳達、架構完整性、合規審計、結案交付報告     │
│ 文件資產        │ 1. docs/specs/ (SA/SD/DBA/QA 活體領域規格書)          │
│                 │ 2. docs/templates/RELEASE_DOSSIER_TEMPLATE.md (範本) │
│                 │ 3. docs/reports/ (每次版本發布正式產出之結案報告)    │
│                 │ 4. docs/adr/ (架構決策紀錄庫 ADR-001 ~ ADR-004)      │
│                 │ 5. docs/governance/RETROSPECTIVE.md (敏捷踩坑記憶庫) │
└─────────────────┴──────────────────────────────────────────────────────┘

┌────────────────────────────────────────────────────────────────────────┐
│ 軌道二：AI 機器執行軌 (AI Machine Execution Track)                     │
├─────────────────┬──────────────────────────────────────────────────────┤
│ 受眾目標        │ 無人分散式平行執行 Agent (AI Workers)                  │
│ 核心訴求        │ 零散文雜訊、結構化範圍邊界、客觀紅轉綠驗收指令       │
│ 文件資產        │ 1. contracts/openapi.yaml (單一事實契約真理)          │
│                 │ 2. apps/web-portal/services/generated/ (自動產出 SDK)│
│                 │ 3. tasks/TASK-xxxx/manifest.yaml (機器執行契約)      │
│                 │ 4. tests/e2e/*.spec.ts (預置 BDD Gherkin 測試骨架)   │
└─────────────────┴──────────────────────────────────────────────────────┘
```

### 2.1 雙軌運作流程與轉換機制
1. **由人類軌提煉機器軌**：
   - 架構師與 PO 於 `docs/specs/` 定義領域規格後，透過工具自動或半自動將 API 契約提煉至 `contracts/openapi.yaml`。
   - 執行命令自動產生前端 TypeScript 呼叫代碼：
     ```bash
     npx @openapitools/openapi-generator-cli generate        -i contracts/openapi.yaml        -g typescript-axios        -o apps/web-portal/services/generated
     ```
2. **AI Worker 依據 `manifest.yaml` 閉環執行**：
   - AI Worker 啟動時僅加載 `manifest.yaml`、產生的 SDK 與測試骨架，在定義好的 `target_files` 範圍內實作，直至 `acceptance_gate` 命令回傳 exit code 0。
3. **結案時由 AI 彙整人類結案報告**：
   - 任務驗收完畢後，由彙整 Agent 讀取 Git 提交日誌、測試報告與程式碼，參照 `RELEASE_DOSSIER_TEMPLATE.md` 產出正式結案報告書存入 `docs/reports/`，供主管檢閱簽核。

---

## 3. 影響與效益評估 (Consequences)

- **正面效益**：
  - AI 任務執行成功率顯著提升，杜絕前端手寫不存在 API 之幻覺。
  - Token 消耗量降低 40% 以上（不再每次傳遞長篇業務散文）。
  - 專案交付具備企業級治理資產，符合金融稽核要求。
- **代價與維護成本**：
  - 需維持 OpenAPI 契約與規格書的同步，契約更新需觸發 SDK 重建。
