# ADR-008: 前後端多庫獨立與契約先行解耦分支生命週期架構 (Multi-Repo Contract-First Decoupled Branching Architecture)

## 1. 狀態 (Status)
**已批准 (Accepted)** - 2026-10-12

## 2. 背景與問題意識 (Context & Problem Statement)
隨著系統規模與組織擴展，專案即將由單一多模組庫 (Monorepo) 轉型為前後端多倉庫獨立體系 (Multi-Repo Architecture)：
- **前端團隊獨立維護**：專屬於 `apps/web-portal`（未來獨立倉庫 `reinsurance-web-portal`）。
- **後端團隊獨立維護**：專屬於 `services/core-service`（未來獨立倉庫 `reinsurance-core-service`）。
- **共用契約與治理資產**：`contracts/openapi.yaml`、六大活體規格書 (`specs/`)、工程規範與 ADR 將由獨立共用庫 (`reinsurance-contracts`) 透過 Git Submodule 雙向掛載。

在此架構下，原先單一庫規範中所允許的「跨端延續性相依鏈（前端分支由後端分支切出）」在物理隔離後**徹底失效**。若不建立明確的多庫解耦治理模型，將引發跨團隊阻塞、分支衝突與 API 契約漂移。

## 3. 架構決策 (Decisions)

### 3.1 徹底廢除跨端鏈式切分支 (No Cross-Repo Chained Branching)
- **原則**：前端 UI 分支與後端 API 分支**嚴禁跨倉庫切出**。
- **分支來源**：
  - 後端 API 微任務：強制從後端倉庫之 `dev` 切出獨立分支（例如 `feature/TASK-xxxx-API`）。
  - 前端 UI 微任務：強制從前端倉庫之 `dev` 切出獨立分支（例如 `feature/TASK-xxxx-UI`）。
- **雙軌解耦**：前端開發不等待後端完成，前端直接以 `contracts/openapi.yaml` 契約為基準，透過 MSW (Mock Service Worker) / Prism 模擬伺服器進行無阻塞獨立並行開發。

### 3.2 契約先行 (Contract-First Workflow) 鐵律
1. **單一真實真理 (Single Source of Truth)**：
   任何業務變更、端點新增、欄位更動，**必須先在共用規格庫 (Contracts Repo) 提出 PR**，由前後端 Tech Lead 共同簽核合併，並發布語意化標籤 (如 `v1.2.0`)。
2. **Submodule SHA 版本鎖定**：
   前端倉庫與後端倉庫各自透過 Git Submodule 鎖定該標籤 SHA，依據確定性契約各自推進，零依賴、零撕裂。

### 3.3 任務切片與執行契約 (Manifest) 物理分離標準
- 任務套件中的 AI 機器執行契約正式拆分為雙軌契約：
  - `manifest-api.yaml`：宣告後端 API 範圍、目標倉庫 (`services/core-service`)、後端驗收閘門 (`mvn test`)。
  - `manifest-ui.yaml`：宣告前端 UI 範圍、目標倉庫 (`apps/web-portal`)、前端驗收雙閘門 (`tsc` + `npm test`)。
- 人類任務切片對稱對應為：
  - `TASK-xxxx-01_API.md`
  - `TASK-xxxx-02_UI.md`

## 4. 影響與成效評估 (Consequences)
- **正向影響**：
  1. 前後端團隊完全物理隔離，權限清楚，依賴與構建徹底解耦。
  2. 前端開發不再等待後端實作，依靠 Mock Server 真正達成敏捷並行。
  3. 任何 API 變更都必須經過共用庫審批，杜絕私改欄位造成的線上當機事故。
- **維護成本**：
  1. 跨團隊開工前必須先完成 OpenAPI 契約與規格書審批。
