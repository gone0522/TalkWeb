# ADR-009: 可演進式模組邊界、軟性關聯與自然芽裂架構 (Evolvable Architecture, Soft Boundaries & Vertical Sprouting)

## 1. 狀態 (Status)
**已批准 (Accepted)** - 2026-10-12

## 2. 背景與問題意識 (Context & Problem Statement)
依據軟體工程經典法則 **MonolithFirst**，專案初期業務邊界模糊時，若過早實體切分微服務或多微前端獨立倉庫，將引發跨庫重構噩夢、網路 RPC 延遲與嚴重的維護摩擦。因此專案在「第 2 階段（前後端各一獨立倉庫）」快速堆疊業務。

然而，若不在初期寫下嚴格的「防糾纏邊界規範」，隨著功能疊加（國家、區域、幣別、合約、理賠），代碼庫將迅速退化為牽一髮動全身的「大泥球 (Big Ball of Mud)」——跨表 SQL 狂 JOIN、跨模組直接 `@Autowired` 內部 Repository、前端私有元件深層混用。屆時日後欲升級至「第 3 階段（垂直領域切片）」與「第 4 階段（AI 原生意圖驅動）」時，將面臨無從拆解的死鎖困境。

為此，本 ADR 正式確立**「五大抗耦合硬防線」**與**「自然芽裂協議 (The Sprouting Protocol)」**，使專案在初期寫在同一個倉庫時，程式碼天生具備自動聚合與無痛垂直拆分的演化能力。

---

## 3. 架構決策 (Decisions)

### 3.1 基因一：全資產領域標籤鐵律 (Domain Tagging Protocol)
任何新增之 API 端點、任務卡、資料庫表或前端頁面，自第一天起強制標註 `domain_tag`：
1. **OpenAPI 契約**：所有路徑必須包含 `tags: ["domain:<domain_name>"]`（例如 `domain:masterdata`、`domain:treaty`）。
2. **機器契約 (`manifest.yaml`)**：強制宣告：
   ```yaml
   domain:
     name: "masterdata"
     subdomain: "currency"
   ```
3. **資料庫命名**：資料表強制包含業務族譜前綴（主檔類 `md_*`、合約類 `tr_*`、理賠類 `cl_*`）。

### 3.2 基因二：軟性外鍵與跨領域 SQL 零 JOIN 鐵律 (Soft FK & Application Assembly)
1. **軟性關聯 (Soft Foreign Key)**：
   - 跨領域引用（例如合約表引用幣別）只儲存邏輯代碼（`currency_code VARCHAR(3)`）。
   - **資料庫物理層面嚴禁建立 `FOREIGN KEY` 實體約束去關聯其他領域之資料表！** 關聯性完整由應用層邏輯防禦。
2. **零跨領域 SQL JOIN**：
   - 嚴禁在 Repository / DAO 撰寫跨不同業務前綴資料表的 SQL `JOIN`。
   - 跨領域資料關聯必須在應用層組裝，或在建檔時保存快照（Snapshot Pattern）。
3. **引用防禦協議 (Referential Guard Protocol)**：
   - 被引用的核心主檔實體必須提供 `GET /references` 摘要端點，變更狀態前必須檢核引用計數。
   - 嚴禁物理 `DELETE`，一律使用邏輯停用 (`is_disabled = true`)。

### 3.3 基因三：後端 Package-Private 封閉性與公開介面防線 (Public Interface Defense)
1. **模組內部封閉**：
   - 領域內部的 Repository、內部實體與私有 Service 必須宣告為 Package-Private（去掉 `public`），杜絕外部模組直接存取。
2. **公開出口唯一性**：
   - 跨領域調用只能透過公開的 `PublicQueryApi` 或 Domain Events。嚴禁直接 `@Autowired` 其他領域的內部 Repository！
3. **架構測試防線 (ArchUnit Guard)**：
   - CI Pipeline 強制執行 ArchUnit 架構單元測試，任何越界引用直接編譯紅燈攔截。

### 3.4 基因四：前端 Feature-Sliced 垂直內聚目錄規範 (Feature-Sliced Directory)
1. **目錄結構**：
   - 前端強制以 `src/features/<domain>/<subdomain>/` 組織畫面與邏輯：
     * `components/` (專屬 UI 元件)
     * `api/` (專屬 API Client)
     * `hooks/` (專屬狀態 Hook)
     * `types/` (專屬型別定義)
     * `index.ts` (對外唯一匯出出口)
2. **禁止深層私有引用**：
   - 外部頁面僅能自 `src/features/<domain>/<subdomain>` 引入公開元件，嚴禁深入私有檔案。
3. **基座上下文注入 (Shell Context)**：
   - UI 元件不直接綁定全局實例，Toast、Auth、語系切換均透過標準 Context 或 Browser Event 注入。
4. **邊界 ESLint 攔截**：
   - 配置 ESLint `import/no-restricted-paths`，跨領域非法引用直接報錯中斷構建。

### 3.5 基因五：測試替身協議 (Test Double Protocol)
1. **禁止測試跨庫插表**：
   - 單元測試中，嚴禁為了測試 A 模組而直接向 B 模組的資料庫表寫入假資料。
2. **替身伴生提供**：
   - 每個領域必須伴隨公開其 Mock 替身 (WireMock Stub 或 In-Memory Stub)，調用方測試僅能依賴替身。

---

## 4. 自然芽裂協議 (The Sprouting Protocol)

當系統累積功能、業務模式成熟時，依據以下三階段無痛完成垂直切片（升級至 Level 3）：

```text
┌────────────────────────────────────────────────────────────────────────┐
│ 階段 1：種子期 (Seed Stage - 當前現狀)                                   │
│  - 前後端各一獨立倉庫，但嚴守五大抗耦合硬防線。                          │
├────────────────────────────────────────────────────────────────────────┤
│ 階段 2：聚合成熟期 (Clustering Stage)                                   │
│  - 相關模組自動聚集於 `masterdata` package 與 `features/masterdata`。   │
│  - 觸發芽裂指標：代碼行數 > 3,000 行，或需要獨立發版部署。               │
├────────────────────────────────────────────────────────────────────────┤
│ 階段 3：自然芽裂轉化 (The Sprouting Moment)                             │
│  - 使用 Git Subtree 歷史無損抽離：                                      │
│    git subtree split -P src/features/masterdata -b split-masterdata    │
│  - 打包為獨立 Domain Pod (包含 UI, API, DB Migration, Specs)，歷史完好。│
└────────────────────────────────────────────────────────────────────────┘
```

## 5. 影響與成效評估 (Consequences)
- **正面影響**：
  1. 初期享有單體系統的高效與低維護成本，免去微服務/微前端早期的白屏與網路 RPC 折磨。
  2. 代碼天生高內聚、低耦合，隨時具備一鍵芽裂成 Level 3 獨立 Pod 的能力。
  3. 為 Level 4（AI 原生軟體工廠）提供乾淨、邊界分明的小沙盒，AI 代碼合成準確率大幅提升至 99%+。
- **約束**：
  1. 開發團隊必須適應「無跨表 SQL JOIN」與「軟性外鍵」設計。