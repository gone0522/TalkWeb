# ADR-006: 規格主權位階、配置強型別防漂移與混沌容錯防線 (Spec Precedence Hierarchy, Schema-Validated Configuration, and Chaos Engineering Gate)

- **狀態**：`ACCEPTED (已採納)`
- **日期**：2026-10-12
- **負責人**：Lead Architect / Fullstack AI Agent Team
- **影響範圍**：`docs/`、`services/core-service/`、`apps/web-portal/`、全端任務拆解與 CI 構建

---

## 1. 背景與長青推演問題 (Context & 1,000-Cycle Analysis)

在系統累積數百次敏捷循環與長青演進推演中（STEP 5017 破綻 3、STEP 5025 黑天鵝 3 & 4），暴露出三項隱蔽但致命的架構坍塌風險：

1. **規格記憶的認知衝突與模型坍塌 (Spec Precedence Collapse)**：
   - 歷史 ADR、業務規格、任務 Manifest 與回顧日誌隨時間膨脹至數百萬字。
   - 當新任務需求與多年前的早期規格或 ADR 出現文字衝突時，AI Agent 產生上下文幻覺，無法判斷何者為真實最高準則，導致代碼行為自我矛盾。
2. **環境配置漂移地獄 (Configuration Drift & Secret Rot)**：
   - 專案累積逾百個環境變數，工程師或 Agent 在本機散落使用 `process.env.XXX` 或 Java `System.getenv()`，一旦某一環境漏設，代碼在本地跑得通，卻在 SIT/UAT 開機數小時後拋出 `NullPointerException` 崩潰。
3. **極端網路中斷的混沌破壞 (Chaos & Partial Failures)**：
   - 傳統自動化測試皆在理想網路環境運行。一旦線上發生網路斷裂或 HTTP Response 遺失，前端發起重試可能引發重複操作或破壞冪等性。

---

## 2. 決策內容 (Decision Drivers & Strategy)

為確保系統在累積千次循環後依然具備絕對的秩序性與抗顛覆能力，確立三大架構準則：

### 2.1 規格主權四級位階協議 (Spec Precedence Hierarchy)
建立不可動搖的法律級規格位階，任何衝突一律依位階裁決：
```text
┌────────────────────────────────────────┐
│ 第 1 位階（最高法）：docs/adr/ (ADR)   │ ── 代表全系統不可動搖之架構憲章與底線
├────────────────────────────────────────┤
│ 第 2 位階（現行法）：docs/specs/ (Spec)│ ── 代表當下真實有效之領域業務與功能契約
├────────────────────────────────────────┤
│ 第 3 位階（施行法）：tasks/ (Manifest) │ ── 僅在該切片生命週期內有效之實作細則
├────────────────────────────────────────┤
│ 第 4 位階（判例法）：RETROSPECTIVE.md  │ ── 僅供避坑參考，無實質立法與修法權
└────────────────────────────────────────┘
```
- **衝突仲裁鐵律**：
  - 下位文件不得牴觸上位文件。
  - 若新需求明確需要變更上位規則（如突破 QoS 門檻或變更審計策略），**必須先發起 ADR 修訂提案，經 PO 簽核後方可修法生效**。

### 2.2 配置強型別校驗與開機零容忍 Fail-Fast 閘門 (Schema-Validated Config at Boot)
- **禁止散落存取**：代碼中嚴格禁止直接散落存取未經強型別校驗的原始環境變數。
- **後端規範**：一律使用 Spring `@ConfigurationProperties` + JSR-380 Bean Validation 宣告配置類別。
- **前端規範**：一律使用強型別 Schema 驗證模組集中管理 `NEXT_PUBLIC_*` 與伺服端環境變數。
- **啟動閘門**：服務啟動時若發現環境變數缺漏或型別不符，**立即拒絕啟動 (Fail-Fast on Boot)** 並印出缺漏報表。

### 2.3 混沌工程故障模擬與極端容錯防禦 (Chaos Engineering Gate)
- CI 流程納入故障注入測試：
  1. **丟失回應 (Dropped ACK)**：模擬伺服端已成功處理請求，但回傳封包遺失，驗證客戶端攜帶相同 `Idempotency-Key` 重試時，後端必須回傳快取結果而非重複執行。
  2. **延遲尖峰 (Latency Spikes)**：模擬資料庫或下游服務突發延遲 2~3 秒，驗證 Hystrix / Resilience4j 斷路器與 Timeout 降級機制運作正常。

---

## 3. 實施成效與預期益處 (Consequences & Benefits)

- **消滅認知幻覺**：AI Agent 在拆解與執行任務時，具備明確的規則仲裁依據，不再因歷史檔案矛盾而徬徨。
- **開機零配置漂移**：100% 確保本地開發、Docker、CI、SIT 與 UAT 環境配置一致，所有環境缺失在容器啟動前 1 秒完全暴露。
- **金融級容錯能力**：抵禦任何線上網路波動與重複請求風險，守護交易與審計數據的絕對一致性。
