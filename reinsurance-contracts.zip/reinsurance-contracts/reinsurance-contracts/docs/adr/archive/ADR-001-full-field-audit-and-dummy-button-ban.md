# ADR-001: 全欄位審計留痕、全異動矩陣測試與空殼假按鈕禁令 (Full-Field Audit, Mutation Matrix Testing, and Dummy Button Ban)

- **狀態**：`ACCEPTED (已採納)`
- **日期**：`2026-10-12`
- **決策者**：`Lead Architect, Product Owner (Kenny)`
- **技術範圍**：`Backend (Spring Boot JPA), Frontend (Next.js/React), QA Testing`

---

## 1. 背景與問題根因 (Context & 5 Whys Analysis)

在系統長期演化與近期任務驗收中，發現了兩類嚴重的隱蔽性品質缺陷：
1. **全欄位審計漏洞 (Audit Log Incompleteness)**：
   - 在 `TASK-007` 結算幣別模組實測中，修改「運算設定」時系統會正確寫入異動原因與審計日誌；但當修改中英文名稱、代碼、狀態時，系統卻完全無留痕。
   - **根因分析**：規格書僅在特殊運算規則段落強調了「必須填寫異動原因」，開發人員與 AI 誤以為「只有需要原因的欄位才要記日誌」，遺漏了主檔基本欄位的異動審計；同時，測試案例甚至使用了反向斷言 `assertTrue(auditLogs.isEmpty())`，導致遺漏變成了「綠燈」。
2. **空殼假按鈕現象 (No-Op Dummy Button Ban)**：
   - 在 `TASK-0101` 與 `TASK-0102` 中，國家選單與區域選單的工具列上均存在看似可點擊的「匯出 Excel」按鈕，但點擊後完全無任何反應，亦無發出網路請求。
   - **根因分析**：需求與設計稿中有匯出按鈕，但早期任務拆解時後端未開立匯出 API。前端工程師在面臨排程交付壓力時選擇妥協，僅切出外觀為 `<button>匯出 Excel</button>` 但未綁定 `onClick` 事件的空殼按鈕，造成使用者誤以為系統故障。

金融與再保險系統對「資料可追溯性」與「操作真實性」具有極高的合規要求，空殼按鈕與審計遺漏在正式環境均屬不可接受的 P1 級缺陷。

---

## 2. 決策內容 (Decisions & Technical Architecture)

### 2.1 全欄位異動審計通用標準 (Full-Field Audit Standard)
凡主檔介面具備「異動紀錄 (Audit Trail / History)」頁籤者，後端必須覆蓋實體之**所有業務欄位**變更：
1. **重大業務欄位**（如結算運算規則、匯率、計價單位）：強制彈窗要求使用者填寫「異動原因 (`reason`)」。
2. **一般基本欄位**（如中英文名稱、代碼、顯示順序、啟用狀態）：自動留痕，異動原因填入預設值（例如：`「基本資料常規維護」` 或系統自動產出之摘要）。
3. **資料庫審計表記錄規格**：
   ```sql
   CREATE TABLE sys_audit_logs (
       id BIGSERIAL PRIMARY KEY,
       entity_name VARCHAR(64) NOT NULL,    -- 例: 'CURRENCY', 'REGION', 'COUNTRY'
       entity_id VARCHAR(64) NOT NULL,      -- 主鍵值，例: 'USD'
       field_name VARCHAR(64) NOT NULL,     -- 變更欄位，例: 'name_zh', 'status', 'calc_rule'
       old_value TEXT,                      -- 變更前值
       new_value TEXT,                      -- 變更後值
       reason TEXT NOT NULL,                -- 異動原因
       operator_id VARCHAR(64) NOT NULL,    -- 操作人員工號/帳號
       created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP NOT NULL
   );
   CREATE INDEX idx_audit_entity ON sys_audit_logs(entity_name, entity_id);
   ```
4. **後端統一審計攔截架構**：
   使用 Spring AOP 或 JPA Entity Listener 於 Service 更新方法自動比對前後差異（Entity Diff），保證只要任何欄位變更，必自動寫入 `sys_audit_logs`，禁止由業務代碼手動硬編碼組裝。

### 2.2 全異動矩陣測試禁令 (Mutation Matrix Testing)
1. **嚴禁反向斷言**：後端單元測試與整合測試嚴格禁止使用 `assertTrue(logs.isEmpty())` 來掩飾未記日誌的行為。
2. **矩陣測試覆蓋率**：針對實體的所有欄位，必須撰寫參數化測試（Parameterized Test），逐一驗證以下情境：
   - 情境 A：單獨修改名稱 -> 斷言產生 1 筆審計日誌，`field_name == 'name_zh'`。
   - 情境 B：單獨修改啟用狀態 -> 斷言產生 1 筆審計日誌，`field_name == 'status'`。
   - 情境 C：同時修改運算設定與名稱 -> 斷言產生 2 筆審計日誌，且重大欄位包含人工原因。

### 2.3 空殼假按鈕禁令 (No-Op Dummy Button Ban)
1. **按鈕語意與真實性**：
   頁面上任何按鈕必須具備明確且可互動之行為。嚴禁出現無 `onClick` 處理常式、或 `onClick` 僅有 `console.log` 的死按鈕。
2. **功能未就緒時的標準處理規範**：
   若需求拆解中該功能尚未開立後端 API 或排入次期開發：
   - **方式一（推薦：隱藏）**：前端直接不渲染該按鈕，避免混淆使用者。
   - **方式二（介面預留）**：若設計稿要求保留版面位置，該按鈕必須：
     - 設定屬性 `disabled={true}`。
     - 滑鼠懸停（Hover）時必須彈出 Tooltip 提示：`「功能開發中 / 預計下期上線」`。
     - 具備清楚之視覺停用樣式（置灰、禁止指標符號 `cursor-not-allowed`）。
3. **前端防呆包裝器元件範例**：
   ```tsx
   interface ActionButtonProps extends ButtonProps {
     actionReady?: boolean;
     unreadyTooltip?: string;
   }
   
   export const ActionButton: React.FC<ActionButtonProps> = ({
     actionReady = true,
     unreadyTooltip = "此功能規劃中，即將推出",
     onClick,
     children,
     ...props
   }) => {
     if (!actionReady || !onClick) {
       return (
         <Tooltip title={unreadyTooltip}>
           <span>
             <Button {...props} disabled={true} style={{ pointerEvents: 'none' }}>
               {children}
             </Button>
           </span>
         </Tooltip>
       );
     }
     return <Button {...props} onClick={onClick}>{children}</Button>;
   };
   ```

---

## 3. 實施細則與驗收閘門 (Implementation & Acceptance Gates)

1. **靜態與動態檢查防線**：
   - ESLint / TypeScript 檢查：禁止 `<button>` 或 `<Button>` 缺少 `onClick` 且未標記 `disabled`。
   - 審查清單：驗收測試時必須逐一點擊頁面工具列的所有按鈕，確認均能觸發實際行為或正確提示 disabled。
2. **歷史債務清理**：
   - 國家選單 (`TASK-0101`) 與區域選單 (`TASK-0102`) 的「匯出 Excel」假按鈕，必須於次期維護切片中統一置為 disabled 並標註 Tooltip，或補齊後端 API 實現真實匯出。

---

## 4. 影響評估與效益 (Consequences)

- **正面效益**：
  - 徹底杜絕線上「死按鈕」客訴與體驗不一致。
  - 金融審計 100% 留痕，符合內部風控與合規檢查。
- **維護成本**：
  - 後端測試需增加 5~8 個欄位變更測試案例，但能確保重構時不漏日誌。
  - 前端需嚴格遵循防呆按鈕元件封裝。
