# ADR-005: 執行環境長青化、LTS 跟隨與相依套件全生命週期治理 (Evergreen Runtime & Dependency Governance Policy)

- **狀態**：`ACCEPTED (已採納)`
- **日期**：`2026-10-12`
- **決策者**：`Lead Architect, Product Owner (Kenny)`
- **技術範圍**：`Architecture, Java/JDK Runtime, Node.js, Maven pom.xml Ecosystem, npm package.json Ecosystem, DevSecOps`

---

## 1. 背景與問題 (Context)

在企業級長期維運系統中，技術債的積累往往並非來自業務邏輯，而是源自**「第三方相依函式庫與執行環境的老化 (Dependency Rot)」**：
1. **「能跑就別動」的死局 (The Freeze Trap)**：
   - 系統在上線後長期凍結 `pom.xml` 與 `package.json` 中的依賴版本。
   - 隨著時間推移，底層框架失去官方支援 (EOL)，爆發嚴重 CVE 安全漏洞無法修補（如 Log4j、Spring Framework RCE）。
   - 當被迫升級時，面對的是跨越多個大版本的巨大 Breaking Changes，升級週期長達數月，且極易引發線上重大事故。
2. **依賴管理混亂 (Dependency Hell & Jar Hell)**：
   - `pom.xml` 內散落硬編碼 `<version>`，造成傳遞依賴版本衝突；前端缺少確定性鎖定檔造成「本機能跑、CI 失敗」。
3. **過度冒進的踩坑 (The Bleeding-Edge Trap)**：
   - 盲目升級非穩定發行版，承擔開源套件初期的回歸 Bug。

---

## 2. 決策內容 (Decisions)

確立全套「長青工程體系 (Evergreen Engineering System)」，將依賴治理制度化：

### 2.1 執行環境 LTS 演進軌道 (Runtime LTS Track)
- **Java/JDK**：以 **Java 21 LTS** 為起點，未來新 LTS（如 Java 25、Java 30）發布滿 6 個月後自動啟動評估專案，平滑導入新語法、虛擬執行緒與新版 ZGC。
- **Node.js**：鎖定官方 **Active LTS**（現行 Node 20/22），維護期結束前 3 個月無痛遷移。

### 2.2 `pom.xml` 後端依賴收斂與衝突防禦
1. **BOM 集中化**：嚴禁在 `<dependencies>` 中直接寫死版本；優先由 `spring-boot-starter-parent` 託管，獨立第三方套件（如 POI）一律抽取至 `<properties>` 統一宣告。
2. **傳遞依賴仲裁**：透過 Maven Enforcer 插件強制執行 `DependencyConvergence`，禁止鑽石依賴衝突。
3. **每季體檢**：執行 `mvn versions:display-dependency-updates` 盤點落後套件。

### 2.3 `package.json` 前端確定性建置
1. **鎖定檔強制同步**：`package-lock.json` 必須同步提交，CI 與 Docker 強制執行 `npm ci`，嚴禁 `npm install`。
2. **定期掃描**：每雙週執行 `npm outdated` 與 `npm audit`。

### 2.4 依賴升級三級分流策略 (SemVer-Driven Promotion)
- **Patch (`x.y.Z`)**：Bugfix/CVE。自動化測試 100% 全綠走 **Tier 1 自主放行**，零打擾人類。
- **Minor (`x.Y.z`)**：向下相容新功能。每雙週批次開立 PR，由架構師批次審批。
- **Major (`X.y.z`)**：跨主版本升級。走 **Tier 2 最高風險審批**，獨立架構分支，需具備 1,000 QPS 壓測證明與 PO (Kenny) 簽核。

### 2.5 跨代升級四步演進 SOP (Major Migration 4-Step SOP)
1. **靜態預檢**：`jdeps` 與 `npm outdated` 檢驗 API 廢棄狀態。
2. **隔離分支**：開立專屬 `chore/upgrade-*` 分支，禁止混入業務代碼。
3. **自動重構**：使用 OpenRewrite (`UpgradeSpringBoot3_2`, `UpgradeToJava30`) 或 Next.js Codemod 批量自動轉換語法。
4. **效能回歸**：1,000 QPS 讀取壓測確認 P95 < 100ms 零退化，產出報告由 PO 簽核。

---

## 3. 效益與評估 (Consequences)

- **正面效益**：
  - 徹底杜絕系統老化引發的巨額技術債，系統具備持續自動年輕化的反脆弱能力。
  - 將重構風險分攤到日常微步演進中，總維護成本降低 80% 以上。
- **代價**：
  - 需定期維護 CI 依賴掃描工具鏈，但由自動化腳本承擔，人為負擔極低。
