# ADR-003: S / M / L 系統自適應分級模型與 1,000 QPS 服務品質基線 (Tiered Adaptive Scale & 1,000 QPS QoS Baseline)

- **狀態**：`ACCEPTED (已採納)`
- **日期**：`2026-10-12`
- **決策者**：`Lead Architect, Product Owner (Kenny)`
- **技術範圍**：`System Architecture, Performance Engineering, Database, Caching`

---

## 1. 背景與問題 (Context)

在軟體系統工程中，架構設計常面臨兩極化的陷阱：
1. **過度設計 (Over-Engineering / 殺雞用牛刀)**：在小型內部工具或原型階段，過早引入分散式快取、消息隊列、複雜的分相資料庫遷移，導致開發週期冗長，團隊不堪負荷。
2. **裸奔無防禦 (Under-Engineering / 盲目趕工)**：完全忽略非功能性需求 (NFR) 與高併發服務品質，未規劃資料庫索引與連線池，造成系統上線後隨流量增加迅速崩潰。

此外，本再保險核心主檔系統先前未明確定義非功能性指標（QPS、回應延遲、連線池上限），造成工程團隊在設計時缺乏客觀衡量標準。

---

## 2. 決策內容 (Decisions)

### 2.1 三級系統自適應分級模型 (The S / M / L Matrix)
確立系統自適應等級，系統在不同生命週期自動掛載對應標準：

| 指標維度 | S 級 (小型 / MVP / 工具) | M 級 (中型 / 本專案核心主檔基準) | L 級 (超大型 / 金融高併發清算) |
| :--- | :--- | :--- | :--- |
| **目標場景** | 原型、POC、內部批次小工具 | 企業核心主檔系統、再保營運管理中樞 | 跨國金融即時撮合、百萬保單清算 |
| **資料表規模** | < 15 張表 | 15 ~ 60 張表 | > 60 張表 |
| **API 數量** | < 30 支 API | 30 ~ 150 支 API | > 150 支 API |
| **預設 QPS** | < 300 QPS | **1,000 QPS (基準基線)** | 10,000+ QPS |
| **DB 遷移策略** | 循序號 `V1__init.sql` | **時間戳版號 `V{YYYYMMDDHHMMSS}__`** | **Expand/Contract 雙相無感遷移** |
| **快取架構** | 無快取 (直連 DB) | **預留 Spring `@Cacheable` 介面** | **Redis 集群 + 分散式互斥鎖** |
| **測試策略** | 全量測試本機跑 (< 20s) | 全單元測試 + i18n 靜態驗證 + 審計矩陣 | **TIA 增量測試分流 + 混沌工程** |
| **人機協同** | 對話即時驗收 | 拆解對齊 + 雙軌規格 + 信號燈報表 | **Tier 1 自主放行 + Tier 2 高亮審批** |

### 2.2 本專案 M 級服務品質基線 (QoS Baseline - 1,000 QPS)
本專案現階段定義為 **M 級系統**，所有模組之設計必須符合以下服務品質要求：
1. **吞吐量與延遲預算 (Latency Budget)**：
   - 吞吐量：日常承載 300~500 QPS，尖峰承載 1,000 QPS 查詢。
   - 讀取延遲：**P95 < 100ms**，P99 < 200ms。
   - 寫入延遲：**P95 < 250ms**，P99 < 500ms。
   - 靜態資源前端繪製：FCP < 1.0s，LCP < 2.0s。
2. **資料庫連線池調優 (HikariCP 配置規範)**：
   後端必須配置生產級 HikariCP 參數，杜絕連線耗盡死鎖：
   ```yaml
   spring:
     datasource:
       hikari:
         maximum-pool-size: 20
         minimum-idle: 10
         connection-timeout: 3000   # 3 秒逾時，快速失敗
         idle-timeout: 600000       # 10 分鐘釋放閒置連線
         max-lifetime: 1800000      # 30 分鐘生命週期，防連線老化
         leak-detection-threshold: 2000 # 2 秒偵測連線洩漏
   ```
3. **資料庫檢索 100% 索引覆蓋**：
   - 凡清單查詢、過濾條件、外鍵關聯欄位（如 `code`, `status`, `country_id`, `created_at`），必須建立 B-Tree 索引。
   - 嚴禁全表掃描 (Seq Scan)；分頁查詢必須強制依索引鍵排序。
4. **萬級 QPS 平滑擴展預留 (Extensibility to 10k QPS)**：
   主檔資料查詢 Service 必須使用標準 Spring `@Cacheable(value = "currencies", key = "#code")` 註解。現階段使用本機內存快取 (Caffeine)，未來只需透過設定檔注入 Redis 依賴即可無痛承載 10,000 QPS，無需改動業務邏輯。

### 2.3 四大客觀感知升級閥值 (Sensory Threshold Triggers)
系統不需要人工評估等級，自動依據客觀指標動態提示升級：
1. **測試耗時閥值**：全量測試突破 **3 分鐘** -> 自動切換為 L 級 TIA 增量測試分流。
2. **規格大小閥值**：主規格突破 **2,000 行** (或 30,000 Tokens) -> 自動拆分模組目錄隔離。
3. **性能流量閥值**：模組業務目標調至 **10,000 QPS** -> 自動掛載 Redis 快取與互斥鎖防護。
4. **並行節點閥值**：多機或多 Agent 並行開發 -> 強制啟用時間戳 Migration 與 Mock 隔離協議。

---

## 3. 效益與影響評估 (Consequences)

- **正面效益**：
  - 杜絕初期過度設計帶來的交付拖延。
  - 確保系統具備明確的效能底線，防止效能回退 (Performance Regression)。
  - 預留清楚的升級階梯，平滑支援從單體演進至大規模高併發。
