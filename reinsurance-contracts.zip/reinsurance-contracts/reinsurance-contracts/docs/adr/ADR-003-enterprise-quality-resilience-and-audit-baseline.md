<!--
governance_metadata:
  last_reviewed: "2026-10-13"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-13"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# ADR-003: 企業級品質韌性、合規審計與 QoS 基線 (Enterprise Quality, Audit & Resilience)

## 1. 狀態 (Status)
**已批准 (Accepted - 統合基石決策)** - 2026-10-12
*(整合並昇華歷史決策：ADR-001 全欄位異動審計、ADR-003 自適應 QoS 基線、ADR-005 常青依賴升級策略)*

## 2. 背景與問題意識 (Context)
金融與企業級核心系統要求絕對的資料一致性、嚴格的合規可追溯性與確定的服務品質 (QoS)。若缺乏統一標準，各模組往往在審計紀錄、錯誤回傳、配置管理與資料精度上各自為政，引發嚴重監管風險與線上故障。

## 3. 架構決策 (Decisions)

### 3.1 金融級同交易全欄位異動審計與 Canonical Standard Key 典範 (Full-Field Audit Trails & Canonical Keys)
- **同交易同持久化**：任何核心業務資料（國家、區域、幣別、合約）變更時，必須在同一個資料庫交易內自動寫入審計日誌。
- **審計上下文與全欄位差量**：審計紀錄必須涵蓋完整上下文：操作時間、操作人、所屬部門、欄位識別鍵、變更前值、變更後值與異動原因代碼。
- **規範鍵值存儲鐵律 (Canonical Identifiers in DB)**：
  * 資料庫審計表之 `change_reason` 與欄位名稱一律儲存 **規範代碼 / 標準鍵值 (Canonical Keys)**（例如 `SYSTEM_DEFAULT_UPDATE`、`MANUAL_USER_MAINTENANCE`、`BATCH_IMPORT_UPDATE`、`NAME_ZH`、`IS_SANCTIONED`），**嚴格禁止存入任何自然語言字串**。
  * 呈現層 (UI/報表) 統一由多語系資源包動態渲染在地化文案。
- **嚴禁反向斷言**：嚴禁測試反向斷言（如用 `isEmpty()` 掩飾未留痕）。

### 3.2 系統自適應分級、QoS 效能基線與 Java 21 虛擬執行緒
- **S 級 (輕量工具/原型)**：QPS < 100，P95 < 200ms。
- **M 級 (標準企業級 - 本專案預設基準)**：
  * 基準 1,000 QPS 尖峰吞吐，讀取 P95 < 100ms，寫入 P95 < 250ms。
  * **啟用 Java 21 虛擬執行緒 (Virtual Threads)**：在 `application.yml` 配置 `spring.threads.virtual.enabled: true`，消除 I/O 與 DB 連線池等待時的執行緒阻塞。
  * **HikariCP 連線池調優**：最大池 20、連線逾時 3s 快速失敗。
  * **100% B-Tree 索引覆蓋**：所有查詢條件、過濾狀態與外鍵關聯代碼必須建立索引。
- **L 級 (關鍵高併發/結算核心)**：QPS > 10,000，P95 < 50ms，強制作業拆分、Redis 快取與 Transactional Outbox 模式。

### 3.3 企業級技術棧 Tier-1 BOM (Bill of Materials) 與套件治理 (Enterprise BOM - 拒絕低效手刻輪子)
- **拒絕手刻低效輪子原則**：AI 與工程師嚴禁手刻已有成熟開源方案之基礎建設（如手寫大量構造函數、手寫繁瑣 DTO 映射、手寫屬性差異比對、手寫 inline SVG、手寫 10 個 useState 表單、手寫 Prop-drilling Toast）。
- **Spring Boot 3.x Tier-1 Approved BOM**：
  1. `Lombok`: `@RequiredArgsConstructor`, `@Getter`, `@Setter`, `@Builder`, `@Slf4j`，消除手刻樣板代碼。
  2. `Flyway` / `Liquibase`: 企業級版本化資料庫遷移管線；**嚴格禁止 `hibernate.ddl-auto=update`**（在企業級環境只允許 `validate` 或 `none`），配置 `lock_timeout = '5s'`。
  3. `MapStruct`: 編譯期型別安全 Entity <-> DTO 高性能映射器，杜絕手寫 `toResponse()` 維護負擔。
  4. `Spring Data JPA Auditing`: `@EnableJpaAuditing` 搭配 `@CreatedDate`, `@LastModifiedDate`, `@CreatedBy`, `@LastModifiedBy` 自動維護審計欄位。
  5. `JaVers` / `Hibernate Envers`: 自動化實體屬性差量比對審計引擎 (Entity Diff)，自動記錄前值、後值與變更歷程。
  6. `EasyExcel` / `Spring POI Template`: 註解驅動流式 Excel 匯出 (`@ExcelProperty`)，百萬級資料流式傳輸不 OOM。
  7. `springdoc-openapi-starter-webmvc-ui`: 自動生成 Swagger UI 與 OpenAPI 3.0 契約。
  8. `ArchUnit`: 自動化架構單元測試，嚴格防禦 Package-Private 與邊界隔離。
  9. `Testcontainers`: 真實 Docker PostgreSQL 容器化整合測試。
- **Next.js 15 / React 19 前端企業級強制技術棧標準 (Frontend Enterprise Mandatory Architecture)**：
  1. **RSC vs Client Components 嚴格邊界**：頁面入口與佈局預設 Server Components (零 Bundle, 高 SEO)；`'use client'` 嚴格限制於葉節點互動元件。
  2. **三層狀態管理拓撲**：
     * Server State: `@tanstack/react-query` (強制用於所有 API 請求、快取、去重、樂觀更新)。
     * Global Client State: `zustand` (輕量狀態庫，取代 Context/Redux 地獄，管理會話、彈窗、主題)。
     * Form & Local State: `react-hook-form` + `zod`，淘汰宣告多個 `useState` 的原始寫法。
  3. **網路傳輸與攔截器標準**：集中式 Client，內建 JWT 自動注入、無感 Refresh Token 輪轉、`X-Trace-ID` 鏈路追蹤、`AbortController` 請求防競爭、RFC 7807 錯誤規範化。
  4. **設計系統與 Design Tokens 鐵律**：集中化 `tokens.css` (4px 網格、HSL 色系、層級規範)，**全面嚴格禁止 JSX 行內 `style={{ ... }}`**。
  5. **無障礙 Headless 元件體系 (WCAG 2.1 AA)**：全面基於 Radix UI Primitives 封裝，自帶 Focus Trap 焦點陷阱與全鍵盤操作。
  6. **企業級表格與虛擬化**：`@tanstack/react-table` 搭配 `@tanstack/react-virtual`（> 100 筆資料強制虛擬滾動）。
  7. **高可用性與性能基線**：`react-error-boundary` 錯誤邊界、骨架屏 Suspense Skeletons、Web Vitals 門檻 (LCP < 2.5s, INP < 200ms, CLS < 0.1)、`next/dynamic` 延遲載入。
  8. **圖示與全域通知**：`lucide-react`（零手寫 inline SVG）與 `sonner`（全域宣告式 Toast，消除 Prop-drilling）。
- **強型別配置與 ProblemDetail**：
  * 環境變數透過 `@ConfigurationProperties` + JSR-380 驗證。
  * 錯誤處理全面採用 Spring Boot 3 內建 `ProblemDetail` (RFC 7807/9457)，自帶機器錯誤代碼 (`errorCode`)。
  * Jakarta EE 10 嚴格約束 (`jakarta.validation.*`, `jakarta.persistence.*`)。

### 3.4 測試瞬態隔離與分散式容錯模式
- **測試資料庫瞬態隔離 (Ephemeral Test DB)**：測試方法強制標註 `@Transactional`，測試完成後自動 Rollback，嚴禁殘留髒資料。
- **容錯消費者 (Tolerant Reader)**：外部 DTO 一律標註 `@JsonIgnoreProperties(ignoreUnknown = true)`，避免跨服務欄位演進時反序列化報錯。
- **事務性發件箱模式 (Transactional Outbox Pattern)**：跨領域重大事件必須與業務操作在同一事務內寫入 `outbox_events` 表，由異步中繼器保證至少送達一次。

### 3.5 架構自動升級、自主演化與防熵自閉環機制 (Autonomous Evolution & Self-Healing Architecture)
- **架構靜態探針 (Sensory Probes)**：CI 自動掃描手刻 DTO 映射、表單多個 useState、行內 SVG、行內 style、缺少樂觀鎖、自然語言寫死等異味，自動自舉引入 Tier-1 標準解法。
- **踩坑程式化自閉環協定 (Rules-as-Tests Pipeline)**：人類每一次反饋強制依據 5 Whys 記入 `RETROSPECTIVE.md`，並編寫自動化門禁腳本固化為系統硬約束。
- **企業常青技術雷達 (Technology Radar)**：確立 Adopt, Trial, Assess, Hold 四階技術生命週期，持續吸收成熟開源標準，淘汰過時手刻代碼。
- **季度評審與保鮮節奏 (Quarterly Freshness Cadence)**：確立每 90 天為一個審核週期。定期檢驗 Meta-ADRs、ENGINEERING_STANDARDS、.agents/rules 與 .agents/skills 與當前主流 LTS 技術棧及大模型能力之相容性。
- **條款元資料規範 (Governance Metadata)**：所有治理文件強制標註 `last_reviewed: "2026-10-13"`、`review_cadence: QUARTERLY`、`next_review_due: "2027-01-13"`、`governance_status: ACTIVE`。
- **自動化適性函數防護 (Architectural Fitness Function Gate)**：CI 流程執行 `scripts/audit-specs.py` 自動驗證所有規範文件之保鮮期限，超過審核期限即時告警阻斷，防止架構與現實脫節。

### 3.6 全層次零自然語言寫死與動態在地化報表 (Zero Hardcoded Strings & Dynamic Localized Reports)
- **非呈現層自然語言全面禁令**：任何語言之自然語言字串常值嚴禁硬編碼於 Service、Domain、Repository 與 API Client。
- **傳輸層機器代碼唯一性**：前端 API Client 拋出異常時僅傳遞機器錯誤代碼 (`errorCode`) 與 HTTP 狀態，由 UI 層以 `t('errors.' + errorCode)` 解析多語系。
- **動態在地化報表匯出**：後端生成 Excel / CSV / PDF 報表時，表頭與列舉名稱必須透過動態注入之 `MessageSource`，依照當前 HTTP `Accept-Language` 標頭即時解析語系，嚴禁寫死靜態字串陣列。

### 3.7 結構化日誌、MDC 鏈路追蹤、樂觀鎖與冪等防護 (Structured Logging, MDC & Idempotency Baseline)
- **結構化日誌與參數化**：全面使用 SLF4J 參數化日誌 (`log.info("...", arg)`)，嚴格禁止日誌字串拼接。
- **MDC 鏈路追蹤**：全請求鏈路強制綁定 MDC 上下文：`traceId`, `spanId`, `operatorId`, `domain`。
- **樂觀鎖併發控制**：所有可變核心實體強制具備 `@Version private Long version;`，衝突時回傳 409 Conflict。
- **冪等性防護**：變更資料與匯出請求支援 `X-Idempotency-Key` 標頭防範重複執行。



### 3.8 演化與修復第一法則——修復原型原語，而非手冊追加規則 (Patch the Archetype, NOT the Rulebook)
- **破除打地鼠惡性循環**：當發現全域性品質缺陷（例如報表表頭在地化遺漏、併發衝突缺少刷新提示、按鈕防連點失效）時，**嚴禁在規範手冊中不斷追加微觀列舉條款**。
- **直擊原型核心 (Patch the Archetype)**：
  * 架構師與 AI 的唯一修復職責，是**直接升級 `Agent SDK` 內部對應的原型原語**（例如在 `GenericExcelExportEngine` 內部將 `MessageSource` 設為強制注入，或在 `<MasterDataGrid>` 內部封裝骨架屏）。
  * 原型原語一旦修復並通過測試，所有引用該 SDK 的業務模組在下次構建時自動獲得免疫力。
  * **規範手冊永遠維持精簡、純粹與高階，杜絕條文無限膨脹**。

### 3.9 可觀測性驗收神諭與環境前置契約 (Observable Verification Oracles & Host Pre-flight Contracts)
- **環境前置神諭 (Pre-flight Host Contract)**：
  * 任務字節碼 (Task-IR) 必須顯式宣告執行環境先決條件（如 DB 最低遷移版本、容器運行狀態、前置分支狀態）。AI 虛擬機在解譯代碼前強制執行 Probe 驗證，防止因環境未就緒導致盲目除錯。
- **行為與觀測性斷言神諭 (Observable Behavioral Oracles)**：
  * 拒絕「測試通過但行為脫節」的作弊。驗收神諭必須鎖定**真實可觀測性指標**：
    - Micrometer 計數器是否真實遞增？
    - 資料庫 `version` 是否真實攔截併發覆蓋？
    - ArchUnit 架構單元測試是否 100% 阻斷跨層自然語言滲漏？
