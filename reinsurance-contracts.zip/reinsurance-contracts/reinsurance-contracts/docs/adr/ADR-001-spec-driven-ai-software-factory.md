<!--
governance_metadata:
  last_reviewed: "2026-10-13"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-13"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# ADR-001: 規格驅動之 AI 原生軟體工廠架構 (Spec-Driven AI Software Factory)

## 1. 狀態 (Status)
**已批准 (Accepted - 統合基石決策)** - 2026-10-12
*(整合並昇華歷史決策：ADR-002 雙軌規格體系、ADR-004 風險自主放行、ADR-006 規格主權位階、ADR-007 軟體工廠防熵體系)*

## 2. 架構願景與核心定位 (Vision & Charter) - 百年不變的人機意圖契約

### 2.1 最原始的目的 (The Primal Mission)
整個 AI 軟體工廠架構最原始、最神聖的目的，就是**將「人類商業意圖」精準無損地轉換為「機器語言」，而且機器可以確實無誤、零歧義、零妥協地執行，幾乎 100% 依照人類想要的樣子去落地實作**。
在傳統軟體工程中，無數系統之所以失敗，不是因為人類缺乏想法，而是想法在經歷自然語言溝通、層層人員轉譯、代碼拼裝的過程中產生了不可逆的語意衰減與認知斷層。

### 2.2 百年不變量公理 (The Centennial Invariant Axiom)
當我們將系統架構的生命週期年線拉伸至**一百年（Centennial Horizon: 2026 ~ 2126+）**：
* **原則的東西就像太陽升起一樣不會改變**：數學的真實性、借貸複式平衡、領域邏輯與表現層的物理隔離、不可篡改的審計軌跡、單一真理源契約——這些如同自然律與物理定律，永恆有效。
* **會隨時代改變的，僅僅是運作的模型與具體的計算機器**：從 2026 年的 Claude、Gemini、GPT 與 JVM/React 宿主，到未來的超神經模型、光子或量子計算機。機器是短命的可拋棄耗材，但轉譯意圖的字節碼規範與核心原則永遠長青。

### 2.3 軟體工廠核心演進五階自閉環流水線 (The 5-Stage Spec-Driven Closed-Loop Evolution Pipeline)
**口訣與鐵律：【有問題先討論 ➔ 調整規範 ➔ 產生任務 ➔ 確認執行 ➔ 驗收覆盤與自閉環】**  
**核心精神：嚴禁遇到問題就急著修改業務程式碼（打地鼠）。每一項調整都必須著眼於「如何讓未來的軟體資產更好、百年可重現、全域可免疫」。即便完全重啟對話，本流程亦必須強制執行！**

1. **第一階：有問題先討論 (Stage 1: Collaborative Root Cause & First-Principles Discussion)**:
   - **禁止動作**：禁止在沒有釐清根本原因前直接切換分支、修改程式碼、發布緊急補丁，或以局部 CSS / if-else 掩蓋症狀（嚴禁打地鼠）。
   - **核心任務**：回歸第一性原則 (First Principles)、認知心理學（完形、雙系統、工作記憶）、社會心理學（霍桑效應、心理安全感）、行為經濟學（推力、阻尼、損失厭惡）、貿易資訊經濟學（檸檬市場、交易成本、共有地治理）與反脆弱架構哲學，深入探討問題發生的本質原因。盤點全系統中是否存在同類盲點、歷史包袱或老骨董反模式（如 Windows 資料夾頁籤、disabled input 唯讀反模式、收據式破折虛線分割線）。與人類使用者充分對齊設計哲學與長期架構方向，直到取得完全共識。
2. **第二階：調整規範 (Stage 2: Specification & Governance Codification)**:
   - **禁止動作**：禁止在規範未定稿前產生具體任務或撰寫業務代碼。
   - **核心任務**：將討論共識 100% 寫入合約倉庫之活體規格 (Living Specs: `UI_SPEC.md`, `SD_SPEC.md`, `ENGINEERING_STANDARDS.md`, `TASK_EXECUTION_RULES.md`, `Agent SDK RFCs`)。若屬通用架構原語，提煉至 `Agent SDK` 原語與範本。主動清除歷史規格中殘留的「打地鼠條款」。執行 `scripts/audit-specs.py` 驗證五大治理閘門 100% 通過，並提交至 `reinsurance-contracts:dev`。
3. **第三階：產生任務 (Stage 3: Contract-Driven Task Synthesis)**:
   - **禁止動作**：禁止手動拼裝隨意命名之任務，禁止跨模組職責混雜。
   - **核心任務**：嚴格依照已定稿之現行規範與 OpenAPI 契約，合成標準 6 位數任務包 (`tasks/TASK-{06d}/`)。編譯輸出嚴格的 Task-IR (Task Intermediate Representation) 字節碼 (`task.ir.yaml`) 與標準 Manifest (`manifest.yaml`)。明確界定 `target_files`、`read_only_references` 與客觀驗收閘門。
4. **第四階：確認執行 (Stage 4: Explicit User Confirmation & Sentry Execution)**:
   - **禁止動作**：**未獲人類使用者明確指示前，絕對禁止擅自開始執行任務或修改運行時代碼！**
   - **核心任務**：當人類使用者發出執行指令後，始得建立專屬工作分支 (`feature/<TASK_ID>`)。嚴格遵循 TDD (Red-Green-Refactor) 與三庫串行合併順序實施落地。完成後通過客觀自動化門禁（編譯無錯、零死按鈕、零中文字串洩漏、同構矩陣 100% 對齊）。
5. **第五階：驗收覆盤與反脆弱自閉環 (Stage 5: Verify, Reconcile & Antifragile Retro)**:
   - **核心任務**：通過客觀自動化神諭驗收；實施主規格合併回寫 (Master Spec Reconciliation)；依據 5 Whys 在 `RETROSPECTIVE.md` 進行問題聚類分析。累計 3 次之反模式強制提煉至 Agent SDK 或實體防退化架構探針，實現系統負熵自演進。

## 3. 背景與問題意識 (Context)
在 AI 驅動的現代軟體工程中，若僅依賴自然語言 Prompt 或乾燥的代碼骨架，系統將迅速面臨四大死穴：
1. **規格漂移與認知斷層**：代碼往前推進而文檔落後，或重複撰寫兩套 API 定義導致不一致。
2. **假完工與空殼按鈕交付**：AI 為求完成任務，常妥協產出無實質處理的 Dummy 按鈕或假端點，甚至以空箭頭函式欺騙靜態語法檢查。
3. **無人化交付缺乏安全閥**：缺乏客觀風險分級，導致小修小補負擔沉重，或盲目自動合併引發災難。
4. **前後端整合摩擦**：缺乏明確的 Mock 轉真實 API 時機與資料同源機制，聯調時頻繁引發 404 與資料斷層。

## 4. 架構決策 (Decisions)

### 3.1 雙軌規格與 OpenAPI Code-Gen 職責分離 (Spec Separation & Code-Gen)
- **單一真理源**：`reinsurance-contracts` 倉庫為全系統規格事實真理，線上代碼純為規格之投影。
- **機器實體契約 (`contracts/openapi.yaml`)**：唯一掌握端點路徑、HTTP Method、Query/Body 欄位型別、Status Code 與 RFC 7807 錯誤模型。前端 Client 與後端 DTO 100% 由其自動 Code-Gen 生成，輸出至專屬投影目錄，禁止手寫修改。
- **人類活體規格 (`Living Specs`)**：專注於架構意圖（Mermaid 時序圖、業務驗證規則、領域交易邊界、快取與引用防禦），**嚴禁在 SD_SPEC 中手抄 JSON 資料字典**，徹底消除重複定義。

### 3.2 風險分級與三庫串行審批分流 (Tri-Repo Promotion Pipeline)
- **人機對話協同之絕對安全閥 (Human-in-the-Loop Confirmation Gate - 核心鐵律)**：
  * 在與人類結對協同開發（Interactive / Pair-Programming 模式）下，**無論任務宣告為 Tier-1 或 Tier-2，Agent 的任務執行邊界一律嚴格止步於在 feature/task 分支上完成代碼實作、提交並通過所有品質閘門，產出驗收報告。**
  * **嚴格禁止 Agent 在未經人類使用者明確確認同意前，自行切換分支並執行 `git merge dev` 或 `git merge main`**。
  * 所有進入受保護主幹分支（`dev`、`main`）的合併動作，必須由人類架構師 / PO 檢閱驗收報告並在對話中明確表達合併意圖（例如「請合併 TASK-XXXX」、「合併 TASK-XXXX」、「幫我將 TASK-XXXX 合併到 dev」等自然語言指令）後，方可執行！接獲意圖授權後，Agent 獲自主評估拓撲並自決採用 `merge` 或 `rebase` 最適策略。
- **Tier-1 (低風險任務)**：展示型 UI、唯讀端點、樣式微調、既有欄位補丁。所有品質閘門（型別、測試、AST 深入掃描、i18n）全綠後，Agent 產出驗收報告供人類檢閱；經人類確認授權後始可合併入 `dev`。
- **Tier-2 (高風險人工簽核)**：涉及 DB Schema 異動、核心主檔與合約狀態變更、財務幣別精度計算、安全認證。強制產生《結案發布報告書》，必須經由人類架構師簽核授權方可合併。
- **三庫串行合併鐵律**：
  1. `reinsurance-contracts` 的 `task/<TASK_ID>` 分支預審就緒（暫不合併）。
  2. 後端代碼 PR 測試全綠，經人類確認授權後合併入 `core-service:dev`。
  3. 前端代碼 PR 本地聯調通過，經人類確認授權後合併入 `web-portal:dev`。
  4. Contracts 庫由結案 Agent 完成主規格回寫檢驗，經人類確認授權後最終合併入 `contracts:dev`。
- **嚴守生產線禁令**：無論 Tier-1 或 Tier-2，**嚴格禁止 Agent 私自執行 `git merge main`**，生產發布必須由 PO 簽核。

### 3.3 防熵機制與 AST 深入函式體死按鈕審計 (Deep AST Anti-Entropy)
- **零死按鈕禁令 (Zero Dummy Buttons)**：任何 UI 按鈕嚴禁無實質點擊事件處理。未就緒功能必須顯式標記 `disabled={true}` 搭配 Tooltip 預留。
- **深入 AST 函式體審計 (`audit-buttons.js`)**：Babel AST 深入檢查 `onClick` 函式內容。若 Block 為空 `{}`、或僅含 `console.log` / `void 0`，一律判定為「假按鈕作弊」直接紅燈攔截！
- **BDD 場景紅轉綠**：以 Task Manifest 中定義的可執行 Gherkin 場景轉綠為唯一客觀驗收標準。

### 3.4 規格主權仲裁位階與現行法優先律 (Spec Precedence Hierarchy)
面對需求衝突時，遵循以下最高仲裁位階，嚴禁下層反向覆寫上層：
1. **最高法**：三大核心架構決策 (`docs/adr/`)
2. **現行法**：活體領域規格書 (`docs/specs/`) 與機器契約 (`contracts/openapi.yaml`)
3. **歷史判例與審計留痕**：踩坑經驗庫 (`docs/governance/RETROSPECTIVE.md`) 與歷史任務 (`tasks/`)
> **防污染鐵律**：AI 規劃與開發時默認**只調閱現行法**，嚴禁將歷史 `tasks/` 中的舊規格當作現行真理。

### 3.5 操作閉環、虛假可供性杜絕與確定性優雅降級 (Operational Closure & Resilient Landing)
- **第一性原理（操作閉環與零未定義行為）**：
  系統對外暴露之任何互動入口（頁籤、按鈕、側邊欄、超連結），其對應的狀態轉移必須是有界、受控且封閉自洽的。嚴格禁止在呈現層暴露任何會導向未定義狀態或呈現原生 HTTP 404 / 500 / 白屏的**虛假可供性 (False Affordance)**。
- **未就緒功能之三態降級階梯**：
  未就緒之功能必須嚴格遵循「不露出 (Hidden) ➔ 顯式抑制 (`disabled` + Tooltip) ➔ 規範化降級著陸 (Resilient Landing)」三態階梯。
- **標準降級卡片 (`ComingSoonPlaceholder`) 規範**：
  若功能作為全域導覽的一部分需漸進披露（如 6 大選單頁籤），未實作之頁面必須配置標準降級組件，呈現橘色 Sparkles 徽章、脈衝「模組規劃建置中」狀態、排程任務編號（如 TASK-000013）、架構規範錨點與返回基準工作區之安全逃生門。
- **核心主流程 API 缺失**：Agent 立即標記任務為 `BLOCKED`，終止開發並出示決策選單由負責人定奪。
- **非核心附加功能缺失**：啟動確定性降級，前端元件標記 `disabled={true}` 包裹 Tooltip「此功能規劃中，即將推出」，交付清單標記 `[UI-Placeholder]`，嚴禁留存無事件假按鈕。

### 3.6 Tier-1 輕量任務規格繼承與主規格語意錨點回寫 (Tier-1 Spec Inheritance & Reconciliation)
- **規格繼承授權 (Spec Inheritance)**：若該業務模組在 `docs/specs/` 已存在完整規格，Tier-1 任務**無須重複建立 6 大規格目錄**。Manifest 宣告 `spec_mode: "lightweight"` 與 `base_spec_ref`，任務卡強制包含 15 行極簡 Delta 單（引用來源 + 變更差量 + 1 個可執行 BDD 場景）。
- **主規格語意錨點回寫 (Semantic Anchor Reconciliation - Mandatory DoD)**：代碼合併入庫時，DoD 強制將增量欄位與邏輯以精確局部 Diff 替換寫回 `docs/specs/` 對應章節錨點（`<!-- SECTION: ... -->`），嚴禁全篇覆寫，杜絕規格漂移。

### 3.7 Mock 到真實 API 接軌時機與種子資料同源協議 (The Handshake Moment & Seed Data)
- **平行開發期 (Mocking)**：前端 `NEXT_PUBLIC_ENABLE_MOCK=true` 打 MSW Mock；後端單元測試。
- **本地真機聯調期 (The Handshake Moment)**：提 PR 前夕，前端切換 `NEXT_PUBLIC_ENABLE_MOCK=false` 直連 `http://localhost:8080`，執行真實 HTTP 請求與 Playwright E2E 走查。
- **種子資料同源**：後端 Flyway `V999__dev_seed_data.sql` 與前端 Mock Fixture (`currencies.json`) 採用完全相同之業務代碼與識別碼，杜絕聯調資料斷層。

### 3.8 依賴套件授權與自動引入協定 (Dependency Authorization & Bootstrap Protocol - 破除依賴悖論)
- **問題意識（依賴悖論）**：大語言模型 (LLM) 受到「嚴禁幻覺、嚴禁未經授權引入外部套件」之紀律約束，在缺乏明確授權時容易陷入「手刻輪子」的原始低效陷阱（例如手刻十幾欄位的 DTO 轉換、手刻十個 useState、手寫 inline SVG、手刻 Toast 傳遞）。
- **架構決策（白名單預授權與自舉）**：
  1. **規格宣告授權**：架構師/Planner 於 `manifest-api.yaml` 或 `manifest-ui.yaml` 之 `authorized_dependencies` 欄位中，顯式宣告該任務授權採用之 Tier-1 Approved BOM 套件。
  2. **執行端自動引進自舉 (Step 0 Dependency Bootstrap)**：Runner Agent 執行前置檢查時，若發現授權之依賴尚未包含於 `pom.xml` 或 `package.json`，**強制且自動地將其注入項目配置並執行安裝**，隨後直接採用成熟主流套件實作，嚴格禁止手刻輪子！
  3. **BOM 白名單安全閘門**：所有可授權引入之套件嚴格限定於 Meta-ADR 3 與 ENGINEERING_STANDARDS 規範之「企業級 Tier-1 Approved BOM」，嚴禁引入未經審核的未知第三方依賴。

### 3.9 嚴格多國語言架構邊界與零自然語言寫死禁令 (Strict i18n Boundaries & Zero Hardcoded Strings)
- **全語言零硬編碼鐵律**：無論中文、英文、日文或任何人類自然語言，**一律嚴禁在非 Presentation 層硬編碼字串常值**。靜態檢查不限於中文字元正則，亦涵蓋所有未參數化之自然語言字串。
- **四層架構分界原則**：
  1. **傳輸層 (Transport / API Client)**：純機器代碼層。嚴格禁止構造自然語言句子（例如 `throw new ApiError('Failed to export')` 亦屬違規），僅允許傳遞 HTTP 狀態碼與結構化機器錯誤代碼 (`errorCode` / `code`)。
  2. **資料庫與審計持久層 (Persistence / Audit Logs)**：審計異動原因 (`change_reason`) 與欄位名稱一律儲存 **規範代碼 (Canonical Identifiers / Standard Keys)**（例如 `SYSTEM_DEFAULT_UPDATE`, `NAME_ZH`），嚴禁於 DB 存入自然語言文字。
  3. **呈現層 (Presentation / UI Layer)**：唯一負責將機器代碼轉換為人類語言的層次。透過 `next-intl` 等多國語言字典（`zh-TW.json`, `en-US.json`）進行鍵值動態映射呈現。
  4. **報表匯出層 (Excel / Report Export)**：後端生成 Excel 或報表時，表頭與列舉值嚴禁寫死靜態字串陣列，必須動態注入 `MessageSource` 根據當前請求語系 (`LocaleContextHolder.getLocale()`) 即時解析多語系文案。

### 3.10 專案七階全生命週期工廠流水線 (The 7-Stage SDLC Pipeline)
- 專案從需求到發布強制劃分為七大標準階段：
  1. **Stage 0 (規格定錨)**：Living Specs + OpenAPI + Manifest 雙軌產出，QoS 與依賴預授權確定。
  2. **Stage 1 (分支解耦)**：Tri-Repo 分支切出，MSW Mock 啟動，前後端並行零阻塞。
  3. **Stage 2 (依賴自舉實作)**：Runner 執行 Step 0 Bootstrap，採用 Tier-1 Approved BOM。
  4. **Stage 3 (真機聯調接軌)**：Mock 關閉，Seed Data 同源對齊，真實連線與 E2E 走查。
  5. **Stage 4 (四大閘門串行晉級)**：四道客觀品質門禁全綠，三庫串行依序合併。
  6. **Stage 5 (容器化發布防線)**：Docker 構建、健康探針、PO 簽核。
  7. **Stage 6 (全鏈路可觀測與反思自閉環)**：MDC 日誌、Sentry 追蹤、Retrospective 自閉環。

### 3.11 架構自適應升級、自主演化與自癒引擎 (Autonomous Evolution & Self-Healing Engine)
- **破除被動納入陷阱**：建立「靜態架構探針 (Sensory Probes)」與「踩坑程式化自閉環 (Rules-as-Tests)」。
- **探針主動感知**：CI 自動偵測手寫 DTO 轉換、表單多個 useState、行內 SVG、行內 style 等異味，主動引進標準解法。
- **踩坑永不犯第二次錯**：人類每一次反饋強制轉化為 `RETROSPECTIVE.md` 根因記錄與代碼化自動門禁，開工前強制檢索繼承。



### 3.12 意圖編譯器、任務字節碼 (Task-IR) 與 AI 虛擬機體系 (The Intent Compiler, Task-IR & AI-VM Architecture)
- **Java 哲學之軟體工廠映射**：保留人類可讀的高階活體規格 (`.spec.md` - 相當於 `.java`)，但嚴禁依賴模糊的自然語言散文指揮任務執行。
- **意圖編譯器 (Intent Compiler / Task Planner)**：
  * 將人類高階規格、商業意圖與架構原則，標準化「編譯」為機器執行之中介字節碼：**Task-IR (Task Intermediate Representation, `task.ir.yaml`)**。
  * 編譯過程執行靜態型別檢驗、依賴符號連結 (Symbol Linking) 與語意消歧義。
- **任務字節碼 (Task-IR / Machine Bytecode)**：
  * 具備 100% 自包含性（Self-Contained Payload）：內建環境前置神諭 (Pre-flight Contract)、狀態變遷不變量 (State Invariants)、精確型別範圍、遙測度量名稱與可觀測性驗收神諭 (Verification Oracles)。
  * 消除為迎合人類審閱而產生的無效格式雜訊（如重複手抄表格、宣導標語、空目錄）。
- **AI 虛擬機 (AI Runtime / Task Runner)**：
  * 跨模型、跨平台標準執行引擎（無論底層為 Gemini, Claude, GPT, DeepSeek 或各類 Agent 工具）。
  * 虛擬機嚴格依循 Task-IR 執行 Strict TDD（紅燈先驗 ➔ 綠燈落庫 ➔ 重構優化），並透過客觀架構適性檢驗 (ArchUnit) 保證無歧義落地。

### 3.13 AI 標準函式庫 (Agent SDK) 與原型原語演化原則 (The Agent SDK & Archetype Evolution Mandate)
- **終結打地鼠與重新發明輪子**：軟體工廠的核心競爭力在於沉澱出跨專案通用之 **`Agent SDK`**。
- **三振成庫芽裂協議 (Rule of Three Graduation)**：
  * 同類業務模式（如 Master Data、匯出、審計、分頁）在業務領域出現第 3 次時，強制抽象為通用架構原語 (Archetype Primitives) 抽離並入 `Agent SDK`。
  * **領域零污染鐵律**：`Agent SDK` 嚴禁包含具體業務名詞，純粹封裝架構分層、高可用防禦、數學精度與 UI 互動原語。
- **修復原型原語，而非手冊追加規則 (Patch the Archetype, NOT the Rulebook)**：
  * 發現全域性缺陷（如報表表頭在地化、併發衝突處理、按鈕防連點）時，**嚴禁在規則手冊中無休止地追加微觀列舉條文**。
  * 團隊與 AI 的唯一職責是**直接修復 `Agent SDK` 內部對應的原型原語**。底層原語一旦修復，所有使用該 SDK 的業務模組自動獲得免疫力。### 3.14 嚴禁遭遇問題直接修改代碼與任務規格先行鐵律 (Anti-Adhoc Patching & Spec-Task Primacy Mandate)
- **任務顆粒度自評與實用主義修復啟發式 (Task Granularity Assessment & Decision Heuristic)**：
  * **微粒度變更 (Micro-Granularity)**：針對防禦性佔位路由、非業務型樣式微調、型別補齊等極小問題，允許直接修改代碼後隨即回溯微調既有 Task 規格（如回溯 TASK-000010），維持整體重放自洽。
  * **中/大粒度變更 (Medium/Macro-Granularity)**：凡涉及新業務、DB Schema 或狀態機，強制開立全新 Task 經人類審核後執行。
  * **無法確定時之安全閥**：最安全作法一律為「產生全新 Task」或「主動發起對話互動 (`ask_question`) 詢問人類架構師」。
- **第一性硬約束 (Code is Merely an Artifact; Specs & Tasks are Truth)**：
  在規格驅動 (Spec-Driven) 與時空膠囊確定性重現 (Deterministic Replay) 體系中，嚴格禁止任何「未經 Task 規格定義、跳過人類審批、遭遇問題直接修改工作區代碼」的私自修補 (Ad-hoc Patching) 行為。
  任何程式碼變更，其背後必須具備不可篡改、可溯源的 Task 規格與任務字節碼作為法理依據。若脫離 Task 直接改代碼，將導致未來全新環境重放任務時無法再現該修復，引發百年架構歷史漂移。
- **標準推進閉環 (Mandatory 5-Step Closed Loop)**：
  凡遭遇任何未實作、缺陷或架構優化需求，必須嚴格依循標準五階流水線推進：
  1. **確認問題 (Confirm Problem)**：精準定位異常現象、範圍與影響層面。
  2. **深入討論 (Discuss)**：向人類使用者陳述技術根因與可能解法，釐清業務與技術意圖。
  3. **任務規劃 (Plan Task - 嚴格二選一)**：
     - **路徑 A（回溯時空膠囊）**：若問題源自某既有任務的規格漏失，回溯修訂該任務之 manifest、task.ir 與 Living Specs，確保自首個任務重放即具備完整自洽性。
     - **路徑 B（開立全新任務）**：若屬於全新功能演進或架構增量修復，開立全新 6 位數 Task（如 TASK-000016），備齊 manifest.yaml、task.ir.yaml 與完整規格子任務。
  4. **人類審批確認 (Human Sign-off)**：明確出示 Task 變更計畫，取得人類架構師確認同意後，方可開啟 feature 分支。
  5. **代碼修改與門禁驗證 (Modify & Verify)**：嚴格依據審批通過之 Task 規格實作程式碼，通過所有門禁後呈交驗收報告，止步於分支等待合併指示。


