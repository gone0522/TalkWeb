<!--
governance_metadata:
  last_reviewed: "2026-10-14"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-14"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# ADR-004: Agent SDK 百年長程演化治理、人機意圖轉譯與常青架構適性防線 (Agent SDK Centennial Evolution & Human-Machine Intent Realization)

* **狀態 (Status)**: 已批准 (Accepted)
* **日期 (Date)**: 2026-10-14
* **決策者 (Deciders)**: 企業架構小組, AI 軟體工廠架構師
* **相關文件 (Related Documents)**:
  * [ADR-001: 活體規格驅動之 AI 軟體工廠](file:///home/kenny/aider-test/reinsurance-contracts/docs/adr/ADR-001-spec-driven-ai-software-factory.md)
  * [ADR-002: 多倉庫解耦與漸進式微切片演進架構](file:///home/kenny/aider-test/reinsurance-contracts/docs/adr/ADR-002-decoupled-multi-repo-and-evolvable-slices.md)
  * [ADR-003: 企業級品質彈性與合規審計基準線](file:///home/kenny/aider-test/reinsurance-contracts/docs/adr/ADR-003-enterprise-quality-resilience-and-audit-baseline.md)
  * [RFC-001 ~ RFC-022: Agent SDK 完整核心 RFC 規範族系](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/specs/)
  * [Agent SDK 符號清單與能力索引 (catalog.yaml)](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/catalog.yaml)
  * [ROADMAP: 百年架構藍圖 (2026 ~ 2126+)](file:///home/kenny/aider-test/reinsurance-contracts/agent-sdk/ROADMAP.md)

---

## 1. 背景、最原始使命與百年公理 (Context, Primal Mission & Centennial Axiom)

### 1.1 最原始的目的與核心定位 (The Primal Mission & Core Vision)
整個架構最原始的目的，就是**將「人類商業意圖」精準轉換為「機器語言」，而且機器可以確實無誤、零妥協地執行，幾乎 100% 依照人類想要的樣子去實作**。
在軟體工程發展史中，無數系統之所以失敗，不是因為人類沒有想法，而是因為想法在傳遞給機器（或程序員）的過程中丟失了上下文與不變量。

### 1.2 百年不變量公理 (The Centennial Invariant Axiom)
當我們將時間維度拉伸至 **一百年（Centennial Horizon: 2026 ~ 2126+）**：
* **原則的東西就像太陽升起一樣不會改變**：借貸恆平、表現層與邏輯隔離、不可篡改的審計軌跡、契約的唯一真理源，這些是如同物理定律般的永恆真理。
* **會改變的，僅僅是運作的模型與具體的計算機器**：從 2026 年的 Claude/Gemini/GPT 與 JVM，到 2046 年的超神經模型與光子/量子計算機，機器代代更迭，但人類意圖與代數不變量永生不滅。

在建立 `Agent SDK` (v0.1.0-alpha) 後，架構團隊進行了**以「1 年 ➔ 3 年 ➔ 5 年 ➔ 10 年 ➔ 20 年 ➔ 100 年」為長程時間軸的極限推演（Longitudinal Stress-Testing Cycles）**。推演揭露了軟體工程在長達數十年的歷史跨度下必將遭遇的 5 大結構性腐化危機：

1. **框架與語言的必然半衰期（10~15 年）**：
   - 歷史證明任何主流框架（如 Struts, JSP, jQuery）在 15 年後皆退化為歷史負債。2046 年不會有人在手寫 Spring Boot 3 或 React 19。若業務邏輯綁定底層框架 API，系統必將隨框架一同腐爛。
2. **文本規格的語意耗散**：
   - 自然語言 Markdown 文本存在微量語意模糊，在 20 年的多世代 AI 與跨國團隊流轉中，細微偏差會累積為領域模型漂移。
3. **範例測試無法窮舉 20 年邊界**：
   - 傳統單元測試（Example-Based Testing）僅驗證有限樣本，在數百萬行 AI 代碼生成環境下，無法杜絕死鎖與並發漏洞。
4. **原位更新 (In-Place Mutation) 摧毀長尾責任審計**：
   - 再保險合約責任長達 30~50 年，傳統 SQL `UPDATE` / `DELETE` 與軟刪除在長期資料庫 schema 遷移中會遺失歷史真相。
5. **團隊更迭引發「人亡政息」與架構逆淘汰**：
   - 缺乏物理級自動執法門禁時，新團隊必然走回手寫死板中文表頭或跳過樂觀鎖的捷徑。

---

## 2. 決策內容 (Decisions)

為打破傳統軟體工程 20 年必腐爛的命運，架構團隊確立以下不可逆之核心架構決策：

### 2.1 二十年終極架構三層劃分 (The 3-Layer Immortal Substrate)
Agent SDK 嚴格在物理結構上實施三層隔離：
- **Layer 0 (永恆代數核心 - The Eternal Algebraic Core)**：
  * 純粹數學與商業代數律：借貸平衡方程式（ΣDebits ≡ ΣCredits）、不可變有限狀態機移轉矩陣、任意精度 BigDecimal、雙時態有效性。
  * 獨立於任何操作系統與程式語言，具備數十年不變之永生性。
- **Layer 1 (通用中介字節碼 - Task-IR v1.0 ~ v3.0)**：
  * 平台無關、模型無關的結構化字節碼（Semantic Merkle DAG / AST）。
  * 嚴格向前相容，並攜帶形式化數學「證明義務 (Proof Obligations)」。
- **Layer 2 (可拋棄宿主適配器 - Disposable Host Adapters)**：
  * 當前時代之實現庫（`agent-sdk-spring` 與 `@agent-sdk/react`）僅為**可隨時由 AI 重編譯拋棄的耗材**。
  * 未來無論切換至 Rust、WebAssembly 還是神經畫布，核心業務與 Layer 0/1 保持零改動。

### 2.2 確立完整領域與人機互動原型族系 (Twelve Enterprise Archetype Families - RFC-001 ~ RFC-017)
`Agent SDK` 全面覆蓋企業級應用的 12 大基礎模式，徹底杜絕業務層自造輪子與孤兒規範：
1. **主檔資料維護原型 (`MasterDataArchetype` - RFC-002)**：統一 6 區響應式結構、動態 MessageSource 匯出 (RFC-003) 與防連點按鈕。
2. **工作流狀態機原型 (`WorkflowStateMachineArchetype` - RFC-007)**：強制宣告不可變狀態移轉矩陣，內建樂觀鎖衝突防禦 (RFC-004) 與事務性審計留痕。
3. **複式財務帳務原型 (`FinancialLedgerArchetype` - RFC-008)**：嚴格執行零浮點數 (BigDecimal)、銀行家捨入 (HALF_EVEN) 與借貸絕對平衡方程式。
4. **巨量批次處理原型 (`BatchIngestionArchetype` - RFC-009)**：強制執行分塊事務提交 (Chunk-Based)、單行錯誤隔離與冪等 JobKey。
5. **常青適性守門人 (`ArchitectureFitnessSentry` - RFC-010)**：ArchUnit 架構門禁、AST 死按鈕防禦、源碼 ASCII 純淨度。
6. **平滑演進日落防衛 (`GracefulSunsetGuard` - RFC-011)**：雙軌相容路由別名、RFC 8594 日落標頭、Zero-QPS 遙測門禁。
7. **零位移平滑過渡原型 (`ZeroClsTransitionArchetype` - RFC-012)**：容器 min-h 保全、非塌陷淡入淡出、消除版面累計跳動。
8. **雙模態檢驗畫布原型 (`DualModeInspectionCanvasArchetype` - RFC-013)**：雙系統思維分離 (快思閱覽/慢想操作)、禁 disabled input、未儲存髒檢查阻尼。
9. **現代底線頁籤原型 (`ModernUnderlineTabsArchetype` - RFC-014)**：減法美學、除 Windows 檔案夾樣式、品牌橘底線滑動指示。
10. **引用防禦阻尼原型 (`ReferenceDefenseDamperArchetype` - RFC-015)**：共有地悲劇治理、全域引用計數聚合、引用數 > 0 物理禁刪。
11. **即時試算預覽原型 (`RealtimeCalculationPreviewArchetype` - RFC-016)**：寇斯交易成本消除、特斯勒複雜度守恆、原位雙向試算範例。
12. **欄位級異動審計原型 (`FieldDiffAuditArchetype` - RFC-017)**：霍桑效應、雙時態真相溯源、反射式欄位差異留痕、必填 5 字理由。

### 2.3 雙時態不可變帳本準則 (Bi-Temporal Immutability Mandate)
金融與再保險核心持久化實施**「原位覆寫絕對禁令」**：
- 每一筆資料狀態具備雙時間軸：**業務有效時間 (Valid Time)** 與 **系統記錄時間 (Transaction Time)**。
- 禁止毀滅性 SQL `UPDATE` / `DELETE`，所有修改皆為追加版本與紅字沖銷（Red-Ink Reversal），確保 20 年後可隨時重演任意歷史切面。

### 2.4 形式化驗證與可證明契約 (Formal Verification & SMT Solvers)
- 未來代碼交付逐步要求攜帶不可反駁的數學證明（Proof-Carrying Code）。
- CI 門禁除執行 ArchUnit 與單元測試外，引入 SMT 求解器求解狀態機無死鎖與借貸恆平衡之數學定理，達成數學級可靠度。

### 2.5 工廠自主負熵引擎 (Autonomous Negative Entropy Engine)
- 靜態探針持續監控全域 AST 相似度。
- 當 3 個模組出現 >75% 結構相似邏輯時，工廠自主起草 RFC、提煉共用原語回 SDK，並發起自主代碼收斂 PR。
- 系統以「淨代碼消除率」為衡量核心，越演進代碼越少、抽象層次越高。

### 2.7 規碼對偶律與跨學科第一性原則自主對稱化 (Spec-to-Primitive Duality Law)
- **嚴禁孤兒規範 (Zero Orphan Specs)**：任何寫入 Living Specs（如 `UI_SPEC.md`, `DBA_SPEC.md`）或工程標準（`ENGINEERING_STANDARDS.md`）之架構不變量、人因互動模式與跨學科原則（反脆弱、推力、認知負荷、交易成本），**嚴禁僅停留於 Markdown 文字宣導**。
- **一對一投影義務**：每一條強制性規範，必須 1:1 對偶對應到 `Agent SDK` 的 RFC 規格與物理樣板代碼（Physical Template Spec），並註冊於 `catalog.yaml`。
- **自主昇華機制**：當架構師或 AI 感知到高頻出現的設計模式時，必須主動提煉為 Agent SDK RFC 原語，杜絕等待人類指出才被動修補的落後姿態。

### 2.6 常青適性守門人 (Architecture Sentry Invariant - RFC-010)
- 代碼即憲法，測試即執法人。所有架構不變量全量代碼化為 ArchUnit 與 AST 測試，CI 編譯期自動物理阻斷違規合併。

---

## 3. 結果與長期影響 (Consequences)

### 正面效益 (Positive)
* **抗世紀腐化能力 (Centennial Durability)**：將核心商業邏輯與短命的第三方框架徹底物理隔離。
* **歷史審計不可篡改 (Bi-Temporal Truth)**：滿足跨越 30~50 年的極端金融法規與理賠訴訟審計要求。
* **跨模型通用性**：Task-IR 字節碼保證了未來 AI 模型更迭時工廠能平滑運作。
* **真正的系統負熵**：工廠隨著業務擴展反而代碼更簡練，徹底根除大企業軟體「越寫越臃腫、終成遺留泥球」之宿命。

### 承擔成本 (Trade-offs)
* 開發初期需要嚴格遵守三層解耦與原型規範，前期設計思考門檻較傳統 CRUD 高。
* 雙時態儲存架構相較傳統覆寫儲存需要更多的磁碟空間（但在現代儲存成本持續下降之趨勢下完全可接受）。
