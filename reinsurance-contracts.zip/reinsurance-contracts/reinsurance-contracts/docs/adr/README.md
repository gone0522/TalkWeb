# 架構決策記錄庫 (Architecture Decision Records - ADR)

本目錄為專案之最高架構決策真理庫。為兼顧**架構清晰度**與**歷史演進足跡**，系統將 ADR 分為兩大層次：

---

## 一、 現行生效之四大核心基石決策 (Consolidated Meta-ADRs)

| 決策編號 | 核心決策主題 | 狀態 | 核心使命與防線 |
| :--- | :--- | :--- | :--- |
| **[ADR-001](ADR-001-spec-driven-ai-software-factory.md)** | **規格驅動之 AI 原生軟體工廠架構** | ✅ **生效中** | 單一真理庫、雙軌規格、風險自主放行、AST 死按鈕防熵、Task-IR 編譯器與 AI-VM |
| **[ADR-002](ADR-002-decoupled-multi-repo-and-evolvable-slices.md)** | **多庫契約先行與可演進垂直切片架構** | ✅ **生效中** | 契約先行分支解耦、MonolithFirst 邏輯聚合、五大抗耦合防線、自然芽裂協議、雙子星標準庫實作庫 |
| **[ADR-003](ADR-003-enterprise-quality-resilience-and-audit-baseline.md)** | **企業級品質韌性、合規審計與 QoS 基線** | ✅ **生效中** | 同交易全欄位變更審計、S/M/L QoS 基線、強型別配置 Fail-Fast、常青依賴、直擊原型修復法則 |
| **[ADR-004](ADR-004-agent-sdk-longitudinal-evolution-governance.md)** | **Agent SDK 百年長程演化治理、人機意圖轉譯與常青架構適性防線** | ✅ **生效中** | 人類意圖精準轉譯為機器語言、百年原則不變量公理 (2026~2126+)、三層不朽基底 (Layer 0/1/2 宿主解耦)、雙時態不可變帳本、形式化證明義務、四大領域原型、工廠自主負熵、RFC-010 ArchUnit 門禁、無方言中立開源 |

---

## 二、 歷史時序演進封存庫 (Historical Archive)

所有過去伴隨對話與問題逐步探索演進的 9 篇原始歷史 ADR，100% 完整保留封存於：
👉 **[`docs/adr/archive/`](archive/)**

- `archive/ADR-001-full-field-audit-and-dummy-button-ban.md`
- `archive/ADR-002-dual-track-specification-architecture.md`
- `archive/ADR-003-tiered-adaptive-scale-and-qos-baseline.md`
- `archive/ADR-004-risk-tiered-autonomous-promotion.md`
- `archive/ADR-005-evergreen-runtime-and-dependency-upgrade-policy.md`
- `archive/ADR-006-spec-precedence-config-validation-and-chaos-defense.md`
- `archive/ADR-007-software-factory-degradation-and-anti-entropy-defenses.md`
- `archive/ADR-008-multi-repo-contract-first-decoupled-branching.md`
- `archive/ADR-009-evolvable-architecture-and-vertical-sprouting.md`
