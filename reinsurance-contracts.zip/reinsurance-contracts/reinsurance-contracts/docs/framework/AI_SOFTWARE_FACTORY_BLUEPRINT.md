# 通用 AI 原生軟體工廠架構基底 (Universal AI-Native Software Factory Framework)

> **定位**：本文件為**跨專案 100% 可共用**之 AI 原生軟體工程基底。無論應用於金融、SaaS、電商或 ERP 專案，均可直接複製套用。

---

## 0. 軟體工廠核心演進五階自閉環流水線 (The 5-Stage Spec-Driven Closed-Loop Evolution Pipeline)

**鐵律口訣：【有問題先討論 ➔ 調整規範 ➔ 產生任務 ➔ 確認執行 ➔ 驗收覆盤與自閉環】**  
**核心精神：嚴禁遇到問題就急著修改業務程式碼（打地鼠）。每一項調整都必須著眼於「如何讓未來的軟體資產更好、百年可重現、全域可免疫」。即便完全重啟對話，本流程亦必須強制執行！**

```mermaid
flowchart LR
    S1["<b>第一階：有問題先討論</b><br/>回歸跨學科人因、行為經濟學與貿易理論<br/>深入釐清根本原因，嚴禁打地鼠"] --> S2["<b>第二階：調整規範</b><br/>寫入 Living Specs, ADR & SDK 原語<br/>清除歷史打地鼠條款，審計全過"]
    S2 --> S3["<b>第三階：產生任務</b><br/>合成標準 6 位數任務包<br/>編譯 Task-IR 字節碼與 Manifest"]
    S3 --> S4["<b>第四階：確認執行</b><br/>獲得人類使用者明確授權後<br/>開分支並依 TDD 嚴格執行落地"]
    S4 --> S5["<b>第五階：驗收覆盤與自閉環</b><br/>客觀神諭驗收、主規格回寫<br/>問題聚類歸因，沉澱反脆弱抗體"]
    S5 -.->|系統負熵演進| S1
```

1. **第一階：有問題先討論 (Stage 1: Collaborative Root Cause & First-Principles Discussion)**：
   - 發現問題或接到反饋時，**嚴禁立即切換分支動代碼**。
   - 必須回歸第一性原則、認知心理學（完形、雙系統、工作記憶）、社會心理學（霍桑效應、心理安全感）、行為經濟學（推力、阻尼、損失厭惡）、貿易資訊經濟學（檸檬市場、交易成本、共有地治理）與反脆弱架構哲學，深入探討問題發生的本質原因。
   - 盤點全系統中是否存在同類盲點、歷史包袱或老骨董反模式（如 Windows 資料夾頁籤、disabled input 唯讀反模式、收據式破折虛線），與人類使用者充分對齊長期架構哲學。
2. **第二階：調整規範 (Stage 2: Specification & Governance Codification)**：
   - 嚴禁在規範未定稿前產生具體任務或撰寫業務代碼。
   - 將討論共識 100% 寫入合約倉庫之活體規格 (`UI_SPEC.md`, `SD_SPEC.md`, `ENGINEERING_STANDARDS.md`, `TASK_EXECUTION_RULES.md`, `Agent SDK RFCs`)。
   - 主動清除歷史規格中殘留的「打地鼠條款」（如虛線卡片、手寫像素硬編碼、局部補丁描述）。
   - 執行 `scripts/audit-specs.py` 驗證五大治理閘門 100% 通過，並提交至 `reinsurance-contracts:dev`。
3. **第三階：產生任務 (Stage 3: Contract-Driven Task Synthesis)**：
   - 嚴格依照已定稿之現行規範與 OpenAPI 契約，合成標準 6 位數任務包 (`tasks/TASK-{06d}/`)。
   - 編譯輸出嚴格的 Task-IR (Task Intermediate Representation) 字節碼 (`task.ir.yaml`) 與標準 Manifest (`manifest.yaml`)。
   - 明確界定 `target_files`、`read_only_references` 與客觀驗收閘門。
4. **第四階：確認執行 (Stage 4: Explicit User Confirmation & Sentry Execution)**：
   - **未獲人類使用者明確指示前，絕對禁止擅自開始執行任務或修改運行時代碼！**
   - 當人類使用者發出執行指令後，始得建立專屬工作分支 (`feature/<TASK_ID>`)。
   - 嚴格遵循 TDD (Red-Green-Refactor) 與三庫串行合併順序實施落地，通過客觀自動化門禁驗收。
5. **第五階：驗收覆盤與反脆弱自閉環 (Stage 5: Verify, Reconcile & Antifragile Retro)**：
   - **客觀神諭驗收**：全量單元測試、AST 深入零死按鈕審計、多語系洩漏檢查與同構矩陣 100% 綠燈證明。
   - **主規格回寫閉環 (Master Spec Reconciliation)**：若實作過程發現新約束，必須同步回寫全局主規格書 (`docs/specs/`)，杜絕規格落後代碼。
   - **問題聚類與經驗沉澱 (Incident Pattern Clustering & Rule of Three)**：在 `docs/governance/RETROSPECTIVE.md` 中記錄聚類標籤與 5 Whys；當同類問題累計達 3 次（三振法則），強制抽象提煉為 Agent SDK 原生原語或實體架構探針，達成「全系統永久免疫」。

---

## 1. 核心哲學：規格即系統 (Spec-as-System) 與百年意圖轉譯公理
0. **最原始目的與百年公理 (The Primal Mission & Centennial Axiom)**：
   - **人機意圖轉譯**：AI 軟體工廠最原始、最神聖的目的，就是**將「人類商業意圖」精準無損地轉換為「機器語言」**，且由機器確實無誤、零歧義、零妥協地執行，幾乎 100% 依照人類想要的樣子落地實作。
   - **百年不變之原則**：當時間軸拉伸至**一百年 (Centennial Horizon)**，原則的東西就像太陽升起一樣亙古不變（數學真實、借貸恆平、呈現層外部化、不可篡改的審計軌跡）；會隨時代更替的，僅僅是運作的模型（Claude/Gemini/GPT ➔ 未來超神經模型）與具體的執行機器（JVM ➔ 矽基/光子/量子計算機）。
1. **單一事實真理庫 (Single Source of Truth - SSOT)**：
   - 契約庫 (`*-contracts`) 獨立為最高主權庫，所有線上代碼僅為規格之即時投影。
2. **雙軌規格與 OpenAPI Code-Gen 職責分離 (Code-Gen Purity & Spec Separation)**：
   - **機器實體契約 (`contracts/openapi.yaml`)**：
     * 掌握唯一端點路徑、HTTP Method、Header、Query/Body 欄位型別、Status Code 與 RFC 7807 錯誤結構。
     * 前端 TypeScript Client/Type (`src/shared/generated/api.d.ts`) 與後端 Java DTO 全自動一行指令生成 (`Code-Gen`)。
     * **純投影目錄隔離**：生成代碼目錄嚴禁手寫業務邏輯；業務輔助邏輯採 Extension Pattern 封裝，杜絕重複覆寫災難。
   - **架構意圖與活體規格 (`SD_SPEC.md` / `Living Specs`)**：
     * 專注於架構意圖：Mermaid 時序圖、業務規則 (BR)、交易邊界 (`@Transactional`)、快取機制與引用防禦。
     * **消滅重複定義**：嚴禁在 `SD_SPEC.md` 手動重抄 OpenAPI JSON 資料字典。
3. **規格分級繼承與主規格合併回寫閉環協議 (Spec Inheritance & Master Spec Reconciliation Protocol)**：
   - **分級規格產出機制**：
     * **全新模組 / 重大特性 (Tier-2 高風險)**：強制產出全套 6 大 Living Spec 實體套件 (`SA`, `DBA`, `SD`, `UI`, `USE_CASE`, `QA`) 與雙軌 Manifest。
     * **輕量修復 / 欄位補丁 (Tier-1 低風險)**：若所屬模組在全局 `docs/specs/` 已有完整主規格，**嚴禁重複複製產生 6 大規格目錄**。任務僅需在 Manifest 宣告 `spec_mode: "lightweight"` 與 `base_spec_ref: "docs/specs/..."`，任務卡強制要求 15 行極簡 Delta 單（引用來源 + 變更差量 + 1 個可執行 BDD 場景）。
   - **主規格合併回寫鐵律 (Master Spec Reconciliation upon Merge - Mandatory DoD)**：
     * **防禦規格漂移**：任何被合併入庫的代碼變更，其 Definition of Done (DoD) 強制要求**必須同步回寫更新全局主規格書 (`docs/specs/`)**。
     * **語意錨點與局部 Diff 替換**：主規格建立標準標籤（`<!-- SECTION: BUSINESS_RULES -->`、`DATA_MODEL`、`UI_SPEC`），回寫時以精確行替換插入增量，**嚴禁全篇覆寫**，防止 AI 幻覺誤刪既有業務規則。
4. **現行法調閱位階與歷史審計隔離 (Active Truth vs Audit Trail)**：
   - **現行法 (Active Law)**：`docs/specs/` 與 `contracts/openapi.yaml` 是唯一現行法。AI 規劃與開發時默認只調閱此真理源。
   - **歷史留痕 (Audit Trail)**：`tasks/TASK-xxx/` 僅供結案驗收與事後追溯，**嚴禁未來的 AI 將舊 Task 目錄視為現行規格真理**，徹底杜絕歷史噪音與上下文中毒。
5. **依賴套件授權與自動引入自舉協定 (Dependency Authorization & Step 0 Bootstrap - 破除依賴悖論)**：
   - **破除依賴悖論**：AI Agent 受到反幻覺紀律約束，在缺乏明確依賴授權時容易倒退為「手刻輪子」的原始低效寫法。
   - **規格授權機制**：任務規劃者 (Task Planner) 於 `manifest-api.yaml` 或 `manifest-ui.yaml` 之 `authorized_dependencies` 顯式宣告授權之 Tier-1 Approved BOM 套件。
   - **執行端自動引進自舉 (Step 0 Bootstrap)**：Task Runner 啟動前置檢查時，自動將清單注入項目配置並執行安裝，直接採用主流成熟套件實作，嚴格禁止手刻輪子！
6. **嚴格多國語言架構分界與全語言零寫死鐵律 (Strict i18n Boundaries & Zero Hardcoded Strings)**：
   - **全語言零自然語言常值禁令**：無論中文、英文或任何自然語言，嚴格禁止在非 Presentation 層硬編碼。
   - **傳輸層 (Transport)**：純機器代碼層，僅允許傳遞 HTTP 狀態與機器錯誤碼 (`errorCode`)，嚴禁構造自然語言句子（例如 `throw new ApiError('Failed to export')` 亦屬違規）。
   - **持久審計層 (Persistence)**：審計原因與欄位識別一律儲存 **規範代碼 (Canonical Identifiers / Standard Keys)**（如 `SYSTEM_DEFAULT_UPDATE`, `NAME_ZH`），嚴禁於 DB 存入自然語言文字。
   - **呈現層 (Presentation)**：唯一多語系對應層，透過 `next-intl` 查表顯示。
   - **報表匯出層 (Excel/Report)**：後端生成 Excel / CSV 表頭與列舉名稱必須透過動態注入之 `MessageSource`，依照 HTTP `Accept-Language` 動態解析語系，嚴禁寫死靜態字串陣列。

---

## 2. 現代多庫與可演進切片架構 (Evolvable Architecture - Meta-ADR 2)
1. **三庫串行合併鐵律 (Tri-Repo Promotion Pipeline)**：
   - 解決跨庫合併死鎖與孤兒依賴：
     * **順序 1 (Contracts PR 預審就緒)**：在 `*-contracts` 切出 `task/<TASK_ID>` PR，通過規格與語法審查，**保持 PR 開啟暫不合入 dev**。
     * **順序 2 (後端合入 dev)**：後端倉庫 `feature/<TASK>-API` 依 PR 契約實作，`mvn test` 全綠，PR 合併入 `core-service:dev`。
     * **順序 3 (前端本地真機聯調 ➔ 合入 dev)**：前端切換 `MOCK=false`，直連本機後端通過 Playwright 走查，PR 合併入 `web-portal:dev`。
     * **順序 4 (Contracts 主權庫結案合入 dev)**：雙端代碼均已進 `dev` 後，Agent 在 Contracts PR 完成主規格回寫檢驗，最終合併入 `contracts:dev`。
2. **領域內 vs 跨領域 CQRS 分級架構 (Domain-Bounded CQRS Architecture)**：
   - **領域內部 (Intra-Domain)**：為解決複雜統計報表與 N+1 效能問題，合約領域內或主檔領域內**全力開放**資料庫 View 與多表 SQL JOIN。
   - **跨領域邊界 (Cross-Domain)**：**嚴格禁止**資料庫跨領域實體 JOIN！跨領域組合必須採用：
     * **應用層組裝 (BFF Pattern)**：由後端在記憶體中平行調用各模組 Public API 組裝。
     * **快照記錄 (Snapshot Pattern)**：寫入交易時保存當時主檔名稱與代碼快照，單表直出。
   - 保證極致查詢效能，同時 100% 守護未來自然芽裂 (Sprouting) 抽離獨立微服務之能力。
3. **Expand/Contract 雙相無感資料庫遷移鐵律 (Zero-Downtime Migration)**：
   - 任何欄位更名或型別變更，嚴禁一次性物理刪除或更名，防止滾動部署引發舊 Pod 500 錯誤風暴：
     * **Phase 1 (Expand)**：新增欄位，保留舊欄位，後端雙寫或視圖向下相容。
     * **Phase 2 (Contract)**：全站 Pod 100% 升級穩定運行後，於下個版本 Flyway 遷移才安全移除舊欄位。
4. **五大抗耦合防線與自然芽裂協議**：
   - 全資產領域標籤 (`domain:<name>`)、軟性外鍵與零跨領域 JOIN、引用防禦端點 (`GET /references`)、後端 Package-Private 封閉性、前端 Feature-Sliced 垂直內聚。
   - 達到芽裂閾值（模組代碼 > 3,000 行），執行 `git subtree split` 無損抽離為獨立 Domain Pod。

---

## 3. 客觀品質防禦網與聯調時機 (Automated Quality Gates & Handshake Timing)
1. **前後端 Mock 換真實 API 的三階段接軌節奏 (The Handshake Moment)**：
   - **階段 1 (平行獨立開發)**：前端 `NEXT_PUBLIC_ENABLE_MOCK=true`，打 MSW/Prism Mock Server (4010 埠)；後端單元測試與 H2 記憶體資料庫全綠。前後端完全不阻塞彼此。
   - **階段 2 (本地真機聯調 - The Handshake Moment)**：雙方各自開發完成、提 PR 前夕，前端切換 `NEXT_PUBLIC_ENABLE_MOCK=false`，Base URL 指向 `http://localhost:8080`，本地執行真實 HTTP 請求與 Playwright E2E 走查。
   - **階段 3 (整合環境驗收 - Staging SIT)**：PR 依序合併入 `dev` 後，CI 自動部署至 Staging 測試環境進行全自動迴歸走查。
2. **種子資料與 Mock Fixture 雙向同源協議 (Seed Data Alignment Protocol)**：
   - 後端 Flyway 具備 `V999__dev_seed_data.sql`，本機啟動自動灌入標準測試資料（如 USD, TWD, EUR）。
   - 前端 Mock Fixture (`currencies.json`) 採用完全相同的業務代碼與識別碼，確保切換真實 API 時零畫面落差、零 404 資料斷層。
3. **AST 深度函式體零死按鈕審計 (`audit-buttons.js`)**：
   - Babel AST 不僅檢查按鈕具備 `onClick`，**深入檢查函式主體 (Function Body AST)**：
   - 若 BlockBody 為空 `{}`、或僅含 `console.log` / `void 0`，一律判定為「假按鈕作弊」強制紅燈阻斷！未就緒功能必須顯式標記 `disabled` 搭配 Tooltip 預留。
4. **多國語言中文洩漏檢查 (`validate-i18n.js`)**：
   - 靜態掃描 `en-US.json`，若英文值內含有未轉譯之中文字符，自動判定為「假翻譯」門禁直接攔截。
5. **規格主權與架構適應性稽核 (`audit-specs.py`)**：
   - 驗證 OpenAPI 領域標籤、Living 6 大規格完整性、Freshness 90 天保鮮檢驗、以及 Tier-1 規格繼承與回寫同步率。
6. **企業級技術棧 Tier-1 Approved BOM 品質標準（拒絕低效手刻輪子）**：
   - 後端強制採用 Lombok、MapStruct、Flyway/Liquibase、Spring Data JPA Auditing、JaVers/Hibernate Envers、EasyExcel、springdoc-openapi、ArchUnit、Testcontainers。
   - 前端強制採用 lucide-react（取代手寫 inline SVG）、sonner（取代 Prop-drilling Toast）、react-hook-form + zod（取代多個 useState）、@tanstack/react-query、@tanstack/react-table。
7. **資料庫遷移管線安全與 Hibernate DDL 嚴格禁令**：
   - 企業級環境嚴格禁止 `hibernate.ddl-auto=update`（只允許 `validate` 或 `none`）。
   - 遷移腳本強制宣告 `SET lock_timeout = '5s';`，保障併發高可用。

---

## 4. 現代 AI 原生軟體工廠四階演進藍圖 (The Four Levels of AI-Native Software Evolution)

軟體架構並非一蹴可幾，而是伴隨業務規模與 AI Agent 能力逐步躍遷的演進過程。本架構體系確立四階演進階梯，使系統始終處於最佳人機協同狀態：

```text
┌────────────────────────────────────────────────────────────────────────┐
│ Level 1：單體探索期 (Monolith Prototype / Vibe Coding)                 │
│ • 架構拓撲：前後端混寫於單一程式碼庫，未設模組隔離。                   │
│ • 人機協同：人類下 Prompt，AI 盲目嘗試；缺乏客觀規格與邊界約束。       │
│ • 局限與瓶頸：上下文窗口極易爆炸，AI 產生全域越界污染與大泥球代碼。   │
├────────────────────────────────────────────────────────────────────────┤
│ Level 2：前後端解耦與多庫聚合期 (Decoupled Repos) ── 【本專案當前現狀】│
│ • 架構拓撲：契約庫 (contracts) 獨立，前後端實體分庫 (web-portal / core)│
│ • 核心原則：MonolithFirst（享受單體快速編譯、秒級除錯與單進程運行紅利）│
│ • 抗耦合基因：強制植入「五大抗耦合防線」（全資產領域標籤、軟性外鍵    │
│             零跨庫 JOIN、後端 Package-Private 隱蔽、前端 Feature-Sliced│
│             垂直內聚、引用防禦端點）。                                 │
│ • 階段成效：代碼在同庫聚合運行，但邏輯邊界嚴密，為 Level 3 隨時芽裂做好│
│             100% 準備，杜絕任何耦合死鎖。                              │
├────────────────────────────────────────────────────────────────────────┤
│ Level 3：垂直領域切片與自然芽裂期 (Vertical Domain Pods / Micro-Slices)│
│ • 觸發指標：單一業務領域（如 masterdata）代碼行數 > 3,000 行或獨立發版。│
│ • 芽裂實作：執行 git subtree split 歷史無損抽離為專屬 Domain Pod。     │
│ • 架構特徵：單一 Pod 內垂直聚合該模組專屬之 UI 元件、API、DB Migration│
│             與 Living Specs，原系統與新 Pod 零業務代碼修改無痛剝離。   │
│ • 階段成效：消除跨模組認知干擾，各業務領域具備獨立微服務發版與部署能力。│
├────────────────────────────────────────────────────────────────────────┤
│ Level 4：AI 原生軟體工廠與全自主意圖驅動期 (AI-Native Software Factory)│
│ • 核心特徵：規格即系統 (Spec-as-System)。人類只專注於契約庫立法與審查。 │
│ • 執行模式：AI Agent 在邊界完全隔離的 Domain Pod 小沙盒中閉環運行。   │
│ • 產出成效：排除全庫龐大上下文干擾，AI 代碼合成準確率大幅躍升至 99%+； │
│             全自動完成從規格合成代碼、跑綠 BDD 場景、通過全套客觀品質 │
│             閘門、產出發布報告書，代碼純粹成為規格之即時投影產物。     │
└────────────────────────────────────────────────────────────────────────┘
```

### 4.1 四階演化矩陣與躍遷指標 (Evolutionary Progression Matrix)

| 評估維度 | Level 1: 單體探索期 | Level 2: 多庫聚合期 (現狀) | Level 3: 垂直領域切片 | Level 4: AI 原生軟體工廠 |
|:---|:---|:---|:---|:---|
| **倉庫形態** | 單一混雜 Monorepo | 3 獨立庫 (Contracts, UI, API) | 契約庫 + N 個獨立 Domain Pods | 契約真理庫 + AI 動態沙盒 Pods |
| **程式碼架構** | 水平技術分層 (大泥球) | 模組化單體 (植入五大抗耦合防線) | 垂直切片微模組 (Vertical Slices) | 規格投影產物 (Spec Projections) |
| **上下文半徑** | 全域混雜 (> 50,000 行) | 獨立前後端倉庫 (< 15,000 行) | 領域小沙盒 (< 3,000 行) | 任務微切片 (< 500 行) |
| **AI 合成準確率** | 50% ~ 70% (頻繁跑偏) | 85% ~ 90% (雙軌規格約束) | 95%+ (邊界純淨無干擾) | 99%+ (閉環沙盒極致轉綠) |
| **人類角色** | 逐行編寫與 Debug | 架構守衛與雙軌任務簽核 | 領域業務模型分析師 | 商業意圖立法與放行審批官 |
| **升級觸發條件** | 業務原型確立 | 模組規模 > 3,000 行 | 企業多團隊平行自治需求 | 規格庫與品質防線 100% 健全 |

---

## 5. 專案七階全生命週期工廠流水線 (The 7-Stage SDLC Pipeline)

為保證無論任何規模之任務皆能具備 100% 確定性品質，工廠流水線確立七階標準閉環：

1. **Stage 0 (需求接裝與規格定錨)**：
   - 檢索歷史踩坑記憶 (`docs/governance/RETROSPECTIVE.md`)，對齊 QoS 目標（預設 M 級 1,000 QPS）。
   - 產出雙軌規格：人類 6 大活體規格 (`SA`, `DBA`, `SD`, `UI`, `USE_CASE`, `QA`) 或 Tier-1 極簡 Delta 單。
   - 同步 `contracts/openapi.yaml` 注入 `domain:<name>` 標籤；產出 `manifest-*.yaml` 宣告 `authorized_dependencies`。
   - 執行 `python3 scripts/audit-specs.py` 確保 4 道規格治理閘門 100% 通過。
2. **Stage 1 (契約先行分支治理與 Mock 解耦)**：
   - Contracts 庫建立 `task/<TASK_ID>` PR（保持預審開啟）；後端建立 `feature/<TASK>-API`，前端建立 `feature/<TASK>-UI`。
   - 前端啟動 MSW Mock Server (`NEXT_PUBLIC_ENABLE_MOCK=true`)，前後端零阻塞獨立平行開發。
3. **Stage 2 (依賴自舉與前後端並行實作 - 嚴格測試驅動開發 TDD: Red-Green-Refactor)**：
   - 實作前嚴格遵守 TDD 鐵律：先寫失敗測試 (Red) ➔ 撰寫最小實作 (Green) ➔ 綠燈重構 (Refactor)，嚴禁測試後置補票。
   - Task Runner 執行 **Step 0 Dependency Bootstrap**，自動引入宣告之 Tier-1 Approved BOM 套件。
   - 後端落實 Lombok, MapStruct, Flyway (`SET lock_timeout = '5s'`), JPA Auditing, MessageSource 動態報表。
   - 前端落實 RSC 服務端渲染邊界, React Query, Zustand, React Hook Form + Zod, Sonner, Lucide, 傳輸層純機器錯誤碼。
4. **Stage 3 (本地真機聯調接軌 - The Handshake Moment)**：
   - 前端切換 `NEXT_PUBLIC_ENABLE_MOCK=false` 直連後端服務 (`http://localhost:8080`)。
   - Seed Data 對齊驗證 (`V999__dev_seed_data.sql` 與 Mock Fixture 同源)。
   - 執行真機 HTTP 通訊走查與 Playwright E2E 測試。
5. **Stage 4 (四大客觀品質閘門與三庫串行晉級)**：
   - 門禁檢核：規格治理、OpenAPI 標籤、前端型別與 AST 死按鈕/i18n、後端單元測試全數綠燈。
   - 三庫串行發布：Contracts PR 預審 ➔ 後端合入 `dev` ➔ 前端合入 `dev` ➔ Contracts 完成主規格回寫結案合入 `dev`。
6. **Stage 5 (容器化構建、部署與生產防線)**：
   - Docker Multi-stage 構建容器，健康探針檢查 (`/actuator/health`, `/api/health`)。
   - 嚴禁 Agent 私自合入 `main`，生產發布必須由 PO / 人類架構師簽核。
7. **Stage 6 (全鏈路可觀測性、審計溯源與反思自閉環)**：
   - MDC 上下文日誌追蹤，Prometheus 指標與 Sentry 異常監控。
   - 踩坑自動固化協議：任何線上問題或評審反饋，自動記入 `RETROSPECTIVE.md` 並編寫自動化門禁，永不犯第二次錯。

---

## 6. 架構自適應升級、自主演化與自癒引擎 (Autonomous Evolution & Self-Healing Architecture Engine)

為徹底破除「人類提出、AI 才被動納入」的被動性，架構體系確立以下三柱自主演化機制：

1. **靜態架構探針與自動感知閥值 (Sensory Probes)**：
   - CI 與 Pre-commit 自動掃描程式碼異味 (Code Smells)：
     * 手寫 DTO 轉換 (`toResponse()`) ➔ 自動建議引入 `MapStruct`。
     * 表單超過 3 個 `useState` ➔ 自動觸發 `react-hook-form` + `zod` 宣告式表單改寫。
     * 行內手寫 `<svg>` ➔ 自動替換為 `lucide-react`。
     * 行內寫死 `style={{ ... }}` ➔ 自動觸發 Design Token 違反警報。
     * 原生 `window.confirm` 或自刻 Toast ➔ 自動觸發 `sonner` / Radix Dialog 封裝。
     * 核心實體缺少 `@Version` ➔ 自動觸發樂觀鎖補齊。
     * 非呈現層硬編碼自然語言 ➔ 自動觸發 i18n 隔離警報。
2. **踩坑程式化自閉環協定 (Rules-as-Tests Pipeline)**：
   - 每一次人類的反饋與踩坑，強制依據 5 Whys 記入 `RETROSPECTIVE.md`，並轉化為 Babel AST、ArchUnit 或 Playwright 客觀門禁，開工前由記憶檢索協議強制載入。
3. **企業常青技術雷達 (Technology Radar: Adopt / Trial / Assess / Hold)**：
   - 確立技術生命週期，持續將業界成熟主流標準納入 Tier-1 BOM，自動淘汰低效手刻模式。

## 7. 全自動共用模組識別與自治演化架構 (Autonomous Archetype & Shared Module Evolution Engine)
### 7.1 業務原型自動認領機制 (Archetype Claiming Protocol)
為解決各垂直功能切片 (Vertical Feature Slices) 由於局部任務視野導致的「各自手刻、介面漂移」問題，工廠建立全自動業務原型認領機制：
1. **特徵指紋比對 (Feature Fingerprinting)**：在 `task-planner` 規劃任務的 Step 0，系統自動分析任務需求與 Mockups：
   - **主檔維護原型 (`MasterDataMaintenance`)**：具有「關鍵字/狀態查詢表單 + 清單資料表格 + 雙側排版分頁列 + 側邊抽屜 (基本/審計頁籤) + 新增/編輯彈窗 + Excel 匯出 + 刪除防呆」之特徵組合。
   - **審批流程原型 (`ApprovalWorkflow`)**：具有「申請單填報 + 流程進度條 + 簽核/退回對話框 + 簽核歷程軌跡」之特徵組合。
   - **報表分析原型 (`AnalyticsDashboard`)**：具有「維度篩選器 + 指標卡片 + 圖表展示 + 匯總表」之特徵組合。
2. **原型約束與樣板先行 (Template Primitive First)**：
   - 任務一旦被標記為特定原型，**AI 代理人嚴禁從零手刻私有頁面與表格元件**。
   - 必須直接引用或繼承專案頂層共用樣板模組 (`<MasterDataPageLayout>`, `<MasterDataTableToolbar>`, `<MasterDataPagination>`, `<MasterDataDetailDrawer>`, `<MasterDataFormModal>`)。

### 7.2 制度化「三振重構法則 (Rule of Three Engine)」
為在「過早抽象 (Premature Abstraction)」與「代碼重複腐化 (Duplication Entropy)」間取得最佳平衡，軟體工廠確立三振自動演化引擎：
- **第 1 次出現 (Instance 1 - 探索期)**：允許在 Feature Slice 內部實作，探索真實業務邊界與特定需求。
- **第 2 次出現 (Instance 2 - 候選期)**：系統記錄特徵指紋，發出 `[INFO] Potential shared pattern detected`，記錄於架構技術債清單。
- **第 3 次出現 (Instance 3 - 強制升級期)**：**觸發硬性阻擋 (Hard Block & Promote)**！當專案出現第 3 個同質性模組時，AI 不得手刻第 3 套，必須自動注入 `Subtask 0: Extract & Promote Shared Template Component`，先完成共用抽象，再將第 1、2、3 個模組收斂整併。

### 7.3 AST 代碼克隆與重複度阻擋門禁 (AST Clone Detection Gate)
在品質檢驗流水線中整合 AST Token 相似度比對：
- 凡新產出之組件與既有切片元件之 AST 樹結構相似度超過 70%，視為違反 DRY 原則。
- CI 直接攔截並提示：「檢測到跨切片代碼高度重複 (AST Similarity > 70%)，請重構並抽斂至共用模組」。

### 7.4 兄弟切片同構差異感知與自適應演化 (Sibling Homomorphic Parity & Adaptive Evolution Protocol)
為根除「遇到單一頁面問題才手動補上一條死條款、寫死個別像素/顏色/字串」之微觀打地鼠模式，軟體工廠確立**同構原型橫向差異感知與自適應架構**：
1. **橫向差異自動感知 (Horizontal Sibling Diff Sensing)**：
   - 凡屬於同一 Archetype（如 `MasterDataMaintenance`）之功能切片，由靜態探針與 AI 代理人共同執行功能分區 (Zone 1 ~ Zone 6) 結構比對。
   - 代理人於提 PR 前必須主動掃描同家族兄弟切片，一旦偵測到共用原語（如分頁、工具列、刪除彈窗），當前模組必須 100% 同步引用，杜絕私有手刻代碼。
2. **自適應 Design Tokens 契約 (Adaptive Tokens vs Rigid Literals)**：
   - 所有版面尺寸與色彩樣式參數，必須綁定自適應 Design Tokens（`tokens.layout.*`、`tokens.color.*`），嚴格禁止在業務代碼寫死固定像素（如 672px, 768px）或特定色碼（如 #374151）。
   - 保證系統在多端解析度、響應式斷點與未來主題切換時，具備動態自適應彈性，實現規範之永續保鮮。

### 7.5 意圖-交付實質閉環與防幽靈依賴協定 (Intent-Realization Parity & Anti-Phantom Delivery Protocol)
為根除 AI 代理人於軟體開發中「形式主義交付（只改設定檔/宣告依賴，核心業務代碼避重就輕 0 落地）」與「微觀打地鼠（為個別套件寫死死板條款）」之惡性循環，軟體工廠確立三項通用的自適應工程準則：
1. **零幽靈依賴與引用計數審計 (Zero Phantom Dependencies & Active Usage Ratio)**：
   - 凡任務宣稱引入新函式庫、框架或工具（於 `pom.xml`, `package.json` 或架構配置中宣告），該依賴在受影響業務邊界（Domain / Service / Component / Page）內的實質引用計數（Reference Count）嚴禁為 0。
   - 嚴格禁止「設定檔有宣告，但業務檔案 0 呼叫」之幽靈依賴（Phantom Dependency）。一旦檢測到引用計數為 0，門禁直接阻擋並標記為形式主義交付。
2. **逆向代碼消除與 Diff 輪廓比對 (Negative Invariants & Diff Profile Shift)**：
   - 凡目標為「架構現代化 / 消除樣板冗餘 / 統一規範」之任務，其 Pull Request Diff 輪廓必須呈現業務程式碼的「結構性替換（Structural Shift）」或「淨代碼消除（Net Deletion）」。
   - 嚴格禁止新舊雙軌冗餘（引入了新原語，舊手刻代碼卻完好如初）。任務承諾消除的代碼，在業務模組中必須被徹底拔除。
3. **破除既有測試盲區，強制影響力切片證明 (Proof of Impact & Walking Skeleton)**：
   - 既有測試全綠（Regression Green）僅代表「未引發新錯誤（Baseline）」，不代表「新需求實質落地（Fulfillment）」。
   - 任務驗收門禁必須包含至少一組見證「新機制端到端運作」之實質業務驗證鏈，親自證明新架構在執行期產生預期價值。


## 8. 通用 AI 標準函式庫體系 (The Agent SDK Framework & Specification)

### 8.1 願景與定位：AI 原生軟體工廠的標準 JDK (The Enterprise Standard Library)
在軟體工程歷史中，JDK 與 Standard Libraries 終結了人類程式設計師重複編寫底層算法與資料結構的混亂；而在 AI 軟體工廠時代，**`Agent SDK`** 的定位正是**跨專案、跨模型、跨平台之企業級通用標準庫**。
- **消滅低效手刻輪子**：AI 代理人不再於各業務模組重複手寫 Excel 迴圈、手寫分頁邏輯、手刻樂觀鎖衝突攔截、手刻表單防連點。
- **跨平台與未來開源 (Open-Source Ready)**：
  * **第一階段 (Monorepo Incubation)**：於現有專案中作為底層共用原語庫孵化演進。
  * **第二階段 (Standalone Open-Source)**：抽離為獨立 GitHub 倉庫 (`open-ai-software-factory/agent-sdk`)，發布至 Maven Central 與 NPM，供全球 AI 軟體工程生態採用。

### 8.2 雙子星對稱套件架構 (Twin-Star Symmetric Architecture)
`Agent SDK` 橫跨全端多語言環境，以三層結構保證前後端行為 100% 同步：
1. **核心規格協議 (`agent-sdk-specs`)**：
   - 以 RFC 與 JSON Schema 定義標準通訊協議（分頁、排序、審計欄位規範、RFC 7807 錯誤模型、死按鈕語意、骨架屏 QoS）。
2. **後端標準原語庫 (`agent-sdk-spring`)**：
   - 封裝 `GenericExcelExportEngine<T>`（自動動態在地化與串流輸出）。
   - 封裝 `BaseAuditableEntity` 與 JPA 審計監聽器。
   - 封裝 `@OptimisticLockGuard` 與統一 409 衝突處理器。
3. **前端標準原語庫 (`@agent-sdk/react`)**：
   - 封裝 `<MasterDataMaintenanceView>`（內建工具列、虛擬滾動表格、自動分頁、骨架屏、死按鈕預留）。
   - 封裝全域宣告式通知與 409 衝突覆蓋刷新引導。

### 8.3 意圖編譯器 (Intent Compiler) 與任務字節碼 (Task-IR v1.0 Schema)
- **Java 哲學的完整映射**：
  * **高階人類規格 (`.spec.md` - 似 `.java`)**：由人類架構師維護，表達商業概念、領域邊界與 UX 意圖，擺脫繁文縟節與格式雜訊。
  * **意圖編譯器 (Task Planner - 似 `javac`)**：解析高階規格，比對 `Agent SDK` 能力清單 (Catalog)，進行符號連結與型別驗證。
  * **任務字節碼 (Task-IR - 似 `.class` Bytecode)**：輸出高密度、確定性、跨模型相容的 `task.ir.yaml`，包含狀態不變量、環境前置契約與行為神諭。
  * **AI 虛擬機 (Task Runner - 似 JVM)**：任何模型（Gemini / Claude / GPT / DeepSeek）解譯字節碼，執行 Strict TDD 與落庫。

### 8.4 演化與自癒閉環：修復原型原語，而非手冊追加規則 (Patch the Archetype, NOT the Rulebook)
- 當系統偵測到通用性品質漏洞時，**嚴禁在手冊中無休止地追加死板條文**。
- 開發者與 AI 的唯一職責，是**直接向 `Agent SDK` 提交 PR 修復對應的原型原語**。
- 底層標準庫一旦升級修復，所有業務模組在下次編譯建構時自動免疫，實現軟體工廠的極致整潔與負熵演化。


## 9. 多年期演化治理與常青適性守門人 (Multi-Year Evolution Governance & Architecture Sentry)

### 9.1 完整領域與人機互動原型族系全覆蓋 (Enterprise Archetype Taxonomy - RFC-001 ~ RFC-017)
為抵禦業務從 3 個模組擴展至 50 個模組時的系統碎片化危機，`Agent SDK` 建立完整 12 大領域、人因互動與持久化原型：
1. **主檔資料維護原型 (`MasterDataArchetype` - RFC-002)**：統一 6 區響應式佈局、動態多語系匯出 (RFC-003)、樂觀鎖衝突防禦 (RFC-004)。
2. **工作流狀態機原型 (`WorkflowStateMachineArchetype` - RFC-007)**：強制宣告不可變狀態移轉矩陣，內建樂觀鎖衝突防禦與事務性審計留痕。
3. **複式財務帳務原型 (`FinancialLedgerArchetype` - RFC-008)**：嚴格執行零浮點數 (BigDecimal)、銀行家捨入 (HALF_EVEN) 與借貸絕對平衡方程式。
4. **巨量批次處理原型 (`BatchIngestionArchetype` - RFC-009)**：強制執行分塊事務提交 (Chunk-Based)、單行錯誤隔離與冪等 JobKey。
5. **常青適性守門人原型 (`ArchitectureFitnessSentry` - RFC-010)**：ArchUnit 架構門禁、AST 死按鈕防禦、源碼 ASCII 純淨度。
6. **平滑演進日落防衛原型 (`GracefulSunsetGuard` - RFC-011)**：雙軌相容路由別名、RFC 8594 日落標頭、Zero-QPS 遙測門禁。
7. **零位移平滑過渡原型 (`ZeroClsTransitionArchetype` - RFC-012)**：容器 min-h 保全、微抖動消解、非塌陷淡入淡出。
8. **雙模態檢驗畫布原型 (`DualModeInspectionCanvasArchetype` - RFC-013)**：雙系統思維分離、禁 disabled input、未儲存髒檢查阻尼。
9. **現代底線頁籤原型 (`ModernUnderlineTabsArchetype` - RFC-014)**：減法美學、除 Windows 檔案夾樣式、滑動品牌指示條。
10. **引用防禦阻尼原型 (`ReferenceDefenseDamperArchetype` - RFC-015)**：共有地悲劇治理、全域引用計數聚合、引用數 > 0 物理禁刪。
11. **即時試算預覽原型 (`RealtimeCalculationPreviewArchetype` - RFC-016)**：寇斯交易成本消除、特斯勒複雜度守恆、原位雙向試算範例。
12. **欄位級異動審計原型 (`FieldDiffAuditArchetype` - RFC-017)**：霍桑效應、雙時態真相溯源、反射式欄位差異留痕、必填 5 字理由。

### 9.1.1 規碼對偶律 (Spec-to-Primitive Duality Law - 嚴禁孤兒規範)
任何寫入架構藍圖或活體規格之原則，嚴禁僅停留於 Markdown 文字宣導。每一項強制性規範必須 1:1 對偶對應到 Agent SDK RFC 規格與物理樣板代碼，徹底終結「口頭宣導、落庫走樣」的軟體工程通病。

### 9.2 標準庫吸震哲學 (Standard Library Shock-Absorber Pattern)
業務微切片嚴禁直接依賴第三方底層框架之脆弱 API，統一依賴 `agent-sdk-spring` 與 `@agent-sdk/react` 提供的抽象原語。未來框架換代（如 Spring Boot 4 / Java 25 / Next.js 16）時，僅需在 `Agent SDK` 內部升級適配器，數十個業務服務透過版本號升級即可實現「零業務代碼修改」平滑躍遷。

### 9.3 語意化版本與二元解耦日落律 (SemVer 2.0 & Dual-Prism Progressive Sunset)
Agent SDK 嚴格遵循 SemVer 2.0，確立規格與運行時二元解耦治理：
- **規格治理層零包袱**：Task ID 嚴格 6 位數，Living Specs 與 RFCs 永遠代表單一真理，不保留過渡分支。
- **運行時代碼強制平滑相容**：涉線上運行的 API、DTO 參數與資料庫欄位，強制提供雙軌路由 (`@RequestMapping({"/new", "/old"})`)、`@JsonAlias` 與 Expand-Contract 漸進遷移機制，確保生產滾動發布、快取客戶端零中斷。
- **零墓碑代碼 (Zero Tombstones via Telemetry)**：舊 API 與廢棄原語透過 Micrometer 監控。唯有當線上流量客觀歸零 (`QPS == 0`) 且日落期滿時，AI 方開立任務進行安全實體拔除，杜絕永久殘留死代碼。

### 9.4 Task-IR 字節碼向前相容性鐵律 (Backward-Compatibility Invariant)
Task-IR 結構化字節碼作為 AI 軟體工廠的中介執行碼，必須維持強行向前相容。主版本內部所有欄位擴充一律為可選欄位（Optional Fields），確保新舊世代 AI 模型皆能無歧義解析。

### 9.5 常青架構適性守門人 (Architecture Sentry Invariant - RFC-010)
**「代碼即憲法，測試即執法人」**。
將所有 Meta-ADR 原則與四大核心不變量（表現層外部化、契約唯一真實源、同構模組對稱性、確定性彈性）100% 轉化為**自動化編譯期測試**（Java 使用 ArchUnit，TypeScript 使用 AST Lint Rules）。
- 嚴格禁止依賴人工 Code Review 或手冊記憶防堵架構退化。
- 任何違反架構不變量之代碼（如在 Service 寫死中文表頭、實體缺少 @Version、財務使用 float），CI/Maven 編譯直接拋出紅色阻斷，拒絕合併。

### 9.6 無方言中立性與開源生態路徑 (Dialect-Agnostic Substrate & Open Source Readiness)
1. 核心 SDK 代碼命名一律使用 `com.agentsdk.*` 與 `@agent-sdk/*`，嚴禁任何業務專用名詞（如 Reinsurance）污染。
2. 資料庫與持久化原語透過 SPI 適配器（Adapter Pattern）隔離，維持對 PostgreSQL / MySQL / Oracle / SQLite 之中立性。
3. 前端 UI 原語採用 Headless 核心，透過 CSS 變數抽離樣式，相容於 Vanilla CSS、Tailwind 與 Radix UI。
4. 採用 Apache-2.0 授權，依照 5 年演化藍圖逐步由 Monorepo 孵化過渡為獨立開源組織。


## 10. 二十年負熵軟體工廠與永恆領域核心架構 (The 20-Year Negative Entropy & Immortal Domain Core)

### 10.1 三層不朽基底與可拋棄宿主 (The 3-Layer Substrate & Disposable Hosts)
在 20 年的長程時間跨度中，第三方運行框架（如 Spring Boot, React）必然經歷興起與退役。軟體工廠確立三層物理分離：
1. **Layer 0 (永恆代數核心)**：定義純粹數學定理與領域代數律（借貸平衡方程式、狀態機移轉矩陣、雙時態有效性、零浮點數純量），具備超越具體語言的永生性。
2. **Layer 1 (通用中介字節碼 - Task-IR)**：平台無關、模型無關的中介執行碼（Semantic Merkle DAG），攜帶數學證明義務。
3. **Layer 2 (可拋棄宿主適配器)**：當前時代的代碼實作（Java/Spring Boot, TypeScript/React）皆為耗材。當代際更換時，AI-VM 僅需在數十秒內將 Task-IR 重新編譯為新時代宿主（如 Rust, WebAssembly, 神經畫布），業務邏輯 0 改動。

### 10.2 雙時態不可變狀態網格 (Bi-Temporal Event Mesh)
為因應金融再保險長達 30~50 年的責任週期，持久化架構徹底禁止原位覆寫（In-Place Mutation）：
- 每一筆商業事實皆標註雙時間軸：**業務有效時間 (Valid Time)** 與 **系統入帳時間 (Transaction Time)**。
- 嚴禁破壞性 SQL `UPDATE` / `DELETE`，所有變更一律以新版本事件追加或紅字沖銷（Red-Ink Reversal），確保跨越數十年皆能完美重現任意歷史秒點之真實狀態。

### 10.3 形式化驗證與可證明契約 (Formal Verification & SMT Solvers)
超越範例測試（Example-Based Testing）的盲區，將架構約束轉化為一階邏輯定理：
- Task-IR 字節碼攜帶狀態機無死鎖、借貸恆平衡、邊界無洩漏之證明義務。
- 門禁系統逐步整合 SMT 求解器（如 Z3），實現數學級的絕對可靠度。

### 10.4 自主負熵與三振自合成引擎 (Autonomous Rule of Three & Negative Entropy)
傳統軟體系統隨規模膨脹必定趨向混亂（熵增）。AI 軟體工廠實施自主負熵機制：
- 靜態探針全時監控業務切片的 AST 結構相似度。
- 當同質性模式出現第 3 次時，工廠自主起草 RFC、自主生成標準庫原語、自主提 PR 替換業務層舊代碼。
- 系統以「淨代碼消除率 (Net Code Deletion Ratio)」為演化衡量，模組越多，共用抽象層次越高，全域代碼反而越簡練。


## 11. 自我分析演化週期與百萬級任務時空重現機制 (Self-Evolution Cadence & Centennial Replay Mesh)

### 11.1 四級自我分析與重構節奏 (The 4-Tier Evolution Protocol)
軟體工廠的負熵演進不能仰賴人工作業，必須由自動化定時神諭與結構化週期驅動：
1. **季度防熵 (Quarterly - 3M)**：自動依賴漏洞修復、AST 死按鈕防禦、ArchUnit 架構適性測試驗收、Living Specs 審核有效性標記。
2. **年度負熵 (Annual - 1Y)**：發動「三振自合成機制 (Rule of Three)」，重複邏輯提煉回 `Agent SDK`，要求淨代碼消除指標（業務消除行數 / SDK 抽象行數）> 1.0。
3. **三年代際 (Triennial - 3Y)**：底層可拋棄宿主（Spring Boot, React, Node）代際升級，清理逾期淘汰 API，校準新型 AI 虛擬機之 Task-IR 解析效能。
4. **十年重校 (Decennial - 10Y)**：歷史任務轉冷存檔，雙時態時間旅行壓力測試，全面擴展 SMT 形式化數學證明。

### 11.2 任務歷程確定性重現 (Deterministic Replayability of Historical Tasks)
- 軟體工廠保留全部歷史任務歷程。
- 每一筆 Task 目錄均為自包含的「時空膠囊」，以 `task.ir.yaml` 機器語言字節碼為核心。
- 未來的 AI 模型能以拓撲序完全重放 `TASK-000001` 至最新任務，在全新運算宿主環境中 100% 完整無損重現歷史全貌與架構真實。

### 11.3 百年 6 位數 Task ID 規格 (Centennial 6-Digit Task ID Schema)
- **主任務 ID**：強制採 6 位數 `TASK-000001` ~ `TASK-999999`（百萬級容量，滿足百年工廠運作需求）。
- **子任務 ID**：強制採 3 位數 `TASK-000012-001_Backend.md`。
- **純粹 6 位數嚴格規格**：TASK ID 嚴格強制為 6 位數（`TASK-[0-9]{6}`），無須向下相容舊版 3 位數；全系統既有與未來任務一律依照最新架構規範重新分析與拆分。
