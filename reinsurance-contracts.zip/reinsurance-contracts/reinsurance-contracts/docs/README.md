# 再保險合約與軟體工程規格中心 (Architecture & Specification Hub)

> **定位**：本目錄為本系統之「最高架構主權庫」與「規格即系統 (Spec-as-System)」單一真實來源 (Single Source of Truth)。  
> 代碼僅為規格之即時投影產物。所有人類工程師、架構師與自主 AI Agent 均以此文件作為導航起點。

---

## 快速導航地圖 (Master Documentation Map)

```text
reinsurance-contracts/docs/
├── README.md                                # [本文件] 規格中心總覽導覽
├── framework/                               # 【第一層：跨專案通用框架 (100% 可共用)】
│   └── AI_SOFTWARE_FACTORY_BLUEPRINT.md    # AI 原生軟體工廠基底、雙軌規格、五大抗耦合防線、自然芽裂
├── domain/                                  # 【第二層：專案專屬領域規範 (再保險金融)】
│   └── REINSURANCE_DOMAIN_STANDARDS.md     # 業務族譜命名 (md_*, tr_*, cl_*, bl_*)、金融審計日誌、Banker's Rounding
├── ENGINEERING_STANDARDS.md                 # 【第三層：全端工程實作準則】
│                                            # Spring Boot 3 + Next.js 14 實作細節、SQL 建模、DoD 四大閘門
├── adr/                                     # 架構決策記錄 (Architecture Decision Records)
│   ├── README.md                            # ADR 導航與追溯矩陣
│   ├── ADR-001-spec-driven-ai-software-factory.md                 # 統合 Meta-ADR 1 (規格驅動軟體工廠)
│   ├── ADR-002-decoupled-multi-repo-and-evolvable-slices.md      # 統合 Meta-ADR 2 (多庫契約解耦與演進切片)
│   ├── ADR-003-enterprise-quality-resilience-and-audit-baseline.md # 統合 Meta-ADR 3 (企業級品質韌性與審計基線)
│   └── archive/                             # 歷史 9 篇原始 ADR 完整時序存檔 (100% 保存)
├── specs/                                   # 6 大活體規格書庫 (The 6-Core Living Spec Suite)
│   ├── SA_SPEC.md                           # 系統分析、業務規則 (BR-xxx)、RBAC 矩陣
│   ├── USE_CASE_SPEC/                       # Gherkin 驗收場景與主替代流程
│   ├── UI_SPEC/                             # 畫面互動、三道防呆、色彩階層與 Mockup 對照
│   ├── DBA_SPEC/                            # 資料庫模型、軟性外鍵、時間戳 Flyway 遷移
│   ├── SD_SPEC/                             # 系統時序圖、Package-Private 封閉性、引用防禦端點
│   └── QA_SPEC/                             # 需求追溯矩陣 (RTM)、負面測試矩陣、測試替身協議
├── architecture/                            # 架構演進藍圖
│   └── MULTI_REPO_SPLIT_BLUEPRINT.md        # 多庫解耦藍圖與分支協作規範
├── templates/                               # 標準範本庫
│   ├── TASK_MANIFEST_TEMPLATE.yaml          # 機器契約 manifest 2.0 範本
│   └── RELEASE_DOSSIER_TEMPLATE.md          # 結案發布報告書範本
└── governance/                              # 敏捷回顧與治理記憶庫
    └── RETROSPECTIVE.md                     # 歷史踩坑覆盤、教訓程式化記錄
```

---

## 一、 規範三層治理架構 (The 3-Layer Standards Hierarchy)

| 層次 | 目錄與核心文件 | 涵蓋範疇 | 適用對象 |
|:---|:---|:---|:---|
| **第一層：跨專案通用框架** | [`docs/framework/AI_SOFTWARE_FACTORY_BLUEPRINT.md`](framework/AI_SOFTWARE_FACTORY_BLUEPRINT.md)<br>[`docs/adr/ADR-001 ~ ADR-003`](adr/README.md) | • 規格即系統 (Spec-as-System)<br>• 雙軌規格體系 (Living Spec vs. Manifest)<br>• 契約先行多庫解耦分支協作<br>• 五大抗耦合防線與自然芽裂 (Sprouting)<br>• AST 死按鈕門禁與 i18n 完整性掃描 | **所有軟體專案 100% 共用**<br>(SaaS, FinTech, E-Commerce, ERP) |
| **第二層：業務專屬領域規範** | [`docs/domain/REINSURANCE_DOMAIN_STANDARDS.md`](domain/REINSURANCE_DOMAIN_STANDARDS.md) | • 資料庫領域族譜命名 (`md_*`, `tr_*`, `cl_*`, `bl_*)<br>• 金融審計全欄位留痕 (變更原因 $\ge 5$ 字元)<br>• 四捨六入五成雙 (Banker's Rounding, 精度 0~4)<br>• 幣別引用防禦鏈 (`treatyCount` 檢核)<br>• 再保險專業術語字典 | **再保險業務核心專屬** |
| **第三層：全端工程實作準則** | [`docs/ENGINEERING_STANDARDS.md`](ENGINEERING_STANDARDS.md) | • 基礎工程基線 (12-Factor 配置, MDC 日誌, 密鑰)<br>• Clean Architecture + DDD + 垂直切片<br>• Spring Boot 3 + Java 21 + JPA / Flyway 實作<br>• Next.js 14 + Feature-Sliced UI + SafeActionButton<br>• 四大客觀自動化品質閘門 (DoD) | **全體開發人員與 AI 執行工** |

---

## 二、 三大統合架構決策 (Consolidated Meta-ADRs)

為降低認知負載，過去對話演進產生的 9 篇歷史 ADR 已收斂整合為三大核心 Meta-ADRs（歷史原始檔案 100% 封存於 [`docs/adr/archive/`](adr/archive/)）：

1. **[ADR-001：規格驅動之 AI 原生軟體工廠架構](adr/ADR-001-spec-driven-ai-software-factory.md)**  
   *涵蓋原 ADR-002, 004, 006, 007*：確立單一真理契約庫、雙軌規格分離、風險自主放行、AST 死按鈕防熵、規格衝突仲裁。
2. **[ADR-002：多庫契約先行與可演進垂直切片架構](adr/ADR-002-decoupled-multi-repo-and-evolvable-slices.md)**  
   *涵蓋原 ADR-008, 009*：確立契約先行多庫解耦分支、MonolithFirst 邏輯聚合、五大抗耦合防線 (領域標籤、軟性外鍵、引用防禦、Package-Private、Feature-Sliced UI)、自然芽裂協議。
3. **[ADR-003：企業級品質韌性、合規審計與 QoS 基線](adr/ADR-003-enterprise-quality-resilience-and-audit-baseline.md)**  
   *涵蓋原 ADR-001, 003, 005*：確立全欄位變更審計與原因驗證、S/M/L QoS 基線、強型別配置 Fail-Fast、LTS 世代平滑演進與依賴 BOM 治理。

---

## 三、 四大客觀自動化品質驗收閘門 (Quality Gates)

任何代碼變更在合併至 `dev` 或發布前，必須通過以下四道自動化閘門檢驗：

```bash
# 閘門 1 & 閘門 2：規格治理與 OpenAPI 領域標籤稽核
python3 scripts/audit-specs.py

# 閘門 3：前端多語系字典完整性與 AST 死按鈕靜態門禁
cd /home/kenny/aider-test/reinsurance-web-portal && npm test

# 閘門 4：雙端編譯與單元測試雙綠燈
cd /home/kenny/aider-test/reinsurance-web-portal && npx tsc --noEmit
cd /home/kenny/aider-test/reinsurance-core-service && mvn test
```
