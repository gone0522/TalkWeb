# 前後端共用開發與架構規範 (Shared Conventions) - [已廢棄]

> [!NOTE]
> **本文件已正式廢棄並分層收斂！**
> 1. 通用軟體工程、雙軌規格、多庫分支與抗耦合防線請參閱：👉 **[docs/framework/AI_SOFTWARE_FACTORY_BLUEPRINT.md](framework/AI_SOFTWARE_FACTORY_BLUEPRINT.md)**
> 2. 再保險業務命名族譜、幣別精度與金融審計請參閱：👉 **[docs/domain/REINSURANCE_DOMAIN_STANDARDS.md](domain/REINSURANCE_DOMAIN_STANDARDS.md)**
> 3. 全系統核心架構決策請參閱：👉 **[docs/adr/README.md](adr/README.md)** (ADR-001 ~ ADR-003)
> 4. AI Agent 執行指示請參閱：👉 **[AGENTS.md](../AGENTS.md)**
