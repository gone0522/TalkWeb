<!--
governance_metadata:
  last_reviewed: "2026-10-13"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-13"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# 企業級全端工程設計規範與架構準則 (Master Engineering Standards)

> **版本**：v3.0 (Consolidated & Layered Architecture)  
> **適用範圍**：全體軟體架構師、前後端工程師與自主 AI Agent  
> **關聯核心規約**：
> - 跨專案通用框架：[`docs/framework/AI_SOFTWARE_FACTORY_BLUEPRINT.md`](framework/AI_SOFTWARE_FACTORY_BLUEPRINT.md)
> - 業務核心領域規範：[`docs/domain/REINSURANCE_DOMAIN_STANDARDS.md`](domain/REINSURANCE_DOMAIN_STANDARDS.md)
> - 三大統合架構決策：[`docs/adr/ADR-001`](adr/ADR-001-spec-driven-ai-software-factory.md), [`ADR-002`](adr/ADR-002-decoupled-multi-repo-and-evolvable-slices.md), [`ADR-003`](adr/ADR-003-enterprise-quality-resilience-and-audit-baseline.md)
> 
> **架構願景與核心定位 (Vision & Charter)**：  
> 軟體工程最原始的目的，就是將**「人類意圖」**精準無損地轉換為**「機器語言」**，而且機器可以確實無誤、零歧義、零妥協地執行，幾乎 100% 依照人類想要的樣子去落地實作。  
> 當持續年線拉伸至**一百年（Centennial Horizon: 2026 ~ 2126+）**：原則的東西就像太陽升起一樣不會改變（數學真實、借貸複式平衡、呈現邊界外部化、不可篡改的審計軌跡）；會隨時代更迭的，僅僅是運作的模型與具體的計算機器。

---

## 規範分層與架構位階 (Architecture Hierarchy & Scope)

為達成高內聚、跨專案 70% 資產即插即用、並杜絕歷史規範膨脹腐蝕，本系統確立**三層清晰治理體系**：

```text
┌────────────────────────────────────────────────────────────────────────┐
│ 第一層：跨專案通用 AI 原生軟體工廠框架 (Universal Framework)          │
│ • docs/framework/AI_SOFTWARE_FACTORY_BLUEPRINT.md                      │
│ • docs/adr/ (ADR-001 規格驅動軟體工廠, ADR-002 多庫演進切片, ADR-003 品質韌性) │
│ 範疇：單一真理契約、雙軌規格、多庫分支解耦、五大抗耦合防線、自然芽裂、AST 死按鈕防線 │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ 繼承與約束
┌───────────────────────────────────▼────────────────────────────────────┐
│ 第二層：專案專屬業務領域規範 (Domain-Specific Standards)                │
│ • docs/domain/REINSURANCE_DOMAIN_STANDARDS.md                          │
│ 範疇：再保險資料表前綴 (md_*, tr_*, cl_*, bl_*)、金融審計日誌 (原因≥5字)、    │
│       四捨六入五成雙 (Banker's Rounding)、幣別引用防禦鏈 (treatyCount)        │
└───────────────────────────────────┬────────────────────────────────────┘
                                    │ 具體工程落實
┌───────────────────────────────────▼────────────────────────────────────┐
│ 第三層：全端工程實作與技術指引 (Master Engineering Standards - 本文件)  │
│ • docs/ENGINEERING_STANDARDS.md                                        │
│ 範疇：Spring Boot 3 + Next.js 14 實作指南、SQL 建模、TypeScript、DoD 品質閘門 │
└────────────────────────────────────────────────────────────────────────┘
```

---

## 目錄 (Table of Contents)
1. [第一章：架構願景與核心憲章 (Architectural Charter)](#第一章架構願景與核心憲章-architectural-charter)
2. [第二章：基礎工程基線 (Foundational Engineering Baselines)](#第二章基礎工程基線-foundational-engineering-baselines)
3. [第三章：領域驅動設計與垂直切片 (Domain-Driven Design & Vertical Slices)](#第三章領域驅動設計與垂直切片-domain-driven-design--vertical-slices)
4. [第四章：資料庫架構與資料建模準則 (Database Architecture & Flyway)](#第四章資料庫架構與資料建模準則-database-architecture--flyway)
5. [第五章：後端架構與設計模式 (Backend Architecture & Clean Patterns)](#第五章後端架構與設計模式-backend-architecture--clean-patterns)
6. [第六章：前端現代架構與強制基礎標準 (Frontend Architecture & Mandatory Baselines)](#第六章前端現代架構與強制基礎標準-frontend-architecture--mandatory-baselines)
7. [第七章：專案全生命週期流程標準 (End-to-End Enterprise SDLC Standard)](#第七章專案全生命週期流程標準-end-to-end-enterprise-sdlc-standard)
8. [第八章：系統自適應分級與可演進芽裂架構 (Adaptive Scale & Evolvable Architecture)](#第八章系統自適應分級與可演進芽裂架構-adaptive-scale--evolvable-architecture)
9. [第九章：資安防護、可觀測性與高可用防禦 (Cybersecurity, Observability & Resilience)](#第九章資安防護可觀測性與高可用防禦-cybersecurity-observability--resilience)
10. [第十章：技術棧長青演進與依賴治理 (Evergreen Tech Stack & Dependency Governance)](#第十章技術棧長青演進與依賴治理-evergreen-tech-stack--dependency-governance)
11. [第十一章：架構自動升級、自主演化與防熵自閉環機制 (Autonomous Evolution & Self-Healing Architecture)](#第十一章架構自動升級自主演化與防熵自閉環機制-autonomous-evolution--self-healing-architecture)

---

## 第一章：架構願景與核心憲章 (Architectural Charter)

### 1.1 四大全域架構不變量 (The Four Core Architectural Invariants)
本軟體工廠徹底揚棄「出一個 Bug 就追加一條手冊細則」的窮舉列舉與打地鼠模式，全面奠基於四大不可逾越之第一性原理（First Principles）：
1. **【表現層文字外部化不變量】(Presentation Externalization Invariant)**：
   - 核心系統內部（Domain / Service / Repository / Transport Client）一律只流通「規範機器代碼 (Canonical Codes / Enums / Keys)」；所有面向終端使用者的自然語言（UI 顯示、報表表頭、通知訊息、審計描述），皆屬動態在地化投影，**嚴格禁止於業務邏輯硬編碼自然語言常值**。
2. **【契約單一真理源不變量】(Contract As Single Source of Truth)**：
   - 資料結構、端點路徑與欄位投影以機器契約 (`openapi.yaml` / DTO Schema) 為唯一事實真理，嚴禁在業務層各自發明欄位對應或手工維護第二套元資料。
3. **【同構對稱不變量】(Homomorphic Sibling Parity Invariant)**：
   - 同屬相同業務原型（Archetype，如 Master Data 三兄弟：Country, Region, Currency）的模組，結構、分區與行為必須保持 100% 同構對稱。修復一個，其餘兄弟必須具備同等防禦。
4. **【確定性優雅防禦不變量】(Deterministic Resilience & Anti-Entropy)**：
   - 所有系統互動必須具備確定性反饋；狀態不確定或未就緒之功能必須顯式標記 `disabled` 並包裹 Tooltip，嚴禁無事件假按鈕；併發寫入強制樂觀鎖攔截與刷新引導。

### 1.2 Java 哲學之編譯與執行體系 (The Spec-to-Bytecode Pipeline)
本系統將需求落地拆解確立為「高階語言 ➔ 編譯器 ➔ 字節碼 ➔ 虛擬機」之標準體系：
- **高階活體規格 (`.spec.md` - 似 `.java`)**：人類架構師維護，表達商業概念、領域邊界與 UX 意圖，擺脫瑣碎格式雜訊。
- **意圖編譯器 (Task Planner - 似 `javac`)**：解析高階規格，比對 `Agent SDK` 原語清單，消除歧義並輸出字節碼。
- **任務字節碼 (Task-IR - 似 `.class` Bytecode)**：跨模型、跨平台、高密度結構化宣告契約 (`task.ir.yaml`)，包含環境前置神諭、狀態不變量與可觀測性驗收神諭。
- **AI 虛擬機 (Task Runner - 似 JVM)**：任何主流大模型作為執行引擎，Strict TDD 落地並通過客觀架構檢驗。

---

## 第二章：基礎工程基線 (Foundational Engineering Baselines)

### 2.1 外部化配置管理 (Externalized Configuration)
1. **後端 Spring Boot**：
   - 所有的環境變動值（DB 連線、超時閥值、批次上限、快取 TTL）必須定義於 `application.yml` 或 `application-{profile}.yml`。
   - 採用 `@ConfigurationProperties(prefix = "app.service-name")` 進行強型別物件綁定，嚴禁在業務程式碼中散落 `@Value("${...}")`。
   - 全面支援作業系統環境變數覆寫（如 `${APP_TIMEOUT_MS:5000}`）。
2. **前端 Next.js**：
   - 瀏覽器端變數強制加上 `NEXT_PUBLIC_` 前綴（如 `NEXT_PUBLIC_API_BASE_URL`）；伺服器端密鑰與連線嚴禁加上 `NEXT_PUBLIC_`。
   - API Client Base URL 宣告必須具備環境變數與本地預設 Fallback：
     `const API_BASE_URL = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8080";`
   - 根目錄必須維護 `.env.development` 與 `.env.example`。

### 2.2 多國語言、動態在地化報表與零自然語言硬編碼鐵律 (i18n & Zero Hardcoded Strings)
1. **全語言零自然語言寫死鐵律 (Zero Hardcoded Natural Language Strings in Any Language)**：
   - 無論中文、英文、日文或任何人類語言，**嚴格禁止在非 Presentation 層硬編碼自然語言字串常值**。
   - 包含但不限於後端 Service 預設異動原因、業務異常訊息，以及前端 API Client 錯誤封裝。
   - 靜態門禁突破純中文字元正則盲區，進一步透過 AST 語法樹檢查確保無任何未經參數化或字典包裹之自然語言字串。
2. **四層架構分界原則 (Architectural Boundary Principles)**：
   - **傳輸層 (Transport Layer / API Client)**：純機器代碼層。嚴禁構造自然語言句子（例如寫出 `throw new ApiError('Failed to export', ...)` 亦屬嚴重違規），必須僅攜帶 HTTP 狀態碼與機器錯誤代碼 (`errorCode` / `code`)。
   - **持久與審計層 (Persistence & Audit Layer)**：資料庫審計表之 `change_reason` 與欄位名稱一律儲存 **規範代碼 / 標準鍵值 (Canonical Identifiers / Standard Keys)**（例如 `SYSTEM_DEFAULT_UPDATE`、`MANUAL_USER_MAINTENANCE`、`BATCH_IMPORT_UPDATE`、`NAME_ZH`、`IS_SANCTIONED`），嚴格禁止存入自然語言文字。
   - **呈現層 (Presentation Layer / UI)**：唯一負責將機器代碼轉換為人類自然語言的層次。前端以 `next-intl` 之 `t('errors.' + errorCode)` 解析錯誤提示，以 `t('audit.reasons.' + changeReason)` 解析審計異動原因。
   - **報表匯出層 (Excel / Report Export)**：後端生成 Excel、CSV 或 PDF 報表時，表頭與列舉值嚴禁在代碼中寫死靜態字串陣列（如 `new String[]{"國家代碼", "國家名稱"}`），必須動態注入 `MessageSource`，並依據當前 HTTP 請求標頭 `Accept-Language` (`LocaleContextHolder.getLocale()`) 即時解析對應語系。
3. **語系字典目錄與命名規範**：
   - 前端字典集中於 `src/locales/`（如 `zh-TW.json`, `en-US.json`），各語系鍵值結構必須 100% 同步。
   - 命名空間格式遵循 `<模組>.<頁面/特性>.<區塊>.<元素>`，錯誤代碼對齊 `errors.<errorCode_lowercase>`。
4. **自動化品質門禁**：
   - CI 強制執行 `scripts/validate-i18n.js`，雙語字典未同步、JSX 中存在未經翻譯字串、或英文語系存在中文洩漏一律紅燈阻斷。

### 2.3 日誌、全鏈路追蹤與結構化上下文 (Structured Logging & MDC Tracing)
1. **結構化 JSON 日誌與參數化格式**：使用 SLF4J + Logback，嚴格禁止日誌字串拼接 (`log.info("msg: " + id)`)，強制使用參數化佔位符 (`log.info("Updating entity id={}, reasonKey={}", id, reasonKey)`)。
2. **MDC 全鏈路上下文**：由 Web Filter / Interceptor 注入追蹤識別碼至 `MDC`：`traceId`, `spanId`, `operatorId`, `domain`。跨微服務呼叫必須沿 HTTP Header (`X-Trace-ID`, `X-Span-ID`) 傳遞。
3. **敏感資訊脫敏 (PII Masking)**：身分證號、銀行帳號、信用卡號、密碼嚴禁明文印出，日誌輸出前必須遮罩（如 `A12****789`）。

### 2.4 數值精度與金融進位規範 (Financial Precision & Rounding)
1. **高精度數值型別**：後端處理所有貨幣、比率、費率嚴格使用 `BigDecimal`，資料庫欄位使用 `DECIMAL(p, s)` 或 `NUMERIC(p, s)`，嚴禁使用 `float` 或 `double`。
2. **四捨六入五成雙 (Banker's Rounding)**：精算與金融結算計算預設採用 `RoundingMode.HALF_EVEN`，杜絕累積進位偏差。
3. **小數位數約束**：小數位數必須介於 0 至 4 之間（如日圓 0 位、新台幣 0 或 2 位、美元 2 位、特殊精算 4 位）。
4. **前端金額格式化**：一律由共用 Util 格式化輸出貨幣符號、指定小數位數與千分位（例如 `$ 1,234.56`）。

---

## 第三章：領域驅動設計與垂直切片 (Domain-Driven Design & Vertical Slices)

### 3.1 DDD 領域分層與純粹性 (Clean Architecture & Core Purity)
1. **核心領域純粹性**：Domain Entity 與 Value Object 保持為純 Java/TypeScript 邏輯，嚴禁直接依賴外圍框架（如 Spring MVC Controller、HTTP Client）。
2. **聚合根與身分識別引用 (Reference by Identity)**：
   - 跨聚合關聯一律僅持有身分識別碼 (ID / Code)，嚴禁直接持有跨領域實體物件參照。
   - 禁止在 JPA Entity 中使用跨領域的 `@ManyToOne` 或 `@OneToMany` 實體導航載入，杜絕巨大物件圖與記憶體爆炸。

### 3.2 垂直切片架構 (Vertical Slice Architecture)
1. **以業務功能切片，而非以水平技術分層切片**：
   - 每個任務聚焦於一條具體的業務價值切片（例如「幣別新增與審計」、「幣別停用前引用檢核」）。
   - 切片包含該功能所需之資料庫遷移、後端端點、前端 UI 與測試，具備獨立交付與可測試性。
2. **微任務解耦標準 (Decoupled Task Slices)**：
   - 後端任務聚焦於 API 與業務邏輯，從後端倉庫 `dev` 切出 `feature/<TASK>-API`。
   - 前端任務聚焦於使用者體驗與畫面互動，從前端倉庫 `dev` 切出 `feature/<TASK>-UI`，依據 OpenAPI 契約使用 Mock Server 平行獨立開發。

### 3.3 領域內 vs 跨領域 CQRS 分級架構 (Domain-Bounded CQRS Architecture)
1. **領域內部 CQRS (Intra-Domain)**：為因應複雜業務報表與防止 N+1 效能問題，合約領域或主檔領域內部全力開放建立資料庫 View 或多表 SQL JOIN。
2. **跨領域邊界嚴格隔離 (Cross-Domain Isolation)**：嚴格禁止跨領域資料庫實體 JOIN！跨模組組合必須採應用層 BFF 組裝或 Snapshot 快照表，確保模組具備獨立微服務芽裂能力。

### 3.4 規格分級繼承與主規格語意錨點回寫閉環 (Spec Inheritance & Semantic Anchor Reconciliation)
1. **Tier-1 規格繼承與極簡 Delta 單**：
   - 若所屬模組在全局 `docs/specs/` 已具備完整規格，任務無須複製冗餘的 6 大規格目錄，Manifest 宣告 `spec_mode: "lightweight"` 與 `base_spec_ref`。
   - 任務卡強制包含 15 行極簡 Delta 單（引用來源 + 變更差量 + 1 個可執行 BDD 場景）。
2. **主規格語意錨點回寫鐵律 (Mandatory DoD)**：
   - 任務代碼合併入庫時，DoD 強制將增量變更同步回寫更新至全局主規格庫 (`docs/specs/`) 對應章節錨點（`<!-- SECTION: ... -->`）。
   - 採行局部 Diff 替換，嚴禁全篇覆寫，杜絕規格漂移。
3. **現行法優先律 (Active Law vs Audit Trail)**：
   - `docs/specs/` 為唯一現行法真理源，`tasks/` 僅供歷史審計留痕，嚴禁未來 AI 誤讀舊 Task 造成上下文污染。
4. **時空膠囊規格純淨與防補丁污染鐵律 (Time-Capsule Spec Purity - Rule 34 & 35)**：
   - 任務規格卡 (`tasks/**/*.md`) 是可確定性重放（Deterministic Replay from Scratch）的終態藍圖。
   - 規格描述必須是「該功能第一天就應該被正確建構的樣貌」，嚴禁在規格中寫入運行期維護補丁記錄、維護分支名稱或事後補償敘述（如「維護分支」、「修復分支」、「補全」）。
   - 雙端專庫修復分支唯一合法命名為 `fix/<TASK_ID>-<ROLE>`（如 `fix/TASK-000012-UI`），嚴禁 `task/` 前綴或雙重 `-fix` 尾綴。
   - 門禁檢核：`python3 scripts/audit-specs.py` Gate 4 全面自動掃描規格文本純淨度與本地多庫分支命名，違者直接阻斷。

---

## 第四章：資料庫架構與資料建模準則 (Database Architecture & Flyway)

### 4.1 遷移腳本規範與資料庫治理 (Database Migrations & Flyway/Liquibase)
1. **時間戳版號命名**：所有遷移檔案強制採用時間戳命名 `V{YYYYMMDDHHMMSS}__{description}.sql`，徹底杜絕多人並行時的版號衝突。
2. **等冪與防禦性 DDL**：所有 DDL 必須具備防禦性條件：
   - `CREATE TABLE IF NOT EXISTS ...`
   - `ALTER TABLE ... ADD COLUMN IF NOT EXISTS ...`
   - `CREATE INDEX IF NOT EXISTS ...`
3. **遷移鎖定逾時防護 (Lock Timeout)**：所有遷移腳本開頭強制宣告 `SET lock_timeout = '5s';`，防止 DDL 遭遇排隊鎖定時造成整庫連線池耗盡。
4. **企業級環境嚴格禁止 `hibernate.ddl-auto=update`**：
   - 在企業級生產與測試環境中，`spring.jpa.hibernate.ddl-auto` 僅允許配置為 `validate` 或 `none`。
   - 所有 Schema 演進必須嚴格由 Flyway 或 Liquibase 遷移腳本統一管理，絕對禁止依賴 Hibernate 自動變更資料庫結構。
5. **雙相無感遷移 (Expand/Contract Pattern)**：重大結構調整嚴禁在單一任務中執行 `DROP COLUMN`：
   - Phase 1 (Expand)：新增欄位，後端雙寫新舊欄位，保留舊欄位支援回滾。
   - Phase 2 (Migrate)：背景排程批次補齊舊資料。
   - Phase 3 (Contract)：穩定運行一個版本週期後，於次期清理舊欄位。

### 4.2 領域族譜與軟性外鍵鐵律 (Table Prefixes & Soft Foreign Keys)
1. **業務族譜前綴 (Table Prefixes)**：
   - 主檔類：`md_*`（如 `md_currency`, `md_country`）
   - 合約類：`tr_*`（如 `tr_treaty`, `tr_facultative`）
   - 理賠類：`cl_*`（如 `cl_claim`, `cl_recovery`）
   - 計費結算類：`bl_*`（如 `bl_bill`, `bl_settlement`）
2. **零跨領域實體外鍵 (Zero Hard Foreign Keys)**：
   - 跨領域資料表之間**嚴禁建立資料庫實體 FOREIGN KEY 約束**。
   - 跨領域參照僅記錄邏輯代碼（如 `currency_code VARCHAR(3)`），一致性由應用層服務檢核保證。
3. **跨領域 SQL 零 JOIN (Zero Cross-Domain SQL JOINs)**：
   - 嚴禁在 Repository / DAO 中撰寫跨不同族譜前綴資料表的 SQL `JOIN`。
   - 跨領域資料組合一律在應用層完成，或在建檔時保存快照 (Snapshot Pattern)。

### 4.3 引用防禦協議與邏輯軟刪除 (Referential Guard & Soft-Delete)
1. **引用摘要端點**：被引用的主檔實體必須提供 `GET /api/v1/{entity}/{id}/references` 摘要端點。在停用或作廢前主動檢核引用計數。若有生效中關聯合約，強制阻擋停用。
2. **禁止物理刪除**：核心主檔與業務資料一律採邏輯軟刪除（`is_disabled = true` 或 `status = 'INACTIVE'`），嚴禁執行物理 `DELETE FROM`，確保歷史審計鏈條不中斷。
3. **全欄位變更審計 (Full-Field Audit)**：資料變更必須在同一個資料庫交易內寫入審計表記錄變更時間、操作人、部門、欄位名稱、變更前值、變更後值與異動原因（原因長度 $\ge 5$ 字元）。

---

## 第五章：後端架構與設計模式 (Backend Architecture & Clean Patterns)

### 5.1 後端架構、技術棧與 Tier-1 Approved BOM (Backend Architecture & Enterprise BOM)
- **技術棧基線**：Java 21 LTS + Spring Boot 3.2+ + Spring Data JPA + Flyway/Liquibase + PostgreSQL 15+。
- **後端 Tier-1 Approved BOM（拒絕低效手刻輪子）**：
  1. `Lombok`：強制使用 `@RequiredArgsConstructor` 取代手寫建構子注入，搭配 `@Getter`, `@Setter`, `@Builder`, `@Slf4j` 消除大量樣板代碼。
  2. `Flyway` / `Liquibase`：標準化資料庫版本遷移；`hibernate.ddl-auto` 嚴格鎖定 `validate`。
  3. `MapStruct`：編譯期型別安全 Entity <-> DTO 高性能映射器，嚴禁手刻繁瑣的 `toResponse()` 欄位複製函式。
  4. `Spring Data JPA Auditing`：`@EnableJpaAuditing` 搭配 `@CreatedDate`, `@LastModifiedDate`, `@CreatedBy`, `@LastModifiedBy` 自動維護審計欄位。
  5. `JaVers` / `Hibernate Envers`：實體差量自動審計引擎，自動比對並記錄變更前後值，杜絕手寫反射或逐欄比對。
  6. `EasyExcel` / `Spring POI Template`：註解驅動流式 Excel 讀寫 (`@ExcelProperty`)，百萬級資料流式傳輸不 OOM。
  7. `springdoc-openapi-starter-webmvc-ui`：自動生成 Swagger UI 與 OpenAPI 3.0 契約驗證。
  8. `ArchUnit`：架構單元測試，嚴格防禦 Package-Private 與禁止跨領域私有調用。
  9. `Testcontainers`：真實 Docker PostgreSQL 容器化整合測試。
- **RESTful API 與統一錯誤規範**：
  - 資源化路徑、正確 HTTP 動詞 (`GET`, `POST`, `PUT`, `PATCH`, `DELETE`)。
  - 全面遵循 **RFC 7807 Problem Details**，包含 `type`, `title`, `status`, `detail`, `errorCode`, `instance`, `invalidParams` 與 `traceId`。
- **併發控制與冪等防護**：
  - 核心實體強制增加 `@Version private Long version;` 樂觀鎖防護。
  - 資料異動端點支援 `X-Idempotency-Key` 請求標頭防重送。

### 5.2 領域邊界封閉性 (Package-Private Boundary Encapsulation)
1. **內部元件 Package-Private**：領域內部的 Repository、內部 Entity、私有 Service 實作類必須宣告為 Package-Private（去掉 `public` 修飾子）。
2. **公開出口唯一性**：跨領域訪問只能透過公開的 `PublicQueryApi` 或發布領域事件。嚴禁跨領域直接 `@Autowired` 私有組件。
3. **ArchUnit 架構單元測試**：在 CI 中運行 ArchUnit，自動攔截任何跨領域私有呼叫與越界依賴。

### 5.3 系統彈性與高可用防護 (Resilience & Outbox Pattern)
1. **斷路器與重試機制 (Resilience4j)**：呼叫外部服務必須配置 CircuitBreaker 與 Retry（帶指數退避與隨機抖動 Jitter），防止級聯崩潰。
2. **發件箱模式 (Transactional Outbox Pattern)**：跨服務發布非同步事件時，事件必須在同一個本地資料庫事務中寫入 `outbox_events` 表，由背景排程可靠投遞至訊息隊列，保證最終一致性。

---

### 5.4 領域實體審計基底標準 (BaseAuditableEntity & JPA Auditing Baseline)
為徹底消除各 Entity 手寫審計欄位產生的代碼漂移（例如大小寫 `"system"` vs `"SYSTEM"`、手動 inline new `OffsetDateTime.now()`）：
1. **強制實體繼承基底類別**：所有業務實體必須繼承統一的基底類別：
   ```java
   @MappedSuperclass
   @EntityListeners(AuditingEntityListener.class)
   public abstract class BaseAuditableEntity {
       @CreatedBy
       @Column(name = "created_by", nullable = false, updatable = false, length = 50)
       private String createdBy;

       @CreatedDate
       @Column(name = "created_at", nullable = false, updatable = false)
       private OffsetDateTime createdAt;

       @LastModifiedBy
       @Column(name = "updated_by", length = 50)
       private String updatedBy;

       @LastModifiedDate
       @Column(name = "updated_at")
       private OffsetDateTime updatedAt;

       @Version
       @Column(name = "version")
       private Long version;
   }
   ```
2. **啟用自動化審計監聽**：於配置類別標註 `@EnableJpaAuditing(auditorAwareRef = "auditorAware")`，審計使用者統一由 Spring Security / 上下文提供者注入，嚴禁手寫預設字串。

### 5.5 RESTful API 命名空間與路由階層規範 (API Namespace & Routing Hierarchy)
為杜絕 Controller 路由漂移、多重重複控制器與 OpenAPI 契約分歧：
1. **命名空間層級規則**：
   - 系統基礎設定與代碼主檔維護：強制統一前綴 `/api/v1/system/<resource>`（例如 `/api/v1/system/countries`, `/api/v1/system/regions`, `/api/v1/system/currencies`）。
   - 核心再保業務資源：統一前綴 `/api/v1/<domain>/<resource>`（例如 `/api/v1/treaty/contracts`）。
2. **單一資源單一控制器原則**：嚴禁同一領域實體在不同 package 宣告多個 Controller（如禁止同時存在 `lookup.CurrencyController` 與 `currency.CurrencyController`）。
3. **契約與實作零偏差鐵律**：Controller 的 `@RequestMapping`、方法路徑與匯出端點（如 `/export`）必須與 `contracts/openapi.yaml` 100% 精準匹配。

## 第六章：前端現代架構與強制基礎標準 (Frontend Architecture & Mandatory Baselines)

### 6.1 前端核心技術棧與 Tier-1 Approved BOM (Frontend Enterprise Stack & BOM)
1. **核心技術基線**：Next.js 15+ (App Router) + React 19+ + TypeScript 5+。
2. **Server Components (RSC) vs Client Components (`'use client'`) 嚴格邊界**：
   - **預設服務端渲染 (Server-First)**：所有頁面入口 (`page.tsx`)、佈局 (`layout.tsx`) 與靜態資料載入元件預設為 Server Components，享有零客戶端 Bundle 體積、高速首屏加載與 SEO 支援。
   - **互動葉節點約束 (`'use client'`)**：`'use client'` 宣告嚴格限制於「最末端互動葉節點」（如按鈕點擊、表單輸入、抽屜彈窗、動態圖表），**嚴禁在頂層頁面或整個 feature 根目錄濫用 `'use client'`** 導致整頁退化為傳統肥大 SPA。
3. **前端 Tier-1 Approved BOM（拒絕手刻低效輪子）**：
   - **狀態管理體系**：
     * 伺服器端狀態：`@tanstack/react-query`（強制用於所有非同步 API 請求、快取、自動重試、去重、視窗聚焦重新整理、樂觀更新）。
     * 全域客戶端狀態：`zustand`（輕量極速狀態庫，取代 Redux 與 React Context 巢狀地獄，管理用戶工作階段、全域彈窗佇列、佈局開關）。
     * 表單與區域狀態：`react-hook-form` + `zod` (`@hookform/resolvers/zod`)，`useState` 嚴格限制於極簡 UI 開關（如 Accordion 展開）。
   - **UI 與元件體系**：
     * 圖示庫：`lucide-react`（現代主流向量圖示，**全面取代行內手寫 inline SVG**）。
     * 全域通知：`sonner`（現代宣告式 Toast，消除元件層層傳遞 `showToast` 的 Prop-drilling 噩夢）。
     * 無障礙 Headless 原語：Radix UI (`@radix-ui/react-dialog`, `@radix-ui/react-popover`, `@radix-ui/react-dropdown-menu`, `@radix-ui/react-tooltip`, `@radix-ui/react-select`, `@radix-ui/react-tabs`)。
     * 資料表格與虛擬化：`@tanstack/react-table` 搭配 `@tanstack/react-virtual`（超過 100 筆資料強制虛擬滾動）。
4. **垂直內聚目錄結構 (Feature-Sliced)**：業務功能全面組織於 `src/features/<domain>/<subdomain>/`：
   ```text
   src/features/<domain>/<subdomain>/
   ├── components/       # 專屬 UI 元件 (Table, Drawer, Modal)
   ├── api/              # 專屬 API Client (純機器錯誤碼，無自然語言)
   ├── hooks/            # 專屬狀態 Hook (React Query, Form, Zustand slice)
   ├── types/            # 專屬 TypeScript 型別
   └── index.ts          # 對外唯一公開匯出出口
   ```
5. **禁止深層私有引用**：外部頁面與路由僅能從 `index.ts` 引入組件，嚴禁跨越邊界引用內部私有檔案。

### 6.2 網路傳輸層架構與攔截器標準 (API Transport & Interceptor Standards)
1. **集中式 HTTP 傳輸用戶端 (`src/shared/api/client.ts`)**：
   - 封裝統一的 fetch / axios 實例，嚴禁各元件散落呼叫原生 `fetch()`。
2. **五大核心攔截器 (Client Interceptors)**：
   - **JWT Bearer Token 自動注入**：由 Request 攔截器自動自安全存儲讀取並注入 `Authorization: Bearer <token>`。
   - **無感 Refresh Token 輪轉 (Token Refresh Rotation)**：
     * 遭遇 401 Unauthorized 時，自動發起 `/api/v1/auth/refresh` 換取新 Token。
     * 刷新期間自動將並行的其他請求置入佇列等待重放；若刷新失敗則清空憑證並導向 `/login?redirect=...`。
   - **分散式全鏈路追蹤標頭**：所有傳出請求自動附加 `X-Trace-ID` 與 `X-Span-ID`，串聯前後端全鏈路日誌。
   - **請求主動取消防競爭 (AbortController)**：
     * 元件卸載 (Unmount) 或快速路由切換時，自動中止未完成之網路請求，防止 Race Condition 狀態覆蓋與記憶體洩漏。
   - **RFC 7807/9457 ProblemDetail 正規化**：
     * 統一解析後端錯誤 JSON，反序列化為強型別 `ApiError(status, errorCode, details)`。
     * 傳輸層**嚴格禁止構造自然語言句子**（寫死英文如 `'Export failed'` 亦屬違規），僅傳遞機器錯誤代碼 (`errorCode`)。

### 6.3 設計系統與 Design Tokens 規範 (Design Tokens & Styling Standards)
1. **Design Tokens 集中化 (`src/styles/tokens.css`)**：
   - 色彩尺度：Primary, Neutral, Success, Warning, Danger 等 HSL/Hex 變數。
   - 排版尺度：Font Family (Inter, Roboto), Font Size, Line Height, Font Weight。
   - 間距尺度：嚴格遵循 4px 網格系統（`--space-1: 4px`, `--space-2: 8px`, `--space-4: 16px`, `--space-6: 24px` 等）。
   - 圓角與陰影：`--radius-sm`, `--radius-md`, `--radius-lg`, `--shadow-sm`, `--shadow-md`。
   - 層級尺度：`--z-dropdown: 1000`, `--z-modal: 1050`, `--z-toast: 1100`。
2. **零 Inline Style 禁令**：
   - **嚴格禁止在 JSX 中寫死隨手 style 屬性**（如 `style={{ marginTop: '13px', color: '#334455' }}`）。
   - 所有樣式必須透過 CSS Modules 或 Vanilla CSS 引用 Design Tokens。
3. **明暗主題雙向適配 (Dark / Light Theme Tokens)**：
   - 透過根標籤 `[data-theme="dark"]` 切換 CSS 變數，組件樣式底層色碼零寫死。

### 6.4 企業級表格與大數據虛擬滾動標準 (Enterprise Data Grid & Virtualization)
1. **`@tanstack/react-table` + `@tanstack/react-virtual` 規範**：
   - 資料量超過 100 筆時，強制啟用虛擬滾動 (Virtual Scrolling)，將 DOM 節點數量控制在視窗內可視數量，杜絕瀏覽器卡死。
2. **企業表格必備能力**：
   - 伺服器端分頁 (`page`, `size`) 與多欄排序 (`sort=field,asc`)。
   - 關鍵字防抖查詢 (300ms Debounce)。
   - 欄位可見度切換 (Column Visibility) 與操作欄固定右側 (Pinned Columns)。

### 6.5 無障礙性基線與 Headless 互動標準 (WCAG 2.1 AA a11y & Radix UI)
1. **Radix UI Primitives 優先**：所有 Dialog, Popover, DropdownMenu, Tooltip, Select 強制基於 Radix UI 原語封裝。
2. **焦點管理與焦點陷阱 (Focus Trap)**：開啟彈窗或抽屜時，焦點自動鎖定於內部，Esc 鍵關閉後游標平滑返回觸發按鈕。
3. **全鍵盤無障礙導航**：表單與操作支援 Tab 循環、方向鍵選單移動、空格/Enter 鍵觸發。
4. **語意化 ARIA 綁定**：按鈕具備文字或 `aria-label`，表單標籤必須綁定 `htmlFor`，動態內容配置 `aria-live`。

### 6.6 錯誤邊界、骨架屏與 Web Vitals 性能基線 (Resilience & Web Vitals)
1. **React 錯誤邊界 (`react-error-boundary`)**：
   - 在路由級與核心功能卡片級配置 Error Boundary，發生 JS 運行期異常時展示在地化兜底畫面與「重試」按鈕，嚴禁白屏崩潰。
2. **骨架屏與載入過渡 (Suspense Skeletons)**：
   - 所有非同步加載區域強制採用 Skeleton 骨架屏或 Spinner，嚴禁突兀閃爍。
3. **Core Web Vitals 企業性能門檻**：
   - 最大內容繪製 (LCP) < 2.5s。
   - 互動到下一次繪製 (INP) < 200ms。
   - 累計版面位移 (CLS) < 0.1。
4. **重型元件動態加載 (`next/dynamic`)**：
   - 抽屜 (Drawers)、新增/編輯彈窗 (Modals)、圖表元件 (Charts) 強制使用 `next/dynamic` 進行 Code-Splitting，降低初始首屏 Bundle 體積。

### 6.7 零死按鈕禁令與互動防護 (Zero Dummy Buttons & Safe Action)
1. **嚴禁無事件空殼按鈕**：所有按鈕必須具備明確且可觸發之 `onClick` 處理常式，或顯式標註 `disabled={true}` 並提示說明 Tooltip。
2. **`<SafeActionButton>` 封裝**：按鈕元件必須內建防連點 (Debounce / Throttle)、非同步載入 Loading 狀態指示與錯誤回報。
3. **AST 靜態掃描門禁**：CI 強制執行 `scripts/audit-buttons.js`，以 Babel AST 掃描所有元件，檢測到既無點擊事件亦未禁用的死按鈕一律紅燈阻斷！

---

### 6.8 主檔業務原型同構對齊與自適應樣板架構 (Master Data Archetype Homomorphic Parity & Adaptive Primitives)
#### 6.8.1 背景與同構防漂移原則 (Principle of Homomorphic Consistency)
在垂直切片 (Vertical Slices) 平行開發下，多個功能切片容易產生「手刻版面導致的局部視覺漂移」。
傳統做法是針對個別元素（如分頁、彈窗、按鈕）撰寫瑣碎硬性規範，但容易陷入「打地鼠式治理」（遇到一種補一條，未遇到則繼續漂移）。
因此，本專案確立 **「同構原型橫向差異對齊原則 (Archetype Homomorphic Parity Principle)」**：
1. **業務原型功能分區不變性 (Functional Zone Invariance)**：
   屬於同一業務原型（如 `MasterDataMaintenance`）的模組，在結構上映射為標準的六大功能分區：
   - Zone 1: [頁面動作區] 新增、批次操作與通用動作。
   - Zone 2: [條件檢索區] 查詢表單與狀態篩選。
   - Zone 3: [表格工具列] 筆數統計、操作群組與 Excel 匯出。
   - Zone 4: [清單表格區] 欄位展示、狀態 Badge、檢視/編輯操作。
   - Zone 5: [分頁控制區] 雙側分頁、筆數切換、換頁操作與抗塌陷防護。
   - Zone 6: [詳情維護區] 詳情抽屜、編輯彈窗與二次確認對話框。
2. **兄弟模組橫向對齊協定 (Sibling Parity Protocol)**：
   - 同一原型家族內的所有兄弟模組（如國家、區域、幣別、評等機構），在對應的功能分區必須 100% 採用相同的共用原語元件。
   - 嚴格禁止「兄弟 A 已抽共用元件，兄弟 B 卻手刻私有 inline 代碼」之局部脫節行為。
3. **自適應 Token 契約取代硬編碼樣式 (Adaptive Design Tokens)**：
   - 抽屜寬度、彈窗尺寸、按鈕色系等樣式參數，必須綁定自適應 Design Tokens（如 `tokens.layout.drawerWidth`、`tokens.layout.modalWidth`、`tokens.color.primary`），嚴禁在業務程式碼中硬寫像素（如 `672px`, `768px`）或色值（如 `#374151`），確保全域自適應響應與主題切換能力。

#### 6.8.2 MasterDataMaintenance 原型原語映射矩陣
| 功能分區 (Zone) | 標準原語組件 (Standard Primitive) | 職責與自適應能力 |
|:---|:---|:---|
| **Zone 1: Header** | `<MasterDataHeaderActions>` | 統一動作排版、Lucide 圖示與純文字語系，自適應支援額外操作槽 (slot) |
| **Zone 3: Toolbar** | `<MasterDataTableToolbar>` | 統一「查詢結果筆數」與「Excel 匯出」排版、自適應防連點與 Spinner 動畫 |
| **Zone 5: Pagination** | `<MasterDataPagination>` | 統一雙側排版、每頁筆數切換、頁碼切換；自適應單頁與 0 筆防塌陷保護 |
| **Zone 6: Drawer** | `<MasterDataDetailDrawer>` | 現代底線指示頁籤（基本資料 / 異動紀錄）、雙模態閱覽畫布、安全刪除防呆 |
| **Zone 6: Modal** | `<MasterDataFormModal>` | 自適應對話框尺寸、取消 / 儲存並繼續新增 / 存檔三鍵標準佈局 |
| **Zone 6: Confirm** | `<MasterDataDeleteConfirmModal>` | 獨立二次確認對話框，具備防呆代碼名稱顯示與刪除中防連點 |

#### 6.8.3 主檔分頁元件強制契約與零手刻防漂移規範 (MasterDataPagination & Anti-Drift Contract)
1. **型別強制約束 (Required Props)**：
   - `MasterDataPaginationProps` 中的 `pageSize` 與 `onPageSizeChange` 為強制必填（Required），禁止宣告為 optional。
   - 父層頁面（`page.tsx`）必須妥善管理 `pageSize` 狀態並傳遞給表格，嚴禁寫死分頁筆數。
2. **雙側版面佈局標準**：
   - **左側筆數統計**：統一渲染「查詢結果：共 {totalElements} 筆」，對齊 Mock UI，並支援 i18n 多語系。
   - **右側分頁操作**：由左至右依序為「每頁筆 [ 10 / 20 / 50 v ]」選單與「‹ {currentPage + 1} / {totalPages} ›」翻頁按鈕。
   - **抗塌陷保護**：在 0 筆或單頁時，左右結構保持完整，按鈕以 disabled 呈現，嚴禁隱藏換頁區塊或造成版面置中位移。
3. **編譯層與門禁阻擋**：
   - 前端強制開啟 `tsconfig.json` 之 `noUnusedLocals: true`，杜絕「有 import 卻未在 JSX 中置換」之假性重構。
   - 專案門禁 `audit-master-data-standards.js` 自動化掃描所有主檔表格，凡發現未調用 `<MasterDataPagination>` 或殘留舊版手刻分頁者，一律判定為架構漂移並阻斷合併。

### 6.9 業務原型自動認領與三振重構演化標準 (Archetype Claiming & Rule-of-Three Standard)
1. **業務原型自動認領 (Archetype Claiming)**：
   - 所有進入研發的新功能必須在 Step 0 進行特徵比對。
   - 若具備「主檔維護 (MasterDataMaintenance)」特徵，任務規劃必須直接認領原型，強制繼承原型元件，禁止自建空白 Layout 與自製元件。
2. **三振重構法則 (Rule of Three)**：
   - 第 1 次出現：切片內探索。
   - 第 2 次出現：標記為共用候選。
   - 第 3 次出現：**硬性阻擋 (Hard Block)**，強制提煉共用模組並重構既有切片。

### 6.10 前端 AST 代碼克隆與重複度阻擋標準 (Frontend AST Clone Detection Gate)
1. **靜態克隆分析**：CI 流水線對所有新增/修改之 React 元件進行語法樹 (AST) 相似度掃描。
2. **阻擋門檻**：跨切片元件結構與 Token 相似度超過 70% 且未抽成共用模組者，一律判定為「架構腐化」，阻擋合併並要求重構。

### 6.11 現代企業級 UI 與人機介面互動 (HCI) 第一性原則 (Modern Enterprise UI & HCI Principles)
為杜絕二十年前 Windows 資料夾頁籤、收據折線與唯讀 disabled 輸入框等老骨董反模式，前端元件開發必須深度立足於**跨學科人因、認知心理學、社會心理學、行為經濟學與現代貿易理論**：
0. **跨學科行為科學與經濟學底座 (Behavioral & Economic Foundations)**:
   - **反脆弱演進與槓鈴策略 (Antifragility, Barbell Strategy & Anti-Iatrogenics - Taleb)**：錯誤與波動是架構進化的養分。拒絕局部打地鼠修補，任何架構震盪必須昇華為 SDK 全域原語與永久免疫探針。基底追求不可篡改之保守絕對性（雙時態審計、強約束引用防禦），呈現層追求極致解耦與柔性微動態；嚴禁過度治療式的瑣碎補丁。
   - **隱性誘因與破除常識偏見 (Freakonomics, Goodhart's Law & Cobra Effect - Levitt)**：以 AST 深度檢查徹底消滅空殼假按鈕；打破「唯讀畫面就得用 disabled input 灰底」與「資訊分區得用破折虛線」的陳腐常識，回歸高對比結構化閱覽畫布。
   - **跨國貿易交易成本、資訊透明與共有地防禦 (Trade Economics - Coase, Akerlof & Ostrom)**：以高對比制裁標籤消滅檸檬市場資訊不對稱；以即時試算與減法設計將使用者檢索與決策摩擦成本在介面內原地歸零；公共主檔實施引用防護硬約束（引用數 > 0 物理禁刪），杜絕誤刪公共資源破壞千萬合約。
   - **知覺完形、空間恆常性與雙系統思維 (Gestalt, Spatial Permanence & Kahneman)**：以微色調卡片取代虛線；以 <SmoothDataTableContainer minHeightPx={420}> 達成空間物理恆常性與零累計版面位移 (Zero-CLS)；檢視模態為系統 1 提供 200ms 清晰閱覽，編輯模態為系統 2 提供無干擾高聚焦輸入。
   - **推力與阻尼管理 (Nudge & Friction - Thaler)**：序號自推算 (Max + 10) 為智慧預設值；清除 disabled 灰框等無效「污泥」，保留高風險變更強制輸入 5 字原因之「建設性阻尼」。
   - **決策偏誤防禦 (Cognitive Bias Guards - Kahneman & Tversky)**：未儲存髒檢查 (Dirty State Guard) 防禦沉沒成本誤觸損失；< 100ms 微動態滿足即時掌控；二次確認彈窗精確框架損失邊界。
   - **社會心理學與組織協同動力學 (Social Psychology - Hawthorne Effect & Psychological Safety)**：處處可見雙時態不可篡改審計與操作者標記，以透明觀察降低疏失率；提供優雅容錯與非懲罰性 UI 反饋，嚴禁指責性報錯；明確操作者責任以防範社會惰化。
   - **認知負荷與工作記憶分塊 (Cognitive Load Theory - Sweller / Miller's Law 7±2)**：徹底掃除雜訊以最小化外在認知負荷；將複雜欄位資訊分塊 (Chunking) 為 3~4 個高內聚微色調容器；主動吸收繁複運算，最大化相關認知負荷以支援核心再保決策。

1. **雙模態人因學 (Dual-Mode Ergonomics: Inspection vs. Manipulation)**:
   - **檢視模態 (Inspection Canvas)**：高對比純文字 Typography 呈現鍵值對，嚴格禁止 `<input disabled>` 與 `cursor-not-allowed` 禁用游標，嚴禁標註必填紅星號 (`*`)。代碼旁支援一鍵複製微按鈕與向量鎖頭提示 (`lucide-react: Lock`)。
   - **編輯模態 (Manipulation Canvas)**：互動輸入框具備柔和焦點光暈 (`focus:ring-2 focus:ring-orange-500/20`)，游標自動聚焦第一欄位，支援未儲存髒檢查防誤觸 (Dirty State Guard)。
2. **減法美學與現代材質層級 (Subtraction Aesthetics & Tonal Surfaces)**:
   - **淘汰 Windows 資料夾頁籤**：全面升級為現代底線導航頁籤 (`MenuHeaderTabs`)，配備平滑品牌橘底線指示條；或懸浮膠囊分段控制器 (Segmented Control)。
   - **淘汰收據式破折虛線 (`border-dashed`)**：資訊分區以空間留白節奏或微色調卡片 (`bg-slate-50/70 rounded-xl p-4 border border-slate-100`) 收納。
   - **色彩與按鈕階調**：淘汰死黑方塊按鈕 (`#374151`)，統一採用現代企業 Slate 色階搭配細緻微陰影 (`shadow-xs` / `shadow-sm`)。
3. **空間物理恆常性與零累計版面位移 (Spatial Permanence & Zero-CLS)**:
   - 表格主容器強制整合 `<SmoothDataTableContainer minHeightPx={420}>`，確保無論筆數多寡，分頁控制列位置絕對靜止。
   - 資料載入與過濾採用 200ms 透明度淡入交接 (Cross-fade)，骨架屏與真實列保持 1:1 幾何等高，嚴禁閃爍出 1 幀 Loading。
4. **古典人因定律與無障礙互動 (Classical HCI Laws & Accessibility)**:
   - **費茨法則**：點擊熱區桌面端 >= 36px，行動端 >= 44px。破壞動作（刪除）與安全動作保持物理空間隔離。
   - **席克法則**：高頻欄位優先呈現，進階條件平滑展開；序號自動推算 (`Max + 10`)，降低決策耗時。
   - **雅各布法則**：遵循通用心智習慣（Esc 關閉、Enter 檢索、Tab 焦點流動、標準語意色彩）。
   - **焦點捕捉 (Focus Trap)**：抽屜開啟時焦點鎖定於抽屜內部，關閉後焦點精準復原至觸發按鈕。
5. **兄弟親和同構律 (Sibling Homomorphism)**:
   - 國家、區域、結算幣別三個模組在抽屜寬度 (`max-w-2xl`)、Header 徽章結構、4 按鈕階調、鎖頭意符、引用防護卡、系統資訊微卡片上保持 100% 同構一致。

### 6.12 通用操作閉環與虛假可供性杜絕標準 (Operational Closure & Anti-False-Affordance Standard)

- **6.12.3 表格零閃動與 Stale-While-Revalidate 留存過渡 (Zero-Strobe Table Invariant)**：
  - 依據覆盤案 009，嚴禁在表格已有資料時將 `<tbody>` 內容拔除替換為旋轉菊花或單行加載狀態。
  - 查詢、篩選、分頁時必須採用 **Stale-While-Revalidate**：原有資料列原地保留，外層容器透過 `opacity-60` 柔和淡化並展示頂部極細 Shimmer 脈衝呼吸線，資料返抵時以 `250ms` 平滑交叉淡入（Cross-fade）。
  - 僅在首次掛載且 `data.length === 0` 時，允許渲染 1:1 仿真骨架屏（Skeleton Mesh），徹底杜絕高速網路微秒級反饋造成的白閃與畫面抽搐。

- **第一性原理與操作閉環硬約束 (Operational Closure Invariant)**：
  導覽頁籤 (`MenuHeaderTabs`)、側邊欄導航 (`Sidebar`)、按鈕、麵包屑或任何入口組件，凡使用者可點擊之元素，其狀態轉移**嚴格禁止導向未定義狀態或呈現 Next.js 預設 404 (This page could not be found) / 500 / 未捕獲異常白屏**。
- **虛假可供性杜絕與三態處置階梯**：
  未就緒之功能必須嚴格遵循「不露出 (Hidden) ➔ 顯式抑制 (Disabled with Tooltip) ➔ 規範化降級著陸 (Resilient Landing)」三態階梯。
- **標準降級卡片 (`ComingSoonPlaceholder`) 規範**：
  若功能作為全域導覽架構的一部分需漸進披露，未實作之頁面必須配置標準降級組件：
  1. 承襲 `<MenuCardFrame>`，維持頂部頁籤、排版與導覽脈絡。
  2. 呈現橘色 Sparkles 徽章、脈衝「模組規劃建置中」狀態膠囊與功能簡述。
  3. 清楚載明「排程任務編號」（如 `TASK-000013`）、「活體架構規範錨點」與「排程進度」。
  4. 右上角提供次要白底「返回安全基準頁面」按鈕，消除使用者迷航感。
- **靜態防漂移審計探針支援**：
  CI 腳本（`audit-master-data-standards.js`）具備自動豁免檢測，識別包含 `ComingSoonPlaceholder` 之頁面，免除分頁與查詢表單檢查，防禦虛假報警。

## 第七章：專案全生命週期流程標準 (End-to-End Enterprise SDLC Standard)

### 7.1 七階全生命週期工廠流水線 (The 7-Stage SDLC Pipeline)
> **人機放行安全閥核心鐵律 (Human-in-the-Loop Gate)**：在第七階「結案驗收與入庫 (Reconciliation & Promotion)」中，無論 Tier-1 或 Tier-2 任務，**Agent 嚴格禁止私自執行 `git merge dev` 或 `git merge main`**。Agent 之交付終點止步於 feature/task 分支之代碼提交、測試全綠與驗收報告呈現，必須經由人類架構師 / PO 審查確認授權後，方得執行合併。

專案從業務需求提出至生產上線，必須嚴格依照以下七大階段閉環演進：

```mermaid
graph TD
    S0["Stage 0: 需求接裝與規格定錨<br>(Living Specs + OpenAPI + Manifest)"] --> S1["Stage 1: 契約先行分支治理與 Mock 解耦<br>(Tri-Repo Branches + MSW Mock)"]
    S1 --> S2["Stage 2: 依賴自舉與前後端並行實作<br>(Step 0 Bootstrap + Tier-1 BOM)"]
    S2 --> S3["Stage 3: 本地真機聯調接軌<br>(The Handshake Moment + Seed Data)"]
    S3 --> S4["Stage 4: 四大客觀品質閘門與三庫串行晉級<br>(audit-specs + tsc + test + mvn)"]
    S4 --> S5["Stage 5: 容器化構建、部署與生產防線<br>(Docker + Health Probes + PO Gate)"]
    S5 --> S6["Stage 6: 全鏈路可觀測性與反思自閉環<br>(MDC + Sentry + Retrospective Engine)"]
```

1. **Stage 0：需求接裝與規格定錨 (Requirement Ingestion & Living Specs Grounding)**：
   - 檢索歷史踩坑記憶 (`RETROSPECTIVE.md`)，對齊 QoS 目標（預設 M 級 1,000 QPS）。
   - 產出雙軌規格：人類 6 大活體規格 (`SA`, `DBA`, `SD`, `UI`, `USE_CASE`, `QA`) 或 Tier-1 極簡 Delta 單。
   - 同步 `contracts/openapi.yaml` 並注入 `domain:<name>` 標籤。
   - 產出機器契約 `manifest-*.yaml`，顯式宣告 `authorized_dependencies`。
   - 門禁檢核：`python3 scripts/audit-specs.py` 100% Passed（強制執行 Gate 4 分支命名鐵律：後端 Manifest 強制 `feature/<TASK_ID>-API`、前端 Manifest 強制 `feature/<TASK_ID>-UI`、契約 Manifest 強制 `task/<TASK_ID>`，格式漂移一律阻斷）。
2. **Stage 1：契約先行分支治理與 Mock 解耦 (Contract-First Branching & Mock Decoupling)**：
   - Contracts 庫切出 `task/<TASK_ID>` PR 處於預審開放狀態。
   - 後端從 `dev` 切出 `feature/<TASK_ID>-API`；前端從 `dev` 切出 `feature/<TASK_ID>-UI`。
   - 前端啟動 MSW Mock Server (`NEXT_PUBLIC_ENABLE_MOCK=true`)，前後端零阻塞獨立平行開發。
3. **Stage 2：依賴自舉與前後端並行實作 (Step 0 Bootstrap & Parallel Implementation)**：
   - Runner 執行 **Step 0 Dependency Bootstrap**：檢核 Manifest 授權之 Tier-1 BOM 套件，自動注入 `pom.xml` 或執行 `npm install`。
   - 後端實作：Lombok, MapStruct, Flyway (`SET lock_timeout = '5s'`), JPA Auditing, JaVers, MessageSource 動態報表。
   - 前端實作：RSC 邊界, React Query, Zustand, React Hook Form + Zod, Sonner, Lucide, 傳輸層純機器錯誤碼。
4. **Stage 3：本地真機聯調接軌 (The Handshake Moment & Integration Verification)**：
   - 前端切換 `NEXT_PUBLIC_ENABLE_MOCK=false` 直連 `http://localhost:8080`。
   - 種子資料對齊：後端 `V999__dev_seed_data.sql` 與前端 Mock Fixtures 同源同值。
   - 執行真實 HTTP 請求連線走查與 Playwright E2E 驗收測試。
5. **Stage 4：四大客觀品質閘門與三庫串行晉級 (Quality Gates & Tri-Repo Promotion Pipeline)**：
   - 執行四大品質閘門（規格治理、OpenAPI 標籤、前端型別與 AST、後端單元測試）全數綠燈。
   - 遵循三庫串行合併鐵律：Contracts PR 預審就緒 ➔ 後端合入 `dev` ➔ 前端合入 `dev` ➔ Contracts 完成主規格回寫最終合入 `dev`。
6. **Stage 5：容器化構建、部署與生產防線 (Containerization, Deployment & Release Gate)**：
   - Docker Multi-stage 輕量化構建容器映像檔。
   - 容器健康探針檢查：後端 `/actuator/health`、前端 `/api/health`。
   - 生產線防護禁令：嚴禁 Agent 擅自合併生產線 `main`，Tier-2 任務必須由 PO / 人類架構師簽核授權。
7. **Stage 6：全鏈路可觀測性、審計溯源與反思自閉環 (Observability & Post-Mortem Feedback Loop)**：
   - MDC 上下文日誌追蹤 (`traceId`, `spanId`)，Sentry 異常遙測，Prometheus 指標採集。
   - 敏捷反思閉環：任何線上異常、測試失敗或 Code Review 糾正，自動記入 `RETROSPECTIVE.md` 並轉化為永久自動化測試與規範。

### 7.2 四大自動化品質驗收閘門 (The Four Automated Quality Gates)
所有任務提交與分支合併前，必須通過以下四大客觀自動化品質閘門：

| 閘門編號 | 檢核名稱 | 檢驗指令 | 通過標竿 |
|:---|:---|:---|:---|
| **閘門 1** | **規格治理、保鮮期限與依賴白名單稽核** | `python3 scripts/audit-specs.py` | 驗證 Meta-ADRs (001~003)、Universal Framework、Domain Standards 與 6 大活體規格全數合規，依賴授權符合 Tier-1 BOM 白名單 (0 Violations)。 |
| **閘門 2** | **OpenAPI 領域標籤稽核** | `python3 scripts/audit-specs.py` | `contracts/openapi.yaml` 所有端點嚴格標註 `domain:<name>` (0 Untagged)。 |
| **閘門 3** | **前端語系與 AST 死按鈕靜態門禁** | `npm test` | `validate-i18n.js` 0 缺失鍵值 + `audit-buttons.js` 0 死按鈕。 |
| **閘門 4** | **雙端靜態編譯與單元測試雙綠燈** | 後端 `mvn test`<br>前端 `npx tsc --noEmit` | 後端 100% 綠燈 (0 Failures, 0 Errors)；前端 TypeScript 0 型別錯誤。 |

### 7.3 常規提交、語意化版本與分支整合策略矩陣 (Conventional Commits & Branch Integration Matrix)
#### 分支整合策略決策模型 (Merge vs Rebase Invariant)
在人類授權合併至 `dev` 時，Agent 應依據分支拓撲與 Commit 品質自適應選擇最適整合模式：
1. **Rebase / Fast-Forward 模式**：適用於 Commit 粒度已高度精煉（如單一原子性 feat/fix commit）。直接 Fast-forward 推入主幹，維持百年 Git 歷史之極致線性與零分叉雜訊。
2. **Explicit Merge (`--no-ff`) 模式**：適用於跨模組大型同構演進或多階段子任務封閉膠囊，明確留下任務起訖之拓撲閉環審計點。
3. **Squash 模式**：適用於長週期 feature 分支，消除中途試錯之瑣碎 commit。
1. **常規提交規範 (Conventional Commits)**：所有 Git 提交訊息必須具備明確前綴與範圍：
   - `feat(domain)`: 新增業務功能
   - `fix(domain)`: 修復缺陷
   - `refactor(domain)`: 代碼重構（無功能變更）
   - `docs(specs)`: 規格與治理文檔修訂
   - `test(domain)`: 新增或修改測試
   - `chore(deps)`: 依賴套件升級或構建腳本變更
   - `perf(domain)`: 效能優化
2. **語意化版本 (SemVer - MAJOR.MINOR.PATCH)**：
   - MAJOR: 不相容之架構重構或破壞性 API 變更。
   - MINOR: 向下相容之新業務模組或特性發布。
   - PATCH: 向下相容之缺陷修復與安全修補。

### 7.4 運行時代碼向下相容與日落生命週期標準 (Runtime Backward-Compatibility & Progressive Sunset)
為解決線上生產環境「滾動發布節點流量交錯、用戶瀏覽器快取尚未更新、跨微服務/第三方調用延遲」等實際運行限制，本架構確立**二元解耦治理法則 (Dual-Prism Decoupling Architecture)**：
- **規格治理層 (Spec & Task-IR Layer) 零向下相容包袱**：Task ID 嚴格強制為純粹 6 位數 (`TASK-000009`)，Living Specs 與 RFCs 永遠代表單一真理（Single Source of Truth），嚴禁在治理規範與審計工具中維護歷史版本兼容分支。
- **運行時代碼層 (Runtime Code Layer: Backend, Frontend, DTO, DB) 強制向下相容平滑替代**：所有涉線上運行的程式碼、端點與參數，**必須提供向下相容機制**，嚴禁在代碼庫修改當場實體拔除仍在承載流量的舊資產。

#### 1. 運行時代碼平滑相容四項核心機制 (原生整合 Agent SDK RFC-011 原語)
向下相容絕不只停留在文檔口頭宣導，必須直接由 **Agent SDK 核心原語 (RFC-011: GracefulSunsetGuard)** 原生代碼化承載：
1. **API 雙軌路由外觀 (Dual-Route Mapping Facade)**：
   - 當 API 端點重命名或命名空間調整時（如 `/api/v1/currencies` 遷移至 `/api/v1/system/currencies`），後端控制器禁止直接刪除舊路由，必須宣告雙軌路由：
     ```java
     @GetMapping({"/api/v1/system/currencies", "/api/v1/currencies"})
     public ResponseEntity<ApiResponse<List<CurrencyResponse>>> listCurrencies(...)
     ```
   - 對透過舊路由抵達的請求，由 Interceptor / Filter 自動注入 RFC 8594 標準日落標頭：
     - `Deprecation: true`
     - `Sunset: <Wed, 11 Nov 2026 00:00:00 GMT>`（宣告最終移除日期）
   - 業務邏輯與回傳 DTO 維持完全一致，確保舊前端與快取請求 100% 正常運作。
2. **DTO 與參數寬容解析 (Tolerant Reader & Parameter Aliasing)**：
   - 當請求/回應欄位更名時（如 `currencyCode` 遷移至 `code`），DTO 禁止直接刪除舊欄位名稱。
   - 使用 `@JsonAlias({"currencyCode", "code"})` 或保留 Setter 多載委派至新屬性，確保舊客戶端送來的 JSON payload 依然能無損反序列化。
   - 內部公開服務方法重構時，舊方法標註 `@Deprecated` 並委派 (Delegate) 給新方法，避免跨模組動態鏈結噴出 `NoSuchMethodError`。
3. **前端呼叫端相容防護 (Resilient Frontend Adapters)**：
   - 前端 API 調用層對伺服器回應結構實施寬容防禦（如 `res.data?.code || res.data?.currencyCode`），防範滾動發布中 Pod 節點版本交錯導致的瞬時白屏。
4. **資料庫 Expand / Migrate / Contract 三相演化律**：
   - 資料庫 Schema 變更嚴格遵循 Expand-Contract 漸進演進：
     * **Phase 1 (Expand)**：新增新欄位/新表，保留舊欄位，後端雙寫或建立向前相容視圖。
     * **Phase 2 (Migrate)**：後端切換至讀取新欄位，背景執行非同步歷史資料回填。
     * **Phase 3 (Contract)**：確認舊資料庫讀寫已完全歸零，方可於下一個重大週期執行物理 DROP。

#### 2. 客觀指標驅動的安全實體拔除門禁 (Telemetry-Driven Zero-QPS Sunset Gate)
舊端點、舊欄位與過渡代碼何時才能實體拔除？
- **嚴禁依憑 AI 即時修改當場拔除**。
- **Zero-QPS 客觀門禁**：後端透過 Micrometer / Prometheus 監控標註 `@Deprecated` 之舊路由與舊參數。只有當線上生產監控客觀證明**該舊路由/舊參數在過去 14 天（或至少一個完整正式發布週期）之調用流量連續歸零 (`QPS == 0`)**，AI 軟體工廠方可開立 Contract 任務（例如 `TASK-XXXXXX_Contract_Deprecations`）安全實體刪除該代碼，徹底終結過渡期。

### 7.5 結案交付與主規格同步回寫閉環 (Definition of Done & Master Spec Reconciliation)
所有任務宣告完成與 Pull Request 合併時，必須滿足以下 DoD 閉環：
1. **客觀品質雙綠燈**：四大客觀品質閘門全數綠燈通過。
2. **主規格同步回寫 (Master Spec Reconciliation)**：若任務包含任何資料庫欄位、API 契約、UI 互動或業務規則變更，必須同步更新 `docs/specs/` 下對應之主規格書（`DBA_SPEC.md`、`SD_SPEC.md`、`UI_SPEC.md` 等），確保全局規格庫與線上代碼庫零漂移。

---

### 7.6 AI 輔助同構原型橫向差異自檢協定 (AI-Assisted Sibling Parity Review Gate)
在任務進入 Stage 4 (DoD 合併前驗收) 時，AI 代理人必須主動執行「同構原型橫向差異比對」：
1. **識別領域兄弟家族 (Identify Sibling Family)**：
   依據任務修改之模組，自動檢索同一原型目錄下的所有兄弟切片（如 `src/components/menus/*`）。
2. **提取分區組件矩陣 (Extract Zone-Component Matrix)**：
   分析各兄弟模組於各大功能分區 (Zone 1 ~ Zone 6) 之組件依賴與 JSX 結構。
3. **差量偵測與自癒修補 (Detect Disparity & Auto-Align)**：
   - 若偵測到任一兄弟切片未採用家族共用組件，AI 必須判定為「未完工 (Incomplete Refactoring)」並於提交前自動補齊換裝。
   - 嚴格禁止依賴人類使用者肉眼在 UI 上尋找「為何三個畫面長得不一樣」。

## 第八章：系統自適應分級與可演進芽裂架構 (Adaptive Scale & Evolvable Architecture)

### 8.1 S / M / L 系統自適應分級模型 (Scale Tiers)
系統依據業務規模自動對齊適配等級，避免過度設計或架構不足：
- **S 級 (MVP 探索期)**：單一資料庫、循序 Flyway 腳本、無快取直打 DB、全量本機測試 (< 20s)。
- **M 級 (企業主檔與中型系統 - 現行基準)**：時間戳 Flyway 腳本、雙軌規格體系、OpenAPI 契約隔離、全欄位審計留痕、承載 1,000 QPS (P95 < 100ms)。
- **L 級 (高併發與多領域分散期)**：讀寫分離、TIA 增量分流測試 (< 90s)、Redis 快取互斥鎖、Expand/Contract 雙相無感遷移、承載 10,000 QPS。

### 8.2 四大客觀感知升級閥值 (Sensory Triggers)
1. **測試耗時閥值**：全量測試 > 3 分鐘時，日常 CI 切換為 TIA 增量分流測試。
2. **規格大小閥值**：單一 `SD_SPEC.md` > 2,000 行時，拆分為 `docs/specs/modules/{module}/` 物理目錄。
3. **併發流量閥值**：模組 QPS > 1,000 時，掛載 Redis 二級快取與互斥鎖防護。
4. **代碼規模閥值**：單一 Feature 模組代碼 > 3,000 行時，評估觸發自然芽裂。

### 8.3 自然芽裂協議 (The Sprouting Protocol)
遵循 MonolithFirst 哲學，在初期保持聚合於單一倉庫或單一進程，但嚴格遵循五大抗耦合防線。當模組觸發芽裂閥值時：
1. 使用 Git Subtree 無損抽離歷史：
   ```bash
   git subtree split -P src/features/masterdata -b split-masterdata
   ```
2. 獨立為微服務或專屬倉庫 (Domain Pod)，100% 保留歷史 commit 與作者足跡，達成無痛漸進式演進。

---

### 8.4 現代 AI 軟體工程四階演進藍圖 (Four Levels of AI-Native Software Evolution)
本專案嚴格遵循跨專案通用框架之四階演化路徑：
1. **Level 1：單體探索期 (Monolith Prototype)**：單一混雜倉庫，以快速驗證業務為核心，AI 容易全域污染。
2. **Level 2：多庫聚合期 (Decoupled Repos ── 專案當前現況)**：
   - 前後端與契約庫分離（`reinsurance-contracts`、`reinsurance-web-portal`、`reinsurance-core-service`）。
   - 遵循 MonolithFirst，享受單體極速編譯與單一進程除錯紅利。
   - 強制植入五大抗耦合防線（領域標籤、軟性外鍵零跨領域 JOIN、Package-Private 封閉性、Feature-Sliced 目錄、引用防禦協議）。
3. **Level 3：垂直領域切片與自然芽裂期 (Vertical Domain Pods)**：
   - 單一業務領域規模超過 3,000 行時，執行 `git subtree split` 歷史無損抽離為獨立 Domain Pod。
   - 單一 Pod 內垂直聚合 UI、API、DB Migration 與 Specs，具備獨立微服務發版與自治能力。
4. **Level 4：AI 原生軟體工廠與全自主合成期 (AI-Native Software Factory)**：
   - 規格即系統 (Spec-as-System)。人類只專注於契約庫撰寫商業意圖與 Living Specs。
   - AI Agent 在隔離沙盒中達到 99%+ 代碼合成準確率，以可執行 BDD 全綠為唯一驗收標竿。

---

## 第九章：資安防護、可觀測性與高可用防禦 (Cybersecurity, Observability & Resilience)

### 9.1 資安防護基線 (OWASP Top 10)
1. **SQL Injection 防護**：所有資料庫操作強制使用 Spring Data JPA、ORM 或參數化查詢 (`PreparedStatement`)，**嚴禁字串拼接 SQL**。
2. **水平越權防護 (IDOR)**：查詢或修改資源時，必須校驗當前操作人或租戶是否有權限存取該資源 ID，嚴禁僅憑前端傳入的 ID 即放行。
3. **XSS 與 CSRF 防禦**：前端輸出自動跳脫 HTML；API 啟用 SameSite Cookie 與 CSRF Token 防禦。

### 9.2 可觀測性與健康檢查 (Observability & SRE)
1. **健康檢查端點**：後端暴露 `/actuator/health`（區分 liveness 與 readiness探針），監控資料庫連線池與相依服務狀態。
2. **度量指標導出**：暴露 `/actuator/prometheus`，採集 JVM GC、執行緒池、HTTP 請求延遲與錯誤率度量。

---

## 第十章：技術棧長青演進與依賴治理 (Evergreen Tech Stack & Dependency Governance)

### 10.1 執行環境 LTS 鎖定與平滑升級
1. **Java LTS 軌道**：以 **Java 21 LTS** 為基準。新 LTS 釋出滿 6 個月（生態圈相容成熟期）啟動相容性評估。
2. **Node.js LTS 軌道**：嚴格鎖定 **Active LTS**（Node 20 / 22），在舊版本 EOL 前 3 個月完成平滑切換。
3. **框架主版本**：Spring Boot 3.2+ 與 Next.js 14+ 持續跟隨官方安全修補版更新。

### 10.2 依賴套件治理規範與自動擴充協定 (Dependency Governance & Bootstrap Protocol)
1. **集中版本收斂 (BOM 原則)**：後端 `pom.xml` 嚴禁在 `<dependencies>` 的 `<dependency>` 內硬編碼 `<version>`。所有套件版本必須集中於 `spring-boot-starter-parent`、`<dependencyManagement>` 或 `<properties>` 宣告。
2. **確定性前端構建**：前端必須提交並嚴格鎖定 `package-lock.json`，CI 建置強制執行 `npm ci`。
3. **套件自動引入授權協定 (Dependency Authorization & Step 0 Bootstrap - 破除依賴悖論)**：
   - **問題意識**：AI Agent 恪守反幻覺與不破壞現狀原則，若無明確授權不敢主動加套件，導致倒退至手刻輪子。
   - **規格授權機制**：任務規劃者 (Task Planner) 在 `manifest-api.yaml` 與 `manifest-ui.yaml` 內透過 `authorized_dependencies` 顯式聲明授權之 Tier-1 Approved BOM 套件。
   - **執行端自舉開通 (Step 0 Bootstrap)**：Task Runner 啟動時先檢核該清單，若未安裝則自動寫入 `pom.xml` 或執行 `npm install`，並驗證通過後直接使用，**嚴禁手刻已有成熟方案之基礎建設**。
   - **白名單邊界防禦**：所有授權套件必須嚴格隸屬於 Meta-ADR 3 規範之「Tier-1 Approved BOM」清單，嚴禁引入未經架構審查之高風險套件。
4. **零墓碑代碼鐵律 (Zero Tombstone Mandate)**：墓碑代碼 (Tombstone Code) 係指在線上流量已客觀歸零 (`QPS == 0`) 且日落週期屆滿後，仍無意義殘留之死代碼。在線上替換過渡期內，運行時代碼必須嚴格維護相容外觀；一旦通過 Zero-QPS 門禁，AI 重構時方可當場實體拔除，杜絕永久遺留無人維護之歷史死代碼。

---

## 第十一章：架構自動升級、自主演化與防熵自閉環機制 (Autonomous Evolution & Self-Healing Architecture)

> **核心方針**：為徹底破除「人類提出、AI 才被動納入」的落後模式，本專案建立**架構自適應升級、自主演化與自癒引擎 (Self-Healing Architecture Engine)**。透過靜態架構探針 (Sensory Probes)、踩坑程式化自閉環 (Rules-as-Tests)、企業技術雷達 (Tech Radar) 與季度適性函數 (Fitness Functions)，確保架構規範與程式碼具備自驅前進與自我保鮮之能力。

### 11.0 軟體工廠六維封閉正交基底公理 (Six-Dimensional Closed Orthogonal Substrate Axiom - 終結打地鼠模式)

> **終結打地鼠的核心哲學**：  
> 傳統軟體工程與劣質 AI 代理人最大的通病是**「打地鼠模式 (Whack-a-Mole Pattern)」**：踩到一個坑，就加一條規則；使用者問一句，就補一個探針。這種「枚舉式補丁」永遠有未知的盲點，只要人類沒有注意到，系統就會在生產環境崩潰。  
> **軟體工廠的根本變革**：我們拒絕枚舉錯誤，確立**「第一性原理之六維封閉正交基底 (Closed Orthogonal Basis)」**。在計算機科學中，任何 enterprise-grade 的運行時切片，其物理存在皆可且必須投影至六大互不重疊的生命週期平面：

```text
┌────────────────────────────────────────────────────────────────────────┐
│             企業級軟體六維封閉正交生命週期平面 (The 6 Orthogonal Planes)│
├────────────────────────────────┬───────────────────────────────────────┤
│ 維度 1：契約編譯 (Contract & Ingress)  │ OpenAPI, Task-IR v1.0, 氣密依賴 (RFC-001, RFC-010)     │
│ 維度 2：狀態併發 (State & Concurrency) │ 樂觀鎖 @Version, 狀態機矩陣, 衝突防禦 (RFC-004, RFC-007)│
│ 維度 3：時間留痕 (Time & Immutability) │ 雙時態帳本, 變更審計留痕, 禁原位覆寫 (RFC-005, RFC-008)│
│ 維度 4：呈現隔離 (Presentation & UX)   │ 表現層文字外部化, 動態匯出, 虛擬滾動 (RFC-002, RFC-003)│
│ 維度 5：平滑演進 (Evolution Continuity)│ 雙軌路由外觀, 寬容解析, 參數別名 (RFC-011)             │
│ 維度 6：客觀日落 (Telemetry & Sunset)  │ QPS 遙測監控, RFC 8594 標頭, Zero-QPS 門禁 (RFC-011)  │
└────────────────────────────────┴───────────────────────────────────────┘
```

#### 正交完備律 (The Orthogonal Completeness Invariant)
1. **編譯期先驗完備**：任何由 Intent Compiler (Task Planner) 生成的任務字節碼 (`task.ir.yaml`)，**必須具備在上述六大平面上的非空投影**。
2. **拒絕人眼抽查**：若任一切片缺失維度 5（平滑演進策略）或維度 6（日落遙測），編譯器直接視為「字節碼先天殘缺 (Incomplete Bytecode)」，拒絕進入執行階段。
3. **終結人講才做**：下線或重構一個端點，不需要人類使用者提醒「為什麼沒向下相容」。因為字節碼架構中，維度 5 與維度 6 是強型別約束，不聲明相容策略代碼根本無法產出！

---

### 11.1 靜態架構探針與自動感知閥值 (Sensory Probes & Code Smell Detection - 破除被動納入)
建立靜態架構探針，於日常開發與 CI 流程中自動掃描程式碼異味，主動告警並建議/自舉引入成熟解法：

| 探針代碼 | 監測之程式碼異味 (Code Smell) | 自動感知閥值 (Trigger) | 自動自舉/防禦對策 (Auto Remediation) |
|:---|:---|:---|:---|
| **PROBE-01** | 手寫 DTO 轉換與繁瑣 getter/setter 複製 | 出現手寫 `toResponse()` 或手工欄位映射 | 觸發 `MapStruct` 引入，生成型別安全編譯期映射器 |
| **PROBE-02** | 表單狀態碎片化與手刻校驗 | 單一元件宣告超過 3 個 `useState` | 觸發 `react-hook-form` + `zod` 引入，改寫為宣告式表單 |
| **PROBE-03** | 行內手寫向量圖示 | 出現行內 `<svg>` 標籤 (> 3 行) | 觸發 `lucide-react` 替換，消滅行內 SVG 雜訊 |
| **PROBE-04** | 隨意行內樣式寫死 | 出現 `style={{ ... }}` 行內屬性 | 觸發 Design Token 違反警報，強制採用 CSS 變數 |
| **PROBE-05** | 原生彈窗或手刻 Toast 回呼 | 出現 `window.confirm()` 或手寫 toast 傳遞 | 觸發 `sonner` 全域提示與 Radix Dialog 封裝 |
| **PROBE-06** | 併發丟失更新風險 | JPA 可變核心實體缺少版本標記 | 觸發 `@Version private Long version;` 樂觀鎖補齊 |
| **PROBE-07** | 非呈現層自然語言寫死 | Service 或 API Client 出現非字典字串常值 | 觸發 i18n 隔離警報，強制改為 Canonical Key 或機器錯誤代碼 |
| **PROBE-08** | 同構模組兄弟切片實作漂移 (Sibling Parity Drift) | 同一原型家族模組在相同功能分區使用不同元件實作（如 A 模組使用共用樣板，B 模組使用手刻 JSX） | 觸發「橫向同構差異自檢 (Horizontal Parity Review)」，產出差量清單並自動對齊共用原語 |
| **PROBE-09** | 孤兒治理條款與基建缺口 (Orphan Governance Mandate) | `ENGINEERING_STANDARDS.md` 宣告了強制性運行時架構政策（如日落平滑替代、傳輸攔截、併發防禦），但 `agent-sdk/catalog.yaml` 缺失對應原語 ID | 觸發「規碼對偶警報 (Spec-to-Primitive Duality Alarm)」，自動開立 SDK 孵化任務，將條款固化為 RFC 規格與代碼原語，嚴禁僅停留於手冊文字 |
| **PROBE-10** | 跨學科第一性原則自主感知探針 (Multidisciplinary First-Principles Sentry) | 規劃、評審或重構時未主動檢視 9 大跨學科底座（反脆弱槓鈴策略、隱性誘因與眼鏡蛇防禦、檸檬市場與交易成本、共有地悲劇、完形人因、雙系統思維、推力阻尼、認知偏誤、社會心理學與認知負荷） | 自動阻斷「單純代碼級打地鼠思維」，強制在規格中輸出跨學科架構影響分析，並將高頻原則直接對偶提煉為 Agent SDK 原生原語 (RFC-012 ~ RFC-017)，杜絕等人類提示才被動納入 |\n
### 11.2 雙軌自主演化與踩坑程式化自閉環協定 (Dual-Loop Autonomous Evolution & Rules-as-Tests)
為破除「人類提出、AI 才被動納入」的根本病態，架構演化引擎確立**雙軌驅動模型 (Dual-Loop Model)**：

```mermaid
graph TD
    subgraph PrimaryLoop ["【主迴路】機器自主感知演化 (Autonomous Proactive Loop - 無需人類介入)"]
        SensoryScan["1. 靜態架構探針掃描<br>(PROBE-01 ~ PROBE-09)"] --> DualityCheck["2. 規碼對偶審計 (Duality Audit)<br>檢驗手冊規範是否 100% 鑄為 SDK 原語"]
        DualityCheck --> AutoIncubation["3. 自主提煉與擴充 SDK<br>(自動開立 RFC 與原語 PR)"]
        AutoIncubation --> ArchGate["4. ArchUnit 門禁實體執法<br>(代碼化封鎖架構漂移)"]
    end

    subgraph FallbackLoop ["【次迴路】人類糾偏之探針漏檢自省 (Remedial Fallback Loop)"]
        HumanPrompt["人類使用者指出架構盲點<br>(例如：為什麼向下相容沒寫入 SDK？)"] --> Diagnosis["定性為【PROBE 探針漏檢故障】<br>(嚴禁單純修補業務代碼)"]
        Diagnosis --> AddProbe["第 1 步：為該盲點建立新感知探針 (如 PROBE-09)"]
        AddProbe --> Log5Whys["第 2 步：登錄 RETROSPECTIVE.md (5 Whys 歸因)"]
        Log5Whys --> CodifySDK["第 3 步：固化為 SDK 原生原語與 ArchUnit"]
        CodifySDK --> UpdateRules["第 4 步：回寫標準手冊與 Agent Rules"]
    end

    ArchGate --> ContinuousSentry["常態防熵閉環"]
    UpdateRules --> PrimaryLoop
```

1. **第 1 步 (根因歸因)**：於 `docs/governance/RETROSPECTIVE.md` 建立回顧卡片，執行 5 Whys 深入分析根本原因。
2. **第 2 步 (程式化防線)**：撰寫客觀自動化檢驗腳本（如 Babel AST 掃描工具、ArchUnit 測試、Playwright 腳本），使該缺陷由「依賴人腦注意」轉化為「依賴代碼自動阻斷」。
3. **第 3 步 (規範回寫)**：同步更新 `ENGINEERING_STANDARDS.md`、ADR 與 `.agents/rules/task_execution.md`。
4. **第 4 步 (主動記憶繼承)**：後續所有 Agent 在開工時，由【主動記憶檢索協議 (Memory Recall Protocol)】強制調閱歷史教訓，實現系統智慧自我增長。


### 11.4 規碼對偶律與零孤兒治理鐵律 (Spec-to-Primitive Duality & Zero-Orphan Governance)
1. **規碼對偶核心公理 (The Duality Invariant)**：
   - 軟體手冊中的「文字規範」僅是給人類閱讀的投影，**機器只承認能夠編譯、攔截並執行的代碼原語**。
   - 凡在 `ENGINEERING_STANDARDS.md` 中宣告為「強制性、標準、生命週期、防禦」的非業務運行時政策（如日落雙軌相容、樂觀鎖防丟失、多語系字串隔離、審計留痕），**必須 100% 對偶映射為 `Agent SDK` 中的 RFC 規格書、模板與 CI 門禁**。
2. **零孤兒治理條款禁令 (Ban on Orphan Governance Mandates)**：
   - 嚴禁「只在 Markdown 手冊寫下一段原則，卻不提供 SDK 原生原語」的文檔自滿怠惰行為。
   - 任何條款若無對應的 `catalog.yaml` 原語與代碼實作，CI Gate 5 視為「孤兒未完工規格 (Orphan Specification Violation)」直接紅色阻斷！

---

### 11.3 嚴格測試驅動開發 (Strict TDD: Red-Green-Refactor) 協定與執行留痕鐵律

為徹底根除「先寫業務程式碼、最後才補測試驗收 (Test-Last Verification)」之反向慣性，全專案確立**嚴格測試驅動開發 (Strict TDD)** 鐵律：

```text
┌────────────────────────────────────────────────────────────────────────┐
│                      Strict TDD 开发闭环 (Red-Green-Refactor)           │
│                                                                        │
│   1. RED (紅燈先行)         2. GREEN (最小實現)      3. REFACTOR (架構重構)│
│  ┌──────────────────┐      ┌──────────────────┐    ┌─────────────────┐ │
│  │ 撰寫單元/整合測試 │ ───> │ 撰寫最小生產程式碼 │ ─> │ 消除重複/優化設計 │ │
│  │ 執行確認紅燈失敗 │      │ 執行見證翻轉綠燈 │    │ 保持全量測試綠燈 │ │
│  └──────────────────┘      └──────────────────┘    └─────────────────┘ │
└────────────────────────────────────────────────────────────────────────┘
```

1. **第 1 步 (RED - 紅燈先導)**：
   - 凡新增任何業務邏輯、領域行為、計算規則、JPA 實體特徵或共用元件，**嚴格禁止直接建立生產程式碼**。
   - 必須先建立對應之測試案例（如後端 JUnit 5 測試、前端行為斷言），執行該測試並**確認其處於失敗 (Red) 狀態**（組件不存在、編譯未過或斷言不符），並於執行日誌留痕。
2. **第 2 步 (GREEN - 最小實作)**：
   - 撰寫剛好足以讓該測試通過的最小生產程式碼。
   - 執行測試，**見證測試從紅燈翻轉為綠燈 (Green)**。
3. **第 3 步 (REFACTOR - 綠燈重構)**：
   - 在綠燈防護傘下，重構消除重複代碼、提升可讀性、套用 Clean Architecture / DDD 模式。
   - 執行全量迴歸測試，確認系統維持 100% 綠燈。
4. **禁令宣告**：
   - 嚴格禁止「實作已完成、最後僅為了應付 CI 而整批跑既有測試」之偽 TDD 行為。
   - 任何涉及「審計自動留痕」、「樂觀鎖防護」、「分頁防塌陷」等關鍵品質屬性，必須具備專屬之 TDD 測試案例覆蓋。

### 11.4 企業技術雷達與常青依賴演進 (Technology Radar: Adopt / Trial / Assess / Hold)
專案建立常青技術雷達，規範技術引入與淘汰的完整生命週期：

```text
    ┌──────────────────────────────────────────────┐
    │  HOLD (嚴格禁止 / 棄用)                       │
    │  - hibernate.ddl-auto=update                 │
│  - 測試後置補票 (Test-Last Verification)      │
    │  - 手寫 inline SVG                           │
    │  - 手刻 10 個 useState 表單                  │
    │  - 手寫 DTO 欄位拷貝                         │
    │  - 非呈現層寫死自然語言字串                  │
    ├──────────────────────────────────────────────┤
    │  ASSESS (技術評估 / 前瞻雷達)                 │
    │  - React 19 Server Actions 深度應用          │
    │  - Vite 6 構建演進                           │
    ├──────────────────────────────────────────────┤
    │  TRIAL (試點驗證 / 輕量導入)                  │
    │  - @tanstack/react-virtual 虛擬滾動          │
    ├──────────────────────────────────────────────┤
    │  ADOPT (強制企業級標準 - Tier-1 BOM)          │
    │  後端: Lombok, MapStruct, EasyExcel, JaVers, │
    │        Flyway/Liquibase, springdoc, ArchUnit │
    │  前端: Next.js 15 App Router, React Query,   │
    │        Zustand, React Hook Form + Zod,       │
    │        Sonner, Lucide-React, Radix UI        │
    └──────────────────────────────────────────────┘
```

### 11.5 季度定期檢視節奏 (Quarterly Architecture & Governance Spike - 90 天固定週期)
1. **季度評審窗口 (Review Cadence)**：以每季（固定 90 天）為週期，由架構師與研發團隊召開「架構保鮮與條款檢核 Spike」。
2. **審查範圍**：
   - **核心架構決策**：Meta-ADRs (ADR-001 ~ 003) 是否依然契合業務演進目標。
   - **工程實作基準**：`docs/ENGINEERING_STANDARDS.md` 內之技術棧是否符合 Active LTS。
   - **Agent 規範與技能**：`.agents/rules/task_execution.md`、`.agents/skills/` 提示詞是否需要依據大模型最新推理能力調整精簡。
3. **產出物與紀錄**：更新各規範之 `last_reviewed` 與 `next_review_due`，並將評審結論登記於 `docs/governance/RETROSPECTIVE.md`。

### 11.6 事件驅動即時檢視機制 (Event-Driven Trigger Protocol)
除固定季度週期外，凡發生以下重大客觀事件時，強制觸發即時檢視：
1. **主流框架與 LTS 躍遷**：Java 新版 LTS 釋出滿 6 個月，或 Spring Boot / Next.js 迎來 Major Version Bump。
2. **AI Agent / LLM 底層能力代際升級**：採用新一代模型或 Agent 架構時，強制評估既有 Prompts / Skills 是否存在過時的防呆 Workaround 並適時精簡。
3. **自然芽裂觸發 (Sprouting Threshold)**：單一業務模組代碼量突破 3,000 行，啟動獨立 Domain Pod 切割與契約抽離。

### 11.7 CI 門禁自動化適性檢驗 (Automated Freshness Fitness Function)
1. **門禁化檢驗**：將條款保鮮狀態納入 CI 自動化品質閘門：
   ```bash
   python3 scripts/audit-specs.py
   ```
2. **過期預警與阻斷**：
   - 若檢測到任何核心文件、Rules 或 Skills 超過 90 天未更新 `last_reviewed`（即 `next_review_due < today`），自動於 Gate 1 發出過期警報，阻斷發布流程並促使團隊排定架構保鮮任務。

### 4.7 通用意圖閉環與防幽靈依賴準則 (Universal Intent-Realization & Anti-Phantom Mandate)
1. **宣告與實作雙向對齊**：
   - 嚴格禁止「只在 pom.xml / package.json 宣告依賴，而業務模組 0 調用」之形式主義。
   - 任何引入之套件（無論為 MapStruct, Lombok, EasyExcel, Actuator, SpringDoc 或其他新函式庫），必須在受影響領域完成真實調用與測試鏈打通。
2. **樣板代碼徹底收斂**：
   - 引入工具旨在消除特定樣板代碼時，必須實施舊代碼之實質拔除（Net Code Deletion），禁止舊手寫方法與新工具並存。
3. **架構測試防線 (ArchUnit / AST Fitness Functions)**：
   - 將架構設計規則（如分層隔離、Entity 規範、DTO 轉換標準）編寫為自動化測試，使架構防護與代碼庫一同演進。


### 11.8 演化與修復第一法則——修復原型原語，而非手冊追加規則 (Patch the Archetype, NOT the Rulebook)
1. **破除規則手冊膨脹與打地鼠循環**：
   - 當發現全域性品質缺陷（例如報表表頭在地化遺漏、併發衝突缺少刷新提示、按鈕防連點失效）時，**嚴禁在規範手冊中不斷追加微觀列舉條款**。
2. **直擊原型核心 (Patch the Archetype)**：
   - 架構師與 AI 的唯一修復職責，是**直接升級 `Agent SDK` 內部對應的原型原語**（例如在 `GenericExcelExportEngine` 內部將 `MessageSource` 設為強制注入，或在 `<MasterDataGrid>` 內部封裝骨架屏）。
   - 原型原語一旦修復並通過測試，所有引用該 `Agent SDK` 的業務模組在下次構建時自動獲得免疫力。
   - **規範手冊永遠維持精簡、純粹與高階，杜絕條文無限膨脹**。


### 11.9 多年期架構保鮮與常青適性守門人 (Longitudinal Architecture Sentry & Evergreen Oracles)
1. **完整領域與人機互動原型族系強制映射 (Enterprise Archetype Taxonomy - RFC-001 ~ RFC-017)**：
   - 業務模組開發禁止隨意發明架構模式，必須強制對齊 `Agent SDK` 之完整 12 大核心領域、人因互動與持久化原型：
     * **主檔資料維護 (`MasterDataArchetype` - RFC-002)**：6 區佈局、動態多語系匯出 (RFC-003)、樂觀鎖衝突防禦 (RFC-004)。
     * **工作流狀態機 (`WorkflowStateMachineArchetype` - RFC-007)**：不可變狀態轉移矩陣、RBAC 權限、交易內審計。
     * **複式財務帳務 (`FinancialLedgerArchetype` - RFC-008)**：零浮點數 (BigDecimal)、銀行家捨入、借貸絕對平衡。
     * **巨量批次處理 (`BatchIngestionArchetype` - RFC-009)**：分塊事務隔離 (Chunk-Based)、單行錯誤隔離、冪等 JobKey。
     * **常青適性守門人 (`ArchitectureFitnessSentry` - RFC-010)**：編譯期 ArchUnit 物理門禁、AST 死按鈕防禦、源碼 ASCII 純淨度。
     * **平滑演進日落防衛 (`GracefulSunsetGuard` - RFC-011)**：雙軌相容路由別名、RFC 8594 日落標頭、Zero-QPS 遙測門禁。
     * **零位移平滑過渡 (`ZeroClsTransitionArchetype` - RFC-012)**：容器 min-h 保全、微抖動消解、非塌陷淡入淡出。
     * **雙模態檢驗畫布 (`DualModeInspectionCanvasArchetype` - RFC-013)**：雙系統思維分離、禁 disabled input、未儲存髒檢查阻尼。
     * **現代底線頁籤 (`ModernUnderlineTabsArchetype` - RFC-014)**：減法美學、除 Windows 檔案夾樣式、滑動品牌指示條。
     * **引用防禦阻尼 (`ReferenceDefenseDamperArchetype` - RFC-015)**：共有地悲劇治理、全域引用計數聚合、引用數 > 0 物理禁刪。
     * **即時試算預覽 (`RealtimeCalculationPreviewArchetype` - RFC-016)**：寇斯交易成本消除、特斯勒複雜度守恆、原位雙向試算範例。
     * **欄位級異動審計 (`FieldDiffAuditArchetype` - RFC-017)**：霍桑效應、雙時態真相溯源、反射式欄位差異留痕、必填 5 字理由。
2. **規碼對偶律 (Spec-to-Primitive Duality Law - 嚴禁孤兒規範)**：
   - 任何寫入 Living Specs 或工程標準之原則，嚴禁僅停留於文字宣導（禁止孤兒規範 Orphan Spec）。
   - 每一項強制性規範必須 1:1 對偶對應到 Agent SDK RFC 規格與物理樣板代碼，並由 AST / ArchUnit 門禁強制執法。
3. **常青適性守門人 (RFC-010: ArchUnit & AST Fitness Oracles)**：
   - 將「四大不變量」與「架構紀律」全量轉化為客觀代碼化測試（`ArchitectureFitnessTest`）。
   - CI/Maven 建構必須將 ArchUnit 設為強制門禁，凡出現：
     * 服務層/領域層包含硬編碼非 ASCII / 呈現層文字
     * 控制器跨層直呼其他控制器或跳過服務層直接存取資料庫
     * 實體遺漏 `@Version` 樂觀鎖防護
     * 財務金額使用 `float` 或 `double`
     編譯期直接拋出紅色阻斷，徹底打破「人員更迭、手冊遺忘、架構腐蝕」之歷史詛咒。
3. **語意化版本與平滑替代演進 (SemVer 2.0 & Progressive Runtime Migration)**：
   - Agent SDK 與核心業務嚴格遵循 SemVer 2.0。規格層維持零歷史包袱，運行時代碼遵循雙軌相容機制，直至線上指標客觀歸零後安全實體拔除。
4. **無方言中立性 (Dialect-Agnostic Substrate)**：
   - Agent SDK 嚴禁包含任何專屬業務領域名詞（如 Reinsurance）或專屬資料庫方言 SQL，確保開源通用性。


### 11.10 跨世紀工程守恆法則——可拋棄宿主、雙時態帳本與數學證明義務 (Centennial Invariant Conservation)
1. **可拋棄宿主隔離 (Disposable Host Isolation)**：
   - 所有業務切片嚴禁直接依賴第三方框架（Spring Boot, React）之專屬黑魔法或內部私有 API。
   - 所有具體語言實作皆視為可消耗、可替換之 Layer 2 投影。核心業務規格完全依賴 Layer 0 永恆代數與 Layer 1 Task-IR 字節碼，確保 20 年後可隨時無痛重新投影至新一代語言或運行時。
2. **雙時態不可變紀錄法規 (Bi-Temporal Immutability Mandate)**：
   - 金融、合約與理賠核心實體禁止原位覆寫（In-Place Mutation）。
   - 歷史狀態追溯必須具備雙時間坐標（業務生效日 Valid Time 與系統記錄日 Transaction Time），變更一律以版本追加或紅字沖銷記錄，確保 20 年後任意歷史時點之精準重現。
3. **證明義務與形式化求解 (Proof Obligations & Formal Verification)**：
   - 核心狀態機與借貸平衡邏輯必須具備形式化證明義務，CI 門禁逐步整合 SMT 求解器，將架構約束轉為數學定理求解，達成超越傳統測試案例的絕對正確性。
4. **自主負熵指標 (Net Code Deletion Ratio)**：
   - 工廠持續監控全系統 AST 相似度。當重複結構出現 3 次時，強制提煉回 Agent SDK，以「淨代碼消除率」為品質核心，系統越演進代碼越精簡。


### 11.11 百萬級任務標識與向下相容律 (Centennial 6-Digit Task ID & Canonical Normalization)
1. **6 位數百萬級任務容量**：
   - 全新建立之任務模組目錄，強制採用 6 位數固定寬度命名：`TASK-000001` ~ `TASK-999999`。
   - 子任務切片採用 3 位數固定寬度命名：`TASK-{06d}-{03d}_{Role}.md`。
   - 百萬級容量可保障百年以上持續演化，徹底杜絕 3 位數（999 限制）短期溢出之工程風險。
2. **純粹 6 位數嚴格規格（無須向下相容）**：
   - 任務模組 ID 嚴格強制為 6 位數 `TASK-[0-9]{6}`，子任務為 3 位數 `[0-9]{3}`。
   - 由於所有原本任務後續將全量依照新架構重新分析與拆分，因此規範完全杜絕 3 位數向下相容包袱，保持全系統規範之極致整潔與確定性。


### 11.12 任務時空膠囊與確定性歷史重放 (Temporal Task Capsule & Deterministic Replay)
1. **全任務歷程永久留痕**：
   - 歷史任務目錄（`tasks/`）嚴禁破壞性刪除，所有任務記錄視為不可篡改之「時空膠囊」。
2. **確定性重現保證 (Deterministic Replay Guarantee)**：
   - 每一筆任務必須具備完整自洽的 `task.ir.yaml`（機器字節碼）、`manifest.yaml`（氣密依賴）與 Living Specs。
   - 未來新世代之 AI 虛擬機只需以拓撲序執行字節碼重放，即可在任何全新宿主機器上分毫不差地 1:1 還原全系統任何歷史時間點的狀態與功能。


### 11.13 軟體工廠四級自我分析與演化節奏 (Quarterly, Annual, Triennial, Decennial Evolution Cadence)
1. **季度防熵 (Quarterly: 3 Months)**：自動審視 Living Specs 期限、升級依賴 BOM 安全補丁、執行 AST 死按鈕與 ArchUnit 門禁。
2. **年度負熵 (Annual: 1 Year)**：發起「三振自合成檢核 (Rule of Three)」，重複業務邏輯提煉至 `Agent SDK`，維持年度淨代碼消除指標 $> 1.0$。
3. **三年代際 (Triennial: 3 Years)**：評估底層可拋棄宿主（Spring Boot / React）生命力，升級 SDK 內部 Adapter 實現業務代碼零修改遷移；清理滿 12~36 個月之淘汰 API。
4. **十年重校 (Decennial: 10 Years)**：歷史任務轉冷儲存歸檔，執行雙時態歷史重現壓力測試，升級形式化數學證明義務。
### 11.12 全域文檔漣漪同步 SOP 與自適應經驗學習閉環 (Synchronous Ripple SOP & Experiential Learning Protocol)

1. **全域文檔漣漪同步 10 點檢核 SOP (The 10-Point Ripple Checklist)**：
   為徹底打破「AI 遺忘、局部產物定勢與跨文檔脫節」之歷史通病，凡新增或變更架構 RFC、領域原型或核心設計模式時，架構師與 AI 必須嚴格執行以下 10 點同步檢核：
   - **① 核心規格**：`agent-sdk/specs/RFC-xxx.yaml` 宣告契約與 Schema。
   - **② 物理樣板**：`agent-sdk/templates/` 實作宿主樣板代碼（`.spec`）。
   - **③ 符號總表**：`agent-sdk/catalog.yaml` 登錄能力條目與特徵清單。
   - **④ 頂層入口**：`agent-sdk/README.md` 完整同步 RFC 清單、12 大原型矩陣與物理目錄樹。
   - **⑤ 演進藍圖**：`agent-sdk/ROADMAP.md` 標註里程碑歸屬與生命週期。
   - **⑥ 代理人技能**：`.agents/skills/agent-sdk/SKILL.md` 刷新能力速查表。
   - **⑦ 活體規格對偶**：`docs/specs/*.md`（SA, DBA, SD, UI, USE_CASE, QA）雙向對偶綁定 RFC，嚴禁孤兒規範。
   - **⑧ 頂層治理同步**：`docs/adr/ADR-004`、`docs/ENGINEERING_STANDARDS.md` §11.9 與 `.agents/rules/task_execution.md` 擴展原型清單。
   - **⑨ 自動門禁校驗**：`scripts/audit-specs.py` Gate 5 執行跨文檔動態一致性斷言（缺失即 Exit 1）。
   - **⑩ 經驗覆盤歸檔**：`docs/governance/RETROSPECTIVE.md` 記錄演進脈絡，轉化為工廠長期資產。

2. **自適應經驗學習四步閉環 (The 4-Step Experiential Learning Loop)**：
   - **第一步：記錄覆盤 (Retrospective Recording)**：將人類使用者的糾偏與指導記錄於 `RETROSPECTIVE.md`，分析 5 Whys 根因。
   - **第二步：調整規範 (Specification Evolution)**：在規範手冊中將指導昇華為高階工程不變量與防呆 SOP。
   - **第三步：原型沉澱 (Archetype Codification)**：拒絕打地鼠，將解法提煉為 `Agent SDK` 之通用原語。
   - **第四步：門禁代碼化 (Automated Gate Enforcement)**：為該盲點建立自動化檢測探針（如 CI Gate 5 跨文檔一致性檢查），使機器永遠接管記憶與執法。


### 7.7 任務顆粒度自評與三階決策啟發式 (Task Granularity Assessment & Decision Heuristic)
當面對缺陷修復、佔位防禦或架構調整時，AI 代理人必須主動評估變更之「任務顆粒度 (Granularity)」：
1. **微粒度變更 (Micro-Granularity - 實用主義敏捷修復)**：
   - 範疇：防禦性佔位路由、非業務型樣式微調、文字錯字修正、型別宣告補齊等極小改動。
   - 授權作法：允許直接修改代碼，但**必須隨後立即回溯調整關聯既有 Task 之 manifest 與 specs**（如回溯 `TASK-000010`），確保未來時空重放能 100% 完整還原。
2. **中/大粒度變更 (Medium/Macro-Granularity - 嚴格規格先行)**：
   - 範疇：新增業務主檔、DB Schema 異動、跨切片 API 端點增修、核心狀態機演進。
   - 授權作法：強制先行開立全新 6 位數 Task（如 `TASK-000016`），備齊 `manifest.yaml`、`task.ir.yaml` 與完整規格子任務，呈報人類審批後方可動工。
3. **顆粒度邊界模糊時之雙安全閥 (Two Safety Fallbacks)**：
   - 若 AI 無法確信變更屬於微粒度或中粒度，**最安全之作法強制二選一**：
     * 途徑 A：開立全新獨立 Task 備查。
     * 途徑 B：主動調用互動提問介面 (`ask_question`) 向人類架構師請示執行決策，嚴格杜絕私自冒進。
