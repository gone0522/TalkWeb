<!--
governance_metadata:
  last_reviewed: "2026-10-13"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-13"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# TASK-008-01: 國家與區域全欄位審計資料庫遷移、Audit Log 實體服務與 Excel 匯出 API (後端解耦切片)

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **倉庫邊界**：後端獨立倉庫 `reinsurance-core-service`
- **分支規範 (Meta-ADR 2)**：自後端 `dev` 分支獨立切出 `feature/TASK-008-API`，獨立實作與提交。**驗收完成後嚴禁私自執行 git merge dev，統一提交 Pull Request 等待簽核**。
- **規格追溯依據**：
  - 架構決策：[Meta-ADR 1 (ADR-001)](../../docs/adr/ADR-001-spec-driven-ai-software-factory.md), [Meta-ADR 2 (ADR-002)](../../docs/adr/ADR-002-decoupled-multi-repo-and-evolvable-slices.md), [Meta-ADR 3 (ADR-003)](../../docs/adr/ADR-003-enterprise-quality-resilience-and-audit-baseline.md)
  - 機器契約：`tasks/TASK-008/manifest-api.yaml`
  - 資料庫規格：`tasks/TASK-008/specs/DBA_SPEC/Country_Region_Audit_DBA_SPEC.md`
  - API 契約：`tasks/TASK-008/specs/SD_SPEC/Country_Region_Audit_Export_SD_SPEC.md`
  - 品質與工程規範：[docs/ENGINEERING_STANDARDS.md](../../docs/ENGINEERING_STANDARDS.md) §3.1, §4.1, §7.2, §11 (季度架構保鮮)

### 1.1 API 依賴追溯表 (API Dependency Traceability Table - Meta-ADR 1 & Meta-ADR 2)
| 按鈕 / 觸發操作 | 呼叫端點 (Method & Path) | 領域標籤 | 交付模式 | 後端對應任務編號 | 依賴狀態 |
|:---|:---|:---|:---|:---|:---|
| 國家 Excel 匯出 | GET /api/v1/countries/export | domain:masterdata | Full-Delivery | 本任務 (TASK-008-01) | NEW IMPLEMENTATION |
| 國家異動紀錄清單 | GET /api/v1/countries/{id}/audit-logs | domain:masterdata | Full-Delivery | 本任務 (TASK-008-01) | NEW IMPLEMENTATION |
| 區域 Excel 匯出 | GET /api/v1/regions/export | domain:masterdata | Full-Delivery | 本任務 (TASK-008-01) | NEW IMPLEMENTATION |
| 區域異動紀錄清單 | GET /api/v1/regions/{id}/audit-logs | domain:masterdata | Full-Delivery | 本任務 (TASK-008-01) | NEW IMPLEMENTATION |

### 1.2 BDD 驗收條件 (Meta-ADR 1 & Meta-ADR 3)
- **場景 1 (Flyway V4 遷移腳本與結構安全 - Meta-ADR 3 §3.2)**：
  - 建立 `country_audit_logs` 與 `region_audit_logs` 資料表（含 id, target_id, field_name, before_value, after_value, change_reason, changed_by, changed_at）。
  - 所有查詢外鍵與時間欄位具備 B-Tree 索引覆蓋。
- **場景 2 (Service 層全欄位變更自動留痕 - Meta-ADR 3 §3.1)**：
  - `CountryService` 與 `RegionService` 於 `update()` 與 `updateStatus()` 時，比對各欄位差異並同交易寫入審計日誌。
  - 審計異動原因 `change_reason` 長度強制校驗 $\ge 5$ 字元。
- **場景 3 (Excel 匯出串流端點 - Meta-ADR 1)**：
  - 發出 `GET /api/v1/countries/export` 與 `GET /api/v1/regions/export`，回傳真實 `.xlsx` binary stream。
- **場景 4 (TDD 單元與整合測試 100% 綠燈)**：
  - 新增 `CountryAuditExportTest` 與 `RegionAuditExportTest`，100% 通過 `mvn test`。

## 2. 影響範圍與檔案清單 (Backend Scope)
- `src/main/resources/db/migration/V4__create_country_region_audit_tables.sql`
- `src/main/java/com/reinsurance/core/domain/CountryAuditLog.java`
- `src/main/java/com/reinsurance/core/domain/RegionAuditLog.java`
- `src/main/java/com/reinsurance/core/repository/CountryAuditLogRepository.java`
- `src/main/java/com/reinsurance/core/repository/RegionAuditLogRepository.java`
- `src/main/java/com/reinsurance/core/service/CountryService.java`
- `src/main/java/com/reinsurance/core/service/RegionService.java`
- `src/main/java/com/reinsurance/core/controller/CountryController.java`
- `src/main/java/com/reinsurance/core/controller/RegionController.java`
- `src/test/java/com/reinsurance/core/CountryAuditExportTest.java`
- `src/test/java/com/reinsurance/core/RegionAuditExportTest.java`

## 3. 品質閘門 (Acceptance Gates)
- 在後端獨立倉庫根目錄執行：`mvn test` (100% 通過，0 Failures, 0 Errors)。

## 4. 三庫串行合併發布順序 (Tri-Repo Promotion Pipeline - Meta-ADR 2 §3.2)
1. **Contracts PR 預審就緒**：`reinsurance-contracts` 的 `task/TASK-008` PR 通過規格與語法審核，保持 PR 開啟暫不合入 dev。
2. **後端合入 dev (本任務執行點)**：本後端代碼通過 `mvn test` 驗收後，提 PR 合併入 `reinsurance-core-service:dev`。
3. **前端真機聯調合入 dev**：等待前端切換 `MOCK=false` 直連後端通過 E2E 走查後，合併入 `reinsurance-web-portal:dev`。
4. **Contracts 主權庫結案合入 dev**：確認雙端代碼均已就緒，執行主規格語意錨點回寫，PR 最終合併入 `contracts:dev`。

## 5. 結案交付定義與主規格語意錨點回寫 (Definition of Done & Master Spec Reconciliation)
- **客觀品質雙綠燈**：`mvn test` 100% 綠燈（0 失敗、0 錯誤）。
- **主規格語意錨點回寫 (Mandatory DoD)**：
  * 將 `country_audit_logs` 與 `region_audit_logs` 實體模型以局部 Diff 寫回 `docs/specs/DBA_SPEC.md` 之 `<!-- SECTION: DATA_MODEL -->` 錨點。
  * 將審計日誌查詢端點與 Excel 匯出端點以局部 Diff 寫回 `docs/specs/SD_SPEC.md` 之 `<!-- SECTION: API_CONTRACT -->` 錨點。
  * 嚴禁全篇重寫 Markdown，杜絕規格漂移。
