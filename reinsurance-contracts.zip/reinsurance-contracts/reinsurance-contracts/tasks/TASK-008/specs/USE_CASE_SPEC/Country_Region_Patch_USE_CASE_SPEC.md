# 國家與區域補強使用案例規格書 (Country & Region Patch Use Case Specification)

> **模組代碼**：`TASK-008`  
> **畫面編號**：`SC-0101-01-01` (國家清單), `SC-0101-01-03` (國家抽屜), `SC-0101-01-04` (區域清單), `SC-0101-01-06` (區域抽屜)  
> **業務代碼**：`UC-CR-EXP-01`, `UC-CR-EXP-02`, `UC-CR-AUDIT-01`, `UC-CR-AUDIT-02`  
> **規範依據**：`docs/adr/ADR-001`, `ENGINEERING_STANDARDS.md` §15, §37  

---

## 案例導覽與矩陣 (Use Case Inventory)

| 案例代碼 | 使用案例名稱 | 主要參與者 | 流程類型 | 驗收核心重點 |
| :--- | :--- | :--- | :--- | :--- |
| **UC-CR-EXP-01** | 國家清單查詢結果 Excel 匯出 | 系統管理員 / 核保主管 | Happy Path | 繼承清單篩選條件，串流下載 `.xlsx`，含代碼、中英文名稱、所屬區域、制裁標記、狀態。 |
| **UC-CR-EXP-02** | 區域清單查詢結果 Excel 匯出 | 系統管理員 / 核保主管 | Happy Path | 繼承清單篩選條件，串流下載 `.xlsx`，含代碼、中英文名稱、排序、狀態。 |
| **UC-CR-AUDIT-01**| 檢視國家主檔全欄位異動歷程 | 法遵主管 / 稽核人員 | Happy Path | 側邊抽屜切換「異動紀錄」分頁，即時呈現時間、操作人、欄位名稱、變更前後值與異動原因。 |
| **UC-CR-AUDIT-02**| 檢視區域主檔全欄位異動歷程 | 法遵主管 / 稽核人員 | Happy Path | 側邊抽屜切換「異動紀錄」分頁，即時呈現時間、操作人、欄位名稱、變更前後值與異動原因。 |

---

## 詳細使用案例規格 (Detailed Specifications)

### UC-CR-EXP-01: 國家清單查詢結果 Excel 匯出 (Happy Path)
- **參與者**: 系統管理員、核保主管、外部稽核人員
- **前置條件**: 使用者登入系統並進入「國家選單」清單頁 (`/settings/menus/countries`)。
- **觸發條件**: 使用者點擊表格工具列右上角之 `[ 匯出 Excel ]` 按鈕。
- **主要成功流程**:
  1. 使用者於多維篩選表單輸入條件（例如：關鍵字「亞洲」、區域「ASIA」、狀態「ACTIVE」）。
  2. 使用者點擊 `[ 匯出 Excel ]` 按鈕。
  3. 前端按鈕進入 Loading 狀態並鎖定，防止連點。
  4. 前端以相同 Query String 呼叫 `GET /api/v1/countries/export`（或 `/api/v1/system/countries/export`）。
  5. 後端 `CountryService` 根據條件查詢，經由 Apache POI 生成 Excel 二進位串流，回傳 `Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`。
  6. 前端接收二進位 Blob，動態建立隱藏 `<a>` 標籤觸發瀏覽器下載，檔案命名為 `countries_export_{timestamp}.xlsx`。
  7. 匯出按鈕解除 Loading 狀態，Toast 提示「匯出成功」。
- **異常流程 (Exception Path)**:
  - 若後端查詢逾時或發生錯誤，按鈕恢復可用狀態，跳出紅色 Toast 警示「匯出失敗，請稍後重試」，嚴禁畫面卡死。

---

### UC-CR-AUDIT-01: 檢視國家主檔全欄位異動歷程 (Happy Path)
- **參與者**: 法遵主管、稽核人員
- **前置條件**: 國家主檔已存在，且有歷史修改或狀態變更紀錄。
- **觸發條件**: 使用者點擊國家清單中任一筆資料之「查看/編輯」按鈕，側邊抽屜展開並切換至「異動紀錄」標籤頁。
- **主要成功流程**:
  1. 使用者於抽屜上方 Tab 列點擊「異動紀錄」分頁。
  2. 前端向後端發出 `GET /api/v1/countries/{id}/audit-logs`（限制最近 20 筆，降冪排序）。
  3. 後端回傳審計陣列，欄位包含：`id`, `fieldName`, `beforeValue`, `afterValue`, `changeReason`, `department`, `changedBy`, `changedAt`。
  4. 前端渲染結構化異動表格：
     - 若欄位為狀態變更，前後值轉譯為語意化標籤（例如「有效 $ightarrow$ 作廢」）。
     - 變更原因若為系統自動記錄，顯示「基本資料維護更新」或具體輸入原因。
     - 時間精準格式化為 `YYYY-MM-DD HH:mm:ss`。
- **空值流程 (Zero State)**:
  - 若該國家為全新建立且尚無後續修改，表格展示優雅空狀態插畫與文字「尚無歷史異動紀錄」。
