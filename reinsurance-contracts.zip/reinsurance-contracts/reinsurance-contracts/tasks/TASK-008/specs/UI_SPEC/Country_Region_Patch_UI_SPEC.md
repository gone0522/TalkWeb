# 國家與區域補強介面與互動設計規格書 (Country & Region Patch UI Specification)

> **模組代碼**：`TASK-008`  
> **畫面編號**：`SC-0101-01-01` (清單工具列), `SC-0101-01-03` (抽屜分頁)  
> **規範依據**：`docs/adr/ADR-001` (Zero Dummy Button Ban), `DESIGN_CONVENTIONS.md` (Wireframe 3, 6)  

---

## 1. 介面視覺與互動規範 (UI/UX Spec)

### 1.1 清單工具列「匯出 Excel」按鈕規格
- **元件位置**：`CountryListTable.tsx` 與 `RegionListTable.tsx` 頂部工具列。
- **視覺規範**：
  - 白底灰框次級操作按鈕 (`border border-slate-300 bg-white text-slate-700 hover:bg-slate-50`)。
  - 圖示：掛載 Excel / 下載圖示 (`DownloadOutlined` 或 SVG)。
- **互動防呆**：
  - **點擊行為**：觸發真實 API 調用，按鈕內部替換為旋轉 Loading Spinner，文字變更為「匯出中...」，並加上 `disabled={isExporting}` 屬性防止使用者連點造成伺服器 OOM。
  - **完成行為**：下載完成後自動復原，彈出 Toast 訊息「檔案匯出成功」。

---

### 1.2 詳情側邊抽屜「異動紀錄 (Audit Logs)」頁籤規格
- **元件位置**：`CountryDetailDrawer.tsx` 與 `RegionDetailDrawer.tsx`。
- **分頁結構**：
  - Tab 1: 基本資料 (General Info)
  - Tab 2: 外部引用狀況 (Reference Summary)
  - **Tab 3: 異動紀錄 (Audit Trail) - [本任務交付重點]**
- **表格欄位定義**：
  | 欄位名稱 | 資料屬性 | 寬度權重 | 對齊方式 | 渲染格式 / 規則 |
  |:---|:---|:---|:---|:---|
  | 異動時間 | `changedAt` | 160px | 靠左 | `YYYY-MM-DD HH:mm:ss` (灰色字體) |
  | 操作人 | `changedBy` | 100px | 靠左 | 顯示帳號或「SYSTEM」，附人員圖示 |
  | 部門/單位 | `department` | 110px | 靠左 | 預設「合規風險部」 |
  | 變更欄位 | `fieldName` | 110px | 靠左 | 中文顯示（如「中文名稱」、「制裁標記」） |
  | 異動前值 | `beforeValue` | 120px | 靠左 | 刪除線或紅底淡色標記 |
  | 異動後值 | `afterValue` | 120px | 靠左 | 綠底淡色標記 |
  | 異動原因 | `changeReason` | 自適應 | 靠左 | 完整呈現異動說明 |

---

## 2. 死按鈕禁令合規檢核 (ADR-001 Audit)
- 靜態掃描工具 `scripts/audit-buttons.js` 必須 100% 通過。
- 嚴禁 `<button>` 缺少 `onClick` 或僅有 `alert()` / `console.log()` 等偽邏輯。

---

## 3. Tier-1 Approved BOM 與多語系呈現規範
1. **圖示與通知**：全面使用 `lucide-react` 圖示（嚴禁 inline SVG），全域通知使用 `sonner` (`toast.success()`, `toast.error()`)。
2. **表單狀態管理**：抽屜表單採用 `react-hook-form` + `zod`，嚴格防呆並消除多個 `useState`。
3. **審計多語系解析**：`fieldName` 與 `changeReason` 透過 `t('audit.fields.' + fieldName)` 與 `t('audit.reasons.' + changeReason)` 動態查表渲染。
4. **傳輸層零自然語言**：API Client 僅回傳機器代碼，錯誤提示統一由 UI 以 `t('errors.' + error.code)` 觸發 `toast.error()`。
