# 測試策略與驗收追溯規格書 (QA_SPEC) - TASK-008

## 1. 測試案例追溯矩陣 (RTM)
- `TC-PATCH-01`: 國家 Excel 匯出端點集成測試 (驗證 Content-Type 與二進位流)
- `TC-PATCH-02`: 國家審計日誌全欄位留痕測試 (驗證 update 名稱、狀態觸發留痕)
- `TC-PATCH-03`: 區域 Excel 匯出端點集成測試
- `TC-PATCH-04`: 區域審計日誌留痕測試
- `TC-PATCH-05`: 前端 AST 死按鈕靜態稽核驗證 (`audit-buttons.js` 0 Errors)
