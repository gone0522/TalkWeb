# 系統設計與詳細 API 契約規格書 (SD_SPEC) - TASK-008

## 1. RESTful 端點清單
1. `GET /api/v1/countries/export`
   - 功能：匯出國家清單為 Excel (.xlsx) 檔案
   - 回傳：`application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`
2. `GET /api/v1/countries/{id}/audit-logs`
   - 功能：查詢指定國家之全欄位審計紀錄
   - 回傳：`List<AuditLogResponse>`
3. `GET /api/v1/regions/export`
   - 功能：匯出區域清單為 Excel (.xlsx) 檔案
   - 回傳：`application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`
4. `GET /api/v1/regions/{id}/audit-logs`
   - 功能：查詢指定區域之全欄位審計紀錄
   - 回傳：`List<AuditLogResponse>`

## 2. 傳輸層、在地化與 Tier-1 BOM 實作規範
1. **傳輸層純機器代碼**：API 異常時僅傳回 RFC 7807 `errorCode` 與 HTTP 狀態，嚴禁於 API Client 構造自然語言錯誤句子。
2. **審計紀錄 Canonical Keys**：`AuditLogResponse` 中的 `fieldName` 與 `changeReason` 為 Canonical Keys，由前端 UI 透過 `t('audit.fields.' + fieldName)` 與 `t('audit.reasons.' + changeReason)` 渲染。
3. **Excel 動態多語系匯出**：後端匯出國家與區域清單時，表頭與列舉欄位必須透過 `MessageSource` 依據 `LocaleContextHolder.getLocale()` 動態解析，嚴禁寫死靜態字串陣列。
4. **Tier-1 Approved BOM**：後端採用 Lombok, MapStruct 與 EasyExcel；資料庫遷移強制宣告 `SET lock_timeout = '5s';` 且禁止 `hibernate.ddl-auto=update`。
