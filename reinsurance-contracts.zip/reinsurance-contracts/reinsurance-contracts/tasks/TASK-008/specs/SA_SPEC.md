# 系統分析與業務規格書 (SA_SPEC) - TASK-008 國家與區域治理升級切片

## 1. 業務背景與問題意識
TASK-006（國家與區域模組）上線後，經全域品質巡檢發現兩項重大業務落差：
1. **死按鈕問題**：清單上方之「匯出 Excel」按鈕未具備真實 API 串接，處於未完成狀態。
2. **審計留痕缺失**：國家與區域進行狀態作廢、代碼變更或名稱調整時，系統未依據 ADR-001 實施同交易全欄位審計留痕，無法滿足金融業合規監管要求。

## 2. 範圍定義 (Scope)
- **包含**：
  - 建立獨立審計日誌表 (`country_audit_logs`, `region_audit_logs`)。
  - 後端資料異動自動比對與留痕。
  - 國家與區域 Excel 檔案匯出端點實裝。
  - 前端抽屜異動紀錄真實資料串接與匯出按鈕端到端下載。

---

## 5. ADR-009 可演進式架構與邊界防線對齊 (Evolvable Architecture & Soft Boundaries Alignment)
依據 **ADR-009** 與 **ENGINEERING_STANDARDS.md 第八章 (§45 ~ §52)**，本任務全面落實五大抗耦合防線：
1. **全資產領域標籤鐵律 (Domain Tagging Protocol - §45)**：
   - 領域標籤：`domain: { name: "masterdata", subdomain: "country-region" }`。
   - OpenAPI 標籤：端點強制具備 `tags: ["domain:masterdata"]`。
2. **軟性外鍵與跨領域 SQL 零 JOIN (Soft FK & Zero Cross-Domain Joins - §46)**：
   - 跨領域引用僅儲存邏輯代碼，資料庫實體層嚴禁建立 `FOREIGN KEY` 約束。
   - Repository 嚴禁跨領域資料表 SQL JOIN，一律於應用層組合。
3. **引用防禦協議與軟刪除 (Referential Guard & Soft-Delete - §47)**：
   - 提供 `GET /api/v1/countries/{id}/references` 端點防禦，狀態異動前先算引用計數。
   - 嚴禁物理 `DELETE FROM`，一律使用邏輯停用 (`is_disabled = true`)。
4. **後端 Package-Private 封閉性 (Backend Boundary Encapsulation - §48)**：
   - 內部 Repository、Entity 與 Service 實作宣告為 Package-Private，杜絕跨領域直接存取。
5. **前端 Feature-Sliced 垂直內聚組織 (Feature-Sliced Directory - §49)**：
   - 元件與業務邏輯收斂於 `src/features/masterdata/country-region/`，對外唯一出口為 `index.ts`。
