# 資料庫架構與資料字典規格書 (DBA_SPEC) - TASK-008

## 1. 實體關係模型 (ERD)
- `countries` (1) ---> (N) `country_audit_logs`
- `regions` (1) ---> (N) `region_audit_logs`

## 2. 資料表結構 (DDL V4)
```sql
CREATE TABLE country_audit_logs (
    id BIGSERIAL PRIMARY KEY,
    country_id BIGINT NOT NULL,
    country_code VARCHAR(10) NOT NULL,
    field_name VARCHAR(100) NOT NULL,
    before_value TEXT,
    after_value TEXT,
    change_reason VARCHAR(500),
    department VARCHAR(100) DEFAULT '合規風險部',
    changed_by VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
    changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_country_audit_logs_cid ON country_audit_logs(country_id);

CREATE TABLE region_audit_logs (
    id BIGSERIAL PRIMARY KEY,
    region_id BIGINT NOT NULL,
    region_code VARCHAR(10) NOT NULL,
    field_name VARCHAR(100) NOT NULL,
    before_value TEXT,
    after_value TEXT,
    change_reason VARCHAR(500),
    department VARCHAR(100) DEFAULT '合規風險部',
    changed_by VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
    changed_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE INDEX idx_region_audit_logs_rid ON region_audit_logs(region_id);
```

### 3. Canonical Standard Keys 與多語系存儲鐵律
- `field_name`：一律存入規範欄位鍵 (Canonical Field Key)，如 `NAME_ZH`, `NAME_EN`, `REGION_ID`, `IS_SANCTIONED`, `IS_ACTIVE`, `DISPLAY_ORDER`。
- `change_reason`：一律存入規範原因鍵 (Canonical Reason Key)，如 `SYSTEM_DEFAULT_UPDATE`, `MANUAL_USER_MAINTENANCE`, `BATCH_IMPORT_UPDATE`。嚴格禁止在資料庫存入自然語言文字。
- 前端與報表呈現時，統一透過多語系字典動態解析為本地化文案。
