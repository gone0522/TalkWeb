<!--
governance_metadata:
  last_reviewed: "2026-10-13"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-13"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# TASK-008-02: 國家與區域 Excel 匯出端到端串接、詳情抽屜真實審計歷程表格與死按鈕消除 (前端解耦切片)

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **倉庫邊界**：前端獨立倉庫 `reinsurance-web-portal`
- **分支規範 (Meta-ADR 2)**：自前端 `dev` 分支獨立切出 `feature/TASK-008-UI`（**零依賴後端分支進度**，以 `contracts/openapi.yaml` 契約並行獨立開發）。**驗收完成後嚴禁私自執行 git merge dev，統一提交 Pull Request 等待簽核**。
- **規格追溯依據**：
  - 架構決策：[Meta-ADR 1 (ADR-001)](../../docs/adr/ADR-001-spec-driven-ai-software-factory.md), [Meta-ADR 2 (ADR-002)](../../docs/adr/ADR-002-decoupled-multi-repo-and-evolvable-slices.md), [Meta-ADR 3 (ADR-003)](../../docs/adr/ADR-003-enterprise-quality-resilience-and-audit-baseline.md)
  - 機器契約：`tasks/TASK-008/manifest-ui.yaml`
  - 介面規格：`tasks/TASK-008/specs/UI_SPEC/Country_Region_Patch_UI_SPEC.md`
  - 品質與工程規範：[docs/ENGINEERING_STANDARDS.md](../../docs/ENGINEERING_STANDARDS.md) §6.1, §6.2 (零死按鈕禁令), §6.3 (Vanilla CSS 企業炭黑 `#374151`，**未安裝 Ant Design / Tailwind CSS，嚴禁虛構依賴**), §7.2, §11

### 1.1 API 依賴追溯表 (API Dependency Traceability Table - Meta-ADR 1 & Meta-ADR 2)
| 按鈕 / 觸發操作 | 呼叫端點 (Method & Path) | 領域標籤 | 交付模式 | 後端契約狀態 | 前端解耦開發方式 |
|:---|:---|:---|:---|:---|:---|
| 國家「匯出 Excel」按鈕 | GET /api/v1/countries/export | domain:masterdata | Full-Delivery | 契約已就緒 | Mock Server / 直連 |
| 國家「異動紀錄」頁籤 | GET /api/v1/countries/{id}/audit-logs | domain:masterdata | Full-Delivery | 契約已就緒 | Mock Server / 直連 |
| 區域「匯出 Excel」按鈕 | GET /api/v1/regions/export | domain:masterdata | Full-Delivery | 契約已就緒 | Mock Server / 直連 |
| 區域「異動紀錄」頁籤 | GET /api/v1/regions/{id}/audit-logs | domain:masterdata | Full-Delivery | 契約已就緒 | Mock Server / 直連 |

### 1.2 BDD 驗收條件 (Meta-ADR 1)
- **場景 1 (國家清單匯出 Excel 端到端驗收)**：
  - 點擊工具列「匯出 Excel」按鈕，觸發瀏覽器下載 `countries_export.xlsx`，按鈕具備防連點保護與 Loading 指示。
- **場景 2 (國家詳情抽屜真實審計歷程渲染)**：
  - 切換至「異動紀錄」頁籤，表格呈現「變更時間、操作人、欄位名稱、變更前值、變更後值與異動原因」。
- **場景 3 (區域匯出與審計對稱落實)**：
  - 區域清單與詳情抽屜完成對稱實裝。
- **場景 4 (品質雙閘門 100% 綠燈)**：
  - 執行 `npm test`，`validate-i18n.js` 與 `audit-buttons.js` 100% 通過（0 處死按鈕，0 缺失翻譯）。

### 1.3 前後端 Mock 接軌時機 (The Handshake Moment - Meta-ADR 1 §3.7)
- **平行獨立開發期**：前端 `.env.development` 設置 `NEXT_PUBLIC_ENABLE_MOCK=true`，完全打 Mock Server (MSW / 4010 埠)。
- **本地真機聯調期 (The Handshake Moment)**：前端功能刻畫完畢、提 PR 前夕，切換 `NEXT_PUBLIC_ENABLE_MOCK=false`，Base URL 指向 `http://localhost:8080`，直連真實後端執行真實 HTTP 請求與 Playwright E2E 走查。
- **種子資料同源**：後端 Flyway `V999__dev_seed_data.sql` 與前端 Mock Fixtures 保持一致。

## 2. 影響範圍與檔案清單 (Frontend Scope)
- `src/services/country-api.ts` (Extension Pattern: 引用生成的 API Types，封裝 Client 函式)
- `src/services/region-api.ts`
- `src/components/menus/country/CountryListTable.tsx`
- `src/components/menus/region/RegionListTable.tsx`
- `src/components/menus/country/CountryDetailDrawer.tsx`
- `src/locales/zh-TW.json`
- `src/locales/en-US.json`

## 3. 品質閘門 (Acceptance Gates)
- `npx tsc --noEmit` (0 型別錯誤)。
- `npm test` (i18n 完整性 + 死按鈕 AST 深入函式體靜態稽核 100% 通過，無空函式作弊)。

## 4. 三庫串行合併發布順序 (Tri-Repo Promotion Pipeline - Meta-ADR 2 §3.2)
1. **Contracts PR 預審就緒**：`reinsurance-contracts` 的 `task/TASK-008` PR 通過規格與語法審核，保持 PR 開啟暫不合入 dev。
2. **後端合入 dev**：後端代碼通過 `mvn test` 驗收後，提 PR 合併入 `reinsurance-core-service:dev`。
3. **前端真機聯調合入 dev (本任務執行點)**：本前端切換 `MOCK=false` 直連後端通過 E2E 走查後，提 PR 合併入 `reinsurance-web-portal:dev`。
4. **Contracts 主權庫結案合入 dev**：確認雙端代碼均已就緒，執行主規格語意錨點回寫，PR 最終合併入 `contracts:dev`。

## 5. 結案交付定義與主規格語意錨點回寫 (Definition of Done & Master Spec Reconciliation)
- **客觀門禁雙綠燈**：`npx tsc --noEmit` 0 錯誤；`npm test` 0 死按鈕 + 0 翻譯缺失（英文字典無中文洩漏）。
- **主規格語意錨點回寫 (Mandatory DoD)**：
  * 將國家/區域詳情抽屜真實審計歷程表格與 Excel 匯出按鈕互動行為以局部 Diff 寫回 `docs/specs/UI_SPEC.md` 之 `<!-- SECTION: UI_SPEC -->` 錨點。
  * 嚴禁全篇重寫 Markdown，杜絕規格漂移。
