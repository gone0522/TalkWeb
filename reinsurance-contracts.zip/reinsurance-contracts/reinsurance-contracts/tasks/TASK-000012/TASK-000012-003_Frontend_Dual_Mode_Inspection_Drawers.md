# TASK-000012-003: 雙模態人因抽屜重構與兄弟同構對齊 (Dual-Mode Drawers & Sibling Parity)

> **所屬任務**：`TASK-000012` 前端現代化介面原則、HCI 人機互動與三大主檔模組同構整編  
> **角色負責**：Frontend Developer  
> **分支指引**：由 `reinsurance-web-portal` 的 `dev` 切出 `feature/TASK-000012-003-UI`  
> **前置依賴**：`TASK-000012-001` (需使用 DualModeInspectionCanvas 與 ReferenceDefenseCard)  
> **規格依據**：`docs/specs/UI_SPEC.md §2 & §4`, `agent-sdk/specs/RFC-013`, `RFC-014`, `RFC-015`  

---

## 1. 任務背景與第一性原則 (Background & First-Principles)
- **根絕 disabled input 反模式**：卡尼曼雙系統人因認知心理學指明，使用者在「檢視詳情」時處於快思慢想的 System 1 認知模式，灰底 `<input disabled>` 與 `cursor-not-allowed` 禁用游標會製造強烈的操作受挫感與視覺雜訊，必填星號 (`*`) 更屬於無意義符號。
- **根治兄弟抽屜形制分裂**：現有幣別抽屜寬達 `max-w-4xl`，國家/區域卻是 `max-w-2xl`；國家 Tab 1 塞入了審計日誌表格，幣別抽屜卻是獨立引用卡，三大主檔維護抽屜呈現嚴重分裂。
- **杜絕抽屜降級為內嵌文檔流 (Prohibit Inline Flow Degradation)**：點擊「檢視/編輯」是提供側邊滑出抽屜（Slide-over Sheet）以維持主檔列表的操作上下文與流暢度，絕不可因 CSS 覆蓋層類別缺失而降級為頁面下方靜態塊級嵌入（Block flow insertion），造成版面被向下推擠且背景無法滾動的嚴重操作缺陷。
- **抽屜操作按鈕生命週期同構與防折行 (Action Button Lifecycle & Whitespace)**：編輯模式下僅保留 `取消` 與 `儲存修改`，嚴格禁止在有限的 `max-w-2xl` 抽屜標題列塞入 5 個按鈕導致幾何壓縮；所有按鈕強制 `whitespace-nowrap shrink-0` 杜絕中文文字垂直斷行。
- **異動紀錄載入零幾何突變與純淨國際化 (Zero Reflow & Strict i18n for Audit Logs)**：動態頁籤切換時不得因單一 Loading Spinner 導致容器高度劇烈塌陷（從 600px 驟降至 80px 再彈回 300px），必須透過固定表格幾何與 1:1 骨架屏消除頻閃；同時杜絕「4 entries」等硬編碼英文裸露，落實 100% 語系字典接管。

---

## 2. 目標檔案與實作範疇 (Target Files)
1. `src/components/menus/country/CountryDetailDrawer.tsx`
2. `src/components/menus/region/RegionDetailDrawer.tsx`
3. `src/components/menus/currency/CurrencyDetailDrawer.tsx`
4. `src/app/globals.css` (抽屜浮動覆蓋層、遮罩動畫、獨立捲動與橫向滾動支援)
5. `src/locales/zh-TW.json` & `src/locales/en-US.json` (異動紀錄筆數與人因國際化字典)

---

## 3. 核心改造規格 (Detailed Invariants)

### 3.1 抽屜規格尺寸與標題 100% 同構對齊
- **統一寬度**：幣別抽屜寬度由 `max-w-4xl` 全面收斂為標準 **`max-w-2xl`**，三大抽屜尺寸 1:1 對齊。
- **固定側邊浮動覆蓋層約束 (Fixed Slide-over Overlay Invariant)**：
  * 抽屜本體必須脫離一般文檔流，宣告為 `position: fixed; inset-y: 0; right: 0; z-index: 50;`，寬度嚴格限制為 `max-w-2xl`，右側滑入動效平滑自然。
  * 背景必須附帶全螢幕半透明遮罩（`position: fixed; inset-0; bg-black/40; backdrop-blur-xs; z-index: 40;`），點擊遮罩外側可受 Dirty State Guard 保護離場。
  * **獨立垂直捲動軸 (Isolated Scrollport)**：抽屜內部內容容器必須具備獨立捲動能力（`overflow-y: auto; max-h-screen`），頁面背景表格與導覽列維持鎖定不位移，確保表單不管向下展開多長，頂部標題、操作按鈕與 Tab 頁籤均能快速滑動存取。
- **操作按鈕群生命週期與排版防禦 (Button Lifecycle & Whitespace Parity)**：
  * 檢視模式展示 4 顆操作按鈕：`返回列表`、`刪除`、`設為作廢/啟用`、`編輯`。
  * 編輯模式嚴格切換為 2 顆專注按鈕：`取消`、`儲存修改`。禁止重複展示返回列表或作廢開關。
  * 所有按鈕宣告 `whitespace-nowrap shrink-0`，杜絕任何文字折行跑版。
- **標準標題列結構**：
  * `[模組名稱] - [檢視/編輯]`（如「國家主檔 - 檢視」、「結算幣別主檔 - 編輯」）。
  * 畫面代碼徽章（如 `SC-0101-01-02`，Font-mono 灰底膠囊）。
  * 模式膠囊徽章（檢視時為藍/灰底「檢視模式」，編輯時為橘底「編輯中」）。

### 3.2 雙模態人因閱覽畫布實施 (RFC-013) 與現代底線頁籤 (RFC-014)
- **抽屜分頁現代底線頁籤 (Drawer Underline Tabs)**：
  * 徹底拔除 1995 灰底凸起資料夾頁籤 (`border-t border-l border-r border-b-0`)。
  * 全面改採現代純淨底線頁籤（活躍橘底線 `border-b-2 border-orange-500`，未活躍淡灰平滑淡入）。
- **檢視模式**：
  * **徹底拔除所有 `<input disabled>`、`<select disabled>` 與必填星號 (`*`)**。
  * 改以清晰高對比排版呈現（標籤：`text-xs font-medium text-slate-500`，數值：`text-sm font-semibold text-slate-900`）。
  * 唯一業務代碼（如 ISO 國家代碼、幣別代碼、區域代碼）搭配唯讀鎖頭意符 (`lucide-react: Lock`) 與一鍵複製小按鈕。
- **編輯模式**：
  * 平滑展開現代輸入控制項，帶有品牌橘焦點光暈 (`focus:ring-2 focus:ring-orange-500/20`)。
  * 游標自動聚焦至第一可編輯欄位。

### 3.3 引用防禦卡與審計日誌職責歸位 (RFC-015)
- 統一在 Tab 1 底部採用標準琥珀色 `<ReferenceDefenseCard>` 呈現多模組引用統計。
- **淨化國家抽屜 Tab 1**：移除國家抽屜 Tab 1 內嵌的 6 欄審計預覽表，所有歷史留痕統一收納於 Tab 2「異動紀錄」。
- 系統資訊微卡片統一為現代色調雙欄卡片 (`bg-slate-50/80 rounded-xl border-slate-100 p-4`)。

### 3.4 防禦性人因互動保護 (Defensive HCI)
- **焦點捕捉 (Focus Trap)**：抽屜開啟時攔截鍵盤 `Tab` 循環於抽屜內部，杜絕意外穿透。
- **焦點復原 (Focus Restoration)**：按下 `Esc` 或「返回列表」關閉抽屜時，焦點自動精準復原至觸發之表格按鈕。
- **未儲存離場防護 (Dirty State Guard)**：編輯中未儲存直接點擊遮罩或關閉時，跳出二次確認彈窗，防止意外遺失草稿。

### 3.5 審計紀錄幾何穩定骨架、橫向滾動與國際化契約 (Zero-Flicker Audit Skeleton & i18n Contract)
- **零閃爍幾何穩定性 (Zero-Flicker Layout Stability)**：切換至 Tab 2「異動紀錄」時，嚴禁以全區域單一小 Spinner 覆蓋整個分頁。必須渲染具有固定幾何結構的表格外殼，載入中狀態採用 1:1 等高骨架列（Skeleton Rows）流暢過渡。
- **橫向滾動保全與欄寬尺度合理性 (Scrollport & Colgroup Proportions)**：
  * 表格主體外層包裹 `overflow-x-auto` 容器，表格本身宣告 `min-w-[780px] w-full table-fixed`。
  * `<colgroup>` 顯式鎖定各欄合理寬度（異動時間 `w-44` 176px，異動原因 `w-48` 192px），徹底消除文字撞擊擠壓與單字垂直斷行缺陷。
- **完整國際化標籤契約 (Complete i18n Contract)**：異動紀錄筆數禁止出現硬編碼英文（如 `{count} entries`）。必須由語系檔完整接管，繁體中文定義為 `"共 {count} 筆"`，英文定義為 `"Total {count} entries"`，並透過字典插值格式化渲染。

---

## 4. 驗收標準 (Acceptance Criteria)
- [ ] 三大抽屜檢視模式下 `<input disabled>` 與必填紅星號徹底清零。
- [ ] 三大抽屜尺寸 100% 統一為 `max-w-2xl`。
- [ ] 抽屜採用 `position: fixed` 側邊浮動覆蓋層與獨立 `overflow-y: auto` 垂直捲動，無底層位移推擠與滑動受阻現象。
- [ ] 標題欄操作按鈕生命週期對齊：檢視模式 4 鈕、編輯模式 2 鈕，宣告 `whitespace-nowrap shrink-0` 杜絕文字折行。
- [ ] 抽屜 Tab 頁籤 100% 採用現代純淨底線頁籤 (RFC-014)，消除 1995 灰底凸起資料夾方框。
- [ ] 國家抽屜 Tab 1 內嵌審計表成功移除，專注於基本資訊與 `<ReferenceDefenseCard>`。
- [ ] 切換至「異動紀錄」Tab 2 時幾何結構保持穩定，骨架列 1:1 平滑載入，杜絕高度坍塌與頁面閃爍。
- [ ] 審計歷程表格支援 `overflow-x-auto` 與 `min-w-[780px]`，時間戳記與異動原因欄位空間充裕零擠壓跑版。
- [ ] 異動紀錄筆數完整實現 i18n（繁中為「共 X 筆」，英文為「Total X entries」），硬編碼英文字串清零。
- [ ] `Esc` 焦點原位復原與未儲存離場提示正常運作。
- [ ] `npx tsc --noEmit` 0 錯誤。
- [ ] `npm test` 100% 通過。

