# TASK-000012-002: 主檔表格零位移容器與查詢表單破折虛線消除 (Zero-CLS Tables & Search Forms)

> **所屬任務**：`TASK-000012` 前端現代化介面原則、HCI 人機互動與三大主檔模組同構整編  
> **角色負責**：Frontend Developer  
> **分支指引**：由 `reinsurance-web-portal` 的 `dev` 切出 `feature/TASK-000012-002-UI`  
> **前置依賴**：`TASK-000012-001` (需使用 SmoothDataTableContainer)  
> **規格依據**：`docs/specs/UI_SPEC.md §3.2 & §4`, `agent-sdk/specs/RFC-012`  

---

## 1. 任務背景與第一性原則 (Background & First-Principles)
- **消除收據式破折虛線**：現有國家、區域、幣別表格與查詢表單之間大量充斥著 `border-dashed border-gray-300` 破折虛線，破壞現代企業軟體的視覺連續性與高級質感。
- **根治分頁劇烈上下晃動與頻閃 (Zero CLS & Zero Strobe Invariant)**：
  - 在資料分頁切換或搜尋篩選時，因骨架屏行數與實際資料筆數差異，表格高度大幅坍塌，導致下方分頁控制列上下跳動。
  - **高速網路頻閃消除 (Zero Strobe)**：在本地/快速查詢（20ms~60ms）情境下，若硬性將現有資料行拔除換成單行旋轉菊花，將導致嚴重的畫面頻閃抽搐（Strobe Flash）。必須採用 **Stale-While-Revalidate（舊資料原地留存）** 與 **1:1 仿真骨架屏**。
- **查詢按鈕零抖動與安靜重驗證 (Zero-Jitter Button & Silent Revalidation)**：
  - 快速查詢（< 200ms）不應引發按鈕形態劇變與光害抽搐。嚴格禁止在按鈕內部動態塞入旋轉圖標造成文字位移，嚴格禁止按鈕暴跌透明度（`disabled:opacity-50`）。重驗證狀態由表格頂部 Shimmer 呼吸線承擔，按鈕佈局恆定。
- **首屏三態生命週期與零虛假空狀態 (Zero-False-Empty Page Lifecycle)**：
  - 嚴格禁止在首筆資料載入完成前宣稱「查無資料」。在首屏加載未完成前，表格唯一合法形態為 1:1 仿真骨架屏，杜絕首屏閃現空狀態卡片。
- **表格幾何絕對鎖定與 table-fixed 零跑位 (Table Geometry Absolute Lock & Zero Layout Shift)**：
  - 在瀏覽器預設的 `table-layout: auto` 下，欄位寬度由儲存格當前內容動態推導。當首屏 1:1 骨架屏切換為真實文字或重新整理載入時，瀏覽器會重新計算表格寬度，造成標題欄與表格邊界發生劇烈左右位移與縮放（Layout Shift / 跑位）。
  - **設計系統 CSS 契約完備性 (CSS Contract Completeness)**：在純 Vanilla CSS 專案中，TSX 書寫的 `table-fixed` 與欄寬（`w-XX`）皆為符號引用。若 `globals.css` 缺乏實體規則，瀏覽器將靜默退回 `table-layout: auto`。必須具備實體規則與 `<colgroup>` 前置鎖定，保證表格尺寸與標題絕對靜止零跑位。
  - 此外，容器若在初始載入時替換為普通無頭 `<div>`，會摧毀表格 DOM，造成整張表格與標題閃爍重建。外框與標題必須永久保全。
- **工具列與動作按鈕正交性鐵律 (Toolbar Action Orthogonality Invariant)**：
  - 工具列動作（如「匯出 Excel」）與表格資料的重驗證加載（`isLoading`）應保持正交解耦。
  - 嚴格禁止將表格查詢的 `isLoading` 傳遞至 `<MasterDataTableToolbar>` 的 `disabled` 屬性。匯出按鈕的可用性僅由「是否有資料可供匯出 (`totalElements === 0`)」與「自身是否正在匯出 (`isExporting`)」決定，杜絕使用者點擊「查詢」時匯出按鈕透明度暴跌產生的字體閃爍光害。

---

## 2. 目標檔案與實作範疇 (Target Files)
1. `src/components/menus/common/master-data/SmoothDataTableContainer.tsx`
2. `src/components/menus/country/CountrySearchForm.tsx` & `src/components/menus/country/CountryListTable.tsx`
3. `src/components/menus/region/RegionSearchForm.tsx` & `src/components/menus/region/RegionListTable.tsx`
4. `src/components/menus/currency/CurrencySearchForm.tsx` & `src/components/menus/currency/CurrencyListTable.tsx`
5. `src/app/(dashboard)/settings/menus/countries/page.tsx`
6. `src/app/(dashboard)/settings/menus/currencies/page.tsx`
7. `src/app/(dashboard)/settings/menus/regions/page.tsx`

---

## 3. 核心改造規格 (Detailed Invariants)

### 3.1 破折虛線全面拔除 (Ban on Dashed Borders)
- 刪除 `CountryListTable.tsx`、`RegionListTable.tsx`、`CurrencyListTable.tsx` 頂部的 `<div className="border-t border-dashed border-gray-300 my-4" />`。
- 改以精準空間留白 (`space-y-4` 或 `mt-4`) 與精緻實線分隔 (`border-slate-100`)。

### 3.2 容器保全與 Stale-While-Revalidate 零頻閃過渡 (RFC-012 Zero Strobe Transition)
- 將三大清單表格主體完整包裹於 `<SmoothDataTableContainer minHeightClass="min-h-[380px]" isLoading={isLoading} hasData={data.length > 0}>` 中。
- **Stale-While-Revalidate 樂觀留存**：
  * 當表格已有資料（`data.length > 0`）時，任何查詢、篩選、防抖與分頁事件，**嚴格禁止**將 `<tbody>` 清空並換成單行旋轉菊花。
  * 舊資料原地維持，外層容器降低透明度至 `opacity-60 transition-all duration-250 ease-out pointer-events-none`，頂部亮起平滑 Shimmer 漸層呼吸線。
  * 新資料返抵時，250ms 平滑交叉淡入（Cross-fade），消除任何畫面抽搐與白閃。
- **效果**：當查詢結果為 0 筆空資料或僅 1 筆資料時，容器保全其最小高度，**下方分頁控制列 (`<MasterDataPagination>`) 垂直位置絕對靜止 (CLS = 0)**。

### 3.3 查詢表單按鈕零抖動與安靜重驗證 (Zero-Jitter Button Invariant)
- `CountrySearchForm`、`RegionSearchForm`、`CurrencySearchForm` 之查詢按鈕（Submit Button）：
  * **按鈕幾何尺寸恆定**：按鈕寬度與文字內邊距絕對固定，**嚴格禁止**因加載狀態動態插入 `<svg className="animate-spin">` 導致文字向右彈開或按鈕寬度抖動。
  * **禁止透明度暴跌**：消除 `disabled:opacity-50` 抽搐，按鈕外觀維持標準主視覺（`bg-[#374151]`），僅在加載時設置 `pointer-events-none` 防止使用者連點。
  * **安靜反饋架構**：加載進行時之視覺線索統一由表格外層容器頂部的 Shimmer 進度線呈現，消除按鈕內部光害。

### 3.4 首屏三態生命週期與零虛假空狀態鐵律 (Zero-False-Empty Page Lifecycle Invariant)
- 頁面（`countries/page.tsx`、`regions/page.tsx`、`currencies/page.tsx`）與表格引入三態生命週期（`INITIAL_PENDING` ➔ `STABLE_IDLE` ➔ `REVALIDATING`）：
  * **首屏初始化 (`INITIAL_PENDING`)**：
    - 頁面初始狀態宣告 `isInitialLoading = true` 與 `hasFetched = false`。
    - 在 API 首次請求完成前，表格元件**唯一合法形態為 1:1 仿真骨架屏 (Skeleton Mesh)**，渲染 5 列與真實欄位完全等寬、等高之脈衝骨架行。
    - **嚴格禁令**：絕對禁止在首屏露出「查無資料 (Empty State)」卡片。
  * **真實空狀態 (`STABLE_EMPTY`)**：
    - 唯有在 API 請求確定完成（`hasFetched === true`）且結果筆數確鑿為 0（`data.length === 0`）時，方可平滑切入「查無資料」空狀態卡片。

### 3.5 表格操作欄兄弟同構對齊 (Sibling Parity)
- 國家、區域、結算幣別表格操作欄（Action Column）的「檢視/編輯」動作按鈕，100% 同構為標準白底灰框微陰影按鈕：
  * 樣式：`h-7 px-3 text-xs font-medium rounded-md border border-slate-200 bg-white text-slate-700 hover:bg-slate-50 hover:text-slate-900 shadow-2xs transition-colors`
- 消除任何死黑木訥按鈕 (`bg-[#374151]`)。

### 3.6 表格幾何絕對鎖定與 table-fixed 零跑位鐵律 (Table Geometry Absolute Lock & table-fixed Invariant)
- **`table-fixed` 與 `<colgroup>` 雙重強制約束**：
  * 三大主檔所有表格 `<table>` 必須宣告 `table-fixed w-full`。
  * 必須於 `<thead>` 之前顯式宣告 `<colgroup><col className="w-XX" />...</colgroup>`，確保瀏覽器排版引擎在首幀剖析時即硬性鎖定各欄幾何，不受儲存格文字長度影響。
- **全欄位幾何顯式定義與骨架內邊距 1:1 同構 (Explicit Geometry & Padding Parity)**：
  * 所有欄位必須宣告明確寬度（如 `w-24`, `w-28`, `w-44`, `w-48` 等），禁止出現無寬度的浮動欄。
  * 骨架屏單元格與真實資料單元格之內邊距（Padding）必須 100% 絕對同構對齊（如 `px-4 py-2.5` / `px-3 py-2.5`），消除文字返抵時的儲存格微抖動。
- **設計系統 CSS 契約實體閉環 (Design System CSS Contract Completeness)**：
  * `globals.css` 必須完備定義所有欄寬尺度（`w-12` ~ `w-64`）、`table-fixed`、`border-collapse` 與脈衝動畫，並由自動化工具 `audit-table-css.js` 納入 CI/Test 強制檢驗。
- **外框卡片與結構永續保全 (Persistent Table Shell & Frame)**：
  * 所有主檔表格均包裹於標準微陰影圓角卡片外框 `<div className="border border-slate-200/80 rounded-xl overflow-hidden bg-white shadow-2xs">`。
  * `SmoothDataTableContainer` 永久渲染 `children`，保留完整的 `<table>`、`<thead>` 與外框，骨架屏嚴格限制於 `<tbody>` 內部切換。

### 3.7 工具列與動作按鈕正交性鐵律 (Toolbar Action Orthogonality Invariant)
- **正交解耦 (Decoupling Table Query from Toolbar Actions)**：工具列操作按鈕（如「匯出 Excel」）的禁用狀態，僅由「資料本體存在性 (`totalElements === 0`)」與「自身操作進行狀態 (`isExporting`)」決定，**嚴格禁止**將表格查詢/重新驗證的 `isLoading` 傳遞至工具列按鈕。
- **按鈕視覺狀態穩定**：查詢表格資料時，下方匯出按鈕維持視覺恆定，杜絕任何透明度暴跌或文字閃爍。

---

## 4. 驗收標準 (Acceptance Criteria)
- [ ] 國家、區域、幣別查詢表單與表格區間的所有 `border-dashed` 徹底消除。
- [ ] 三大模組表格全面整合 `<SmoothDataTableContainer>`，分頁列在資料筆數變化時垂直位移恆為 0。
- [ ] 重新檢索時原有資料原地保留不拔除（Stale-While-Revalidate），頂部亮起平滑 Shimmer 呼吸線，杜絕白閃。
- [ ] 查詢表單之查詢按鈕在點擊後幾何尺寸與文字絕對靜止，消除 `animate-spin` 撐開與 `opacity-50` 抽搐。
- [ ] 頁面重新整理（F5）或導航切入時，表格直接展示 1:1 仿真骨架屏，嚴格杜絕首屏閃現「查無資料」空狀態。
- [ ] 查無資料空狀態僅在 API 確定完成且結果為 0 筆時展示。
- [ ] 表格操作按鈕在三模組間達成 1:1 樣式同構。
- [ ] 所有主檔表格均宣告 `table-fixed` 與 `<colgroup>`，且骨架屏單元格內邊距與真實儲存格 100% 同構對齊，首屏與刷新載入時標題欄位幾何尺寸絕對鎖定零跑位。
- [ ] `globals.css` 具備所有幾何與版面 utility class 實體規則，並通過 `node scripts/audit-table-css.js` 自動化檢驗。
- [ ] `SmoothDataTableContainer` 永續渲染表格主體與外框，杜絕無頭 div 替換與 DOM 抽搐。
- [ ] 工具列「匯出 Excel」按鈕解耦表格查詢加載狀態，點擊「查詢」時按鈕字體與外觀絕對靜止無頻閃。
- [ ] `npx tsc --noEmit` 0 錯誤。
- [ ] `npm test` 執行通過（包含 `audit-buttons.js` 與 `audit-master-data-standards.js` 100% PARITY）。
