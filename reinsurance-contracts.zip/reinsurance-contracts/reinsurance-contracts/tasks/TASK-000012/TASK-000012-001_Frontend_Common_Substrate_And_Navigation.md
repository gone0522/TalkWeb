# TASK-000012-001: 共通基礎原語與現代導航框架升級 (Common Substrate & Navigation)

> **所屬任務**：`TASK-000012` 前端現代化介面原則、HCI 人機互動與三大主檔模組同構整編  
> **角色負責**：Frontend UI Architect / Developer  
> **分支指引**：由 `reinsurance-web-portal` 的 `dev` 切出 `feature/TASK-000012-001-UI`  
> **規格依據**：`docs/specs/UI_SPEC.md §2`, `docs/specs/SD_SPEC.md §2`, `agent-sdk/specs/RFC-012`, `RFC-013`, `RFC-014`, `RFC-015`  

---

## 1. 任務背景與第一性原則 (Background & First-Principles)
- **淘汰歷史包袱**：
  * 現有 `MenuHeaderTabs.tsx` 仍採用 1998 年 Windows 灰底資料夾頁籤 (`bg-gray-200/70`、`border-gray-300`、`rounded-t-md`)，風格厚重過時。
  * 現有 `MenuCardFrame.tsx` 使用 2005 年灰底標題欄 (`bg-gray-100 border-b border-gray-300`)，呈現粗糙的 Wireframe 感。
  * 全域缺乏原生元素樣式重置 (Preflight CSS Reset)，導致 `<button>` 元素暴露瀏覽器原生 `buttonface` 灰底與 `2px outset` 3D 浮雕粗框，破壞現代純淨 SaaS 視覺風格。
- **架構原語下沉**：
  * 在重構各業務頁面前，必須先在 `src/components/menus/common/master-data/` 沉澱經過驗證的 Agent SDK UI 原語，為後續清單表格與抽屜提供堅不可摧的抗熵底座。

---

## 2. 目標檔案與實作範疇 (Target Files)
1. `src/components/menus/common/MenuHeaderTabs.tsx`
2. `src/components/menus/common/MenuCardFrame.tsx`
3. `src/components/menus/common/master-data/MasterDataHeaderActions.tsx`
4. `src/components/menus/common/master-data/SmoothDataTableContainer.tsx`
5. `src/components/menus/common/master-data/DualModeInspectionCanvas.tsx`
6. `src/components/menus/common/master-data/ReferenceDefenseCard.tsx`
7. `src/app/globals.css` (全域 Preflight Reset 與現代邊框級聯規則)

---

## 3. 核心改造規格 (Detailed Invariants)

### 3.1 現代底線導航頁籤 (`MenuHeaderTabs.tsx` - 對偶 RFC-014)
- **減法美學 (Subtraction Design)**：全面移除灰色頁籤按鈕底色與粗重外框。
- **純淨底線指示器**：
  * 活躍狀態 (Active)：深色字體 (`text-slate-900 font-semibold`)，底部搭配品牌橘滑動指示線 (`border-b-2 border-orange-500`)。
  * 未活躍狀態 (Inactive)：柔和灰字 (`text-slate-500 hover:text-slate-700`)，懸浮具備平滑淡入效果。
- **鍵盤無障礙 (WCAG AA)**：支援 `ArrowLeft` / `ArrowRight` 頁籤切換與 `Tab` 導航。
- **全域按鈕重置與邊框級聯約束 (Global Preflight Reset & Border Cascade Invariant)**：
  * 全域規範 `button` 預設為 `appearance: none; background-color: transparent; border-width: 0;`，杜絕原生 `buttonface` 灰底與 3D 浮雕粗框。
  * `.border-b-2` 嚴格僅設置 `border-bottom-width: 2px; border-bottom-style: solid;`，禁止硬編碼顏色覆蓋 `border-color` 級聯，杜絕底線頁籤產生四邊凸起黑橘相間方框。

### 3.2 現代卡片外框 (`MenuCardFrame.tsx`) 與頂部操作同構 (`MasterDataHeaderActions.tsx`)
- 移除頂部灰色標題條 (`bg-gray-100`)，改為統一的現代微陰影純淨白底卡片 (`bg-white rounded-xl border border-slate-200/80 shadow-xs`)。
- 標題與操作區以空間留白呈現，與內容區自然融合。
- **主檔操作列同構美學 (Header Actions Parity)**：
  * 主操作按鈕（`+ 新增`）統一升級為現代微陰影 Slate-900 主按鈕（`h-8.5 px-4 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg shadow-xs border-0 shrink-0 whitespace-nowrap`）。
  * 次要操作按鈕（`批次匯入`）與主按鈕尺寸高度及圓角 1:1 同構（`h-8.5 px-3.5 text-xs text-slate-400 bg-slate-50 border border-slate-200 rounded-lg opacity-80 shrink-0 whitespace-nowrap`）。

### 3.3 落地三大 Agent SDK UI 原語 (`src/components/menus/common/master-data/`)
1. **`SmoothDataTableContainer.tsx` (RFC-012)**：
   - 封裝高度容器保全：強制 `min-h-[420px]`，杜絕資料比數變化導致的佈局位移 (CLS = 0)。
   - 數據重新加載 (Refetch) 時採用非坍塌透明度淡入淡出 (200ms Cross-fade)，頂部提供平滑進度脈衝線。
2. **`DualModeInspectionCanvas.tsx` (RFC-013)**：
   - 檢視模式 (Inspection Mode)：高對比 Key-Value 鍵值對排版，徹底根絕 `<input disabled>` 與必填星號 (`*`)。提供唯讀鎖頭意符 (`lucide-react: Lock`) 與懸浮一鍵複製按鈕。
   - 編輯模式 (Edit Mode)：輸入框支援焦點光暈 (`focus:ring-2 focus:ring-orange-500/20`)，第一編輯欄位自動獲取焦點。
   - 未儲存離場防護：內建 `useDirtyStateGuard`，在表單未儲存關閉時彈出確認對話框。
3. **`ReferenceDefenseCard.tsx` (RFC-015)**：
   - 標準琥珀色微色調容器 (`bg-amber-50/80 border-amber-200/80 text-amber-900 rounded-xl p-4`)。
   - 聚合展示跨模組引用統計 (`totalReferenceCount`)，若引用數 > 0 明確標示「因受合約引用中，禁止物理刪除」，按鈕提供解釋性 Tooltip。

---

## 4. 驗收標準 (Acceptance Criteria)
- [ ] `MenuHeaderTabs.tsx` 現代底線導航頁籤落地，1998 Windows 資料夾頁籤與原生 3D 浮雕按鈕徹底消除。
- [ ] `MenuCardFrame.tsx` 純淨現代卡片外框落地，2005 灰底 Header 徹底消除。
- [ ] `MasterDataHeaderActions.tsx` 與各主檔頁面之頂部按鈕達成尺寸、圓角與視覺風格 1:1 同構對齊。
- [ ] `globals.css` 具備完整的全域 Preflight Button Reset 與邊框寬度級聯規則。
- [ ] `SmoothDataTableContainer.tsx`、`DualModeInspectionCanvas.tsx`、`ReferenceDefenseCard.tsx` 正式建立且 TypeScript 型別 0 錯誤。
- [ ] `npx tsc --noEmit` 檢查通過。
- [ ] 執行 `npm test` 保持 100% 綠燈。

