# File: tasks/TASK-007/TASK-007-04_Frontend.md
# TASK-007-04: 結算幣別新增彈窗、即時試算預覽、檢視/編輯抽屜、計算變更警示與引用防護 (SC-0101-02-02 / SC-0101-02-03)

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 使用案例：`tasks/TASK-007/specs/USE_CASE_SPEC/Currency_USE_CASE_SPEC.md` (UC-CUR-02, 03, 04, 05, 06, 07)
  - 系統/API設計：`tasks/TASK-007/specs/SD_SPEC/Currency_SD_SPEC.md` (§2.2 詳情, §2.3 POST, §2.4 PUT, §2.5 PATCH, §2.6 DELETE)
  - 前端架構：`tasks/TASK-007/specs/UI_SPEC/Currency_UI_SPEC.md` (§2.2 mockups/2.jpg, §2.3 mockups/3.jpg)
  - 設計稿對齊：`tasks/TASK-007/mockups/2.jpg, 3.jpg`
  - 測試驗收規範：`tasks/TASK-007/specs/QA_SPEC/Currency_QA_SPEC.md` (TC-CUR-02, 03, 05, 06, 07, 08)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (§6.3.1 前端切片 2 規範, Living Master Docs)
- **業務背景**：提供幣別單筆新增彈窗（含正負數即時試算預覽與「儲存並繼續新增」）、檢視/編輯維護側邊抽屜（含代碼鎖定唯讀、計算變更警示橫幅、多模組引用狀況統計表格、最近 5 筆異動紀錄表格、變更原因彈窗與安全刪除確認彈窗），並於收尾時執行 Master Spec 統整。

### 驗收條件 (BDD 結構化規範)
- **場景 1 (新增表單防呆與即時試算預覽 - 100% 對齊 mockups/2.jpg)**：
  - **Given**: 新增幣別彈窗 (`CurrencyFormModal`, SC-0101-02-02) 開啟。
  - **When**: 使用者輸入幣別基本資料與計算設定。
  - **Then**: 
    1. 顯示順序自動預設填入建議值（現有最大值 + 10）。
    2. 空值送出時前端即時阻擋，首個錯誤欄位標紅並自動聚焦 (`focus()`)；輸入時即時消除紅框。
    3. 小數位數限定輸入 `0 ~ 4`，超出範圍阻擋儲存。
    4. 「設定預覽」區塊即時演算：
       - `計算原始值 1,234.5678 → 套用「{進位設定} / {小數位數} 位」後 {格式化正值}`
       - `負值檢核 -1,234.5678 → 套用同設定後 {格式化負值}`
    5. 若後端回傳 409 Conflict，代碼框標紅提示「此代碼已被使用」，彈窗頂部顯示警示橫幅。
- **場景 2 (儲存並繼續新增連動 - 100% 對齊 mockups/2.jpg)**：
  - **When**: 點擊 `[ 儲存並繼續新增 ]` 按鈕。
  - **Then**: 成功送出落庫後，彈窗保持開啟，Toast 提示儲存成功，顯示順序自動累加 + 10，清空其餘輸入欄位並自動聚焦代碼框。
- **場景 3 (檢視/編輯抽屜與卡片資料夾頁籤 - 100% 對齊 mockups/3.jpg)**：
  - **Given**: 點擊清單項目開啟側邊維護抽屜 (`CurrencyDetailDrawer`, SC-0101-02-03)。
  - **Then**: 
    1. 標題 `結算幣別選單 - 檢視/編輯 SC-0101-02-03 [ 檢視模式 ]`。
    2. 右上按鈕順序：`[ 返回列表 ]` | `[ 刪除 ]` | `[ 設為作廢 / 重新啟用 ]` | `[ 編輯 ]` (`bg-[#374151]`)。
    3. 頁籤導航採用卡片資料夾樣式 (`[ 基本資料 ]` | `[ 異動紀錄 ]`)，作用中頁籤白底粗體無底線 (`-mb-px z-10 border-t border-l border-r border-gray-300`)，嚴禁出現橘色邊框。
    4. 幣別代碼於檢視與編輯模式下均鎖定為唯讀，右側展示 🔒 圖示，下方註明「ISO 4217；主鍵。已被引用，鎖定為唯讀。」。
- **場景 4 (計算設定變更警示橫幅與強制輸入原因對話框 - mockups/3.jpg)**：
  - **Given**: 抽屜渲染。
  - **Then**: 頂部呈現黃色警示橫幅：
    `⚠️ 變更計算設定之影響：進位設定或小數位數異動後，僅適用於變更後之新交易；既有合約與歷史交易金額不重算。變更時系統應跳出確認訊息並強制輸入異動原因。`
  - **When**: 於編輯模式下修改「進位設定」或「小數位數」並點擊儲存。
  - **Then**: 彈出二次確認彈窗 (`CurrencyRuleChangeModal`)，強制要求輸入異動原因；確認後附帶原因送出，並更新最近 5 筆異動紀錄表格。
- **場景 5 (多模組引用狀況統計表格 - 100% 對齊 mockups/3.jpg)**：
  - **Given**: 抽屜展開「資料引用狀況」區塊。
  - **Then**: 表格完整呈現三行引用統計：
    - 再保合約 (結算幣別) / 86 筆 / 因已被引用，本筆資料不可刪除，僅可標記作廢。
    - 交易資料 (再保費/佣金/賠款) / 1,432 筆 / 作廢後歷史交易仍可正常查詢與續用。
    - 金融機構收付款設定 / 7 筆 / 作廢後不再出現於新增收付款設定之下拉選單。
  - **And**: 若引用數 > 0，右上角 `[ 刪除 ]` 按鈕鎖定 Disabled 灰底灰字，滑鼠懸停顯示 Tooltip「已有資料引用，禁止刪除」。
- **場景 6 (零引用安全刪除二次確認對話框)**：
  - **Given**: 幣別未被任何模組引用。
  - **When**: 點擊刪除按鈕。
  - **Then**: 彈出確認對話框 (`CurrencyDeleteConfirmModal`)，確認後送出 DELETE API，關閉抽屜並刷新清單。
- **場景 7 (i18n & 品質閘門)**：
  - 所有文字登錄雙語字典，執行 `npx tsc --noEmit` 0 錯誤。
- **場景 8 (Living Master Documentation DoD - 模組收尾統整)**：
  - 當本任務驗收通過，確認 TASK-007 模組下所有後端/前端任務均已完成時，自動將 `tasks/TASK-007/specs/` 下之增量規範合併更新至專案全局 `docs/specs/` (`SA_SPEC.md`, `DBA_SPEC.md`, `SD_SPEC.md`, `UI_SPEC.md`, `QA_SPEC.md`)。

## 2. 影響範圍與檔案清單 (Scope)
> 注意：本任務為純前端任務，後端清單必須完全留空。

### Backend Files
(無)

### Frontend Files
- src/components/menus/currency/CurrencyFormModal.tsx
- src/components/menus/currency/CurrencyDetailDrawer.tsx
- src/components/menus/currency/CalculationPreviewCard.tsx
- src/components/menus/currency/CurrencyRuleChangeModal.tsx
- src/components/menus/currency/CurrencyDeleteConfirmModal.tsx
- src/locales/zh-TW.json (增量)
- src/locales/en-US.json (增量)
