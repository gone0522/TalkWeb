# File: tasks/TASK-007/TASK-007-02_Backend.md
# TASK-007-02: 結算幣別計算設定變更強制稽核 (Audit Log)、多模組引用統計與 Excel 匯出 API

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 業務需求：`tasks/TASK-007/specs/SA_SPEC.md` (§4 BR-CUR-07 變更影響隔離, BR-CUR-08 異動稽核追蹤)
  - 使用案例：`tasks/TASK-007/specs/USE_CASE_SPEC/Currency_USE_CASE_SPEC.md` (UC-CUR-04 詳情與引用統計, UC-CUR-05 計算變更稽核, UC-CUR-08 Excel 匯出)
  - 資料模型：`tasks/TASK-007/specs/DBA_SPEC/Currency_DBA_SPEC.md` (currency_audit_logs 表)
  - 系統/API詳細設計：`tasks/TASK-007/specs/SD_SPEC/Currency_SD_SPEC.md` (§2.2 詳情與引用, §2.4 變更稽核, §2.7 匯出 Excel)
  - 測試驗收規範：`tasks/TASK-007/specs/QA_SPEC/Currency_QA_SPEC.md` (TC-CUR-07, TC-CUR-08, TC-CUR-10)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (Audit Logging, Streaming Excel Export)
- **業務背景**：幣別之進位設定與小數位數直接牽動全公司合約與交易帳目。變更時必須強制要求輸入異動原因/依據，完整寫入 Audit Log，歷史合約嚴禁重算；並提供多模組引用筆數即時統計與查詢結果 Excel 匯出。

### 驗收條件 (BDD 結構化規範)
- **場景 1 (Mandatory Reason Guard - 計算規則變更強制異動原因 - TC-CUR-07, UC-CUR-05)**：
  - **Given**: 使用者嘗試變更幣別之 `roundingRule` (如從 HALF_UP 改為 HALF_EVEN) 或 `decimalPlaces` (從 4 改為 2)。
  - **When**: 發送 `PUT /api/v1/currencies/{code}`，但 `changeReason` 欄位為空或長度 `< 5`。
  - **Then**: 伺服器直接拒絕更新，回傳 `HTTP 400 Bad Request`，錯誤代碼 `ERR_CHANGE_REASON_REQUIRED`，說明「變更進位設定或小數位數必須填寫至少 5 個字之異動原因/法令依據」。
- **場景 2 (Audit Logging - 異動歷程自動記錄與時間戳更新 - TC-CUR-08)**：
  - **Given**: 使用者送出合法的計算設定變更請求，附帶 `changeReason: "配合 2026 會計年度結算格式修訂"`。
  - **When**: 請求成功執行。
  - **Then**: 伺服器於同一事務內完成：
    1. 更新 `currencies` 主檔之 `rounding_rule`, `decimal_places`，並將 `last_calc_rule_changed_at` 刷新為當前 UTC 時間。
    2. 自動寫入 `currency_audit_logs` 表，記錄 `currency_code`, `changed_at`, `changed_by`, `department`, `field_name`, `before_value`, `after_value`, `change_reason`。
- **場景 3 (Audit Log Query - 最近 5 筆歷程查詢 - UC-CUR-04)**：
  - **When**: 發送 `GET /api/v1/currencies/USD/audit-logs?limit=5`。
  - **Then**: 伺服器回傳 `HTTP 200 OK`，按 `changed_at DESC` 回傳最近 5 筆異動清單，供維護抽屜展示。
- **場景 4 (Reference Summary - 多模組引用筆數動態統計 - UC-CUR-04)**：
  - **When**: 發送 `GET /api/v1/currencies/USD` 查詢詳情。
  - **Then**: 回傳資料包含 `references` 區塊，內含：
    - `treatyCount`: 再保合約 (結算幣別) 引用筆數。
    - `transactionCount`: 交易資料 (再保費/佣金/賠款) 引用筆數。
    - `bankSettingCount`: 金融機構收付款設定引用筆數。
    - `isReferenced`: `true` 若任一計數 > 0。
- **場景 5 (Excel Export - 依查詢條件動態匯出 - TC-CUR-10, UC-CUR-08)**：
  - **When**: 發送 `GET /api/v1/currencies/export?keyword=USD&status=ACTIVE`。
  - **Then**: 伺服器回傳 `HTTP 200 OK`，Content-Type 為 `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`，檔案包含表頭（顯示順序、幣別代碼、中文名稱、英文名稱、進位設定、小數位數、金額範例、狀態）與正確篩選之資料列。
- **場景 6 (TDD 品質閘門)**：
  - 單元測試 `CurrencyAuditServiceTest.java` 與 `CurrencyExportServiceTest.java` 全數通過，`mvn test` 0 Errors。

## 2. 影響範圍與檔案清單 (Scope)
> 注意：本任務為純後端任務，前端清單必須完全留空。

### Backend Files
- src/main/java/com/reinsurance/core/currency/entity/CurrencyAuditLog.java
- src/main/java/com/reinsurance/core/currency/repository/CurrencyAuditLogRepository.java
- src/main/java/com/reinsurance/core/currency/service/CurrencyAuditService.java
- src/main/java/com/reinsurance/core/currency/service/CurrencyExportService.java
- src/main/java/com/reinsurance/core/currency/controller/CurrencyAuditExportController.java
- src/test/java/com/reinsurance/core/currency/CurrencyAuditExportTest.java

### Frontend Files
(無)
