# File: tasks/TASK-007/TASK-007-03_Frontend.md
# TASK-007-03: 結算幣別清單檢索、多維篩選、即時金額範例計算列與 Excel 匯出 (SC-0101-02-01)

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 使用案例：`tasks/TASK-007/specs/USE_CASE_SPEC/Currency_USE_CASE_SPEC.md` (UC-CUR-01, UC-CUR-08)
  - 系統/API設計：`tasks/TASK-007/specs/SD_SPEC/Currency_SD_SPEC.md` (§2.1 GET 清單, §2.7 匯出 Excel)
  - 前端架構：`tasks/TASK-007/specs/UI_SPEC/Currency_UI_SPEC.md` (§2.1 mockups/1.jpg 對齊)
  - 設計稿對齊：`tasks/TASK-007/mockups/1.jpg`
  - 測試驗收規範：`tasks/TASK-007/specs/QA_SPEC/Currency_QA_SPEC.md` (TC-CUR-01, 10)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (§6.3.1 前端切片 1 規範, Core Web Vitals, Debounce, i18n)
- **業務背景**：提供「結算幣別選單」清單入口頁面，落實 4 欄檢索表單、動態金額範例即時格式化欄位、狀態框線徽章與 Excel 匯出。

### 驗收條件 (BDD 結構化規範)
- **場景 1 (Page Mount & Layout 呈現 - 100% 對齊 mockups/1.jpg)**：
  - **Given**: 使用者訪問 `/settings/menus/currencies`。
  - **When**: 頁面加載。
  - **Then**: 呈現「結算幣別選單」清單畫面，標題代碼為 `SC-0101-02-01`，右上角展示 `[ 批次匯入 ]` (白底灰框) 與 `[ + 新增幣別 ]` (`bg-[#374151]` 炭灰)。
- **場景 2 (多維檢索篩選列 - 100% 對齊 mockups/1.jpg)**：
  - **Given**: 檢索表單載入完畢。
  - **When**: 第一列輸入幣別代碼（`請輸入 ISO 4217 代碼`）、幣別中文名稱（`模糊查詢`）、幣別英文名稱（`模糊查詢`）、進位設定下拉（全部/四捨五入/無條件進位/無條件捨去/四捨六入五成雙）；第二列選擇資料狀態（原生 Radio：`◎有效 ○已作廢 ○全部`）。
  - **Then**: 點擊「查詢」或 300ms 防抖觸發篩選；點擊「清除條件」清空所有輸入；按鈕配色嚴格遵循 `#374151` 與白底灰框規範。
- **場景 3 (表格欄位與即時金額範例計算列 - 100% 對齊 mockups/1.jpg)**：
  - **Given**: 查詢結果回傳。
  - **When**: 表格渲染。
  - **Then**: 表格欄位嚴格對齊：
    1. `顯示順序 ⇅` (靠左/居中)
    2. `幣別代碼` (字體加粗 `font-bold font-mono`)
    3. `幣別中文名稱`
    4. `幣別英文名稱`
    5. `進位設定` (中文名稱)
    6. `小數位數`
    7. `金額範例` (依該幣別之進位設定與小數即時格式化，千分位呈現，如 `1,234` 或 `1,234.57`)
    8. `狀態` (有效為綠色外框徽章 `border border-green-600 text-green-700 bg-white`；已作廢為灰色外框徽章 `border border-gray-400 text-gray-500 bg-gray-50`)
    9. `功能` (`檢視/編輯` 純文字連結，`whitespace-nowrap` 嚴禁折行)
- **場景 4 (分頁聯動與匯出 Excel - 100% 對齊 mockups/1.jpg)**：
  - **Given**: 結果總筆數展示於結果列左側 (`查詢結果：共 X 筆`)。
  - **When**: 點擊右側 `[ 匯出 Excel ]` 按鈕。
  - **Then**: 觸發下載包含當前查詢條件之 Excel 報表；切換每頁筆數 (20/50/100) 與分頁頁碼平滑刷新。
- **場景 5 (i18n & 基礎基線合規 - next-intl)**：
  - 所有介面文字、標籤、表頭登錄至 `apps/web-portal/src/locales/zh-TW.json` 與 `en-US.json` 之 `system.currency.*` 命名空間，一律使用 `useTranslations()` Hook，嚴禁 JSX 內寫死中文。
  - API Base URL 預設為 `http://localhost:8080`，支援反向代理。
- **場景 6 (Quality Gate)**：
  - 執行 `npx tsc --noEmit` 型別檢查 0 錯誤。

## 2. 影響範圍與檔案清單 (Scope)
> 注意：本任務為純前端任務，後端清單必須完全留空。

### Backend Files
(無)

### Frontend Files
- src/app/(portal)/settings/menus/currencies/page.tsx
- src/components/menus/currency/CurrencyListTable.tsx
- src/components/menus/currency/CurrencySearchForm.tsx
- src/services/currency-api.ts
- src/locales/zh-TW.json (增量)
- src/locales/en-US.json (增量)
