# 結算幣別模組資料庫架構與實體模型規格書 (Database Architecture & DDL Spec)

> **模組代碼**：`TASK-007`  
> **關聯資料表**：`currencies`, `currency_audit_logs`  
> **外部引用關聯表**：`reinsurance_treaties`, `transaction_records`, `bank_payment_configs`  
> **目標資料庫**：PostgreSQL 16  
> **文件版本**：v2.0 (對齊 M 級時間戳 Migration、1,000 QPS B-Tree 索引、樂觀鎖與全欄位審計)  
> **負責角色**：Lead DBA / Data Architect  
> **關聯架構決策**：`ADR-001` (審計表設計), `ADR-003` (1,000 QPS 與索引覆蓋)  

---

## 1. 實體關聯模型 (Entity Relationship Diagram)

```mermaid
erDiagram
    CURRENCIES ||--o{ CURRENCY_AUDIT_LOGS : "全欄位異動審計"
    CURRENCIES ||--o{ REINSURANCE_TREATIES : "合約結算幣別引用"
    CURRENCIES ||--o{ TRANSACTION_RECORDS : "帳單與賠款明細引用"
    CURRENCIES ||--o{ BANK_PAYMENT_CONFIGS : "金融機構收付款設定引用"

    CURRENCIES {
        bigint id PK "內部主鍵 (自增)"
        varchar code UK "ISO 4217 幣別代碼 (3碼, 業務主鍵)"
        varchar name_zh "幣別中文名稱"
        varchar name_en "幣別英文名稱 (全名)"
        int sort_order "顯示順序 (越小越前)"
        varchar rounding_rule "進位設定 (枚舉)"
        int decimal_places "小數位數 (0~4)"
        varchar status "資料狀態 (ACTIVE / INACTIVE)"
        timestamp last_calc_rule_changed_at "最後設定異動日"
        varchar created_by "建立人員"
        timestamp created_at "建立時間"
        varchar updated_by "最後異動人員"
        timestamp updated_at "最後異動時間"
        bigint version "樂觀鎖版本號 (預設 0)"
    }

    CURRENCY_AUDIT_LOGS {
        bigint id PK "流水號"
        varchar currency_code FK "幣別代碼"
        timestamp changed_at "異動時間"
        varchar changed_by "異動人員"
        varchar department "所屬部門"
        varchar field_name "異動欄位"
        varchar before_value "異動前值"
        varchar after_value "異動後值"
        varchar change_reason "異動原因 / 依據"
    }
```

---

## 2. 資料字典 (Data Dictionary)

### 2.1 結算幣別主檔 (`currencies`)

| 欄位名稱 (Physical Name) | 資料型別 (Type) | 允許空值 | 預設值 | 業務定義與規範說明 |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `BIGINT GENERATED ALWAYS AS IDENTITY` | NO | — | 系統內部唯一主鍵。 |
| `code` | `VARCHAR(3)` | NO | — | **業務主鍵**。嚴格遵循 ISO 4217 三位大寫英文字母（如 `USD`, `TWD`）。全域唯一 B-Tree 索引。 |
| `name_zh` | `VARCHAR(50)` | NO | — | 幣別中文名稱。支援模糊查詢。建立 B-Tree 索引加速。 |
| `name_en` | `VARCHAR(100)` | NO | — | 幣別英文全名。 |
| `sort_order` | `INT` | NO | `0` | 下拉選單顯示順序。建立 B-Tree 索引加速排序。 |
| `rounding_rule` | `VARCHAR(20)` | NO | `'ROUND_HALF_UP'` | 運算進位規則枚舉。 |
| `decimal_places` | `INT` | NO | `2` | 計算採用之小數位數 (0~4)。 |
| `status` | `VARCHAR(20)` | NO | `'ACTIVE'` | 資料狀態：`ACTIVE`, `INACTIVE`。建立狀態索引。 |
| `last_calc_rule_changed_at` | `TIMESTAMP WITH TIME ZONE` | YES | `NULL` | 最後計算規則異動時間戳。 |
| `created_by` | `VARCHAR(50)` | NO | `'SYSTEM'` | 記錄初始建立帳號。 |
| `created_at` | `TIMESTAMP WITH TIME ZONE` | NO | `CURRENT_TIMESTAMP` | 建立時間（UTC）。 |
| `updated_by` | `VARCHAR(50)` | NO | `'SYSTEM'` | 最後更新帳號。 |
| `updated_at` | `TIMESTAMP WITH TIME ZONE` | NO | `CURRENT_TIMESTAMP` | 最後更新時間（UTC）。 |
| `version` | `BIGINT` | NO | `0` | **樂觀鎖版本號**。每次更新自動遞增，防禦並發覆蓋衝突。 |

---

### 2.2 結算幣別異動稽核日誌 (`currency_audit_logs`)

| 欄位名稱 (Physical Name) | 資料型別 (Type) | 允許空值 | 預設值 | 業務定義與規範說明 |
| :--- | :--- | :--- | :--- | :--- |
| `id` | `BIGINT GENERATED ALWAYS AS IDENTITY` | NO | — | 日誌主鍵。 |
| `currency_code` | `VARCHAR(3)` | NO | — | 關聯之幣別代碼。建立複合索引 `(currency_code, changed_at DESC)`。 |
| `changed_at` | `TIMESTAMP WITH TIME ZONE` | NO | `CURRENT_TIMESTAMP` | 異動時間（UTC）。 |
| `changed_by` | `VARCHAR(50)` | NO | — | 異動人員姓名或帳號。 |
| `department` | `VARCHAR(50)` | YES | `NULL` | 異動人員所屬部門。 |
| `field_name` | `VARCHAR(50)` | NO | — | 異動欄位識別（覆蓋全欄位：進位、小數、名稱、排序、狀態）。 |
| `before_value` | `VARCHAR(255)` | YES | `NULL` | 變更前值。 |
| `after_value` | `VARCHAR(255)` | NO | — | 變更後值。 |
| `change_reason` | `VARCHAR(500)` | NO | — | **異動原因**（重大欄位強制人工填寫，基本欄位預設「基本資料常規維護」）。 |

---

## 3. 生產級 DDL 遷移腳本 (強制時間戳版號規範 - M 級標準)

```sql
-- V20261012110000__create_currencies_and_audit.sql
CREATE TABLE IF NOT EXISTS currencies (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    code VARCHAR(3) NOT NULL,
    name_zh VARCHAR(50) NOT NULL,
    name_en VARCHAR(100) NOT NULL,
    sort_order INT NOT NULL DEFAULT 0,
    rounding_rule VARCHAR(20) NOT NULL DEFAULT 'ROUND_HALF_UP',
    decimal_places INT NOT NULL DEFAULT 2,
    status VARCHAR(20) NOT NULL DEFAULT 'ACTIVE',
    last_calc_rule_changed_at TIMESTAMP WITH TIME ZONE,
    created_by VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
    updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    version BIGINT NOT NULL DEFAULT 0,
    CONSTRAINT uk_currencies_code UNIQUE (code),
    CONSTRAINT chk_currencies_code_format CHECK (code ~ '^[A-Z]{3}$'),
    CONSTRAINT chk_currencies_rounding_rule CHECK (rounding_rule IN ('ROUND_HALF_UP', 'ROUND_UP', 'ROUND_DOWN', 'ROUND_HALF_EVEN')),
    CONSTRAINT chk_currencies_decimal_places CHECK (decimal_places BETWEEN 0 AND 4),
    CONSTRAINT chk_currencies_status CHECK (status IN ('ACTIVE', 'INACTIVE'))
);

-- 服務品質 1,000 QPS 查詢覆蓋索引 (B-Tree Indexes)
CREATE INDEX IF NOT EXISTS idx_currencies_code ON currencies(code);
CREATE INDEX IF NOT EXISTS idx_currencies_sort_order ON currencies(sort_order);
CREATE INDEX IF NOT EXISTS idx_currencies_status ON currencies(status);
CREATE INDEX IF NOT EXISTS idx_currencies_name_zh ON currencies(name_zh);

CREATE TABLE IF NOT EXISTS currency_audit_logs (
    id BIGINT GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
    currency_code VARCHAR(3) NOT NULL,
    changed_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT CURRENT_TIMESTAMP,
    changed_by VARCHAR(50) NOT NULL,
    department VARCHAR(50),
    field_name VARCHAR(50) NOT NULL,
    before_value VARCHAR(255),
    after_value VARCHAR(255) NOT NULL,
    change_reason VARCHAR(500) NOT NULL
);

-- 複合索引優化抽屜歷史查詢 (P95 < 50ms)
CREATE INDEX IF NOT EXISTS idx_currency_audit_code_time ON currency_audit_logs(currency_code, changed_at DESC);
```

---

## 4. 種子資料與初始化資料 (Seed Data)

```sql
INSERT INTO currencies (code, name_zh, name_en, sort_order, rounding_rule, decimal_places, status, version, created_by, updated_by)
VALUES
    ('TWD', '新台幣', 'New Taiwan Dollar', 10, 'ROUND_HALF_UP', 0, 'ACTIVE', 0, 'SYSTEM', 'SYSTEM'),
    ('USD', '美元', 'US Dollar', 20, 'ROUND_HALF_UP', 2, 'ACTIVE', 0, 'SYSTEM', 'SYSTEM'),
    ('JPY', '日圓', 'Japanese Yen', 30, 'ROUND_DOWN', 0, 'ACTIVE', 0, 'SYSTEM', 'SYSTEM'),
    ('EUR', '歐元', 'Euro', 40, 'ROUND_HALF_UP', 2, 'ACTIVE', 0, 'SYSTEM', 'SYSTEM'),
    ('DEM', '德國馬克', 'Deutsche Mark', 50, 'ROUND_HALF_UP', 2, 'INACTIVE', 0, 'SYSTEM', 'SYSTEM')
ON CONFLICT (code) DO NOTHING;

INSERT INTO currency_audit_logs (currency_code, changed_at, changed_by, department, field_name, before_value, after_value, change_reason)
VALUES 
    ('USD', CURRENT_TIMESTAMP - INTERVAL '2 days', '陳志豪', '財務精算部', '進位設定', '四捨五入 (ROUND_HALF_UP)', '四捨六入五成雙 (ROUND_HALF_EVEN)', '配合 2026 金融監理新制結算規範修訂'),
    ('USD', CURRENT_TIMESTAMP - INTERVAL '15 days', '林怡君', '再保業務處', '小數位數', '4', '2', '簡化財務報表小數顯示'),
    ('TWD', CURRENT_TIMESTAMP - INTERVAL '30 days', '系統管理員', '資訊技術部', '顯示順序', '0', '10', '系統初始建檔與順序重排')
ON CONFLICT DO NOTHING;
```
