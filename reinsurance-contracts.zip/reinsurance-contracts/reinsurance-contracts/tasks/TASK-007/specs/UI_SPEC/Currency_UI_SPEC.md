# 結算幣別前端介面與元件架構規格書 (Frontend UI Specification)

> **畫面編號**：`SC-0101-02-01`, `SC-0101-02-02`, `SC-0101-02-03`  
> **模組代碼**：`TASK-007`  
> **對齊設計稿**：`mockups/1.jpg`, `mockups/2.jpg`, `mockups/3.jpg`  
> **設計規範依據**：`apps/web-portal/DESIGN_CONVENTIONS.md`  

---

## 1. 元件架構樹 (Component Hierarchy Tree)

```text
CurrencyManagementPage (/settings/menus/currencies)
├── MenuHeaderTabs (一級選單導航 Tab)
└── MenuCardFrame (主卡片容器)
    ├── ScreenHeader (結算幣別選單 SC-0101-02-01 + [批次匯入] + [+ 新增幣別])
    ├── CurrencySearchForm (查詢條件表單 - 代碼/中文/英文/進位/狀態/查詢/清除)
    ├── CurrencyListTable (清單表格 - 排序/代碼/名稱/進位/小數/金額範例/狀態/檢視編輯)
    ├── CurrencyPagination (分頁控制列)
    │
    ├── CurrencyFormModal (SC-0101-02-02: 新增彈窗)
    │   ├── CalculationPreviewCard (即時試算預覽卡片: 正負數 1,234.5678 試算)
    │   └── ModalActions ([取消] [儲存並繼續新增] [儲存])
    │
    ├── CurrencyDetailDrawer (SC-0101-02-03: 維護側邊抽屜)
    │   ├── DrawerHeader ([返回列表] | [刪除] | [設為作廢] | [編輯])
    │   ├── DrawerTabs (Folder Tab: [基本資料] | [異動紀錄])
    │   ├── WarningBanner (變更計算設定之影響警示橫幅)
    │   ├── CalculationPreviewCard (試算預覽)
    │   ├── ReferenceSummaryTable (資料引用狀況統計表格: 合約/交易/銀行設定)
    │   └── AuditLogTable (最近 5 筆異動紀錄表格)
    │
    ├── CurrencyRuleChangeModal (計算規則變更二次確認 & 強制輸入異動原因)
    └── CurrencyDeleteConfirmModal (零引用安全刪除二次確認對話框)
```

---

## 2. 設計稿逐圖對齊規範 (Mockup Alignment)

### 2.1 結算幣別選單主畫面 (SC-0101-02-01, mockups/1.jpg)
- **查詢條件格柵 (4 欄)**：
  - 第 1 列：幣別代碼（`請輸入 ISO 4217 代碼`）、幣別中文名稱（`模糊查詢`）、幣別英文名稱（`模糊查詢`）、進位設定（下拉選單 `全部/四捨五入/無條件進位/無條件捨去/四捨六入五成雙`）。
  - 第 2 列：資料狀態（原生 Radio：`◎有效 ○已作廢 ○全部`）。
  - 按鈕靠右：`[ 清除條件 ]` (白底灰框) 與 `[ 查詢 ]` (`bg-[#374151]` 炭灰)。
- **結果列與表格**：
  - 結果列：左側 `查詢結果：共 X 筆`，右側 `[ 匯出 Excel ]` (白底灰框)。
  - 表格表頭：灰底 `bg-gray-100`，字體 `text-gray-700 font-semibold text-xs`。
  - 金額範例欄位：根據該列之 `進位設定` 與 `小數位數` 動態格式化範例數值（0位為 `1,234`，2位為 `1,234.57`），以千分位逗號呈現。
  - 狀態欄位：有效為綠色外框徽章 `border border-green-600 text-green-700 bg-white`；已作廢為灰色外框 `border border-gray-400 text-gray-500 bg-gray-50`。
  - 操作欄位：`檢視/編輯` 純文字連結，嚴禁折行 (`whitespace-nowrap`)。

---

### 2.2 結算幣別新增彈窗 (SC-0101-02-02, mockups/2.jpg)
- **標題與右上按鈕**：
  - 標題：`結算幣別選單 - 新增 SC-0101-02-02`。
  - 按鈕順序：`[ 取消 ]` (白底灰框) | `[ 儲存並繼續新增 ]` (`border border-orange-200 text-[#FF5A1F] bg-white hover:bg-orange-50`) | `[ 儲存 ]` (`bg-[#374151]` 炭灰)。
- **計算設定與即時預覽 (CalculationPreviewCard)**：
  - 進位設定下拉選單：四捨五入、無條件進位、無條件捨去、四捨六入五成雙。
  - 小數位數：數字輸入框 `0 ~ 4`。
  - **設定預覽方塊**：
    - 背景 `bg-gray-50 border border-gray-200 p-4 rounded`。
    - 顯示：
      - `計算原始值 1,234.5678 → 套用「{進位設定} / {小數位數} 位」後 {格式化正值}`
      - `負值檢核 -1,234.5678 → 套用同設定後 {格式化負值}`
    - 數值變動時即時觸發前端試算演算，讓使用者輸入時即可預覽確認。

---

### 2.3 結算幣別檢視/編輯抽屜 (SC-0101-02-03, mockups/3.jpg)
- **頂部 Header**：
  - 標題：`結算幣別選單 - 檢視/編輯 SC-0101-02-03 [ 檢視模式 ]`。
  - 按鈕順序 (檢視模式)：`[ 返回列表 ]` | `[ 設為作廢 / 重新啟用 ]` | `[ 編輯 ]` (`bg-[#374151]`)。若尚未被引用，亦提供 `[ 刪除 ]`。
  - 按鈕順序 (編輯模式)：`[ 取消 ]` | `[ 儲存 ]` (`bg-[#374151]`)。
- **資料夾卡片頁籤 (Folder Tab)**：
  - 統一卡片頁籤：`[ 基本資料 ]` | `[ 異動紀錄 ]`。
  - 作用中頁籤：白底黑字粗體 `border-t border-l border-r border-gray-300 -mb-px z-10`，與下方卡片內容無縫接合。
- **計算設定變更警示橫幅 (Warning Banner)**：
  - 琥珀色/黃色警示邊框橫幅：`border border-amber-300 bg-amber-50/80 p-3.5 text-xs text-amber-900`。
  - 內文：`⚠️ 變更計算設定之影響：進位設定或小數位數異動後，僅適用於變更後之新交易；既有合約與歷史交易金額不重算。變更時系統應跳出確認訊息並強制輸入異動原因。`
- **資料引用狀況統計表格**：
  - 欄位：`引用模組` | `筆數` | `說明`。
  - 包含三行：
    1. 再保合約 (結算幣別) / 86 筆 / 因已被引用，本筆資料不可刪除，僅可標記作廢。
    2. 交易資料 (再保費/佣金/賠款) / 1,432 筆 / 作廢後歷史交易仍可正常查詢與續用。
    3. 金融機構收付款設定 / 7 筆 / 作廢後不再出現於新增收付款設定之下拉選單。
- **異動紀錄表格 (最近 5 筆)**：
  - 欄位：`異動時間` | `異動人員` | `異動欄位` | `異動前` | `異動後` | `異動原因/依據`。

---

## 3. 金額進位預覽即時演算函數 (Format Utility)

```typescript
export function calculatePreview(
  amount: number,
  roundingRule: 'ROUND_HALF_UP' | 'ROUND_UP' | 'ROUND_DOWN' | 'ROUND_HALF_EVEN',
  decimalPlaces: number
): string {
  // 基於 Decimal.js 或精確算術，支援四捨五入、無條件進位、無條件捨去、銀行家捨入
  // 並格式化為具千分位逗號字串 (例如 "1,234.57")
}
```
