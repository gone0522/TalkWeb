# 結算幣別模組測試策略與驗收追溯規格書 (QA & Test Strategy)

> **模組代碼**：`TASK-007`  
> **文件版本**：v2.0 (對齊 QoS 1,000 QPS 壓測指標、死按鈕禁令驗收、全欄位審計矩陣斷言)  
> **負責角色**：QA Lead / SDET  
> **關聯架構決策**：`ADR-001`, `ADR-003`, `ADR-004`  

---

## 1. 需求與測試追溯矩陣 (Traceability Matrix: BR -> UC -> TC)

| 業務規則 | 使用案例 | 測試案例代碼 | 測試驗收重點 | 自動化層級 |
| :--- | :--- | :--- | :--- | :--- |
| **BR-CUR-01** | UC-CUR-03 | **TC-CUR-01** | ISO 4217 三碼正則檢核、重複代碼 409 Conflict 斷言 | Unit / Integration |
| **BR-CUR-02** | UC-CUR-04 | **TC-CUR-02** | 編輯模式下幣別代碼鎖定唯讀與 🔒 圖示渲染 | E2E / Component |
| **BR-CUR-03** | UC-CUR-07 | **TC-CUR-03** | 已引用幣別禁止刪除；零引用幣別安全刪除二次確認 | Unit / Integration |
| **BR-CUR-04** | UC-CUR-06 | **TC-CUR-04** | 作廢狀態切換，作廢後排除於下拉選單 API 之斷言 | Integration |
| **BR-CUR-05** | UC-CUR-02 | **TC-CUR-05** | 四種進位設定 (HALF_UP, UP, DOWN, HALF_EVEN) 金額演算斷言 | Unit Test (TDD) |
| **BR-CUR-06** | UC-CUR-02 | **TC-CUR-06** | 小數位數 0~4 邊界值驗證，<0 或 >4 阻擋報錯 | Unit / Integration |
| **BR-CUR-07** | UC-CUR-05 | **TC-CUR-07** | 計算設定變更強制要求原因，未填寫阻擋送出 | Integration / E2E |
| **BR-CUR-08** | UC-CUR-04, 05, 06 | **TC-CUR-08** | **全欄位異動審計矩陣測試 (計算設定、中英文名稱、排序、狀態)，嚴禁反向斷言** | Integration |
| **BR-CUR-09** | UC-CUR-03 | **TC-CUR-09** | 新增時建議排序自動推算 (Max + 10) 驗證 | Unit Test |
| **BR-EXCEL**  | UC-CUR-08 | **TC-CUR-10** | 依查詢條件真實端到端匯出 Excel 下載斷言 | Integration / E2E |
| **BR-NO-OP**  | UC-CUR-09 | **TC-CUR-11** | **按鈕真實性與死按鈕禁令：批次匯入必須 disabled 且 hover 提示「即將推出」** | E2E / UI Test |
| **BR-LOCK**   | UC-CUR-04 | **TC-CUR-12** | **樂觀鎖併發衝突驗證：版本不符回傳 409 Conflict 與前端重載彈窗** | Integration / E2E |
| **BR-QOS**    | UC-CUR-01 | **TC-CUR-13** | **服務品質效能門檻：1,000 QPS 讀取壓測 P95 < 100ms 驗收** | Performance |

---

## 2. 核心邊界、負面與架構防禦測試案例 (Negative & Architectural Cases)

1. **進位演算極端值測試 (TC-CUR-05)**：
   - 數值 `1234.5650` 在 `ROUND_HALF_UP` 且 2 位小數時，斷言為 `1234.57`。
   - 數值 `1234.5650` 在 `ROUND_HALF_EVEN` 且 2 位小數時，前一位為偶數 6，斷言為 `1234.56`。
   - 數值 `1234.5750` 在 `ROUND_HALF_EVEN` 且 2 位小數時，前一位為奇數 7，斷言為 `1234.58`。
   - 負數 `-1234.5678` 在 `ROUND_DOWN` 且 2 位小數時，斷言為 `-1234.56`。
2. **小數位數邊界檢核 (TC-CUR-06)**：
   - 輸入 `-1`：回傳 400 Bad Request，提示 `小數位數不可小於 0`。
   - 輸入 `5`：回傳 400 Bad Request，提示 `小數位數不可大於 4`。
   - 輸入 `0` (如 JPY)：正常通過，金額格式化無小數點。
   - 輸入 `4`：正常通過，金額格式化支援 4 位小數。
3. **全欄位審計留痕矩陣測試 (TC-CUR-08 - 嚴禁反向斷言)**：
   - 修改名稱：斷言 `currency_audit_logs` 增加 1 筆，`field_name == 'nameZh'`。
   - 修改排序：斷言增加 1 筆，`field_name == 'sortOrder'`。
   - 修改狀態：斷言增加 1 筆，`field_name == 'status'`。
   - 嚴禁出現 `assertTrue(logs.isEmpty())` 反向掩飾。
4. **按鈕真實性與死按鈕防呆測試 (TC-CUR-11)**：
   - 點擊「匯出 Excel」按鈕：斷言發出 `GET /api/v1/currencies/export` 並觸發二進位檔案下載。
   - 檢查「批次匯入」按鈕：斷言其 DOM 屬性包含 `disabled`，滑鼠 hover 時 Tooltip 包含文字 `「即將推出」`，且點擊不發出任何 HTTP 請求。
5. **樂觀鎖併發衝突驗證 (TC-CUR-12)**：
   - 模擬使用者 A 與 B 同時讀取版本 `version = 0`。
   - 使用者 A 更新成功，資料庫 `version` 遞增至 1。
   - 使用者 B 送出版本 0，斷言後端回傳 HTTP 409 Conflict (`ERR_OPTIMISTIC_LOCK_CONFLICT`)，前端跳出重新載入通知。
