# 結算幣別模組系統設計與 API 契約規格書 (System Design & API Specification)

> **模組代碼**：`TASK-007`  
> **畫面代碼**：`SC-0101-02-01`, `SC-0101-02-02`, `SC-0101-02-03`  
> **API 基礎路徑**：`/api/v1/currencies`  
> **文件版本**：v2.0 (對齊雙軌規格、S/M/L 分級模型、1,000 QPS 基準與企業級 NFR)  
> **負責角色**：Software Architect / Backend Tech Lead  
> **關聯架構決策**：`ADR-001` (全欄位審計與假按鈕禁令), `ADR-002` (雙軌規格), `ADR-003` (QoS 基準)  
> **AI 機器執行軌對應**：`tasks/TASK-007/manifest.yaml`  

---

## 1. 架構分層、服務品質與責任邊界 (Architectural Blueprint & QoS Baseline)

### 1.1 架構分層拓撲
```mermaid
flowchart LR
    subgraph Client [Web Portal (Next.js 14 App Router)]
        Page[SC-0101-02-01 List Page]
        Modal[SC-0101-02-02 Add Modal]
        Drawer[SC-0101-02-03 Detail Drawer]
        SafeBtn[SafeActionButton / Dummy Guard]
    end

    subgraph CoreService [Spring Boot 3 Core Service]
        MDCFilter[TraceId & MDC Filter]
        IdemFilter[Idempotency Filter (X-Request-Id)]
        Controller[CurrencyController]
        AuditController[CurrencyAuditController]
        ExportController[CurrencyExportController]
        Service[CurrencyService]
        AuditService[CurrencyAuditService]
        Repo[CurrencyRepository]
        AuditRepo[CurrencyAuditLogRepository]
    end

    subgraph Database [PostgreSQL 16]
        DB_Currencies[(currencies)]
        DB_Audit[(currency_audit_logs)]
    end

    Client -->|X-Trace-Id / X-Request-Id| MDCFilter
    MDCFilter --> IdemFilter
    IdemFilter --> Controller
    Controller --> Service
    AuditController --> AuditService
    Service --> Repo
    AuditService --> AuditRepo
    Repo --> DB_Currencies
    AuditRepo --> DB_Audit
```

### 1.2 服務品質基準 (SLA / QoS Budget - M 級基準)
依據 `ADR-003` 與工程標準指引 §29，本模組落實以下服務品質門檻：
- **吞吐量目標**：常態承載 300~500 QPS，尖峰承受 **1,000 QPS** 併發查詢。
- **讀取延遲預算**：**P95 < 100ms**，P99 < 200ms（經本機連線池壓測驗證）。
- **寫入延遲預算**：**P95 < 250ms**，P99 < 500ms（含樂觀鎖檢查與全欄位審計寫入）。
- **前端繪製效能**：首次內容繪製 (FCP) < 1.0s，最大內容繪製 (LCP) < 2.0s。
- **資料庫連線池調優 (HikariCP)**：
  - `maximum-pool-size`: 20
  - `minimum-idle`: 10
  - `connection-timeout`: 3000ms（快速失敗）
- **萬級擴展預留**：查詢方法採用標準 Spring `@Cacheable(value = "currencies")`，隨時可無縫切換 Redis 二級快取。

---

## 2. 企業級六大 NFR 實作規範 (Enterprise Non-Functional Requirements)

1. **冪等性與防重複送出 (Idempotency Guard)**：
   - 寫入端點 (`POST`, `PUT`) 支援請求標頭 `X-Request-Id: <UUID>`。
   - 前端表單送出按鈕強制使用節流防連點機制，點擊後立即 `disabled` 並呈現載入轉圈 (Spinner)。
2. **併發衝突與樂觀鎖 (Concurrency & Optimistic Locking)**：
   - 實體與所有查詢 DTO 均包含 `version: Long`。
   - 更新或作廢請求必須帶入原版本號；若資料庫版本不符，後端回傳 **HTTP 409 Conflict** (`ERR_OPTIMISTIC_LOCK_CONFLICT`)，前端彈窗提示並提供「重新載入」按鈕。
3. **可觀測性與鏈路追蹤 (Distributed Tracing)**：
   - 前端發出請求自動附加 `X-Trace-Id: <UUID>`；後端日誌 MDC 打印 `[traceId]`，全鏈路可追溯。
4. **機密脫敏與資安防禦 (Data Masking & PII Hygiene)**：
   - 系統錯誤時嚴禁回傳 Java Exception 堆疊 (Stacktrace) 給前端，一律轉換為標準 `ErrorResponse`。
5. **容錯與彈性 (Resilience & Circuit Breaker)**：
   - 連線資料庫設定 3 秒超時；呼叫外部匯率 API 預留 3 秒 CircuitBreaker 斷路機制。
6. **冷熱資料生命週期 (Data Lifecycle & Retention)**：
   - 異動審計日誌 `currency_audit_logs` 支援時間索引 `idx_currency_audit_code_time`，歷史資料預留依年/月分區機制。

---

## 3. 按鈕真實性與功能交付標籤 (Action Button Delivery Matrix)

依據 `ADR-001` 空殼假按鈕禁令，所有畫面元素必須明確標示交付狀態：

| 畫面代碼 | 按鈕名稱 | 交付類型 | 行為規範與端點綁定 |
| :--- | :--- | :--- | :--- |
| `SC-0101-02-01` | **「查詢」** | `[完整交付 (Full-Delivery)]` | 發出 `GET /api/v1/currencies` 進行清單條件檢索。 |
| `SC-0101-02-01` | **「重設」** | `[完整交付 (Full-Delivery)]` | 清空表單並恢復預設查詢條件。 |
| `SC-0101-02-01` | **「新增幣別」** | `[完整交付 (Full-Delivery)]` | 彈出新增 Modal (`SC-0101-02-02`) 並發出 `POST /api/v1/currencies`。 |
| `SC-0101-02-01` | **「匯出 Excel」** | `[完整交付 (Full-Delivery)]` | 發出 `GET /api/v1/currencies/export` 進行端到端真實檔案下載。 |
| `SC-0101-02-01` | **「批次匯入」** | `[介面預留 (UI-Placeholder)]` | **後端無 API，按鈕必須 `disabled={true}` 且 hover 提示「功能即將推出」**，嚴禁無事件假按鈕。 |
| `SC-0101-02-03` | **「儲存變更」** | `[完整交付 (Full-Delivery)]` | 發出 `PUT /api/v1/currencies/{code}`，帶入樂觀鎖 `version` 與異動原因。 |
| `SC-0101-02-03` | **「狀態切換」** | `[完整交付 (Full-Delivery)]` | 發出 `PATCH /api/v1/currencies/{code}/status` 切換啟用/作廢。 |

---

## 4. RESTful API 契約詳細定義 (REST Endpoints)

### 4.1 結算幣別分頁查詢 (`GET /api/v1/currencies`)
* **用途**：清單檢索與多維條件過濾（對齊 SC-0101-02-01）。
* **Headers**：`X-Trace-Id` (optional, UUID)
* **Query Parameters**：
  - `keyword` (String, optional): 模糊比對幣別代碼、中文名稱、英文名稱。
  - `code` (String, optional): 幣別代碼精確比對（不分大小寫）。
  - `nameZh` (String, optional): 幣別中文名稱模糊查詢。
  - `nameEn` (String, optional): 幣別英文名稱模糊查詢。
  - `roundingRule` (String, optional): 進位設定列舉篩選 (`ROUND_HALF_UP`, `ROUND_UP`, `ROUND_DOWN`, `ROUND_HALF_EVEN`)。
  - `status` (String, optional): 狀態過濾 (`ACTIVE`, `INACTIVE`, 不傳代表全部)。
  - `page` (int, default: 0): 頁碼。
  - `size` (int, default: 20): 每頁筆數。
  - `sort` (String, default: "sortOrder,asc"): 排序規則。
* **Response (200 OK)**：
```json
{
  "content": [
    {
      "id": 1,
      "code": "TWD",
      "nameZh": "新台幣",
      "nameEn": "New Taiwan Dollar",
      "sortOrder": 10,
      "roundingRule": "ROUND_HALF_UP",
      "roundingRuleNameZh": "四捨五入",
      "decimalPlaces": 0,
      "exampleAmount": "1,235",
      "status": "ACTIVE",
      "lastCalcRuleChangedAt": null,
      "version": 0
    },
    {
      "id": 2,
      "code": "USD",
      "nameZh": "美元",
      "nameEn": "US Dollar",
      "sortOrder": 20,
      "roundingRule": "ROUND_HALF_UP",
      "roundingRuleNameZh": "四捨五入",
      "decimalPlaces": 2,
      "exampleAmount": "1,234.57",
      "status": "ACTIVE",
      "lastCalcRuleChangedAt": "2026-07-15T11:20:00Z",
      "version": 3
    }
  ],
  "totalElements": 28,
  "totalPages": 2,
  "size": 20,
  "number": 0
}
```

---

### 4.2 結算幣別單筆詳情與引用統計 (`GET /api/v1/currencies/{code}`)
* **用途**：喚起檢視/編輯維護抽屜（對齊 SC-0101-02-03）。
* **Response (200 OK)**：
```json
{
  "code": "USD",
  "nameZh": "美元",
  "nameEn": "US Dollar",
  "sortOrder": 20,
  "roundingRule": "ROUND_HALF_UP",
  "roundingRuleNameZh": "四捨五入",
  "decimalPlaces": 2,
  "status": "ACTIVE",
  "lastCalcRuleChangedAt": "2026-07-15T11:20:00Z",
  "references": {
    "totalCount": 1525,
    "treatyCount": 86,
    "transactionCount": 1432,
    "bankSettingCount": 7,
    "isReferenced": true,
    "defenseNote": "因已被引用，本筆資料不可刪除，僅可標記作廢。"
  },
  "auditLogs": [
    {
      "id": 101,
      "changedAt": "2026-07-15T11:20:00Z",
      "changedBy": "陳志豪",
      "department": "財會部",
      "fieldName": "小數位數",
      "beforeValue": "4",
      "afterValue": "2",
      "changeReason": "配合結算報表格式調整；僅適用後續新交易"
    },
    {
      "id": 100,
      "changedAt": "2026-07-15T11:18:00Z",
      "changedBy": "陳志豪",
      "department": "財會部",
      "fieldName": "進位設定",
      "beforeValue": "無條件捨去",
      "afterValue": "四捨五入",
      "changeReason": "依 2026 年度會計政策修訂"
    }
  ],
  "systemInfo": {
    "createdBy": "系統管理者",
    "createdAt": "2026-01-08T10:02:00Z",
    "updatedBy": "陳志豪",
    "updatedAt": "2026-07-15T11:20:00Z",
    "version": 3
  }
}
```

---

### 4.3 新增結算幣別 (`POST /api/v1/currencies`)
* **Headers**：`X-Request-Id: <UUID>` (冪等性保護)
* **Request Body**：
```json
{
  "code": "GBP",
  "nameZh": "英鎊",
  "nameEn": "British Pound",
  "sortOrder": 60,
  "roundingRule": "ROUND_HALF_UP",
  "decimalPlaces": 2
}
```
* **校驗與防呆**：
  - `code`: 必填，正規表達式 `^[A-Z]{3}$`。若已存在回傳 409 Conflict (`ERR_DUPLICATE_CURRENCY_CODE`)。
  - `nameZh`: 必填，長度 1~50。
  - `nameEn`: 必填，長度 1~100。
  - `roundingRule`: 必填枚舉。
  - `decimalPlaces`: 必填整數，範圍 0~4。
  - `sortOrder`: 必填正整數。

---

### 4.4 更新結算幣別 (`PUT /api/v1/currencies/{code}`)
* **用途**：編輯幣別資料，支援樂觀鎖並發防護與全欄位異動稽核。
* **Headers**：`X-Request-Id: <UUID>`
* **Request Body**：
```json
{
  "nameZh": "美元 (修訂)",
  "nameEn": "US Dollar",
  "sortOrder": 20,
  "roundingRule": "ROUND_HALF_EVEN",
  "decimalPlaces": 2,
  "changeReason": "依金融主管機關指引改採銀行家捨入法",
  "version": 3
}
```
* **業務檢核與全欄位審計留痕 (ADR-001)**：
  - **計算設定變更審計**：若 `roundingRule` 或 `decimalPlaces` 變更，`changeReason` 必須非空且長度 ≥ 5，否則回傳 400 (`ERR_CHANGE_REASON_REQUIRED`)，更新並記錄至 `currency_audit_logs`。
  - **基本資料變更審計**：若 `nameZh`、`nameEn` 或 `sortOrder` 變更，系統自動寫入 `currency_audit_logs`，原因採使用者輸入或預設「基本資料常規維護」。
  - **狀態切換審計**：PATCH `/status` 狀態翻轉自動寫入 `currency_audit_logs`（資料狀態）。
  - **樂觀鎖檢核**：若傳入 `version` 與資料庫現行不一致，回傳 **409 Conflict** (`ERR_OPTIMISTIC_LOCK_CONFLICT`)。

---

### 4.5 快速狀態切換 (`PATCH /api/v1/currencies/{code}/status`)
* **Request Body**：`{ "status": "INACTIVE", "version": 3 }` 或 `{ "status": "ACTIVE", "version": 3 }`。

---

### 4.6 安全刪除 (`DELETE /api/v1/currencies/{code}`)
* **防呆約束**：
  - 若該幣別存在外部引用筆數 (`references.totalCount > 0`)，嚴格阻擋並回傳 409 Conflict (`ERR_CURRENCY_REFERENCED`)：`"本幣別已被業務模組引用，不可刪除，僅可標記作廢"`。
  - 若零引用，完成實體物理刪除並記錄稽核日誌。

---

### 4.7 匯出 Excel (`GET /api/v1/currencies/export`)
* **輸出**：`application/vnd.openxmlformats-officedocument.spreadsheetml.sheet` 檔案下載，包含欄位：顯示順序、幣別代碼、幣別中文名稱、幣別英文名稱、進位設定、小數位數、金額範例、狀態。
