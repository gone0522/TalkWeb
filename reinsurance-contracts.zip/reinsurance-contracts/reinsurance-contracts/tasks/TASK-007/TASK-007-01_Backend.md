# File: tasks/TASK-007/TASK-007-01_Backend.md
# TASK-007-01: 結算幣別 (Currency) 實體模型、四種捨入演算、分頁檢索、CRUD 與防刪保護 API

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 業務需求：`tasks/TASK-007/specs/SA_SPEC.md` (§4 業務規則 BR-CUR-01 ~ 06, 09)
  - 使用案例：`tasks/TASK-007/specs/USE_CASE_SPEC/Currency_USE_CASE_SPEC.md` (UC-CUR-01, 02, 03, 06, 07)
  - 資料模型：`tasks/TASK-007/specs/DBA_SPEC/Currency_DBA_SPEC.md` (currencies 表結構、約束與索引)
  - 系統/API詳細設計：`tasks/TASK-007/specs/SD_SPEC/Currency_SD_SPEC.md` (§2.1 GET, §2.3 POST, §2.4 PUT, §2.5 PATCH, §2.6 DELETE)
  - 測試驗收規範：`tasks/TASK-007/specs/QA_SPEC/Currency_QA_SPEC.md` (TC-CUR-01, 03, 04, 05, 06, 09)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (DDD, SOLID, TDD, OWASP SQLi, RFC 7807)
- **業務背景**：提供再保險多幣別結算之核心主檔維護，支援 ISO 4217 代碼、四種國際金融捨入規則演算、0~4 位小數精度配置、顯示順序自動推算與引用防刪除防護。

### 驗收條件 (BDD 結構化規範)
- **場景 1 (Query Path - 分頁檢索與多維過濾 - TC-CUR-01, UC-CUR-01)**：
  - **Given**: 資料庫中存在多筆幣別資料。
  - **When**: 發送 `GET /api/v1/currencies?keyword=美&roundingRule=ROUND_HALF_UP&status=ACTIVE&page=0&size=20&sort=sortOrder,asc`。
  - **Then**: 伺服器回傳 `HTTP 200 OK`，包含分頁主體與資料清單。每筆資料包含 `code`, `nameZh`, `nameEn`, `sortOrder`, `roundingRule`, `decimalPlaces`, `exampleAmount`, `status`，資料清單嚴格依 `sortOrder` 升冪排序。
- **場景 2 (Happy Path - 新增幣別與建議順序自動推算 - TC-CUR-09, UC-CUR-03)**：
  - **Given**: 使用者提供合法的幣別代碼（`"GBP"`）、中文名稱（`"英鎊"`）、英文全名（`"British Pound"`）、進位設定（`ROUND_HALF_UP`）、小數位數（`2`），未傳 `sortOrder`。
  - **When**: 發送 `POST /api/v1/currencies`。
  - **Then**: 伺服器回傳 `HTTP 201 Created`，資料庫落地，`sortOrder` 自動帶入現有最大值 + 10，狀態預設為 `ACTIVE`，樂觀鎖 `version = 0`。
- **場景 3 (Conflict Path - 代碼重複 409 Conflict - TC-CUR-01)**：
  - **Given**: 系統已存在代碼為 `"USD"` 之幣別。
  - **When**: 發送 `POST /api/v1/currencies` 且 `code` 為 `"USD"`。
  - **Then**: 伺服器回傳 `HTTP 409 Conflict`，錯誤碼為 `ERR_DUPLICATE_CURRENCY_CODE`，說明「幣別代碼 'USD' 已被使用」。
- **場景 4 (Validation Path - ISO 4217 與小數範圍防呆 400 - TC-CUR-06)**：
  - **Given**: 傳入代碼為小寫或非 3 碼字母（如 `"us"`, `"USDA"`），或小數位數 `< 0` 或 `> 4`。
  - **When**: 發送 `POST` 或 `PUT`。
  - **Then**: 伺服器回傳 `HTTP 400 Bad Request`，明確回傳欄位檢核錯誤。
- **場景 5 (Calculation Engine - 四種進位規則演算斷言 - TC-CUR-05, UC-CUR-02)**：
  - **Given**: 傳入基準測試值 `1234.5650` 與 `-1234.5678`。
  - **When**: 呼叫幣別金額格式化演算邏輯：
    - `ROUND_HALF_UP` 且 2 位小數：斷言為 `"1,234.57"`。
    - `ROUND_HALF_EVEN` 且 2 位小數：前一位 6 為偶數，五成雙捨去，斷言為 `"1,234.56"`。
    - `ROUND_DOWN` 且 2 位小數：斷言為 `"1,234.56"`；負數為 `"-1,234.56"`。
    - `ROUND_UP` 且 0 位小數（如 JPY/TWD）：`1234.5650` 斷言為 `"1,235"`。
  - **Then**: 演算輸出嚴格符合國際會計與 Java `BigDecimal.setScale` 規範。
- **場景 6 (Update Path - 基礎資訊修改與樂觀鎖防護)**：
  - **Given**: 存在 `code = "USD", version = 0` 之幣別。
  - **When**: 發送 `PUT /api/v1/currencies/USD`，更新 `nameZh: "美元 (修訂)"`, 帶入 `version: 0`。
  - **Then**: 伺服器回傳 `HTTP 200 OK`，`version` 遞增為 1；`code` 保持不變（主鍵不可修改）。若傳入錯誤 `version` 則回傳 `409 Conflict`。
- **場景 7 (Status Toggle Path - 快速作廢/啟用切換 - TC-CUR-04)**：
  - **When**: 發送 `PATCH /api/v1/currencies/USD/status`，Body 為 `{ "status": "INACTIVE" }`。
  - **Then**: 伺服器回傳 `HTTP 200 OK`，狀態切換為已作廢。
- **場景 8 (Referential Defense Path - 引用防刪除與零引用安全刪除 - TC-CUR-03)**：
  - **Given**: 幣別已被再保合約或交易資料引用 (`totalCount > 0`)。
  - **When**: 發送 `DELETE /api/v1/currencies/USD`。
  - **Then**: 伺服器阻擋並回傳 `HTTP 409 Conflict` (或 400)，錯誤碼 `ERR_CURRENCY_REFERENCED`，提示「本幣別已被業務模組引用，不可刪除，僅可標記作廢」。
  - **And**: 若幣別零引用，發送 `DELETE` 成功回傳 `204 No Content`，實體物理移除。
- **場景 9 (TDD 品質閘門)**：
  - 撰寫單元與整合測試 `CurrencyServiceTest.java` 與 `CurrencyControllerTest.java`，覆蓋率 100%，執行 `mvn test` 全數通過。

## 2. 影響範圍與檔案清單 (Scope)
> 注意：本任務為純後端任務，前端清單必須完全留空。

### Backend Files
- src/main/resources/db/migration/V3__create_currencies_and_audit.sql
- src/main/java/com/reinsurance/core/currency/entity/Currency.java
- src/main/java/com/reinsurance/core/currency/repository/CurrencyRepository.java
- src/main/java/com/reinsurance/core/currency/service/CurrencyService.java
- src/main/java/com/reinsurance/core/currency/controller/CurrencyController.java
- src/test/java/com/reinsurance/core/currency/CurrencyServiceTest.java
- src/test/java/com/reinsurance/core/currency/CurrencyControllerTest.java

### Frontend Files
(無)
