<!--
governance_metadata:
  last_reviewed: "2026-10-15"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-15"
  governance_status: "ACTIVE"
-->

# 金融機構測試驗收與品質閘門規格書 (Financial Institution QA Specification)

> **模組代碼**：`TASK-000013`  
> **目標**：落實 TDD、邊界測試、OWASP 資安檢核與 100% 自動化驗收  

---

## 1. 測試案例矩陣 (Test Case Matrix)

| 案例代碼 | 測試場景 | 輸入條件 | 預期結果 |
| :--- | :--- | :--- | :--- |
| **TC-FI-01** | 分頁檢索與多條件篩選 | 輸入代碼 `BOT`、國別 `TW`、狀態 `ACTIVE` | 回傳 `200 OK`，清單包含相符資料，依 `sortOrder` 升冪排序。 |
| **TC-FI-02** | 正常單筆新增與順序自動計算 | 輸入代碼 `BOT002`，未提供 `sortOrder` | 回傳 `201 Created`，資料庫落地，`sortOrder` 自動設為現有最大值 + 10。 |
| **TC-FI-03** | 代碼重複衝突檢驗 | 輸入已存在之代碼 `BOT001` | 回傳 `409 Conflict`，錯誤碼 `ERR_DUPLICATE_BANK_CODE`。 |
| **TC-FI-04** | SWIFT/BIC 格式檢核 | 輸入非法 SWIFT 代碼 `12345` (少於8位) | 回傳 `400 Bad Request`，包含格式校驗錯誤訊息。 |
| **TC-FI-05** | 受制裁國家建檔阻擋 | 選取制裁國別 `IR`，但未勾選主管同意核取方塊 | 前端禁止送出；後端若收到未同意請求回傳 `400 Bad Request`。 |
| **TC-FI-06** | 受制裁國家建檔主管授權放行 | 選取制裁國別 `IR`，勾選授權同意 | 回傳 `201 Created`，成功寫入審計日誌與授權標記。 |
| **TC-FI-07** | 被引用機構禁止物理刪除 | 刪除被收付款引用之機構 (`refCount > 0`) | 回傳 `400 Bad Request` (`ERR_BANK_REFERENCED_CANNOT_DELETE`)，實體資料保留。 |
| **TC-FI-08** | 無引用機構物理刪除 | 刪除無任何引用之測試機構 (`refCount == 0`) | 回傳 `204 No Content`，實體自資料庫完全移除。 |
| **TC-FI-09** | 樂觀鎖併發衝突檢驗 | 傳入過期之 `version` (如 999) 進行修改 | 回傳 `409 Conflict`，防止髒資料覆蓋。 |
| **TC-FI-10** | Excel 匯出二進位檔案檢核 | 點擊匯出按鈕 | 回傳 `200 OK`，Content-Type 為 xlsx，檔案內容包含完整標頭與資料。 |

---

## 2. 品質門禁 (Quality Gates)

1. 後端 `FinancialInstitutionServiceTest` 覆蓋率 > 90%，執行 `mvn test` 0 Failure 0 Error。
2. 前端 `npx tsc --noEmit` 型別檢查 0 Error。
3. 全系統執行 `python3 scripts/audit-specs.py` 5/5 閘門 100% 通過。
