<!--
governance_metadata:
  last_reviewed: "2026-10-15"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-15"
  governance_status: "ACTIVE"
-->

# 金融機構資料庫架構與實體模型規格書 (Financial Institution DBA Specification)

> **模組代碼**：`TASK-000013`  
> **關聯資料表**：`system_financial_institutions`  
> **目標資料庫**：PostgreSQL 16+  

---

## 1. 實體領域模型 (ERD)

```mermaid
erDiagram
    system_countries ||--o{ system_financial_institutions : "belongs_to (1:N)"
    
    system_financial_institutions {
        bigserial id PK "主鍵"
        varchar bank_code UK "機構唯一代碼 (如 BOT001)"
        varchar name_zh "機構中文名稱"
        varchar name_en "機構英文名稱"
        varchar swift_code "SWIFT/BIC 代碼 (8或11碼)"
        varchar country_code FK "所屬國家代碼 (參照 system_countries)"
        int sort_order "顯示順序"
        boolean is_disabled "是否作廢 (軟刪除)"
        boolean sanction_acknowledged "主管制裁授權確認旗標"
        bigint version "樂觀鎖版本號"
        timestamp created_at "建立時間"
        varchar created_by "建立者"
        timestamp updated_at "最後更新時間"
        varchar updated_by "最後更新者"
    }
```

---

## 2. 資料表綱要 (Data Dictionary: system_financial_institutions)

| 欄位名稱 (Column) | 實體型別 (Type) | 允許空值 | 預設值 | 限制條件 | 業務含義與設計說明 |
| :--- | :--- | :---: | :--- | :--- | :--- |
| `id` | `BIGSERIAL` | 否 | 自動遞增 | **Primary Key** | 內部實體流水主鍵。 |
| `bank_code` | `VARCHAR(20)` | 否 | 無 | **Unique** | 客戶自訂內部代碼（如 `BOT001`, `CTBC01`）。全域唯一，被引用後鎖定唯讀。 |
| `name_zh` | `VARCHAR(100)` | 否 | 無 | Not Blank | 金融機構中文標準名稱（如「台灣銀行」）。 |
| `name_en` | `VARCHAR(100)` | 否 | 無 | Not Blank | 金融機構英文標準名稱（如「Bank of Taiwan」）。 |
| `swift_code` | `VARCHAR(11)` | 是 | `NULL` | Regex | SWIFT/BIC 代碼，8 碼或 11 碼大寫英數字。國內無外幣機構可留空。 |
| `country_code` | `VARCHAR(3)` | 否 | 無 | **FK** | 所屬國家代碼，參照 `system_countries(country_code)`。 |
| `sort_order` | `INTEGER` | 否 | `0` | Min 0 | 介面顯示順序序號。新增時自動帶入現有最大值 + 10。 |
| `is_disabled` | `BOOLEAN` | 否 | `FALSE` | Boolean | 作廢停用旗標。`true` 表示作廢，不可於新增交易中選用。 |
| `sanction_acknowledged` | `BOOLEAN` | 否 | `FALSE` | Boolean | 若國別受制裁，標記是否已獲得權責主管同意建檔。 |
| `version` | `BIGINT` | 否 | `0` | Not Null | 樂觀鎖版本號，防止併發覆蓋。 |
| `created_at` | `TIMESTAMPTZ` | 否 | `CURRENT_TIMESTAMP` | | 建立時間戳記。 |
| `created_by` | `VARCHAR(50)` | 否 | `'SYSTEM'` | | 建立者帳號。 |
| `updated_at` | `TIMESTAMPTZ` | 否 | `CURRENT_TIMESTAMP` | | 最後異動時間戳記。 |
| `updated_by` | `VARCHAR(50)` | 否 | `'SYSTEM'` | | 最後異動者帳號。 |

---

## 3. 索引規劃 (Indexing Strategy)

```sql
-- 1. 機構代碼唯一業務約束索引
CREATE UNIQUE INDEX IF NOT EXISTS uk_system_financial_institutions_code 
    ON system_financial_institutions (bank_code);

-- 2. 顯示排序與狀態組合索引 (支援依順序排序與狀態過濾)
CREATE INDEX IF NOT EXISTS idx_system_fi_sort_status 
    ON system_financial_institutions (sort_order ASC, is_disabled);

-- 3. 所屬國家外鍵索引 (加速國家連動與制裁狀態關聯檢索)
CREATE INDEX IF NOT EXISTS idx_system_fi_country 
    ON system_financial_institutions (country_code);

-- 4. SWIFT 檢索索引
CREATE INDEX IF NOT EXISTS idx_system_fi_swift 
    ON system_financial_institutions (swift_code);
```

---

## 4. Flyway DDL 遷移腳本 (V20261015_01__create_system_financial_institutions.sql)

```sql
CREATE TABLE IF NOT EXISTS system_financial_institutions (
    id BIGSERIAL PRIMARY KEY,
    bank_code VARCHAR(20) NOT NULL,
    name_zh VARCHAR(100) NOT NULL,
    name_en VARCHAR(100) NOT NULL,
    swift_code VARCHAR(11),
    country_code VARCHAR(3) NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_disabled BOOLEAN NOT NULL DEFAULT FALSE,
    sanction_acknowledged BOOLEAN NOT NULL DEFAULT FALSE,
    version BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
    CONSTRAINT uk_system_financial_institutions_code UNIQUE (bank_code)
);

CREATE INDEX IF NOT EXISTS idx_system_fi_sort_status 
    ON system_financial_institutions (sort_order ASC, is_disabled);

CREATE INDEX IF NOT EXISTS idx_system_fi_country 
    ON system_financial_institutions (country_code);

CREATE INDEX IF NOT EXISTS idx_system_fi_swift 
    ON system_financial_institutions (swift_code);

COMMENT ON TABLE system_financial_institutions IS '再保系統往來金融機構主檔表';
COMMENT ON COLUMN system_financial_institutions.bank_code IS '機構唯一識別代碼 (內部代碼)';
COMMENT ON COLUMN system_financial_institutions.swift_code IS 'SWIFT / BIC 國際清算代碼';
COMMENT ON COLUMN system_financial_institutions.country_code IS '註冊所屬國家 ISO 代碼';
COMMENT ON COLUMN system_financial_institutions.sanction_acknowledged IS '制裁國家建檔主管授權覆核同意旗標';
```
