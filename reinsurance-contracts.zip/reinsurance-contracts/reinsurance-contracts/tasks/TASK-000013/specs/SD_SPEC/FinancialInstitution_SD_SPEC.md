<!--
governance_metadata:
  last_reviewed: "2026-10-15"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-15"
  governance_status: "ACTIVE"
-->

# 金融機構系統與 API 詳細設計規格書 (Financial Institution SD Specification)

> **模組代碼**：`TASK-000013`  
> **API 基礎路徑**：`/api/v1/system/financial-institutions`  
> **契約規範源**：`contracts/openapi.yaml` (Domain: `masterdata`)  

---

## 1. API 契約端點總覽

| HTTP Method | API Path | 說明 | 關鍵狀態碼 |
| :--- | :--- | :--- | :--- |
| `GET` | `/api/v1/system/financial-institutions` | 分頁檢索金融機構清單 | 200 OK |
| `POST` | `/api/v1/system/financial-institutions` | 新增單筆金融機構 | 201 Created, 400 Bad Request, 409 Conflict |
| `GET` | `/api/v1/system/financial-institutions/{id}` | 取得單筆機構詳情 | 200 OK, 404 Not Found |
| `PUT` | `/api/v1/system/financial-institutions/{id}` | 修改金融機構資訊 | 200 OK, 400 Bad Request, 409 Conflict |
| `PATCH` | `/api/v1/system/financial-institutions/{id}/status` | 切換作廢/啟用狀態 | 200 OK, 404 Not Found |
| `DELETE` | `/api/v1/system/financial-institutions/{id}` | 物理刪除 (僅限無引用資料) | 204 No Content, 400 Bad Request |
| `GET` | `/api/v1/system/financial-institutions/{id}/references` | 查詢下游模組引用明細 | 200 OK |
| `GET` | `/api/v1/system/financial-institutions/{id}/audit-logs` | 查詢最近異動審計紀錄 | 200 OK |
| `GET` | `/api/v1/system/financial-institutions/export` | 匯出篩選結果為 Excel | 200 OK (application/vnd.ms-excel) |

---

## 2. 業務時序圖 (Sequence Diagrams)

### 2.1 新增金融機構與制裁法遵檢核時序

```mermaid
sequenceDiagram
    autonumber
    actor User as 經辦人員
    participant Portal as Web Portal (SC-0101-03-02)
    participant Ctrl as FinancialInstitutionController
    participant Svc as FinancialInstitutionService
    participant CtyRepo as CountryRepository
    participant FiRepo as FinancialInstitutionRepository
    participant Audit as AuditLogRepository

    User->>Portal: 選取所屬國家 (如 IR 伊朗)
    Portal->>Portal: 國別為受制裁 -> 動態展開法遵警示橫幅
    User->>Portal: 勾選主管授權同意方塊並點擊儲存
    Portal->>Ctrl: POST /api/v1/system/financial-institutions
    Ctrl->>Svc: createInstitution(request)
    Svc->>FiRepo: existsByBankCode(request.code)
    alt 代碼已存在
        Svc-->>Ctrl: throw DuplicateResourceException(409 Conflict)
    end
    Svc->>CtyRepo: findByCode(request.countryCode)
    alt 國家為受制裁且未勾選授權
        Svc-->>Ctrl: throw BusinessException(400 Bad Request, ERR_SANCTION_CONFIRM_REQUIRED)
    end
    Svc->>FiRepo: findMaxSortOrder()
    Note over Svc: 若未指定排序，預設 max + 10
    Svc->>FiRepo: save(institution)
    Svc->>Audit: recordAudit(CREATE, "經主管授權建立受制裁國家機構")
    Svc-->>Ctrl: FinancialInstitutionResponse
    Ctrl-->>Portal: HTTP 201 Created
    Portal-->>User: 顯示成功 Toast 並跳轉清單
```

### 2.2 檢視與引用防刪防護時序

```mermaid
sequenceDiagram
    autonumber
    actor User as 經辦人員
    participant Portal as Web Portal (SC-0101-03-03)
    participant Ctrl as FinancialInstitutionController
    participant Svc as FinancialInstitutionService
    participant FiRepo as FinancialInstitutionRepository

    User->>Portal: 點擊刪除機構
    Portal->>Ctrl: DELETE /api/v1/system/financial-institutions/{id}
    Ctrl->>Svc: deleteInstitution(id)
    Svc->>Svc: countReferences(bankCode)
    alt 被收付款/交易/再保人引用 (refCount > 0)
        Svc-->>Ctrl: throw BusinessException(400 Bad Request, ERR_BANK_REFERENCED_CANNOT_DELETE)
        Ctrl-->>Portal: 400 Bad Request (說明該機構已被 X 筆資料引用，僅允許作廢)
        Portal-->>User: 彈窗防呆提示並鎖定刪除
    else 無任何引用 (refCount == 0)
        Svc->>FiRepo: delete(institution)
        Svc-->>Ctrl: void
        Ctrl-->>Portal: HTTP 204 No Content
        Portal-->>User: 清單移除成功
    end
```
