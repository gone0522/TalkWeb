<!--
governance_metadata:
  last_reviewed: "2026-10-15"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-15"
  governance_status: "ACTIVE"
-->

# 金融機構使用案例規格書 (Financial Institution Use Case Specification)

> **模組代碼**：`TASK-000013`  
> **畫面代碼**：`SC-0101-03-01` ~ `SC-0101-03-03`  

---

### UC-FI-01: 多維分頁檢索金融機構清單 (Query & Pagination)
- **Actor**：授權業務經辦 / 系統管理員
- **Preconditions**：使用者已登入並導航至 `/settings/menus/financial-institutions`。
- **Main Flow**：
  1. 系統載入金融機構清單，預設依 `sortOrder,asc` 升冪排序。
  2. 使用者輸入查詢條件（代碼、中英文名稱、SWIFT/BIC、所屬國家複選、資料狀態）。
  3. 系統觸發 300ms 防抖查詢，回傳符合條件之分頁資料。
  4. 若查詢結果包含所屬國家受制裁之項目，頂部展示紅色警示橫幅。
  5. 表格中受制裁國別項目以紅框標籤高亮標註 `[受制裁]`。

---

### UC-FI-02: 單筆新增金融機構 (Create Institution)
- **Actor**：授權經辦人員
- **Main Flow**：
  1. 使用者點擊「新增金融機構」按鈕，開啟 `SC-0101-03-02` 畫面/彈窗。
  2. 系統自動計算並帶入 `sortOrder` 建議值（目前最大值 + 10）。
  3. 使用者輸入機構代碼、中文名稱、英文名稱、選取所屬國家、選填 SWIFT/BIC。
  4. 若所選國家為一般有效國家，使用者點擊「儲存」，系統檢核無誤後寫入資料庫，狀態預設為啟用 (`isDisabled = false`)，回傳 `201 Created`。

---

### UC-FI-03: 受制裁國家金融機構建檔與主管授權覆核 (Sanction Compliance Override)
- **Actor**：法遵經辦 / 授權業務主管
- **Main Flow**：
  1. 使用者於新增畫面選取之所屬國家處於受制裁狀態（`isSanctioned = true`）。
  2. 系統即時展開紅色法遵警示橫幅，並展示制裁生效日期。
  3. 系統鎖定儲存按鈕，要求必須勾選「本人已確認上述法遵警示，並經權責主管同意建檔」。
  4. 使用者勾選確認後點擊「儲存」，後端驗證授權旗標，成功建檔並將授權主管與原因寫入審計日誌。

---

### UC-FI-04: 檢視金融機構詳情與引用模組分析 (View Detail & Reference Defense)
- **Actor**：授權使用者
- **Main Flow**：
  1. 使用者於清單點擊「檢視/編輯」按鈕，進入 `SC-0101-03-03`。
  2. 系統讀取機構詳細資料，並動態聚合「收付款設定」、「交易資料」、「再保人主檔」之引用筆數。
  3. 若該機構引用計數 `referenceCount > 0`，系統於 `Bank Code` 欄位呈現鎖頭圖示，禁止修改代碼，且「刪除」功能強制隱藏或鎖定。
  4. 畫面展示最近 5 筆審計歷程。

---

### UC-FI-05: 編輯金融機構基本資料與樂觀鎖併發防禦 (Update & Concurrency Guard)
- **Actor**：授權使用者
- **Main Flow**：
  1. 使用者點擊「編輯」按鈕，修改中文名稱、英文名稱、SWIFT/BIC 或顯示順序。
  2. 輸入必填之異動原因（長度 >= 5 字元）。
  3. 送出 `PUT` 請求，帶入當前 `@Version`。
  4. 後端檢核版本號一致，寫入異動前/異動後審計日誌，版本號 + 1，回傳 `200 OK`。
- **Alternative Flow (409 Conflict)**：若版本不一致，後端拋出 `409 Conflict`，提示「資料已被其他使用者修改，請重新整理後再試」。

---

### UC-FI-06: 切換金融機構狀態為作廢 (Soft Disable / Inactive)
- **Actor**：授權使用者
- **Main Flow**：
  1. 使用者點擊「設為作廢」按鈕，系統彈出確認對話框。
  2. 使用者輸入作廢原因並確認。
  3. 系統發送 `PATCH /status`，將 `isDisabled` 設為 `true`，寫入審計日誌。
  4. 該機構立即自所有新增收付款/合約之下拉選單中移除。

---

### UC-FI-07: 匯出金融機構清單 Excel (Export Excel)
- **Actor**：授權使用者
- **Main Flow**：
  1. 使用者於清單工具列點擊「匯出 Excel」。
  2. 後端依據當前檢索條件，產生二進位 xlsx 檔案，包含排序、代碼、中英文名稱、SWIFT、國別（含制裁標記）與狀態。
  3. 前端完成串流下載，不卡頓主執行緒。
