# TASK-000013-005: 金融機構檢視/編輯畫面、引用狀況防呆與審計異動歷程 (SC-0101-03-03)

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 業務需求：`tasks/TASK-000013/specs/SA_SPEC.md` (§3 SC-0101-03-03)
  - 使用案例：`tasks/TASK-000013/specs/USE_CASE_SPEC/FinancialInstitution_USE_CASE_SPEC.md` (UC-FI-04, UC-FI-05, UC-FI-06)
  - 前端架構：`tasks/TASK-000013/specs/UI_SPEC/FinancialInstitution_UI_SPEC.md` (§2.3)
  - 設計稿對齊：`tasks/TASK-000013/mockups/3.jpg`
  - 測試驗收規範：`tasks/TASK-000013/specs/QA_SPEC/FinancialInstitution_QA_SPEC.md` (TC-FI-07, TC-FI-09)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (Optimistic Locking, Audit Trail)
- **業務背景**：提供金融機構檢視/編輯側邊卡片抽屜，涵蓋已引用 Bank Code 鎖定唯讀、引用狀況面板、最近 5 筆審計歷程與設為作廢功能。

### 驗收條件 (BDD 結構化規範)
- **場景 1 (檢視模式與已引用代碼鎖定 - mockups/3.jpg)**：
  - **Given**: 開啟已受其他模組引用之金融機構（`referenceCount > 0`）。
  - **When**: 檢視畫面渲染。
  - **Then**: 金融機構代碼欄位呈現鎖頭圖示（`[🔒]`），輸入框強制 Disabled 唯讀，禁止任何變更。
- **場景 2 (資料引用狀況面板呈現 - mockups/3.jpg)**：
  - **Given**: 資料加載完成。
  - **When**: 檢視「資料引用狀況」區塊。
  - **Then**: 條列呈現「收付款設定」、「交易資料（再保費/賠款匯款）」與「再保人主檔」之引用筆數與說明文字。
- **場景 3 (異動歷程展示與匯出 - mockups/3.jpg)**：
  - **Given**: 機構存在歷史異動。
  - **When**: 檢視「異動紀錄（最近 5 筆）」區塊。
  - **Then**: 依序呈現異動時間、異動人員、異動欄位、異動前、異動後與異動原因。
  - **And**: 點擊「查看全部」彈出完整審計日誌彈窗；點擊「匯出」下載審計紀錄。
- **場景 4 (設為作廢確認對話框)**：
  - **Given**: 使用者點擊「設為作廢」按鈕。
  - **When**: 彈出作廢確認彈窗。
  - **Then**: 使用者輸入作廢原因後發送 `PATCH /status`，成功後畫面狀態即時更新為作廢 Badge。
- **場景 5 (編輯模式與異動原因必填檢核)**：
  - **Given**: 使用者點擊「編輯」並修改名稱或順序。
  - **When**: 點擊儲存。
  - **Then**: 強制要求輸入至少 5 字元之「異動原因」，並帶入當前 `version` 進行樂觀鎖送出。

## 2. 影響範圍與檔案清單 (Scope - 嚴格 4 檔)
- `src/components/menus/institution/InstitutionDetailDrawer.tsx`
- `src/components/menus/institution/InstitutionReferenceSection.tsx`
- `src/components/menus/institution/InstitutionAuditHistoryModal.tsx`
- `src/components/menus/institution/InstitutionDeleteConfirmModal.tsx`
