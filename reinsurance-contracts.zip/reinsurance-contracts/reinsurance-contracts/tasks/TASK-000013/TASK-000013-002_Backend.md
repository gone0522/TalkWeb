# TASK-000013-002: 法遵制裁警示校驗、引用防護、審計日誌與 Excel 匯出 API

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 業務需求：`tasks/TASK-000013/specs/SA_SPEC.md` (§2 BR-FI-02, BR-FI-03, BR-FI-05, BR-FI-06)
  - 使用案例：`tasks/TASK-000013/specs/USE_CASE_SPEC/FinancialInstitution_USE_CASE_SPEC.md` (UC-FI-03, UC-FI-04, UC-FI-06, UC-FI-07)
  - 系統/API詳細設計：`tasks/TASK-000013/specs/SD_SPEC/FinancialInstitution_SD_SPEC.md` (§1 & §2)
  - 測試驗收規範：`tasks/TASK-000013/specs/QA_SPEC/FinancialInstitution_QA_SPEC.md` (TC-FI-05 ~ TC-FI-08, TC-FI-10)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (OWASP IDOR, RFC-003 Dynamic Exporter, RFC-005 Audit)
- **業務背景**：實作金融機構所屬國別制裁防線（主管同意覆核）、引用計數防護（禁止物理刪除並鎖定代碼）、欄位級審計日誌與 Apache POI Excel 串流匯出。

### 驗收條件 (BDD 結構化規範)
- **場景 1 (Sanction Block Path - 制裁國別無主管同意阻擋 - TC-FI-05, UC-FI-03)**：
  - **Given**: 所屬國家處於受制裁狀態 (`country.isSanctioned == true`)。
  - **When**: 發送 `POST` 且 `sanctionAcknowledged = false`。
  - **Then**: 回傳 `HTTP 400 Bad Request`，錯誤代碼 `ERR_SANCTION_CONFIRM_REQUIRED`。
- **場景 2 (Sanction Override Path - 主管授權放行並留痕 - TC-FI-06, UC-FI-03)**：
  - **Given**: 所屬國家受制裁。
  - **When**: 發送 `POST` 且 `sanctionAcknowledged = true`。
  - **Then**: 回傳 `HTTP 201 Created`，寫入審計日誌標註「經主管授權建立受制裁國家機構」。
- **場景 3 (Referential Defense Path - 引用資料禁止刪除 400 - TC-FI-07, UC-FI-04)**：
  - **Given**: 機構已被收付款設定、交易資料或再保人主檔引用 (`referenceCount > 0`)。
  - **When**: 發送 `DELETE /api/v1/system/financial-institutions/1`。
  - **Then**: 回傳 `HTTP 400 Bad Request` (`ERR_BANK_REFERENCED_CANNOT_DELETE`)，禁止物理刪除。
- **場景 4 (Safe Delete Path - 無引用機構刪除 204 - TC-FI-08, UC-FI-04)**：
  - **Given**: 機構未被任何模組引用 (`referenceCount == 0`)。
  - **When**: 發送 `DELETE /api/v1/system/financial-institutions/1`。
  - **Then**: 回傳 `HTTP 204 No Content`，實體自資料庫完全移除。
- **場景 5 (Status Toggle Path - 切換作廢狀態 - UC-FI-06)**：
  - **When**: 發送 `PATCH /api/v1/system/financial-institutions/1/status`，Body 為 `{ "status": "INACTIVE", "reason": "結束營業" }`。
  - **Then**: 回傳 `HTTP 200 OK`，`isDisabled = true`，記錄審計日誌。
- **場景 6 (Export Path - 二進位 Excel 串流匯出 - TC-FI-10, UC-FI-07)**：
  - **When**: 發送 `GET /api/v1/system/financial-institutions/export`。
  - **Then**: 回傳 `HTTP 200 OK`，Content-Type 為 `application/vnd.openxmlformats-officedocument.spreadsheetml.sheet`，檔案結構符合規範。

## 2. 影響範圍與檔案清單 (Scope - 嚴格 4 檔)
- `src/main/java/com/reinsurance/core/dto/institution/FinancialInstitutionDto.java`
- `src/main/java/com/reinsurance/core/service/FinancialInstitutionExportService.java`
- `src/main/java/com/reinsurance/core/service/FinancialInstitutionComplianceService.java`
- `src/test/java/com/reinsurance/core/service/FinancialInstitutionServiceTest.java`
