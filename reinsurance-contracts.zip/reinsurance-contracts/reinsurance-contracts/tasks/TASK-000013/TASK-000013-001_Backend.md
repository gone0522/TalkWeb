# TASK-000013-001: 金融機構領域實體、資料庫綱要與基礎 CRUD API

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 業務需求：`tasks/TASK-000013/specs/SA_SPEC.md` (§2 BR-FI-01, BR-FI-04, BR-FI-07)
  - 使用案例：`tasks/TASK-000013/specs/USE_CASE_SPEC/FinancialInstitution_USE_CASE_SPEC.md` (UC-FI-01, UC-FI-02, UC-FI-05)
  - 資料模型：`tasks/TASK-000013/specs/DBA_SPEC/FinancialInstitution_DBA_SPEC.md` (`system_financial_institutions`)
  - 系統/API詳細設計：`tasks/TASK-000013/specs/SD_SPEC/FinancialInstitution_SD_SPEC.md` (§1 & §2)
  - 測試驗收規範：`tasks/TASK-000013/specs/QA_SPEC/FinancialInstitution_QA_SPEC.md` (TC-FI-01 ~ TC-FI-04, TC-FI-09)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (DDD, SOLID, TDD, OWASP SQLi, RFC 7807)
- **業務背景**：建立再保險系統往來金融機構主檔，提供唯一代碼管理、SWIFT 格式檢核、順序建議計算與樂觀鎖併發保護。

### 驗收條件 (BDD 結構化規範)
- **場景 1 (Query Path - 分頁與多維模糊檢索 - TC-FI-01, UC-FI-01)**：
  - **Given**: 資料庫存在多筆金融機構。
  - **When**: 發送 `GET /api/v1/system/financial-institutions?keyword=BOT&status=ACTIVE&page=0&size=20&sort=sortOrder,asc`。
  - **Then**: 回傳 `HTTP 200 OK`，主體包含分頁物件。每一項目包含 `id`, `code`, `nameZh`, `nameEn`, `swiftCode`, `countryCode`, `sortOrder`, `isDisabled`，嚴格依 `sortOrder` 升冪排序。
- **場景 2 (Happy Path - 新增機構與順序自動計算 - TC-FI-02, UC-FI-02)**：
  - **Given**: 提供唯一代碼 `"BOT001"`、中文名 `"台灣銀行"`、英文名 `"Bank of Taiwan"`、國家 `"TW"`，未提供 `sortOrder`。
  - **When**: 發送 `POST /api/v1/system/financial-institutions`。
  - **Then**: 回傳 `HTTP 201 Created`，`sortOrder` 自動帶入現有最大順序值 + 10，狀態預設為 `ACTIVE` (`isDisabled = false`)，`version = 0`。
- **場景 3 (Conflict Path - 代碼重複衝突 409 - TC-FI-03)**：
  - **Given**: 系統已存在代碼 `"BOT001"`。
  - **When**: 發送 `POST /api/v1/system/financial-institutions` 且 `code` 為 `"BOT001"`。
  - **Then**: 回傳 `HTTP 409 Conflict`，錯誤碼 `ERR_DUPLICATE_BANK_CODE`。
- **場景 4 (Validation Path - SWIFT 格式檢核 400 - TC-FI-04)**：
  - **Given**: 傳入非法 SWIFT 代碼（如 `"12345"` 或未符合 8/11 碼規範）。
  - **When**: 發送 `POST` 或 `PUT`。
  - **Then**: 回傳 `HTTP 400 Bad Request`，包含欄位格式錯誤提示。
- **場景 5 (Update Path - 樂觀鎖併發保護 - TC-FI-09, UC-FI-05)**：
  - **Given**: 存在 `id = 1, version = 0` 之機構。
  - **When**: 發送 `PUT /api/v1/system/financial-institutions/1`，帶入 `version = 0` 更新名稱與順序。
  - **Then**: 回傳 `HTTP 200 OK`，資料庫更新，`version` 遞增為 1。
  - **And**: 若傳入 `version = 999`，回傳 `HTTP 409 Conflict`。

## 2. 影響範圍與檔案清單 (Scope - 嚴格 5 檔)
- `src/main/resources/db/migration/V20261015_01__create_system_financial_institutions.sql`
- `src/main/java/com/reinsurance/core/domain/institution/FinancialInstitution.java`
- `src/main/java/com/reinsurance/core/repository/FinancialInstitutionRepository.java`
- `src/main/java/com/reinsurance/core/service/FinancialInstitutionService.java`
- `src/main/java/com/reinsurance/core/controller/FinancialInstitutionController.java`
