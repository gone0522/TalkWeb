# TASK-000013-003: 金融機構選單清單檢索表格、制裁高亮與 Excel 匯出畫面 (SC-0101-03-01)

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 業務需求：`tasks/TASK-000013/specs/SA_SPEC.md` (§3 SC-0101-03-01)
  - 使用案例：`tasks/TASK-000013/specs/USE_CASE_SPEC/FinancialInstitution_USE_CASE_SPEC.md` (UC-FI-01, UC-FI-07)
  - 前端架構：`tasks/TASK-000013/specs/UI_SPEC/FinancialInstitution_UI_SPEC.md` (§2.1)
  - 設計稿對齊：`tasks/TASK-000013/mockups/1.jpg`
  - 測試驗收規範：`tasks/TASK-000013/specs/QA_SPEC/FinancialInstitution_QA_SPEC.md` (TC-FI-01, TC-FI-10)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (Core Web Vitals, Debounce, i18n)
- **業務背景**：於「金融機構選單」入口頁面掛載清單檢索介面、多維條件防抖過濾、受制裁國別警示橫幅與高亮標記、以及 Excel 匯出。

### 驗收條件 (BDD 結構化規範)
- **場景 1 (Page Mount & Layout 呈現 - mockups/1.jpg)**：
  - **Given**: 使用者訪問 `/settings/menus/financial-institutions`。
  - **When**: 頁面加載。
  - **Then**: 呈現 `MenuCardFrame` 包裹之金融機構選單主畫面，標題代碼為 `SC-0101-03-01`。
- **場景 2 (多維檢索篩選列 - mockups/1.jpg)**：
  - **Given**: 檢索表單載入。
  - **When**: 使用者輸入代碼、中英文名稱、SWIFT 或選擇所屬國家複選下拉與資料狀態單選鈕。
  - **Then**: 關鍵字輸入框實作 300ms 防抖過濾；點擊「清除條件」清空所有條件。
- **場景 3 (清單表格 8 大欄位與制裁標籤 - mockups/1.jpg)**：
  - **Given**: 資料載入成功。
  - **When**: 表格渲染列表。
  - **Then**: 渲染 8 大欄位（顯示順序 ⇅、機構代碼、中文名稱、英文名稱、SWIFT/BIC、所屬國家、狀態、功能）。
  - **And**: 所屬國家若處於受制裁狀態，國別後方高亮標註紅框徽章 `[受制裁]`。
- **場景 4 (頂部動態制裁警示橫幅 - mockups/1.jpg)**：
  - **Given**: 查詢結果中包含 1 筆以上受制裁國家之金融機構。
  - **When**: 清單呈現。
  - **Then**: 列表上方動態呈現紅色警示橫幅「查詢結果中有 X 筆機構之所屬國家已列入制裁名單，選用該機構進行收付款設定時將觸發法遵警示」。
- **場景 5 (匯出 Excel 功能)**：
  - **Given**: 使用者點擊「匯出 Excel」按鈕。
  - **When**: 呼叫匯出 API。
  - **Then**: 觸發二進位檔案下載，成功提示 Toast。
- **場景 6 (按鈕防呆與 Phase 2 佔位)**：
  - 工具列「批次匯入」按鈕設定為 disabled 置灰狀態，游標懸停提示「批次匯入功能即將於下一階段開放」。

## 2. 影響範圍與檔案清單 (Scope - 嚴格 4 檔)
- `src/app/(dashboard)/settings/menus/financial-institutions/page.tsx`
- `src/components/menus/institution/InstitutionSearchForm.tsx`
- `src/components/menus/institution/InstitutionListTable.tsx`
- `src/services/institution-api.ts`
