# TASK-000013-004: 金融機構新增畫面、國家連動與法遵警示主管覆核確認彈窗 (SC-0101-03-02)

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 業務需求：`tasks/TASK-000013/specs/SA_SPEC.md` (§3 SC-0101-03-02)
  - 使用案例：`tasks/TASK-000013/specs/USE_CASE_SPEC/FinancialInstitution_USE_CASE_SPEC.md` (UC-FI-02, UC-FI-03)
  - 前端架構：`tasks/TASK-000013/specs/UI_SPEC/FinancialInstitution_UI_SPEC.md` (§2.2)
  - 設計稿對齊：`tasks/TASK-000013/mockups/2.jpg`
  - 測試驗收規範：`tasks/TASK-000013/specs/QA_SPEC/FinancialInstitution_QA_SPEC.md` (TC-FI-02, TC-FI-03, TC-FI-05, TC-FI-06)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (Form Validation & Error UX, i18n)
- **業務背景**：提供金融機構新增畫面，支援代碼重複防呆、排序建議值自動帶入、國家選單連動、以及受制裁國家即時法遵警示與主管授權確認方塊。

### 驗收條件 (BDD 結構化規範)
- **場景 1 (新增表單空值防呆與排序帶入 - mockups/2.jpg)**：
  - **Given**: 新增彈窗/畫面開啟。
  - **When**: 表單加載。
  - **Then**: 顯示順序自動填入後端建議值（max + 10）；代碼輸入框自動獲得焦點。
  - **And**: 若未填寫必填欄位點擊儲存，前端阻擋送出並精確紅框提示。
- **場景 2 (受制裁國別動態警示與主管授權確認 - mockups/2.jpg)**：
  - **Given**: 使用者於「所屬國家」下拉選單選取受制裁國別（如 `IR 伊朗`）。
  - **When**: 國別變更。
  - **Then**: 表單下方平滑展開紅色警示橫幅：「法遵警示：所屬國家已列入制裁名單（IR 伊朗，制裁生效日 YYYY/MM/DD）...」。
  - **And**: 呈現強制核取方塊「本人已確認上述法遵警示，並經權責主管同意建檔（必填）」。
  - **And**: 未勾選該核取方塊前，「儲存」按鈕強制保持 Disabled。
- **場景 3 (SWIFT/BIC 格式即時校驗)**：
  - **Given**: 使用者輸入 SWIFT 代碼。
  - **When**: 輸入字元未符合 8 或 11 位大寫英數字規範。
  - **Then**: 輸入框下方顯示格式錯誤提示，阻擋送出。
- **場景 4 (409 代碼衝突定位反饋)**：
  - **Given**: 使用者輸入已存在之代碼。
  - **When**: 點擊儲存且後端回傳 409 Conflict。
  - **Then**: 代碼欄位呈現紅框提示「此代碼已被使用」，彈窗頂部顯示警示橫幅。

## 2. 影響範圍與檔案清單 (Scope - 嚴格 4 檔)
- `src/components/menus/institution/InstitutionFormModal.tsx`
- `src/components/menus/institution/SanctionWarningBanner.tsx`
- `src/locales/zh-TW.json`
- `src/locales/en-US.json`
