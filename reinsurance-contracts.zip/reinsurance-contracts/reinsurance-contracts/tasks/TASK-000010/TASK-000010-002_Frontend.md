# TASK-000010-002_Frontend: 前端 Tier-1 BOM 引入、Master Data 共用樣板元件提煉與全頁面換裝

## 1. 任務目標
消除跨切片介面漂移，落實前端現代化架構：
1. 安裝 `sonner`, `lucide-react`, `@radix-ui/react-dialog`, `react-hook-form`, `zod`。
2. 提煉 6 大 Master Data 共用樣板元件 (`src/components/menus/common/master-data/*`)：
   - `<MasterDataHeaderActions>`
   - `<MasterDataTableToolbar>`
   - `<MasterDataPagination>`
   - `<MasterDataDetailDrawer>`
   - `<MasterDataFormModal>`
   - `<MasterDataDeleteConfirmModal>`
3. 將國家、區域、幣別三大頁面全面換裝使用共用樣板，消滅全部 hand-rolled toast 與分頁塌陷問題。
4. 清理 `src/app/system/regions/page.tsx` 舊導向死碼。

5. 選單防禦性優雅降級與 404 根治 (Menu Graceful Degradation Protocol)：
   - 建立 `<ComingSoonPlaceholder>` 規範化空狀態卡片，承襲 `<MenuCardFrame>` 與現代底線頁籤樣式。
   - 針對尚未實作之金融機構 (`SC-0101-03-01`)、信用評等機構 (`SC-0101-04-01`) 與險別 (`SC-0101-05-01`) 選單，建立對應頁面路由承接點，呈現功能規劃中卡片並導引排程任務（TASK-000013 ~ 000015），確保任何未就緒頁籤點擊均能優雅降級，物理杜絕 404 錯誤。
   - 同步更新 `audit-master-data-standards.js`，對使用 `ComingSoonPlaceholder` 之頁面給予分頁契約審計豁免。
