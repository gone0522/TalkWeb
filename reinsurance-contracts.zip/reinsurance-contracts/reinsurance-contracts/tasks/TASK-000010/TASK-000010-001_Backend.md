# TASK-010-01_Backend: 後端 Tier-1 Approved BOM 引入、BaseAuditableEntity 與 API 命名空間整併

## 1. 任務目標
落實後端 Spring Boot 3.x 企業主流開發套件：
1. 引入 MapStruct 與 Lombok，消除手刻 DTO / Entity 映射與 getter/setter 冗長代碼。
2. 建立 `BaseAuditableEntity`，由 Spring Data JPA Auditing 自動維護 `createdAt`, `createdBy`, `updatedAt`, `updatedBy`。
3. 整併重複的 `CurrencyController`，統一所有主檔路由為 `/api/v1/system/*`。

## 2. 交付檔案
- `pom.xml`: 引入 MapStruct, Lombok, JPA Auditing。
- `BaseAuditableEntity.java`: `@MappedSuperclass` 審計基底類別。
- `JpaAuditingConfig.java`: `@EnableJpaAuditing` 配置類別。
- `CountryController.java`, `RegionController.java`, `CurrencyController.java`: API 命名空間收斂。
