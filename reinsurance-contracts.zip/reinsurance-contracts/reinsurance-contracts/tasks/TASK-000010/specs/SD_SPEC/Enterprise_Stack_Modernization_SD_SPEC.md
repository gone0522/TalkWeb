# TASK-010 SD_SPEC: 系統循序設計規格 (System Sequence)
## 1. 循序互動流
1. **共用分頁與匯出互動**:
   Page -> `<MasterDataTableToolbar>`: 渲染筆數與匯出按鈕。
   Toolbar -> API Service -> Backend `/api/v1/system/<resource>/export`: 防連點 + 旋轉動畫。
   Page -> Sonner `toast.success()`: 全域通知。
2. **實體自動審計流**:
   Controller -> Service -> Repository -> `JpaAuditingListener` -> 自動填入 `createdAt`, `createdBy` -> PostgreSQL Commit.
