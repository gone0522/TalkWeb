# TASK-010 UI_SPEC: 主檔維護共用樣板元件規格
## 1. 元件契約清單
1. `<MasterDataHeaderActions>`: 封裝新增按鈕，統一 Lucide Plus 圖示與炭灰 `#374151` 樣式。
2. `<MasterDataTableToolbar>`: 封裝筆數統計與 Excel 匯出 (附 Spinner 與防連點)。
3. `<MasterDataPagination>`: 雙側排版、內建 10/20/50 筆/頁下拉、單頁與無資料時防塌陷。
4. `<MasterDataDetailDrawer>`: 標準 `max-w-2xl` 寬度、卡片資料夾頁籤、審計歷程表格、安全刪除防呆。
5. `<MasterDataFormModal>`: 標準 `max-w-3xl` 寬度、[取消] | [儲存並繼續新增] | [確定存檔] 三鍵標準。
6. `<MasterDataDeleteConfirmModal>`: 獨立對話框元件，淘汰 inline dialog 與 window.confirm。
