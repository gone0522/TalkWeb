# TASK-010 DBA_SPEC: 資料庫審計結構與模型標準
## 1. 審計欄位規範
- `created_by VARCHAR(50) NOT NULL`
- `created_at TIMESTAMPTZ NOT NULL`
- `updated_by VARCHAR(50)`
- `updated_at TIMESTAMPTZ`
- `version BIGINT DEFAULT 0`
## 2. Migration 連續性
- 確保所有 Migration 序號連續，嚴禁跳號。
