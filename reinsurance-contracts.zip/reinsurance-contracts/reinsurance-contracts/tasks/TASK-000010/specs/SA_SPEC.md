# TASK-010 SA_SPEC: 軟體架構規格 (System Architecture)
## 1. 架構原則
1. **樣板先行 (Template Primitive First)**: 業務切片僅負責傳入 Props 與 Business Hook，佈局與互動全由共用樣板承載。
2. **審計模型基底化 (Base Auditable Entity)**: 所有資料庫業務實體繼承統一基底，確保審計欄位零漂移。
3. **API 命名空間階層化**: 主檔類 API 強制統一 `/api/v1/system/<resource>`。
