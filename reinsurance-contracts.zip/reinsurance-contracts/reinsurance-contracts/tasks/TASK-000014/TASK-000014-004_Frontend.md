# TASK-000014-004: 信用評等機構新增畫面與代碼防呆彈窗 (SC-0101-04-02)

## 1. 需求描述與驗收標準
- **規格依據**：`specs/UI_SPEC/RatingAgency_UI_SPEC.md` (`SC-0101-04-02`), `mockups/2.jpg`
- **業務背景**：提供信用評等機構新增表單，支援排序建議值帶入與代碼重複 409 反饋。

### 驗收條件 (BDD)
- **場景 1 (排序建議值帶入 - mockups/2.jpg)**：打開新增表單，顯示順序自動填入 max + 10；代碼聚焦。
- **場景 2 (空值阻擋)**：未輸入代碼或名稱點擊儲存，前端紅框阻擋送出。
- **場景 3 (409 衝突標紅)**：後端回傳 409 時，代碼輸入框紅框提示「此代碼已被使用」。

## 2. 影響範圍 (嚴格 4 檔)
- `src/components/menus/rating/RatingAgencyFormModal.tsx`
- `src/components/menus/rating/RatingAgencyFormField.tsx`
- `src/locales/zh-TW.json`
- `src/locales/en-US.json`
