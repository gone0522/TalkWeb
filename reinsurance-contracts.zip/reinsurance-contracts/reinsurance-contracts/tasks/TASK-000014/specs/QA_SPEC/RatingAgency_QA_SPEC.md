<!--
governance_metadata:
  last_reviewed: "2026-10-15"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-15"
  governance_status: "ACTIVE"
-->

# 信用評等機構測試驗收規格書 (Credit Rating Agency QA Spec)

> **模組代碼**：`TASK-000014`  

- **TC-CRA-01**: 分頁檢索與多條件模糊查詢，依 `sortOrder` 升冪排序。
- **TC-CRA-02**: 單筆新增與自動計算 `sortOrder` (`max + 10`)。
- **TC-CRA-03**: 代碼重複衝突拋出 `409 Conflict` (`ERR_DUPLICATE_AGENCY_CODE`)。
- **TC-CRA-04**: 被再保人引用之機構禁止物理刪除 (`400 Bad Request`)。
- **TC-CRA-05**: 無引用之機構允許物理刪除 (`204 No Content`)。
- **TC-CRA-06**: 樂觀鎖併發更新衝突檢驗 (`409 Conflict`)。
- **TC-CRA-07**: Excel 二進位檔案匯出檢驗。
