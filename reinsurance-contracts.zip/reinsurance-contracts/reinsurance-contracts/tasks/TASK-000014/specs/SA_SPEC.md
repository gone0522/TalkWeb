<!--
governance_metadata:
  last_reviewed: "2026-10-15"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-15"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# 系統分析規格書：信用評等機構主檔管理 (System Analysis Specification: Credit Rating Agencies)

> **模組代碼**：`TASK-000014`  
> **業務規則代碼**：`BR-0101-04`  
> **畫面識別代碼**：`SC-0101-04-01` (清單), `SC-0101-04-02` (新增), `SC-0101-04-03` (檢視/編輯)  
> **所屬領域**：主檔管理 (`masterdata`) / 信用評等機構 (`credit_rating_agencies`)  

---

## 1. 業務背景與問題意識

在再保險交易中，再保人（Reinsurer）與經紀人（Broker）的信用風險（Credit Risk）直接決定了分保攤回的安全性。各國金融監理機關（如金管會保險局）強制要求再保險公司定期評估往來再保人的信用評等等級（如 S&P, Moody's, Fitch, A.M. Best）。

本模組旨在建立標準化的**信用評等機構主檔**：
1. **機構代碼標準化**：維護標準機構簡稱（如 `SP`, `MDY`, `AMB`, `FITCH`, `TRC`），以利下游再保人登記與合約評等選用。
2. **外部引用防刪與鎖定保護**：已被再保人評等登記引用的評等機構（`referenceCount > 0`），嚴禁物理刪除，僅允許標記作廢；且 Agency Code 永久鎖定唯讀，保護歷史監理申報數據的一致性。
3. **軟作廢隔離機制**：作廢機構不再出現在新增再保人評等之候選下拉中，但已存在之歷史評等紀錄仍可正常查詢顯示。

---

## 2. 業務規則清單 (BR-0101-04)

| 規則代碼 | 規則名稱 | 內容與約束 | 例外與防護處置 |
| :--- | :--- | :--- | :--- |
| **BR-CRA-01** | 代碼唯一性 | `Agency Code` 為全域唯一識別碼，長度上限 20 字元，建議採簡稱（如 SP）。 | 若重複回傳 `409 Conflict` (`ERR_DUPLICATE_AGENCY_CODE`)。 |
| **BR-CRA-02** | 引用後鎖定唯讀 | 當機構已被再保人評等登記引用（`referenceCount > 0`），`Agency Code` 永久鎖定為唯讀。 | 前端呈現鎖頭圖示並禁用輸入框。 |
| **BR-CRA-03** | 引用防刪與軟作廢 | 未被引用的機構得物理刪除；一旦被引用，系統禁止刪除，僅允許切換作廢 (`isDisabled = true`)。 | 刪除時拋出 `400 Bad Request` (`ERR_AGENCY_REFERENCED_CANNOT_DELETE`)。 |
| **BR-CRA-04** | 作廢資料隔離與追溯 | 已作廢機構不得出現在新增再保人評等選單中；已存在之歷史資料完全不受影響，仍可正常查詢與匯出。 | 下拉選單強制帶入 `status=ACTIVE`。 |
| **BR-CRA-05** | 順序自動計算 | 新增表單未填寫 `sortOrder` 時，系統自動帶入 `max + 10` 作為建議值。 | 數值越小越靠前，支援正整數。 |
