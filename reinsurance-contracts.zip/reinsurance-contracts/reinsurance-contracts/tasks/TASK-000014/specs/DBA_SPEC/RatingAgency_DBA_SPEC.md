<!--
governance_metadata:
  last_reviewed: "2026-10-15"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-15"
  governance_status: "ACTIVE"
-->

# 信用評等機構資料庫架構與實體模型規格書 (Credit Rating Agency DBA Spec)

> **模組代碼**：`TASK-000014`  
> **關聯資料表**：`system_credit_rating_agencies`  
> **目標資料庫**：PostgreSQL 16+  

```sql
CREATE TABLE IF NOT EXISTS system_credit_rating_agencies (
    id BIGSERIAL PRIMARY KEY,
    agency_code VARCHAR(20) NOT NULL,
    name_zh VARCHAR(100) NOT NULL,
    name_en VARCHAR(100) NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_disabled BOOLEAN NOT NULL DEFAULT FALSE,
    version BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
    CONSTRAINT uk_system_cra_code UNIQUE (agency_code)
);

CREATE INDEX IF NOT EXISTS idx_system_cra_sort_status 
    ON system_credit_rating_agencies (sort_order ASC, is_disabled);

COMMENT ON TABLE system_credit_rating_agencies IS '信用評等機構主檔表';
COMMENT ON COLUMN system_credit_rating_agencies.agency_code IS '機構唯一代碼 (如 SP, MDY, AMB)';
```

### 種子資料規劃 (Baseline Seed Data)
```sql
INSERT INTO system_credit_rating_agencies (agency_code, name_zh, name_en, sort_order, is_disabled)
VALUES 
    ('SP', '標準普爾', 'S&P Global Ratings', 10, FALSE),
    ('MDY', '穆迪', 'Moody''s Investors Service', 20, FALSE),
    ('AMB', '貝氏評等', 'A.M. Best', 30, FALSE),
    ('FITCH', '惠譽', 'Fitch Ratings', 40, FALSE),
    ('TRC', '中華信用評等', 'Taiwan Ratings Corporation', 50, FALSE)
ON CONFLICT (agency_code) DO NOTHING;
```
