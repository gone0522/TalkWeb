<!--
governance_metadata:
  last_reviewed: "2026-10-15"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-15"
  governance_status: "ACTIVE"
-->

# 信用評等機構使用案例規格書 (Credit Rating Agency Use Cases)

> **模組代碼**：`TASK-000014`  

- **UC-CRA-01 (分頁檢索與篩選)**：使用者輸入機構代碼、中文名稱、英文名稱、資料狀態進行 300ms 防抖查詢，清單依 `sortOrder,asc` 升冪展示。
- **UC-CRA-02 (新增機構與排序建議)**：使用者點擊「新增評等機構」，系統自動帶入 `sortOrder` 建議值 (`max + 10`)，使用者輸入代碼與中英文名稱後儲存，狀態預設為啟用。
- **UC-CRA-03 (檢視詳情與引用防刪防護)**：使用者進入 `SC-0101-04-03`，系統呈現再保人評等引用筆數；若被引用，代碼欄位呈現鎖頭唯讀，刪除按鈕鎖定。
- **UC-CRA-04 (編輯機構與樂觀鎖防禦)**：使用者修改名稱或順序，輸入異動原因，送出時比對版本號 `@Version`，衝突時回傳 409。
- **UC-CRA-05 (設為作廢)**：使用者將機構狀態切換為作廢，記錄審計日誌。
- **UC-CRA-06 (Excel 匯出)**：清單資料依篩選條件匯出為標準 xlsx 檔案。
