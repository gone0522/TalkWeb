<!--
governance_metadata:
  last_reviewed: "2026-10-15"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-15"
  governance_status: "ACTIVE"
-->

# 信用評等機構系統與 API 詳細設計規格書 (Credit Rating Agency SD Spec)

> **模組代碼**：`TASK-000014`  
> **API 基礎路徑**：`/api/v1/system/credit-rating-agencies`  
> **領域標籤**：`domain:masterdata`  

### API 端點表
- `GET /api/v1/system/credit-rating-agencies` (分頁檢索清單)
- `POST /api/v1/system/credit-rating-agencies` (新增機構，支援建議順序 max + 10)
- `GET /api/v1/system/credit-rating-agencies/{id}` (取得單筆詳情與引用筆數)
- `PUT /api/v1/system/credit-rating-agencies/{id}` (修改機構，支援樂觀鎖 @Version)
- `PATCH /api/v1/system/credit-rating-agencies/{id}/status` (切換作廢/啟用狀態)
- `DELETE /api/v1/system/credit-rating-agencies/{id}` (物理刪除，被引用時回傳 400 阻擋)
- `GET /api/v1/system/credit-rating-agencies/{id}/audit-logs` (查詢最近異動審計歷程)
- `GET /api/v1/system/credit-rating-agencies/export` (匯出 Excel)
