# TASK-000014-002: 再保人評等引用防刪保護、異動審計日誌與 Excel 匯出 API

## 1. 需求描述與驗收標準
- **規格依據**：`specs/SA_SPEC.md` (§2 BR-CRA-02, BR-CRA-03, BR-CRA-04)
- **業務背景**：實作被再保人評等引用時之防刪保護、作廢狀態切換、審計歷程與 Excel 匯出。

### 驗收條件 (BDD)
- **場景 1 (引用防刪阻擋 400 - TC-CRA-04)**：機構已被再保人評等引用 (`referenceCount > 0`) 時調用 DELETE，回傳 400 Bad Request (`ERR_AGENCY_REFERENCED_CANNOT_DELETE`)。
- **場景 2 (無引用物理刪除 204 - TC-CRA-05)**：機構未被任何模組引用時調用 DELETE，回傳 204 No Content，實體移除。
- **場景 3 (狀態切換)**：發送 `PATCH /status` 切換作廢，記錄審計日誌。
- **場景 4 (Excel 匯出 - TC-CRA-07)**：調用 `/export` 匯出 xlsx 串流，包含代碼、中英文名稱與狀態。

## 2. 影響範圍 (嚴格 4 檔)
- `src/main/java/com/reinsurance/core/dto/rating/CreditRatingAgencyDto.java`
- `src/main/java/com/reinsurance/core/service/CreditRatingAgencyExportService.java`
- `src/main/java/com/reinsurance/core/service/CreditRatingAgencyComplianceService.java`
- `src/test/java/com/reinsurance/core/service/CreditRatingAgencyServiceTest.java`
