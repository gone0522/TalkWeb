# TASK-000014-005: 信用評等機構檢視/編輯畫面、再保人引用防呆與審計歷程抽屜 (SC-0101-04-03)

## 1. 需求描述與驗收標準
- **規格依據**：`specs/UI_SPEC/RatingAgency_UI_SPEC.md` (`SC-0101-04-03`), `mockups/3.jpg`
- **業務背景**：提供檢視/編輯側邊抽屜，實作已引用 Agency Code 鎖定唯讀、再保人引用說明與最近 5 筆異動審計紀錄。

### 驗收條件 (BDD)
- **場景 1 (已引用代碼鎖定唯讀 - mockups/3.jpg)**：開啟已被再保人評等引用之機構，代碼欄位呈現鎖頭圖示（`[🔒]`），強制 disabled 唯讀。
- **場景 2 (引用狀況面板 - mockups/3.jpg)**：展示「本機構已被 X 筆再保人評等紀錄引用，不可刪除，僅可標記作廢」，刪除按鈕鎖定。
- **場景 3 (審計歷程面板)**：展示最近 5 筆異動（時間、人員、欄位、前後值、原因），提供查看全部與匯出。
- **場景 4 (設為作廢)**：點擊「設為作廢」輸入原因送出，狀態即時刷新。

## 2. 影響範圍 (嚴格 4 檔)
- `src/components/menus/rating/RatingAgencyDetailDrawer.tsx`
- `src/components/menus/rating/RatingAgencyReferenceSection.tsx`
- `src/components/menus/rating/RatingAgencyAuditHistoryModal.tsx`
- `src/components/menus/rating/RatingAgencyDeleteConfirmModal.tsx`
