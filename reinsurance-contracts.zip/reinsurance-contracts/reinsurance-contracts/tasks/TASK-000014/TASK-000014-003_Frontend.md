# TASK-000014-003: 信用評等機構清單檢索表格、狀態標籤與 Excel 匯出畫面 (SC-0101-04-01)

## 1. 需求描述與驗收標準
- **規格依據**：`specs/UI_SPEC/RatingAgency_UI_SPEC.md` (`SC-0101-04-01`), `mockups/1.jpg`
- **業務背景**：實作信用評等機構入口清單畫面、300ms 防抖查詢、6 大欄位表格與 Excel 匯出。

### 驗收條件 (BDD)
- **場景 1 (清單載入 - mockups/1.jpg)**：訪問 `/settings/menus/rating-agencies`，展現標題 `SC-0101-04-01` 主畫面。
- **場景 2 (檢索過濾)**：輸入代碼或中英文名稱，300ms 防抖動態過濾。
- **場景 3 (表格欄位)**：渲染 6 大欄位（顯示順序 ⇅、代碼、中文名稱、英文全名、狀態 Badge、功能按鈕）。
- **場景 4 (工具列防呆)**：「批次匯入」按鈕 disabled 置灰；「匯出 Excel」點擊觸發下載。

## 2. 影響範圍 (嚴格 4 檔)
- `src/app/(dashboard)/settings/menus/rating-agencies/page.tsx`
- `src/components/menus/rating/RatingAgencySearchForm.tsx`
- `src/components/menus/rating/RatingAgencyListTable.tsx`
- `src/services/rating-agency-api.ts`
