# TASK-000014-001: 評等機構實體、資料表綱要、檢索分頁與核心 CRUD API

## 1. 需求描述與驗收標準
- **規格依據**：`specs/SA_SPEC.md` (§2 BR-CRA-01, BR-CRA-05), `specs/DBA_SPEC/RatingAgency_DBA_SPEC.md`
- **業務背景**：建立信用評等機構主檔資料模型、自動排序計算（max + 10）與代碼唯一性檢核。

### 驗收條件 (BDD)
- **場景 1 (分頁檢索 - TC-CRA-01)**：發送 `GET /api/v1/system/credit-rating-agencies?keyword=SP&page=0&size=20&sort=sortOrder,asc`，回傳 200 OK 分頁清單，依 `sortOrder` 升冪排序。
- **場景 2 (新增機構與排序計算 - TC-CRA-02)**：提供代碼 `"AMB"`、中英文名稱，未提供 `sortOrder`。回傳 201 Created，`sortOrder` 自動帶入現有最大值 + 10，`isDisabled = false`。
- **場景 3 (代碼重複衝突 409 - TC-CRA-03)**：代碼已存在時新增，回傳 409 Conflict (`ERR_DUPLICATE_AGENCY_CODE`)。
- **場景 4 (樂觀鎖更新 - TC-CRA-06)**：帶入 `version = 0` 更新名稱，回傳 200 OK，`version` 遞增；版本不符時回傳 409 Conflict。

## 2. 影響範圍 (嚴格 5 檔)
- `src/main/resources/db/migration/V20261015_02__create_system_credit_rating_agencies.sql`
- `src/main/java/com/reinsurance/core/domain/rating/CreditRatingAgency.java`
- `src/main/java/com/reinsurance/core/repository/CreditRatingAgencyRepository.java`
- `src/main/java/com/reinsurance/core/service/CreditRatingAgencyService.java`
- `src/main/java/com/reinsurance/core/controller/CreditRatingAgencyController.java`
