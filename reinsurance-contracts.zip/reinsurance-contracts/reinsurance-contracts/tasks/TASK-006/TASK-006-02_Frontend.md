# File: tasks/TASK-006/TASK-006-02_Frontend.md
# TASK-006-02: 區域新增彈窗、維護抽屜與關聯刪除防呆防護 UX (SC-0101-01-05 / SC-0101-01-06)

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 使用案例：`tasks/TASK-006/specs/USE_CASE_SPEC/Region_USE_CASE_SPEC.md` (UC-REG-02 ~ 07)
  - 系統/API設計：`tasks/TASK-006/specs/SD_SPEC/Region_SD_SPEC.md` (§2.2 POST, §2.3 PUT, §2.5 DELETE)
  - 前端架構：`tasks/TASK-006/specs/UI_SPEC/Region_UI_SPEC.md` (§3.2, §3.3)
  - 設計稿對齊：`tasks/TASK-006/mockups/5.jpg, 6.jpg`
  - 測試驗收規範：`tasks/TASK-006/specs/QA_SPEC/Region_QA_SPEC.md` (TC-REG-02 ~ 07)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (§6.3.1 前端切片 2 規範, Form Validation & Error UX, 409 Conflict)
- **業務背景**：提供區域主檔之新增彈窗與右側滑出維護抽屜，實作三層表單防呆驗證、409 代碼重複標紅反饋，以及被引用時鎖定禁止刪除之資安防護體驗。

### 驗收條件 (BDD 結構化規範)
- **場景 1 (Form Fool-proofing - 前端即時空值阻擋 - mockups/5.jpg)**：
  - **Given**: 新增彈窗 (`RegionFormModal`) 開啟。
  - **When**: 使用者未輸入代碼或名稱即點擊「儲存」按鈕。
  - **Then**: 前端直接阻擋送出，出錯欄位呈現紅色外框 (`border-red-400 focus:ring-red-200`)，輸入框下方顯示紅色提示文字，游標自動聚焦第一個出錯欄位。
- **場景 2 (Immediate Error Clearing - 打字即時消除錯誤)**：
  - **Given**: 某欄位處於紅框錯誤狀態。
  - **When**: 使用者於該欄位開始打字 (`onChange`)。
  - **Then**: 該欄位的紅框外框與錯誤提示文字立即自動消除。
- **場景 3 (Conflict Path - 409 代碼重複衝突定位)**：
  - **Given**: 使用者輸入已存在之代碼並點擊儲存。
  - **When**: 後端回傳 `HTTP 409 Conflict` (包含 `code: "ERR_REGION_CODE_DUPLICATE"` 或 `error`)。
  - **Then**: 彈窗保持開啟，代碼輸入框被精準標紅並提示「此代碼已被使用」，彈窗頂部顯示醒目警示橫幅，外層頁面同步觸發 Toast 提示。
- **場景 4 (維護抽屜與關聯刪除按鈕鎖定 - mockups/6.jpg)**：
  - **Given**: 使用者點擊表格中某區域之「編輯」開啟右側維護抽屜 (`RegionDetailDrawer`)。
  - **When**: 該區域被引用國家數 (`referenceCount`) > 0。
  - **Then**: 抽屜頂部展示提示橫幅「本區域目前關聯 X 個國家，禁止實體刪除」；刪除按鈕鎖定為 Disabled 狀態，滑鼠懸停顯示 Tooltip 提示「已有國家引用，禁止刪除」。
- **場景 5 (抽屜內編輯與樂觀鎖送出)**：
  - **Given**: 維護抽屜開啟。
  - **When**: 使用者修改中文名、英文名或顯示順序，點擊「儲存修改」。
  - **Then**: 發送 `PUT /api/v1/system/regions/{id}`（帶入樂觀鎖 `version`），成功後更新清單資料並關閉抽屜。
- **場景 6 (零引用安全刪除二次確認)**：
  - **Given**: 該區域被引用國家數 `referenceCount === 0`。
  - **When**: 使用者點擊刪除按鈕。
  - **Then**: 喚起刪除二次確認對話框 (`RegionDeleteConfirmModal`)，再次提示影響範圍；確認送出後發送 DELETE API，成功後關閉抽屜並刷新清單。
- **場景 7 (i18n & Config 基線合規 - next-intl)**：
  - 導入 `next-intl` 標準國際化框架，彈窗與抽屜所有標題、欄位 Label、Placeholder、警示與提示文字抽離至 `locales/zh-TW.json` 與 `locales/en-US.json` 雙語字典，元件一律透過 `useTranslations()` Hook 與 `t(key)` 存取，嚴禁於 JSX 內寫死硬編碼文字。
- **場景 8 (Quality Gate)**：
  - 執行 `npx tsc --noEmit` 型別檢查 0 錯誤。

## 2. 影響範圍與檔案清單 (Scope)
> 注意：不屬於該端專案的清單必須完全留空，嚴禁混雜。嚴格遵守 3~5 檔規範。

### Backend Files


### Frontend Files
- src/components/menus/region/RegionFormModal.tsx
- src/components/menus/region/RegionDetailDrawer.tsx
- src/components/menus/region/RegionDeleteConfirmModal.tsx

## 3. 詳細技術規格（只寫規格，不寫程式碼）
### 3.1 新增區域彈窗 (RegionFormModal.tsx)
- 表單欄位：`代碼` (自動轉大寫，必填)、`中文名稱` (必填)、`英文名稱` (必填)、`顯示順序` (數字，預設自動計算帶入)。
- 三層防呆驗證：空值阻擋標紅聚焦、打字即時清錯、409 代碼重複精確定位反紅。

### 3.2 區域維護右側抽屜 (RegionDetailDrawer.tsx)
- 右側滑出式抽屜 (Slide-over Drawer)，包含基本資料檢視/編輯與關聯國家提示卡片。
- 關聯保護邏輯：若 `referenceCount > 0`，刪除按鈕鎖定 Disabled 並提供 Tooltip 說明。
- 狀態切換開關：提供即時設為作廢開關，替代破壞性刪除。

### 3.3 刪除確認彈窗 (RegionDeleteConfirmModal.tsx)
- 危險動作確認：紅色警示圖示、明確標示即將刪除之代碼與名稱，提供「取消」與「確認刪除」按鈕。
