# File: tasks/TASK-006/TASK-006-04_Frontend.md
# TASK-006-04: 國家選單新增與檢視/編輯法遵警示維護畫面與全局規格統整 (SC-0101-01-02 / SC-0101-01-03)

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 使用案例：`tasks/TASK-006/specs/USE_CASE_SPEC/Country_USE_CASE_SPEC.md` (UC-CTY-03 ~ 09)
  - 系統/API設計：`tasks/TASK-006/specs/SD_SPEC/Country_SD_SPEC.md` (§2.2 POST, §2.3 PUT, §2.5 DELETE)
  - 前端架構：`tasks/TASK-006/specs/UI_SPEC/Country_UI_SPEC.md`
  - 設計稿對齊：`tasks/TASK-006/mockups/2.jpg, 3.jpg`
  - 測試驗收規範：`tasks/TASK-006/specs/QA_SPEC/Country_QA_SPEC.md` (TC-CTY-02 ~ 10)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (§6.3.1 前端切片 2 規範, Form Validation & Error UX, Living Master Docs)
- **業務背景**：提供國家主檔之新增彈窗與檢視/編輯側邊卡片抽屜，涵蓋所屬區域關聯檢核、法遵制裁警示維護與多模組引用防護提示，並在模組收尾時執行 Master Spec 統整。

### 驗收條件 (BDD 結構化規範)
- **場景 1 (Form Fool-proofing - 新增表單防呆與 409 衝突定位 - mockups/2.jpg)**：
  - **Given**: 新增國家彈窗 (`CountryFormModal`, mockups/2.jpg) 開啟。
  - **When**: 使用者未填寫必填欄位（代碼、名稱、所屬區域）即點擊「儲存」。
  - **Then**: 前端直接阻擋送出，出錯欄位呈現紅色外框 (`border-red-400 focus:ring-red-200`)，輸入框下方顯示錯誤文字，游標自動聚焦第一個出錯欄位；輸入時即時清除錯誤。
  - **And**: 若後端回傳 409 Conflict (`ERR_DUPLICATE_COUNTRY_CODE`)，代碼輸入框精確標紅提示「此代碼已被使用」，彈窗頂部顯示警示橫幅，外層頁面觸發 Toast。
- **場景 2 (制裁勾選動態連動)**：
  - **Given**: 新增或編輯表單開啟。
  - **When**: 使用者勾選「法遵制裁」(`isSanctioned`) 為 true。
  - **Then**: 制裁生效日期輸入框動態呈現並轉為必填項。
- **場景 3 (檢視/編輯抽屜與引用鎖定防護 - mockups/3.jpg)**：
  - **Given**: 點擊國家項目開啟側邊抽屜 (`CountryDetailDrawer`)。
  - **When**: 該國家已被外部業務模組引用 (`referenceCount > 0`)。
  - **Then**: 渲染 `ReferenceSummaryCard` 統計卡片，國家代碼輸入框自動鎖定為唯讀 (Disabled)，刪除按鈕鎖定禁用並顯示 Tooltip 提示「已有資料引用，禁止刪除」。
- **場景 4 (法遵制裁警示橫幅 - SanctionAlertBanner)**：
  - **Given**: 開啟之國家為受制裁國家。
  - **When**: 抽屜渲染。
  - **Then**: 抽屜頂部渲染醒目的琥珀/紅色警示橫幅 (`SanctionAlertBanner`)，標明制裁生效日與核保審查限制。
- **場景 5 (零引用安全刪除二次確認)**：
  - **Given**: 該國家未被外部業務引用 (`referenceCount === 0`)。
  - **When**: 使用者點擊刪除按鈕。
  - **Then**: 跳出二次確認對話框，確認後送出 DELETE API，成功後關閉抽屜並刷新清單。
- **場景 6 (i18n & 基礎基線合規 - next-intl)**：
  - 導入 `next-intl` 標準國際化框架，畫面所有標題、按鈕、提示文字抽離至 `locales/zh-TW.json` 與 `locales/en-US.json` 雙語字典，元件一律透過 `useTranslations()` Hook 與 `t(key)` 存取，嚴禁於 JSX 內寫死硬編碼文字。
- **場景 7 (Quality Gate)**：
  - 執行 `npx tsc --noEmit` 型別檢查 0 錯誤。
- **場景 8 (Living Master Documentation DoD - 模組收尾統整)**：
  - 當本任務驗收通過，確認 TASK-006 模組下所有後端/前端任務均已完成時，自動將 `tasks/TASK-006/specs/` 下之增量規範合併更新至專案全局 `docs/specs/` (`SA_SPEC.md`, `DBA_SPEC.md`, `SD_SPEC.md`, `UI_SPEC.md`, `QA_SPEC.md`)。

## 2. 影響範圍與檔案清單 (Scope)
> 注意：不屬於該端專案的清單必須完全留空，嚴禁混雜。嚴格遵守 3~5 檔規範。

### Backend Files


### Frontend Files
- src/components/menus/country/CountryFormModal.tsx
- src/components/menus/country/CountryDetailDrawer.tsx
- src/components/menus/country/SanctionAlertBanner.tsx
- src/components/menus/country/ReferenceSummaryCard.tsx

## 3. 詳細技術規格（只寫規格，不寫程式碼）
### 3.1 新增彈窗 (CountryFormModal.tsx)
- 表單驗證：代碼必須為 2~3 碼大寫英文字母，所屬區域為必填選項。
- 實作防呆三道防線：送出前空值標紅聚焦、打字即時清錯、409 代碼重複反紅提示。

### 3.2 檢視/編輯側邊卡片 (CountryDetailDrawer.tsx)
- 整合 `SanctionAlertBanner` 與 `ReferenceSummaryCard`。
- 根據 `referenceCount` 鎖定代碼與刪除按鈕。

### 3.3 收尾統整條款 (Living Master Documentation)
- 當本任務驗收通過，確認 TASK-006 全模組微任務均已完成：
  - 自動將 `tasks/TASK-006/specs/` 合併至專案全局 `docs/specs/`。
