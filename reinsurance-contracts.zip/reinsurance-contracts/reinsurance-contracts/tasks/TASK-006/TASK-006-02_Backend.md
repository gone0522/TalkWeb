# File: tasks/TASK-006/TASK-006-02_Backend.md
# TASK-006-02: 國家 (Country) 主檔資料模型、檢索分頁、CRUD 與法遵引用防護 API

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 業務需求：`tasks/TASK-006/specs/SA_SPEC.md` (§5 業務規則 BR-CTY-01 ~ 04)
  - 使用案例：`tasks/TASK-006/specs/USE_CASE_SPEC/Country_USE_CASE_SPEC.md` (UC-CTY-01 ~ 09)
  - 資料模型：`tasks/TASK-006/specs/DBA_SPEC/Country_DBA_SPEC.md` (system_countries 表結構與索引)
  - 系統/API詳細設計：`tasks/TASK-006/specs/SD_SPEC/Country_SD_SPEC.md` (§2 API 詳細契約與 JSON Schema)
  - 測試驗收規範：`tasks/TASK-006/specs/QA_SPEC/Country_QA_SPEC.md` (TC-CTY-01 ~ 10, 邊界 TC-CTY-B01 ~ B03)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (DDD Reference by Identity, SOLID, OWASP, TDD)
- **業務背景**：升級國家主檔，提供多維檢索分頁、所屬區域關聯檢核、法遵制裁註記與生效日連動、以及多模組外部引用防刪保護機制。

### 驗收條件 (BDD 結構化規範 - 覆蓋 100% 業務情境)
- **場景 1 (Query Path - 多維條件檢索國家清單 - TC-CTY-01, UC-CTY-01, UC-CTY-02)**：
  - **Given**: 資料庫存在多筆國家資料，包含受制裁與一般國家。
  - **When**: 發送 `GET /api/v1/system/countries?keyword=日&regionCode=ASIA&isSanctioned=false&status=ACTIVE&page=0&size=10&sort=sortOrder,asc`。
  - **Then**: 伺服器回傳 `HTTP 200 OK`，包含多條件過濾分頁結果 (`CountryPageResponse`)，每筆包含 `id`, `code`, `nameZh`, `nameEn`, `regionCode`, `regionNameZh`, `isSanctioned`, `sanctionDate`, `sortOrder`, `status`, `referenceCount`。
- **場景 2 (Happy Path - 關聯有效區域新增國家 - TC-CTY-02, UC-CTY-03)**：
  - **Given**: 使用者提供 `code: "JP"` (2~3 碼大寫)、`nameZh: "日本"`、`nameEn: "Japan"`、`regionCode: "ASIA"`（有效且 `is_disabled = false`）、`isSanctioned: false`。
  - **When**: 發送 `POST /api/v1/system/countries`。
  - **Then**: 伺服器回傳 `HTTP 201 Created`，資料庫落地，`status = ACTIVE`，`version = 0`，審計欄位自動注入。
- **場景 3 (Conflict Path - 國家代碼重複 409 - TC-CTY-03, UC-CTY-03)**：
  - **Given**: 系統已存在代碼為 `"JP"` 之國家。
  - **When**: 發送 `POST /api/v1/system/countries` 且 `code` 為 `"JP"`。
  - **Then**: 伺服器回傳 `HTTP 409 Conflict`，包含標準錯誤代碼 `ERR_DUPLICATE_COUNTRY_CODE` 與清晰說明「國家代碼 'JP' 已存在」。
- **場景 4 (Defense Path - 關聯不存在或已作廢區域阻擋 400 - TC-CTY-04, TC-CTY-05, UC-CTY-04)**：
  - **Given**: 傳入之 `regionCode` 不存在、或該區域處於作廢狀態 (`is_disabled = true`)。
  - **When**: 發送 `POST` 或 `PUT` 請求。
  - **Then**: 伺服器回傳 `HTTP 400 Bad Request`，包含錯誤代碼 `ERR_REGION_INACTIVE_CANNOT_ASSIGN`，拒絕建立並提示「指定之所屬區域已停用作廢或不存在」。
- **場景 5 (Sanction Validation Path - 制裁日期連動驗證 400 - TC-CTY-06, UC-CTY-07)**：
  - **Given**: 使用者勾選 `isSanctioned = true` 但未填寫 `sanctionDate`。
  - **When**: 發送 `POST` 或 `PUT` 請求。
  - **Then**: 伺服器回傳 `HTTP 400 Bad Request`，錯誤代碼 `ERR_SANCTION_DATE_REQUIRED`，提示「勾選受制裁時必須填寫制裁生效日期」。
- **場景 6 (Update Path - 修改國家名稱、所屬區域與制裁狀態 - TC-CTY-06, TC-CTY-B03)**：
  - **Given**: 存在 `id = 101, version = 0` 之國家。
  - **When**: 發送 `PUT /api/v1/system/countries/101`，更新中文名、英文名、所屬區域、制裁狀態與生效日，帶入 `version = 0`。
  - **Then**: 伺服器回傳 `HTTP 200 OK`，資料更新且 `version` 遞增為 1；`code` 保持不變（國家代碼建立後鎖定禁止修改）。
- **場景 7 (Status Toggle Path - 切換國家作廢狀態)**：
  - **Given**: 國家處於 `ACTIVE` 狀態。
  - **When**: 發送 `PATCH /api/v1/system/countries/101/status`，Body 為 `{ "status": "INACTIVE" }`。
  - **Then**: 伺服器回傳 `HTTP 200 OK`，`is_disabled = true`，更新時間刷新。
- **場景 8 (Safe Delete Path - 無外部引用國家物理刪除 - TC-CTY-07, UC-CTY-08)**：
  - **Given**: 該國家未被任何外部業務模組引用 (`referenceCount == 0`)。
  - **When**: 發送 `DELETE /api/v1/system/countries/101`。
  - **Then**: 伺服器回傳 `HTTP 204 No Content`，實體成功自資料庫移除。
- **場景 9 (Referential Defense Path - 外部引用防刪阻擋 400 - TC-CTY-08, TC-CTY-09, UC-CTY-09)**：
  - **Given**: 該國家已被金融機構、再保人或合約引用 (`referenceCount > 0`)。
  - **When**: 發送 `DELETE /api/v1/system/countries/101`。
  - **Then**: 伺服器回傳 `HTTP 400 Bad Request`，錯誤代碼 `ERR_COUNTRY_REFERENCED_CANNOT_DELETE`，說明「該國家已被 X 筆外部業務資料引用，禁止實體刪除，僅允許切換為作廢」，實體完好無損。
- **場景 10 (Single Detail Query Path - 查詢單筆國家詳情與引用計數 - TC-CTY-10)**：
  - **Given**: 存在 `id = 101` 之國家。
  - **When**: 發送 `GET /api/v1/system/countries/101`。
  - **Then**: 伺服器回傳 `HTTP 200 OK`，完整包含實體欄位、所屬區域名稱與外部模組引用統計數字。
- **場景 11 (TDD 品質閘門)**：
  - 單元測試 `CountryServiceTest.java` 覆蓋上述全部情境與邊界條件，執行 `mvn test` 100% 通過 (0 Failures, 0 Errors)。

## 2. 影響範圍與檔案清單 (Scope)
> 注意：不屬於該端專案的清單必須完全留空，嚴禁混雜。

### Backend Files
- src/main/java/com/reinsurance/core/domain/country/Country.java
- src/main/java/com/reinsurance/core/dto/country/CountryDto.java
- src/main/java/com/reinsurance/core/repository/CountryRepository.java
- src/main/java/com/reinsurance/core/service/CountryService.java
- src/main/java/com/reinsurance/core/controller/CountryController.java
- src/test/java/com/reinsurance/core/service/CountryServiceTest.java

### Frontend Files


## 3. 詳細技術規格（只寫規格，不寫程式碼）
### 3.1 契約規格與 DTO JSON 長相 (contracts/openapi.yaml)
- **GET /api/v1/system/countries (多維分頁查詢)**:
  - Query: `keyword`, `regionCode`, `isSanctioned`, `status`, `page`, `size`, `sort`.
  - Response 200: `CountryPageResponse`.
- **POST /api/v1/system/countries (新增)**:
  - Body: `CountryCreateRequest` (`code`, `nameZh`, `nameEn`, `regionCode`, `isSanctioned`, `sanctionDate`, `sortOrder`).
  - Response 201: `CountryResponse`.
  - Response 409: Problem Details (`ERR_DUPLICATE_COUNTRY_CODE`).
  - Response 400: Problem Details (`ERR_REGION_INACTIVE_CANNOT_ASSIGN`).
- **PUT /api/v1/system/countries/{id} (修改)**:
  - Body: `CountryUpdateRequest` (`nameZh`, `nameEn`, `regionCode`, `isSanctioned`, `sanctionDate`, `sortOrder`, `version`).
- **PATCH /api/v1/system/countries/{id}/status (狀態切換)**:
  - Body: `StatusUpdateRequest`.
- **DELETE /api/v1/system/countries/{id} (刪除)**:
  - Response 204: 成功刪除。
  - Response 400: Problem Details (`ERR_COUNTRY_REFERENCED_CANNOT_DELETE`).

### 3.2 領域模型與資料存取規範
- **DDD 實體參照原則 (Country.java)**:
  - 對應 `system_countries`。跨聚合參照嚴格使用 `regionCode: String`，嚴禁直接使用 `@ManyToOne Region` 實體綁定。
  - 包含 `is_sanctioned`, `sanction_date`, `is_disabled`, `@Version Long version`。
- **Repository 安全規範 (CountryRepository.java)**:
  - 支援 Spring Data JPA Specification 進行多條件動態過濾。
  - 查詢使用 JPQL，禁止原生 SQL 拼接。
