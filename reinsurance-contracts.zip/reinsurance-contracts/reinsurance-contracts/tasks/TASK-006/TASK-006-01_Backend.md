# File: tasks/TASK-006/TASK-006-01_Backend.md
# TASK-006-01: 區域 (Region) 主檔資料模型、檢索分頁、CRUD 與防刪保護 API

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 業務需求：`tasks/TASK-006/specs/SA_SPEC.md` (§5 業務規則 BR-REG-01 ~ 04)
  - 使用案例：`tasks/TASK-006/specs/USE_CASE_SPEC/Region_USE_CASE_SPEC.md` (UC-REG-01 ~ 07)
  - 資料模型：`tasks/TASK-006/specs/DBA_SPEC/Region_DBA_SPEC.md` (system_regions 表結構與索引)
  - 系統/API詳細設計：`tasks/TASK-006/specs/SD_SPEC/Region_SD_SPEC.md` (§2 API 詳細契約與 JSON Schema)
  - 測試驗收規範：`tasks/TASK-006/specs/QA_SPEC/Region_QA_SPEC.md` (TC-REG-01 ~ 07, 邊界 TC-REG-B01 ~ B04)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (DDD, SOLID, TDD, OWASP SQLi/IDOR, RFC 7807)
- **業務背景**：維護公司自訂風險累積區域主檔，提供國家主檔關聯設定與承保彙總使用，具備完整檢索、新增、修改、狀態切換與關聯防刪保護能力。

### 驗收條件 (BDD 結構化規範 - 覆蓋 100% 業務情境)
- **場景 1 (Query Path - 分頁檢索與關聯國家數投影 - TC-REG-01, UC-REG-01)**：
  - **Given**: 資料庫中存在多筆區域，部分已被國家資料引用。
  - **When**: 發送 `GET /api/v1/system/regions?keyword=亞&status=ACTIVE&page=0&size=10&sort=sortOrder,asc`。
  - **Then**: 伺服器回傳 `HTTP 200 OK`，主體包含分頁物件 (`RegionPageResponse`)。每一項目包含 `id`, `code`, `nameZh`, `nameEn`, `sortOrder`, `status`, `referenceCount`（由 JPQL 動態計算關聯國家數），資料清單嚴格依 `sortOrder` 升冪排序。
- **場景 2 (Happy Path - 新增區域與順序自動計算 - TC-REG-02, UC-REG-02)**：
  - **Given**: 使用者提供唯一的區域代碼（`"ME"`）、中文名（`"中東區"`）、英文名（`"Middle East"`），未提供 `sortOrder`。
  - **When**: 發送 `POST /api/v1/system/regions`。
  - **Then**: 伺服器回傳 `HTTP 201 Created`，資料庫成功落地，`sortOrder` 自動帶入現有最大順序值 + 10，狀態預設為 `ACTIVE` (`is_disabled = false`)，樂觀鎖 `version` 預設為 0，審計欄位自動注入。
- **場景 3 (Conflict Path - 代碼重複衝突 409 - TC-REG-03, UC-REG-03)**：
  - **Given**: 系統已存在代碼為 `"ASIA"` 之區域。
  - **When**: 發送 `POST /api/v1/system/regions` 且 `code` 為 `"ASIA"`。
  - **Then**: 伺服器回傳 `HTTP 409 Conflict`，錯誤主體包含標準代碼 `ERR_REGION_CODE_DUPLICATE` 與說明「區域代碼 'ASIA' 已存在，請使用其他代碼」。
- **場景 4 (Validation Path - 必填、長度與正則格式檢核 400 - TC-REG-B01, TC-REG-B02, TC-REG-B04)**：
  - **Given**: 傳入之 `code` 為空、超過 20 碼、包含小寫或特殊符號（未符合 `^[A-Z0-9_-]+$`）、或名稱為空、或 `sortOrder < 0`。
  - **When**: 發送 `POST` 或 `PUT`。
  - **Then**: 伺服器回傳 `HTTP 400 Bad Request`，包含具體欄位校驗錯誤詳情。
- **場景 5 (Update Path - 修改區域名稱與樂觀鎖併發保護 - TC-REG-04, TC-REG-B03, UC-REG-04)**：
  - **Given**: 存在 `id = 1, version = 0` 之區域。
  - **When**: 發送 `PUT /api/v1/system/regions/1`，更新 `nameZh: "中東與北非區"`, `nameEn: "Middle East & North Africa"`, `sortOrder: 35`, 帶入 `version = 0`。
  - **Then**: 伺服器回傳 `HTTP 200 OK`，資料庫更新，`version` 遞增為 1；`code` 保持不變（代碼建立後禁止變更）。
  - **And**: 若傳入 `version = 999` (版本不一致)，拋出樂觀鎖例外，回傳 `HTTP 409 Conflict`。
- **場景 6 (Status Toggle Path - 快速切換作廢狀態 - TC-REG-05, UC-REG-05)**：
  - **Given**: 區域處於 `ACTIVE` 狀態。
  - **When**: 發送 `PATCH /api/v1/system/regions/1/status`，Body 為 `{ "status": "INACTIVE" }`。
  - **Then**: 伺服器回傳 `HTTP 200 OK`，狀態變更為作廢 (`is_disabled = true`)，更新時間刷新。
- **場景 7 (Safe Delete Path - 無引用區域物理刪除 - TC-REG-06, UC-REG-06)**：
  - **Given**: 該區域關聯國家計數為 0 (`referenceCount == 0`)。
  - **When**: 發送 `DELETE /api/v1/system/regions/1`。
  - **Then**: 伺服器回傳 `HTTP 204 No Content`，實體自資料庫完全移除。
- **場景 8 (Referential Defense Path - 關聯國家防刪阻擋 400 - TC-REG-07, UC-REG-07)**：
  - **Given**: 該區域已被 1 筆以上國家資料引用 (`referenceCount > 0`)。
  - **When**: 發送 `DELETE /api/v1/system/regions/1`。
  - **Then**: 伺服器回傳 `HTTP 400 Bad Request`，錯誤代碼 `ERR_REGION_REFERENCED_CANNOT_DELETE`，說明「該區域已被 X 筆國家資料引用，禁止刪除，僅允許切換為作廢狀態」，實體資料不變。
- **場景 9 (TDD 品質閘門)**：
  - 單元測試 `RegionServiceTest.java` 覆蓋上述全部 8 個場景與邊界條件，執行 `mvn test` 100% 通過 (0 Failures, 0 Errors)。

## 2. 影響範圍與檔案清單 (Scope)
> 注意：不屬於該端專案的清單必須完全留空，嚴禁混雜。

### Backend Files
- src/main/java/com/reinsurance/core/domain/region/Region.java
- src/main/java/com/reinsurance/core/dto/region/RegionDto.java
- src/main/java/com/reinsurance/core/repository/RegionRepository.java
- src/main/java/com/reinsurance/core/service/RegionService.java
- src/main/java/com/reinsurance/core/controller/RegionController.java
- src/test/java/com/reinsurance/core/service/RegionServiceTest.java

### Frontend Files


## 3. 詳細技術規格（只寫規格，不寫程式碼）
### 3.1 契約規格與 DTO JSON 長相 (contracts/openapi.yaml)
- **GET /api/v1/system/regions (分頁查詢)**:
  - Query: `keyword` (String, 可空), `status` (String, 可空, ACTIVE/INACTIVE), `page` (Integer, 預設 0), `size` (Integer, 預設 10), `sort` (String, 預設 "sortOrder,asc").
  - Response 200: `RegionPageResponse` (包含 `content: List<RegionResponse>`, `pageNumber`, `pageSize`, `totalElements`, `totalPages`).
- **POST /api/v1/system/regions (新增)**:
  - Body: `RegionCreateRequest` (`code`, `nameZh`, `nameEn`, `sortOrder`).
  - Response 201: `RegionResponse`.
  - Response 409: Problem Details (`code: ERR_REGION_CODE_DUPLICATE`).
- **PUT /api/v1/system/regions/{id} (修改)**:
  - Body: `RegionUpdateRequest` (`nameZh`, `nameEn`, `sortOrder`, `version`).
  - Response 200: `RegionResponse`.
- **PATCH /api/v1/system/regions/{id}/status (狀態切換)**:
  - Body: `StatusUpdateRequest` (`status: ACTIVE | INACTIVE`).
  - Response 200: `RegionResponse`.
- **DELETE /api/v1/system/regions/{id} (刪除)**:
  - Response 204: 成功刪除。
  - Response 400: Problem Details (`code: ERR_REGION_REFERENCED_CANNOT_DELETE`).

### 3.2 領域模型與資料存取規範
- **實體模型 (Region.java)**:
  - 對應 `system_regions`，包含 `@Id`, `code` (unique, not null), `name_zh`, `name_en`, `sort_order`, `is_disabled` (boolean), `@Version Long version`, 以及審計欄位。
- **Repository 查詢安全 (RegionRepository.java)**:
  - 關聯引用檢查強制使用 JPQL 針對實體屬性查詢（`SELECT COUNT(c) FROM Country c WHERE c.regionCode = :code`）。
  - 清單查詢使用動態 Specification 或自訂 JPQL 投影，嚴禁原生 SQL 拼接。
- **依賴注入與 Clean Code**:
  - 全面採用建構子注入 (Constructor Injection, DIP)，禁止使用 `@Autowired`。
  - Service 實作快速失敗 (Fail-Fast Guard Clauses)。
