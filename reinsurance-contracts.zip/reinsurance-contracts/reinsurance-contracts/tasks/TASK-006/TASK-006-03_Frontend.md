# File: tasks/TASK-006/TASK-006-03_Frontend.md
# TASK-006-03: 國家選單清單檢索、多維篩選與制裁高亮畫面 (SC-0101-01-01)

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 使用案例：`tasks/TASK-006/specs/USE_CASE_SPEC/Country_USE_CASE_SPEC.md` (UC-CTY-01, UC-CTY-02)
  - 系統/API設計：`tasks/TASK-006/specs/SD_SPEC/Country_SD_SPEC.md` (§2.1 GET, §2.4 PATCH)
  - 前端架構：`tasks/TASK-006/specs/UI_SPEC/Country_UI_SPEC.md` & `Common_Tab_UI_SPEC.md`
  - 設計稿對齊：`tasks/TASK-006/mockups/1.jpg`
  - 測試驗收規範：`tasks/TASK-006/specs/QA_SPEC/Country_QA_SPEC.md` (TC-CTY-01)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (§6.3.1 前端切片 1 規範, Core Web Vitals, Debounce, i18n)
- **業務背景**：於「國家選單」入口頁面下提供清單檢索介面，支援所屬區域下拉過濾、法遵制裁狀態篩選與視覺高亮。

### 驗收條件 (BDD 結構化規範)
- **場景 1 (Page Mount & Layout 呈現)**：
  - **Given**: 使用者訪問 `/settings/menus/countries`。
  - **When**: 頁面加載。
  - **Then**: 成功取代佔位頁，展示國家選單清單畫面，標題代碼為 `SC-0101-01-01`，頁籤高亮正常。
- **場景 2 (多維檢索篩選列 - 100% 對齊 mockups/1.jpg)**：
  - **Given**: 檢索表單載入完畢。
  - **When**: 使用者於第 1 列 4 欄分別輸入國家代碼（自動轉大寫）、國家中文名稱、國家英文名稱或選擇所屬區域下拉，並於第 2 列選擇法遵制裁單選鈕（全部/是/否）或資料狀態單選鈕（有效/已作廢/全部）。
  - **Then**: 點擊「查詢」或觸發 300ms 防抖後動態篩選；點擊「清除條件」清空所有條件；按鈕配色嚴格遵從深炭灰 `#374151` 與白底灰框標準。
- **場景 3 (制裁與狀態框線徽章 - 100% 對齊 mockups/1.jpg)**：
  - **Given**: 國家資料清單中包含受制裁國家 (`isSanctioned = true`)。
  - **When**: 資料表格渲染。
  - **Then**: 制裁欄位以紅色框線徽章（`border-red-500 text-red-600 bg-red-50`）標示「是」，一般國家標示「否」；資料狀態以綠框「有效」或灰框「已作廢」標示。
- **場景 4 (功能操作與檢視/編輯 - 100% 對齊 mockups/1.jpg)**：
  - **Given**: 使用者瀏覽國家清單表格。
  - **When**: 點擊功能欄位之「檢視/編輯」文字超連結。
  - **Then**: 喚起側邊抽屜 (`CountryDetailDrawer`)，展示完整基本資料與異動紀錄。表格無任何突兀的開關控制項，完全吻合 Wireframe 原型。
- **場景 5 (分頁與排序聯動)**：
  - **Given**: 資料筆數超過分頁大小。
  - **When**: 使用者點擊分頁頁碼或切換每頁筆數。
  - **Then**: 正確發送 `page`, `size` 參數並重新載入對應分頁資料。
- **場景 6 (無資料 Empty State 提示)**：
  - **Given**: 檢索無相符資料。
  - **When**: 表格渲染。
  - **Then**: 呈現友善的 Empty State 視覺與提示「查無符合條件的國家」。
- **場景 7 (i18n & 基礎基線合規 - next-intl)**：
  - 導入 `next-intl` 標準國際化框架，畫面所有欄位名稱、狀態標籤、按鈕抽離至 `locales/zh-TW.json` 與 `locales/en-US.json` 雙語字典，元件一律透過 `useTranslations()` Hook 與 `t(key)` 存取，嚴禁於 JSX 內寫死硬編碼文字。
  - API Base URL 預設為 `http://localhost:8080`，支援反向代理。
- **場景 8 (Quality Gate)**：
  - 執行 `npx tsc --noEmit` 型別檢查 0 錯誤。

## 2. 影響範圍與檔案清單 (Scope)
> 注意：不屬於該端專案的清單必須完全留空，嚴禁混雜。嚴格遵守 3~5 檔規範。

### Backend Files


### Frontend Files
- src/app/(dashboard)/settings/menus/countries/page.tsx
- src/components/menus/country/CountryListTable.tsx
- src/components/menus/country/CountrySearchForm.tsx
- src/services/country-api.ts

## 3. 詳細技術規格（只寫規格，不寫程式碼）
### 3.1 頁面入口整合 (countries/page.tsx)
- 封裝於 `MenuCardFrame` 容器內，標題為「國家選單」，畫面代碼 `SC-0101-01-01`。
- 整合搜尋條件狀態與清單表格分頁聯動。

### 3.2 國家 API 服務層 (country-api.ts)
- Base URL 預設為 `process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080'`。
- 規範介面：`CountryResponse`, `CountryPageResponse`, `CountryQueryParams`, `CountryStatusUpdateRequest`.
- 欄位定義：`code`, `nameZh`, `nameEn`, `regionCode`, `regionNameZh`, `isSanctioned`, `sanctionDate`, `status: 'ACTIVE' | 'INACTIVE'`.

### 3.3 元件結構規範
- `CountrySearchForm.tsx`: 多維過濾條件控制項（關鍵字防抖 300ms）。
- `CountryListTable.tsx`: 表格欄位展示、制裁 Badge 與編輯觸發。
