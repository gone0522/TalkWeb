# File: tasks/TASK-006/TASK-006-01_Frontend.md
# TASK-006-01: 區域選單清單表格、多維檢索與頁面入口 (SC-0101-01-04)

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **規格追溯依據**：
  - 使用案例：`tasks/TASK-006/specs/USE_CASE_SPEC/Region_USE_CASE_SPEC.md` (UC-REG-01, UC-REG-05)
  - 系統/API設計：`tasks/TASK-006/specs/SD_SPEC/Region_SD_SPEC.md` (§2.1 GET, §2.4 PATCH)
  - 前端架構：`tasks/TASK-006/specs/UI_SPEC/Region_UI_SPEC.md` (§3.1) & `Common_Tab_UI_SPEC.md`
  - 設計稿對齊：`tasks/TASK-006/mockups/4.jpg`
  - 測試驗收規範：`tasks/TASK-006/specs/QA_SPEC/Region_QA_SPEC.md` (TC-REG-01, TC-REG-05)
  - 工程與資安準則：`docs/ENGINEERING_STANDARDS.md` (§6.3.1 前端切片 1 規範, Debounce, i18n)
- **業務背景**：於共用選單管理佈局中的「區域選單」路徑下，掛載區域管理清單表格、關鍵字/狀態檢索控制項與分頁瀏覽。

### 驗收條件 (BDD 結構化規範)
- **場景 1 (Page Mount & Layout 呈現)**：
  - **Given**: 使用者訪問 `/settings/menus/regions`。
  - **When**: 頁面加載。
  - **Then**: 成功取代佔位頁，展示 `MenuCardFrame` 包裹之區域管理主畫面，畫面標題為「區域選單」，畫面代碼標記 `SC-0101-01-04`，頁籤高亮正常。
- **場景 2 (多維檢索與關鍵字防抖 - mockups/4.jpg)**：
  - **Given**: 檢索控制項載入完成。
  - **When**: 使用者於搜尋框輸入關鍵字（代碼/中文名稱/英文名稱）或選擇狀態下拉選單（全部/僅有效/僅作廢）。
  - **Then**: 關鍵字輸入框實作 300ms 防抖處理 (`useDebounce`)，自動觸發過濾，避免高頻重複請求。
- **場景 3 (清單表格 7 大欄位與關聯計數 Badge 呈現 - mockups/4.jpg)**：
  - **Given**: 資料載入成功。
  - **When**: 表格渲染資料列表。
  - **Then**: 依據 `mockups/4.jpg` 渲染 7 大欄位：
    1. `顯示順序` (居中，`text-gray-500`)
    2. `區域代碼` (粗體，`font-medium text-gray-900`)
    3. `中文名稱` (`text-gray-900`)
    4. `英文名稱` (`text-gray-500`)
    5. `關聯國家數` (數字標籤徽章 `rounded-full px-2 py-0.5 bg-blue-50 text-blue-700`)
    6. `狀態` (有效為綠色徽章，作廢為灰色徽章)
    7. `操作` (提供「編輯」按鈕與「狀態切換」開關)。
- **場景 4 (快捷狀態切換)**：
  - **Given**: 使用者點擊某一列的狀態切換開關。
  - **When**: 發送 `PATCH /api/v1/system/regions/{id}/status`。
  - **Then**: 樂觀更新該列狀態 Badge，並透過 Toast 提示狀態更新成功。
- **場景 5 (分頁與排序聯動)**：
  - **Given**: 資料筆數超過分頁大小。
  - **When**: 使用者點擊分頁頁碼或切換每頁筆數。
  - **Then**: 正確發送 `page`, `size` 參數並重新載入對應分頁資料。
- **場景 6 (無資料 Empty State 提示)**：
  - **Given**: 檢索無相符資料或資料庫無任何區域。
  - **When**: 表格渲染。
  - **Then**: 呈現友善的 Empty State 視覺與提示「查無符合條件的區域」，不出現破碎排版或白畫面。
- **場景 7 (i18n & Config 基線合規 - next-intl)**：
  - 導入 `next-intl` 標準國際化框架，畫面所有標題、表格表頭、狀態標籤與操作文字抽離至 `locales/zh-TW.json` 與 `locales/en-US.json` 雙語字典。
  - 元件一律透過 `useTranslations()` Hook 與 `t(key)` 存取，嚴禁於 JSX 或 TypeScript 檔案中寫死自然語言文字。
  - API Base URL 採用環境變數配置，支援反向代理轉發 `/api/:path*`。
- **場景 8 (Quality Gate)**：
  - 執行 `npx tsc --noEmit` 型別檢查 0 錯誤。

## 2. 影響範圍與檔案清單 (Scope)
> 注意：不屬於該端專案的清單必須完全留空，嚴禁混雜。嚴格遵守 3~5 檔規範。

### Backend Files


### Frontend Files
- src/app/(dashboard)/settings/menus/regions/page.tsx
- src/components/menus/region/RegionListTable.tsx
- src/components/menus/region/RegionSearchForm.tsx
- src/services/region-api.ts

## 3. 詳細技術規格（只寫規格，不寫程式碼）
### 3.1 頁面入口整合 (regions/page.tsx)
- 封裝於 `MenuCardFrame` 容器內，標題為「區域選單」，畫面代碼 `SC-0101-01-04`。
- 整合 `RegionSearchForm` 與 `RegionListTable`，管理查詢參數狀態與分頁。

### 3.2 區域 API 服務層 (region-api.ts)
- Base URL 預設為 `process.env.NEXT_PUBLIC_API_BASE_URL || 'http://localhost:8080'`。
- 定義介面：`RegionResponse`, `RegionPageResponse`, `RegionQueryParams`, `RegionStatusUpdateRequest`.
- 提供方法：`fetchRegions(params)`, `updateRegionStatus(id, status)`.

### 3.3 元件結構規範
- `RegionSearchForm.tsx`: 關鍵字防抖 300ms、狀態下拉、查詢與重置按鈕、新增按鈕觸發器。
- `RegionListTable.tsx`: 7 欄位表格排版、關聯國家數 Badge、狀態徽章、分頁控制列。
