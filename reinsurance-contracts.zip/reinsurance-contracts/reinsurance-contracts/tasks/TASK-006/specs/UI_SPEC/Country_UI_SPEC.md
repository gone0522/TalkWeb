# 國家選單介面與互動設計規格書 (Country UI Specification)

> **模組代碼**：`TASK-006`  
> **畫面編號**：`SC-0101-01-01` (清單), `SC-0101-01-02` (新增), `SC-0101-01-03` (詳情/抽屜)  
> **對齊設計稿**：`tasks_temp/TASK-006/mockups/1.jpg`, `2.jpg`, `3.jpg`  
> **入口頁面**：`apps/web-portal/src/app/(dashboard)/settings/menus/countries/page.tsx`  

---

## 1. 介面視覺與互動設計哲學 (UX Design Concept)

國家主檔管理肩負「法遵風控」重任，因此在設計上特別強調**「高風險資訊即時顯性化」**與**「代碼防竄改防呆」**：
- **制裁視覺高亮**：凡 `isSanctioned = true` 的國家，在清單表格與詳情頁面上均以鮮明琥珀色/警示黃 (`bg-amber-100 text-amber-800 border-amber-300`) 徽章呈現，確保核保人員一目了然。
- **外部引用統計與防刪保護**：在側邊抽屜中清楚彙總金融機構、再保人與合約的關聯筆數，若有引用則鎖定代碼並禁用刪除。

---

## 2. 元件層級架構樹 (Component Hierarchy)

```mermaid
graph TD
    Page[countries/page.tsx] --> Frame[MenuCardFrame]
    Frame --> FilterBar[CountrySearchForm]
    Frame --> Table[CountryListTable]
    Frame --> Modal[CountryFormModal]
    Frame --> Drawer[CountryDetailDrawer]
    Drawer --> AlertBanner[SanctionAlertBanner]
    Drawer --> RefCard[ReferenceSummaryCard]
```

---

## 3. 設計稿截圖逐圖對齊 (Mockup Walkthrough)

### 3.1 國家清單與多維篩選列 (對齊 `mockups/1.jpg`)
- **多維篩選列 (`CountrySearchForm.tsx`)**：
  1. `關鍵字輸入框`：模糊搜尋代碼（如 `TW`, `JP`）、中文或英文名稱。
  2. `所屬區域下拉選單`：動態調用 `region-api.ts` 載入所有有效區域清單（如「亞洲及太平洋區」）。
  3. `法遵制裁狀態快選標籤`：全部 / 僅制裁 (帶琥珀色圓點) / 正常。
  4. `作廢狀態過濾`：全部 / 有效 / 作廢。
- **資料表格 (`CountryListTable.tsx`)**：
  - 欄位包含：國家代碼 (ISO 2~3 碼)、中文名稱、英文名稱、所屬區域 (顯示區域名稱)、法遵制裁標籤 (琥珀色 Badge)、狀態、操作按鈕。

### 3.2 新增國家彈窗 (對齊 `mockups/2.jpg`)
- **欄位規劃**：
  - `國家代碼`：2~3 碼大寫英文，必填。
  - `中文名稱` / `英文名稱`：必填。
  - `所屬區域`：下拉必選（僅呈現有效區域）。
  - `法遵制裁勾選框 (Checkbox)`：勾選「本國家處於國際制裁清單」。
  - `制裁生效日期 (DatePicker)`：若勾選制裁，生效日期連動解鎖為必填。

### 3.3 詳情側邊抽屜與合規警示卡 (對齊 `mockups/3.jpg`)
- **制裁警示橫幅 (`SanctionAlertBanner.tsx`)**：
  - 顯著黃底卡片，展示警示圖示、制裁正式生效日期，以及法遵聲明文字「此國家為法遵制裁管制名單，涉及此國家之業務需呈報合規部門專案審查」。
- **外部模組引用統計卡 (`ReferenceSummaryCard.tsx`)**：
  - 條列呈現引用統計：金融機構 (3 筆)、再保人主檔 (2 筆)、再保合約 (1 筆)，總計引用 6 筆。
- **操作防呆控制**：
  - 國家代碼輸入框自動設定為 `disabled bg-gray-100`。
  - 刪除按鈕鎖定為 Disabled，防護 Tooltip 提示「已有 6 筆業務引用，禁止刪除」。
