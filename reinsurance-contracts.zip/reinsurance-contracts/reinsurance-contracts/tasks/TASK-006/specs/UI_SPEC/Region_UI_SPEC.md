# 區域選單介面與互動設計規格書 (Region UI Specification)

> **模組代碼**：`TASK-006`  
> **畫面編號**：`SC-0101-01-04` (清單), `SC-0101-01-05` (新增), `SC-0101-01-06` (詳情/編輯)  
> **對齊設計稿**：`tasks_temp/TASK-006/mockups/4.jpg`, `5.jpg`, `6.jpg`  
> **入口頁面**：`apps/web-portal/src/app/(dashboard)/settings/menus/regions/page.tsx`  

---

## 1. 介面視覺與互動設計哲學 (UX Design Concept)

區域管理介面旨在提供高效率、清晰直覺的風險分區維護環境。整體視覺嚴格遵照 `DESIGN_CONVENTIONS.md`：
- **容器風格**：純白底背景卡片 (`bg-white rounded-xl shadow-sm border border-gray-100`)。
- **色彩語意**：
  - 主要操作按鈕：品牌鮮橘高亮 (`bg-[#FF5A1F] hover:bg-[#E04F1B] text-white`)。
  - 狀態標籤：有效為綠色徽章 (`bg-green-50 text-green-700 border-green-200`)，作廢為灰色徽章 (`bg-gray-100 text-gray-600`)。
  - 刪除與警示：危險紅色 (`text-red-600 hover:text-red-700`)，被鎖定時禁用灰 (`text-gray-400 cursor-not-allowed`)。

---

## 2. 元件層級架構樹 (Component Hierarchy)

```mermaid
graph TD
    Page[regions/page.tsx] --> Frame[MenuCardFrame]
    Frame --> SearchBar[RegionSearchForm]
    Frame --> Table[RegionListTable]
    Frame --> Modal[RegionFormModal]
    Frame --> Drawer[RegionDetailDrawer]
```

---

## 3. 設計稿截圖逐圖對齊 (Mockup Walkthrough)

### 3.1 區域清單檢索畫面 (對齊 `mockups/4.jpg`)
- **頂部工具列**：
  - 關鍵字輸入框：Placeholder「搜尋區域代碼、名稱...」。
  - 狀態下拉選單：全部 / 僅有效 / 僅作廢。
  - 按鈕群：「查詢」按鈕（深灰或品牌橘）與「重置」按鈕。
  - 右側主動作：「+ 新增區域」按鈕（點擊喚起 `RegionFormModal`）。
- **資料表格欄位 (Table Columns)**：
  1. `顯示順序`：數值居中，字體 `text-gray-500`。
  2. `區域代碼`：粗體 `font-medium text-gray-900`（如 `ASIA`, `EUROPE`）。
  3. `中文名稱`：`text-gray-900`。
  4. `英文名稱`：`text-gray-500`。
  5. `關聯國家數`：數字標籤 (`badge rounded-full px-2 py-0.5 bg-blue-50 text-blue-700`)。
  6. `狀態`：有效 (綠) / 作廢 (灰)。
  7. `操作`：提供「編輯」與「作廢切換」按鈕。

### 3.2 新增區域彈窗 (對齊 `mockups/5.jpg`)
- **標題**：新增區域主檔
- **表單欄位**：
  - `區域代碼`：文字輸入框，自動轉為大寫，必填提示 `*`。
  - `中文名稱`：文字輸入框，必填。
  - `英文名稱`：文字輸入框，必填。
  - `顯示順序`：數字輸入框，預設自動帶入後端計算之 `max + 10`。
- **送出動作**：點擊「儲存」送出 POST 請求，成功後提示 Toast 並重載清單。

### 3.3 檢視/編輯與防刪保護抽屜 (對齊 `mockups/6.jpg`)
- **關聯國家提示卡片**：
  - 若 `referenceCount > 0`：上方展示提示橫幅「本區域目前關聯 12 個國家，禁止實體刪除」。
  - **刪除按鈕防呆**：刪除按鈕鎖定為 `disabled`，Hover 時顯示 Tooltip 提示「已有國家引用，禁止刪除」。
- **狀態切換開關 (Toggle Switch)**：
  - 提供即時切換「設為作廢」之開關，避免實體刪除破壞關聯。
