# 國家與區域選單共用 Tab 框架架構規格書 (Common Tab UI Specification)

> **模組代碼**：`TASK-006`  
> **畫面編號**：`SC-0101-01-01` / `SC-0101-01-04`  
> **技術棧**：Next.js 16 (App Router), React 19, Tailwind CSS  
> **設計規範**：`DESIGN_CONVENTIONS.md`  

---

## 1. 既有架構狀態與設計思維 (Architecture Grounding)

為維持再保險企業後台之統一導航體驗，國家與區域選單並非孤立頁面，而是隸屬於系統設定模組下的「選單管理」一級功能群。

### 1.1 既有目錄結構與責任劃分
```
apps/web-portal/src/app/(dashboard)/settings/menus/
├── layout.tsx                  # 【全域共用版面】提供麵包屑導航與 MenuHeaderTabs 頁籤列
├── page.tsx                    # 【根路由】預設重導向至 /settings/menus/countries
├── regions/
│   └── page.tsx                # 【區域選單入口】掛載區域管理清單、搜尋列與維護彈窗
└── countries/
    └── page.tsx                # 【國家選單入口】掛載國家管理清單、多維篩選與維護抽屜
```

### 1.2 硬性防呆規則 (Critical Architecture Guard)
- **嚴禁自訂脫幅路徑**：全專案路徑一律以 `(dashboard)/settings/menus/` 為準，嚴禁自創 `src/app/settings/menus/country-region` 等無效路由。
- **嚴禁重複拆解共用框任務**：`layout.tsx` 與 `MenuHeaderTabs.tsx` 已經完整實現，所有子任務直接專注於各自 `page.tsx` 內之商務元件組裝。

---

## 2. 導航層級與視覺風格 (Visual Style & Layout)

### 2.1 頂部麵包屑 (Breadcrumb)
- 路徑展示：`首頁 > 選單管理 > [國家選單 | 區域選單]`
- 樣式規範：文字顏色 `text-gray-500`，最後一級使用 `text-gray-900 font-medium`，支援點擊返回上一層。

### 2.2 一級頁籤切換器 (`MenuHeaderTabs.tsx`)
- 頁籤選項：
  1. **國家選單**：路由跳轉 `/settings/menus/countries`
  2. **區域選單**：路由跳轉 `/settings/menus/regions`
- 視覺狀態：
  - **Active 狀態**：底邊高亮品牌鮮橘色 (`border-b-2 border-[#FF5A1F] text-[#FF5A1F] font-semibold`)。
  - **Inactive 狀態**：文字 `text-gray-600`，Hover 時背景微淡灰過渡 (`hover:text-gray-900 hover:border-gray-300`)。
