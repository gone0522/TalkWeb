# 區域系統設計與詳細 API 契約規格書 (Region SD Specification)

> **模組代碼**：`TASK-006`  
> **服務層級**：`services/core-service` (Spring Boot 3.2.3, Java 21)  
> **單一真實來源**：`contracts/openapi.yaml`  
> **負責角色**：System Designer / Backend Lead  

---

## 1. 架構分層與責任邊界 (Architectural Blueprint)

本模組嚴格遵循領域驅動設計 (DDD) 與四層架構原則，實現高內聚低耦合：

```mermaid
graph TD
    Client[Web Portal / API Client] -->|HTTP / JSON| Controller[RegionController]
    Controller -->|DTO Request / Validation| Service[RegionService]
    Service -->|Domain Logic / Transactions| Repository[RegionRepository]
    Service -->|Cross-Module Integrity Check| CountryRepo[CountryRepository]
    Repository -->|JPA / Hibernate| Database[(PostgreSQL: system_regions)]
```

| 架構層級 | 負責類別 / 套件路徑 | 責任與實作規範 |
| :--- | :--- | :--- |
| **Controller** | `com.reinsurance.core.controller.RegionController` | 負責 HTTP 端點暴露、Swagger/OpenAPI 註解、參數綁定、JSR-380 Bean Validation 檢核，轉發至 Service 並組裝標準 ResponseEntity。 |
| **DTO** | `com.reinsurance.core.dto.region.RegionDto` | 包含 `RegionCreateRequest`, `RegionUpdateRequest`, `RegionResponse`, `RegionPageResponse`，與 OpenAPI 契約 100% 對齊。 |
| **Service** | `com.reinsurance.core.service.RegionService` | 事務邊界 (`@Transactional`)、代碼全域唯一性檢核、顯示順序自動計算、跨模組國家引用計數檢核與防刪例外拋出。 |
| **Repository** | `com.reinsurance.core.repository.RegionRepository` | 繼承 `JpaRepository` 與 `JpaSpecificationExecutor`，封裝動態多條件查詢與索引最佳化自訂 SQL。 |
| **Domain** | `com.reinsurance.core.domain.region.Region` | JPA 實體映射、審計欄位自動注入、樂觀鎖 `@Version` 控制。 |

---

## 2. 詳細 API 介面契約規格 (RESTful Endpoints)

### 2.1 分頁與多維條件查詢區域清單
- **端點路徑**: `GET /api/v1/system/regions`
- **設計哲學**: 支援無刷新動態搜尋、作廢狀態快篩與彈性分頁排序。
- **Query 參數詳細規格**:
  | 參數名稱 | 資料型態 | 是否必填 | 預設值 | 格式約束與業務說明 |
  | :--- | :--- | :---: | :--- | :--- |
  | `keyword` | `String` | 否 | `null` | 模糊比對區域代碼、中文名稱或英文名稱 (如: `ASIA`) |
  | `status` | `String` | 否 | `null` | `ACTIVE` (僅有效) / `INACTIVE` (僅作廢) / 不帶代表全部 |
  | `page` | `Integer` | 否 | `0` | 分頁頁碼 (0-indexed) |
  | `size` | `Integer` | 否 | `10` | 每頁回傳筆數 (上限 100) |
  | `sort` | `String` | 否 | `sortOrder,asc` | 排序規格 (格式: `欄位,方向`) |

- **Response 200 OK (`RegionPageResponse`)**:
```json
{
  "content": [
    {
      "id": 1,
      "code": "ASIA",
      "nameZh": "亞洲及太平洋區",
      "nameEn": "Asia Pacific",
      "sortOrder": 10,
      "status": "ACTIVE",
      "referenceCount": 12,
      "version": 0,
      "createdAt": "2026-10-07T08:30:00Z",
      "createdBy": "SYSTEM",
      "updatedAt": "2026-10-07T08:30:00Z",
      "updatedBy": "SYSTEM"
    }
  ],
  "pageNumber": 0,
  "pageSize": 10,
  "totalElements": 1,
  "totalPages": 1,
  "last": true,
  "first": true,
  "empty": false
}
```

---

### 2.2 新增區域主檔
- **端點路徑**: `POST /api/v1/system/regions`
- **Request Body (`RegionCreateRequest`)**:
```json
{
  "code": "ME",
  "nameZh": "中東區",
  "nameEn": "Middle East",
  "sortOrder": 30
}
```
- **欄位驗證規則 (Validation Rules)**:
  | 欄位名稱 | 型別 | 必填 | 驗證註解與約束 | 業務規則解說 |
  | :--- | :--- | :---: | :--- | :--- |
  | `code` | `String` | 是 | `@NotBlank`, `@Size(max = 20)`, 正則 `^[A-Z0-9_-]+$` | 區域唯一代碼，禁止小寫與特殊符號。 |
  | `nameZh` | `String` | 是 | `@NotBlank`, `@Size(max = 100)` | 繁體中文標準名稱。 |
  | `nameEn` | `String` | 是 | `@NotBlank`, `@Size(max = 100)` | 英文標準名稱。 |
  | `sortOrder` | `Integer` | 否 | `@Min(0)` | 顯示順序。若未提供，系統自動推算為 `現有最大順序 + 10`。 |

- **Response 201 Created (`RegionResponse`)**: 回傳新建完成之完整物件 JSON。
- **Response 409 Conflict (代碼重複錯誤)**:
```json
{
  "type": "about:blank",
  "title": "Conflict",
  "status": 409,
  "detail": "區域代碼 'ME' 已存在，請使用其他代碼",
  "errorCode": "ERR_REGION_CODE_DUPLICATE",
  "timestamp": "2026-10-07T12:00:00Z"
}
```

---

### 2.3 修改區域主檔
- **端點路徑**: `PUT /api/v1/system/regions/{id}`
- **Path 參數**: `id` (Long, 區域流水主鍵)
- **Request Body (`RegionUpdateRequest`)**:
```json
{
  "nameZh": "中東與北非區",
  "nameEn": "Middle East & North Africa",
  "sortOrder": 35,
  "version": 0
}
```
- **業務防呆與驗證**:
  - `code` 不允許透過 PUT 變更（代碼建立後終身不變）。
  - `version` 為樂觀鎖比對必填項，若比對失敗回傳 HTTP 409 Conflict。

---

### 2.4 切換區域作廢狀態
- **端點路徑**: `PATCH /api/v1/system/regions/{id}/status`
- **Request Body (`StatusUpdateRequest`)**:
```json
{
  "status": "INACTIVE"
}
```
- **說明**: 狀態值限定為 `ACTIVE` (啟用) 或 `INACTIVE` (停用作廢)。

---

### 2.5 刪除區域主檔 (含國家引用防護)
- **端點路徑**: `DELETE /api/v1/system/regions/{id}`
- **業務防護邏輯**:
  1. Service 查詢該區域之 `code`。
  2. 呼叫 `CountryRepository.countByRegionCode(code)` 取得關聯國家數量。
  3. 若 `count > 0`：拒絕刪除，拋出 `InvalidReferenceException`，回傳 HTTP 400 Bad Request。
  4. 若 `count == 0`：執行資料庫實體刪除，回傳 HTTP 204 No Content。
- **Response 400 Bad Request (防刪阻擋範例)**:
```json
{
  "type": "about:blank",
  "title": "Bad Request",
  "status": 400,
  "detail": "該區域已被 12 筆國家資料引用，禁止刪除，僅允許切換為作廢狀態",
  "errorCode": "ERR_REGION_REFERENCED_CANNOT_DELETE",
  "timestamp": "2026-10-07T12:00:00Z"
}
```

---

## 3. 循序時序圖 (Sequence Diagram - 刪除防護流程)

```mermaid
sequenceDiagram
    autonumber
    actor Admin as 系統管理員
    participant Controller as RegionController
    participant Service as RegionService
    participant CRepo as CountryRepository
    participant RRepo as RegionRepository

    Admin->>Controller: DELETE /api/v1/system/regions/1
    Controller->>Service: deleteRegion(id = 1)
    Service->>RRepo: findById(1)
    alt 實體不存在
        RRepo-->>Service: Optional.empty()
        Service-->>Controller: throw ResourceNotFoundException
        Controller-->>Admin: HTTP 404 Not Found
    else 實體存在
        RRepo-->>Service: Region(id=1, code="ASIA")
        Service->>CRepo: countByRegionCode("ASIA")
        CRepo-->>Service: 12 (關聯國家數)
        alt 引用數 > 0
            Service-->>Controller: throw InvalidReferenceException
            Controller-->>Admin: HTTP 400 Bad Request {"errorCode": "ERR_REGION_REFERENCED_CANNOT_DELETE"}
        else 引用數 == 0
            Service->>RRepo: delete(region)
            Service-->>Controller: void
            Controller-->>Admin: HTTP 204 No Content
        end
    end
```
