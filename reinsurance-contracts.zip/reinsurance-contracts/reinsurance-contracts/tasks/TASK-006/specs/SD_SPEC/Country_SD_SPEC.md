# 國家系統設計與詳細 API 契約規格書 (Country SD Specification)

> **模組代碼**：`TASK-006`  
> **服務層級**：`services/core-service` (Spring Boot 3.2.3, Java 21)  
> **單一真實來源**：`contracts/openapi.yaml`  
> **負責角色**：System Designer / Backend Lead  

---

## 1. 架構分層與責任邊界 (Architectural Blueprint)

國家服務承接全系統各業務模組對地理主檔的查詢需求，並負責法遵制裁狀態與外部引用防護：

```mermaid
graph TD
    Client[Web Portal / API Client] -->|HTTP / JSON| Controller[CountryController]
    Controller -->|DTO Request / Validation| Service[CountryService]
    Service -->|Validate Region Existence| RegionRepo[RegionRepository]
    Service -->|Audit References| ExtRefService[ExternalReferenceCountService]
    Service -->|Save / Query| CountryRepo[CountryRepository]
    CountryRepo -->|JPA| Database[(PostgreSQL: system_countries)]
```

---

## 2. 詳細 API 介面契約規格 (RESTful Endpoints)

### 2.1 分頁與多維條件查詢國家清單
- **端點路徑**: `GET /api/v1/system/countries`
- **Query 參數詳細規格**:
  | 參數名稱 | 資料型態 | 是否必填 | 預設值 | 業務說明 |
  | :--- | :--- | :---: | :--- | :--- |
  | `keyword` | `String` | 否 | `null` | 模糊比對國家代碼、中文名稱或英文名稱 |
  | `regionCode`| `String` | 否 | `null` | 依所屬區域代碼精確過濾 (如: `ASIA`) |
  | `isSanctioned`| `Boolean` | 否 | `null` | `true` (僅受制裁) / `false` (正常合規) / 不帶代表全部 |
  | `status` | `String` | 否 | `null` | `ACTIVE` (有效) / `INACTIVE` (作廢) |
  | `page` | `Integer` | 否 | `0` | 分頁頁碼 (0-indexed) |
  | `size` | `Integer` | 否 | `10` | 每頁筆數 |
  | `sort` | `String` | 否 | `sortOrder,asc` | 排序欄位 |

- **Response 200 OK (`CountryPageResponse`)**:
```json
{
  "content": [
    {
      "id": 101,
      "code": "TW",
      "nameZh": "台灣",
      "nameEn": "Taiwan",
      "regionCode": "ASIA",
      "regionNameZh": "亞洲及太平洋區",
      "isSanctioned": false,
      "sanctionDate": null,
      "sortOrder": 10,
      "status": "ACTIVE",
      "referenceCount": 6,
      "version": 1
    }
  ],
  "pageNumber": 0,
  "pageSize": 10,
  "totalElements": 1,
  "totalPages": 1,
  "last": true,
  "first": true,
  "empty": false
}
```

---

### 2.2 新增國家主檔
- **端點路徑**: `POST /api/v1/system/countries`
- **Request Body (`CountryCreateRequest`)**:
```json
{
  "code": "JP",
  "nameZh": "日本",
  "nameEn": "Japan",
  "regionCode": "ASIA",
  "isSanctioned": false,
  "sanctionDate": null,
  "sortOrder": 20
}
```
- **核心檢核邏輯**:
  1. `code`: 必填，2~3 碼大寫英文字母 (`^[A-Z]{2,3}$`)，全域唯一。
  2. `regionCode`: 必填，Service 必須查詢 `RegionRepository`，確認該區域存在且 `is_disabled = false`。若區域不存在或已作廢，拋出 `InvalidReferenceException` (HTTP 400)。
  3. `isSanctioned`: 預設 false；若為 true，`sanctionDate` 建議填寫生效日期。

- **Response 201 Created (`CountryResponse`)**: 回傳新建之國家完整實體資料。

---

### 2.3 修改國家主檔
- **端點路徑**: `PUT /api/v1/system/countries/{id}`
- **Request Body (`CountryUpdateRequest`)**:
```json
{
  "nameZh": "日本國",
  "nameEn": "Japan",
  "regionCode": "ASIA",
  "isSanctioned": true,
  "sanctionDate": "2026-10-07",
  "sortOrder": 20,
  "version": 0
}
```
- **業務防呆**:
  - `code` 不得透過 PUT 修改（國家代碼建立後鎖定）。
  - 若 `regionCode` 有異動，重新檢核新區域之有效性。

---

### 2.4 切換國家作廢狀態
- **端點路徑**: `PATCH /api/v1/system/countries/{id}/status`
- **Request Body (`StatusUpdateRequest`)**: `{ "status": "INACTIVE" }`

---

### 2.5 刪除國家主檔 (多模組引用防護)
- **端點路徑**: `DELETE /api/v1/system/countries/{id}`
- **防護邏輯**:
  1. 統計外部引用總數 `countReferences(code)`（涵蓋金融機構、再保人、合約）。
  2. 若 `referenceCount > 0`：禁止刪除，回傳 HTTP 400 Bad Request。
- **Response 400 Bad Request (防護阻擋範例)**:
```json
{
  "type": "about:blank",
  "title": "Bad Request",
  "status": 400,
  "detail": "國家 'TW' 已被 6 筆外部業務資料引用，禁止實體刪除，僅允許切換為停用/作廢",
  "errorCode": "ERR_COUNTRY_REFERENCED_CANNOT_DELETE",
  "timestamp": "2026-10-07T12:00:00Z"
}
```
