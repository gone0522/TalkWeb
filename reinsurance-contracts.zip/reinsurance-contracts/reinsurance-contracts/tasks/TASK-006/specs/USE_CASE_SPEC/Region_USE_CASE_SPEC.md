# 區域管理業務使用案例規格書 (Region Use Case Specification)

> **模組代碼**：`TASK-006`  
> **畫面編號**：`SC-0101-01-04` ~ `SC-0101-01-06`  
> **業務代碼**：`UC-REG-01` ~ `UC-REG-07`  

---

## 案例導覽與矩陣 (Use Case Inventory)

| 案例代碼 | 使用案例名稱 | 主要參與者 | 流程類型 | 驗收核心重點 |
| :--- | :--- | :--- | :--- | :--- |
| **UC-REG-01** | 分頁與條件檢索區域清單 | 系統管理員 / 核保分析師 | Happy Path | 關鍵字模糊比對、狀態過濾、依 sortOrder 升冪排列。 |
| **UC-REG-02** | 建立新自訂區域主檔 | 系統管理員 | Happy Path | 代碼全域唯一、未填 sortOrder 由系統自動計算最大值 + 10。 |
| **UC-REG-03** | 建立重複區域代碼阻擋 | 系統管理員 | Exception Path | 代碼已存在時，系統拒絕建立並回傳 409 Conflict。 |
| **UC-REG-04** | 編輯區域名稱與自訂排序 | 系統管理員 | Happy Path | 代碼鎖定唯讀，支援樂觀鎖 version 併發保護。 |
| **UC-REG-05** | 切換區域作廢狀態 | 系統管理員 | Happy Path | 快速切換啟用/作廢，作廢後新增國家不可選用。 |
| **UC-REG-06** | 刪除未被引用之區域 | 系統管理員 | Happy Path | 關聯國家數為 0 時，執行物理刪除並回傳 204 No Content。 |
| **UC-REG-07** | 刪除已有國家引用之區域防護 | 系統管理員 | Defense Path | 關聯國家數 > 0 時，前端鎖定按鈕，後端攔截拋出 400 Bad Request。 |

---

## 詳細使用案例規格 (Detailed Specifications)

### UC-REG-01: 分頁與條件檢索區域清單
- **參與者**: 系統管理員、核保分析師
- **前置條件**: 使用者登入系統並開啟「選單管理 > 區域選單」頁面。
- **主要成功流程 (Main Success Scenario)**:
  1. 使用者進入區域選單頁面，系統預設調用 `GET /api/v1/system/regions?page=0&size=10&sort=sortOrder,asc`。
  2. 系統自 `system_regions` 撈取資料，並關聯計算各區域之國家數量。
  3. 介面表格依 `sortOrder` 升冪展示區域代碼、中英文名稱、關聯國家數與有效狀態。
  4. 使用者於搜尋欄輸入關鍵字（如「亞洲」）或選擇狀態（如「僅作廢」），點擊「查詢」。
  5. 系統即時重新發出請求並刷新清單呈現符合結果。
- **後置條件**: 介面呈現符合過濾條件之分頁結果。

---

### UC-REG-02: 建立新自訂區域主檔
- **參與者**: 系統管理員
- **前置條件**: 使用者具備 `ROLE_ADMIN` 權限。
- **主要成功流程**:
  1. 管理員於區域清單右上角點擊「+ 新增區域」按鈕。
  2. 系統彈出新增區域 Modal，顯示代碼、中文名稱、英文名稱與顯示順序欄位。
  3. 管理員輸入代碼 `ME`、中文名稱「中東區」、英文名稱「Middle East」，顯示順序保留空白。
  4. 管理員點擊「儲存」按鈕。
  5. 後端 Service 檢核代碼 `ME` 尚未使用，並查詢目前最大 `sort_order` 為 20，自動指派新區域 `sortOrder = 30`。
  6. 資料庫成功寫入新記錄，回傳 HTTP 201 Created。
  7. 前端關閉 Modal，顯示成功 Toast，並自動重新載入區域清單。
- **後置條件**: 資料庫新增一筆 `ME` 區域記錄，狀態預設為 `is_disabled = false`。

---

### UC-REG-03: 建立重複區域代碼阻擋 (Exception Flow)
- **參與者**: 系統管理員
- **觸發情境**: 管理員嘗試建立已存在之區域代碼（例如 `ASIA`）。
- **異常流程 (Exception Steps)**:
  1. 管理員輸入代碼 `ASIA` 並填妥名稱送出。
  2. 後端 Service 呼叫 `RegionRepository.existsByCode("ASIA")` 回傳 `true`。
  3. 後端拋出 `DuplicateResourceException`，中斷交易並回傳 HTTP 409 Conflict (Problem Details: `ERR_REGION_CODE_DUPLICATE`)。
  4. 前端表單欄位標紅，顯示警示訊息「區域代碼 'ASIA' 已存在，請使用其他代碼」。
- **後置條件**: 資料庫無任何資料寫入，Modal 維持開啟供使用者修正。

---

### UC-REG-06: 刪除未被引用之區域 (Happy Path)
- **前置條件**: 該區域所屬之關聯國家計數為 0。
- **主要流程**:
  1. 管理員於清單中點擊該區域之「刪除」按鈕。
  2. 系統跳出二次確認對話框「確認刪除區域 [ME]？此操作無法還原」。
  3. 管理員點擊「確認刪除」。
  4. 後端檢核 `countByRegionCode("ME") == 0`，執行 `repository.delete(region)`。
  5. 回傳 HTTP 204 No Content，清單平滑移除該列資料。

---

### UC-REG-07: 刪除已有國家引用之區域防護 (Defense Path)
- **前置條件**: 該區域已有 1 筆以上之國家資料綁定（例如 `ASIA` 擁有 12 個國家）。
- **防護流程**:
  1. 前端渲染清單時，因 `referenceCount = 12 > 0`，刪除按鈕鎖定 Disabled，Tooltip 提示「已有國家引用，禁止刪除」。
  2. （邊界防護）若攻擊者直接調用 DELETE API 發送請求：
  3. 後端 `RegionService` 查詢 `countByRegionCode("ASIA")` 發現大於 0。
  4. 後端立即拋出 `InvalidReferenceException`，終止刪除操作，回傳 HTTP 400 Bad Request。
- **後置條件**: 資料庫實體完好無損，資料完整性不受破壞。
