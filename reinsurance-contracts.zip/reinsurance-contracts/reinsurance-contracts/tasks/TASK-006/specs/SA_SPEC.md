# 國家與區域選單模組系統分析規格書 (System Analysis Specification)

> **模組代碼**：`TASK-006`  
> **畫面編號**：`SC-0101-01-01` ~ `SC-0101-01-06`  
> **文件版本**：v2.0 (Living Architecture Release)  
> **負責角色**：System Analyst / Lead Architect  

---

## 1. 業務背景與問題意識 (Business Background & Problem Statement)

在跨國再保險（Reinsurance）業務中，全球地理區域與國家的風險評估是承保簽單（Underwriting）、合約管理（Treaty & Facultative Contracts）與累積風險監控（Risk Accumulation Control）的第一道防線。再保險公司每天需要處理來自各大洲不同司法管轄區的轉分保業務，若地理主檔定義混亂，將直接導致核保風控失準與法遵違規風險。

本專案升級前，系統在地理維度面臨以下三大業務痛點：
1. **缺乏自訂業務區域聚合維度**：既有系統各國家各自獨立，缺乏靈活的「風險累積區域（Accumulation Region）」主檔。各保險公司無法依據自身承保胃納將國家劃分至特定板塊（例如：將特定島嶼自訂歸入「亞洲及太平洋區」或「中東與北非區」），造成核保風險報表無法自訂維度統計。
2. **法遵制裁（Sanction Compliance）資訊脫鉤**：國際洗錢防制（AML）與跨國制裁清單（如 OFAC、聯合國、歐盟制裁）頻繁變動。過去業務人員在輸入合約時，無法即時得知特定國家是否處於受制裁狀態，極易造成違規簽單與鉅額監管罰款。
3. **資料缺乏關聯防護機制**：國家資料若被金融機構、再保人、合約等外部業務模組引用後，若遭管理員誤刪，將引發資料庫孤島或外鍵級聯破壞，嚴重損害核心資料完整性。

---

## 2. 專案目標與範疇 (Objectives & Scope)

### 2.1 核心專案目標
- **統一地理主檔管理中樞**：建立整合型的「國家與區域選單」介面，提供清晰的一級頁籤切換體驗。
- **彈性區域維護**：建立高擴充性的區域主檔模型，支援代碼全域唯一性檢核、顯示順序自動推算與關聯國家數量即時統計。
- **升級國家主檔架構**：升級國家實體，強制關聯有效所屬區域，並導入國際法遵制裁標記（含制裁生效日期與視覺高亮警示）。
- **企業級引用完整性防呆**：落實業務層級引用防護網，已建立關聯的區域或已被業務引用的國家，嚴格禁止實體刪除，僅允許軟性停用/作廢。

### 2.2 業務範疇界定 (In-Scope vs. Out-of-Scope)
- **納入範圍 (In-Scope)**：
  - 區域主檔清單檢索、新增、編輯、作廢切換與關聯防護刪除。
  - 國家主檔多維篩選（關鍵字、區域下拉、制裁標記、作廢狀態）、新增、編輯、作廢切換與引用防護刪除。
  - 前後端 RESTful API 契約對齊與 Next.js 頁面入口整合。
- **排除範圍 (Out-of-Scope)**：
  - 各國行政省份/城市之第三級下鑽維護（保留於後續 Phase 2 擴充）。
  - 自動介接外部國際制裁清單 API 批次更新（本階段採人工維護標記）。

---

## 3. 利害關係人與權限矩陣 (Stakeholders & Permissions)

| 角色名稱 | 角色代碼 | 業務責任與使用情境 | 存取與操作權限 |
| :--- | :--- | :--- | :--- |
| **系統管理員** | `ROLE_ADMIN` | 負責全系統基礎參數配置、主檔維護與資料清理 | 具備區域與國家的完整新增、修改、作廢與刪除（受防呆約束）權限。 |
| **法遵主管** | `ROLE_COMPLIANCE`| 監控全球制裁風險名單，即時維護各國制裁註記與生效日 | 具備國家主檔之制裁狀態修改、檢視詳情與全域清單匯出權限。 |
| **核保主管/分析師**| `ROLE_UNDERWRITER`| 評估各區域業務風險累積量，查詢合約所屬國家之合規性 | 具備區域與國家之檢索、檢視詳情與關聯國家統計檢視權限。 |
| **一般操作員** | `ROLE_VIEWER` | 系統一般檢視者，核對資料代碼 | 僅具備清單分頁檢索與唯讀檢視權限。 |

---

## 4. 核心端到端業務旅程 (End-to-End Business Journeys)

```mermaid
flowchart TD
    Start([使用者登入並進入選單管理]) --> TabDecision{選擇維護維度}
    
    TabDecision -->|區域選單 Tab| RegionFlow[區域管理流程]
    TabDecision -->|國家選單 Tab| CountryFlow[國家管理流程]
    
    subgraph Region_Workflow [區域維護業務旅程]
        RegionFlow --> R_Search[分頁檢索區域清單]
        R_Search --> R_Action{選擇操作}
        R_Action -->|新增區域| R_Create[輸入代碼與中英文名稱]
        R_Create --> R_SortCheck[系統自動計算順序 max + 10]
        R_SortCheck --> R_Save[儲存並建立區域主檔]
        R_Action -->|點擊刪除| R_DelCheck{查詢關聯國家數量}
        R_DelCheck -->|國家數 > 0| R_Block[阻擋實體刪除! 提示僅可設為作廢]
        R_DelCheck -->|國家數 = 0| R_DelSuccess[執行資料庫物理刪除]
    end
    
    subgraph Country_Workflow [國家維護業務旅程]
        CountryFlow --> C_Filter[多維度檢索: 關鍵字/區域下拉/制裁快選]
        C_Filter --> C_Action{選擇操作}
        C_Action -->|新增國家| C_Input[輸入 2~3 碼代碼、名稱與選擇所屬區域]
        C_Input --> C_Sanction[勾選法遵制裁並指定生效日期]
        C_Sanction --> C_Validate{檢核區域有效性}
        C_Validate -->|所屬區域已作廢或不存在| C_Err[拒絕儲存! 提示區域無效]
        C_Validate -->|所屬區域有效| C_CreateOK[成功建立國家主檔]
        C_Action -->|編輯/檢視| C_Drawer[開啟側邊抽屜: 顯示制裁卡與引用統計]
        C_Drawer --> C_RefCheck{外部業務引用數 > 0?}
        C_RefCheck -->|是| C_Lock[鎖定國家代碼, 禁用刪除按鈕]
        C_RefCheck -->|否| C_AllowEdit[允許編輯與刪除]
    end
```

---

## 5. 詳細業務規則矩陣 (Business Rules Matrix)

### 5.1 區域管理業務規則 (Region Business Rules)
- **`BR-REG-01 (代碼唯一性)`**：區域代碼 (`code`) 必須全域唯一，不分大小寫比對，長度上限 20 字元，允許大寫英數字與下底線。若重複則拒絕儲存並提示 409 Conflict。
- **`BR-REG-02 (順序預設邏輯)`**：若使用者於新增表單未指定 `sortOrder`，系統應自動抓取目前資料庫中最大之 `sort_order` 並加 10，作為預設值。
- **`BR-REG-03 (關聯國家計數)`**：區域清單中必須即時呈現該區域所屬的國家總數（含有效與作廢國家）。
- **`BR-REG-04 (刪除防護與狀態切換)`**：已被任何國家引用的區域（關聯數 > 0），嚴禁實體刪除（回傳 400 Bad Request）。前端刪除按鈕鎖定 Disabled 並提供防呆說明，使用者僅能透過狀態開關切換為作廢 (`status: INACTIVE`)。

### 5.2 國家管理業務規則 (Country Business Rules)
- **`BR-CTY-01 (國家代碼規範)`**：國家代碼 (`code`) 必須遵循 ISO 3166-1 alpha-2 或 alpha-3（2 或 3 碼大寫英文），全域唯一。新增成功後代碼永久鎖定不可竄改。
- **`BR-CTY-02 (區域關聯完整性)`**：新增或修改國家時，所選之所屬區域 (`regionCode`) 必須存在於 `system_regions` 且其狀態必須為有效 (`status: ACTIVE`)。若所選區域已停用，系統應拒絕儲存。
- **`BR-CTY-03 (法遵制裁連動)`**：若勾選「是否受制裁 (`isSanctioned = true`)」，系統建議填寫「制裁生效日期 (`sanctionDate`)」。在清單與詳情頁面上，必須以顯著琥珀色或警示黃標籤高亮標記。
- **`BR-CTY-04 (外部引用防護與鎖定)`**：國家若已被金融機構、再保人、合約等外部模組引用（`referenceCount > 0`），其國家代碼輸入框強制 Disabled，且實體刪除功能強制鎖定，僅允許變更為作廢狀態。

---

## 6. 非功能性需求 (Non-Functional Requirements)

1. **回應時間 (Performance)**：分頁查詢 API 在 10,000 筆資料量級下，P95 回應時間必須小於 200ms。
2. **審計軌跡 (Audit Trail)**：區域與國家之每筆新增與異動，必須完整記錄 `createdAt`, `createdBy`, `updatedAt`, `updatedBy`。
3. **並行防護 (Concurrency)**：實體具備 `@Version` 欄位，前端更新時必須帶回版本號，防止多位管理員同時編輯時產生髒寫覆蓋 (Optimistic Locking 409 Conflict)。
4. **設計規範對齊 (Design Alignment)**：前端介面完全依循白底 (#F9FAFB)、卡片陰影與品牌橘 (#FF5A1F) 視覺語彙，提供一致的高質感企業後台體驗。

---

## 7. 業務名詞定義 (Glossary)

| 名詞術語 | 英文對應 | 業務定義與解說 |
| :--- | :--- | :--- |
| **自訂累積區域** | Accumulation Region | 再保險公司基於自身承保胃納與巨災模型自訂之地理分區（如「泛亞太區」）。 |
| **法遵制裁國家** | Sanctioned Country | 受到國際組織（如聯合國、OFAC）金融制裁或貿易禁運之國家/司法管轄區。 |
| **外部引用計數** | Reference Count | 該國家主檔被下游金融機構代碼、再保人合約、理賠案等關聯使用的累計總筆數。 |
| **軟作廢狀態** | Inactive Status | 資料保留於資料庫但不參與業務下拉選單的停用狀態，提供資料歷史完整性追溯。 |
