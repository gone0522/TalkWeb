# 國家測試策略與驗收追溯規格書 (Country QA Specification)

> **模組代碼**：`TASK-006`  
> **驗收閘門**：`services/core-service` -> `mvn test` (必須 100% 通過)  
> **負責角色**：QA Lead / Test Automation Engineer  

---

## 1. 測試策略與品質目標 (Test Strategy)

國家主檔為多業務模組依賴之核心，測試重點在於：
1. **關聯完整性檢核**：測試建立或修改國家時，所選區域之存在性與啟用狀態檢核。
2. **法遵制裁邏輯**：驗證制裁狀態、生效日期與多維篩選之精準度。
3. **外部引用防刪阻擋**：模擬金融機構、再保人合約等下游業務引用情境，確保防刪保護 100% 生效。

---

## 2. 需求與測試追溯矩陣 (Requirements Traceability Matrix - RTM)

| 業務規則 | 使用案例 | 測試案例代碼 | 測試情境說明 | 自動化測試實作方法 | 預期結果 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `BR-CTY-01` | `UC-CTY-01` | **`TC-CTY-01`** | 多維條件篩選國家清單 (關鍵字+區域+制裁) | `CountryServiceTest#testSearchCountriesWithFilters` | 精確回傳符合多條件之分頁結果 |
| `BR-CTY-02` | `UC-CTY-03` | **`TC-CTY-02`** | 關聯有效區域成功建立國家主檔 | `CountryServiceTest#testCreateCountrySuccess` | 建立成功，回傳 201 Created |
| `BR-CTY-01` | `UC-CTY-03` | **`TC-CTY-03`** | 重複國家代碼建立衝突阻擋 | `CountryServiceTest#testCreateCountryDuplicateCodeThrowsException` | 拋出 DuplicateResourceException, 409 |
| `BR-CTY-02` | `UC-CTY-04` | **`TC-CTY-04`** | 關聯不存在之區域代碼建立阻擋 | `CountryServiceTest#testCreateCountryWithNonExistingRegionThrowsException` | 拋出 InvalidReferenceException, 400 |
| `BR-CTY-02` | `UC-CTY-04` | **`TC-CTY-05`** | 關聯已作廢/停用區域建立阻擋 | `CountryServiceTest#testCreateCountryWithDisabledRegionThrowsException` | 拋出 InvalidReferenceException, 400 |
| `BR-CTY-03` | `UC-CTY-07` | **`TC-CTY-06`** | 更新法遵制裁狀態與生效日期 | `CountryServiceTest#testUpdateSanctionStatus` | 制裁旗標與日期成功更新 |
| `BR-CTY-04` | `UC-CTY-08` | **`TC-CTY-07`** | 無外部引用之國家安全物理刪除 | `CountryServiceTest#testDeleteUnreferencedCountrySuccess` | 實體成功移除，回傳 204 |
| `BR-CTY-04` | `UC-CTY-09` | **`TC-CTY-08`** | 被金融機構引用之國家禁止刪除阻擋 | `CountryServiceTest#testDeleteCountryReferencedByFinancialInstThrowsException`| 拋出 InvalidReferenceException, 400 |
| `BR-CTY-04` | `UC-CTY-09` | **`TC-CTY-09`** | 被再保合約引用之國家禁止刪除阻擋 | `CountryServiceTest#testDeleteCountryReferencedByContractThrowsException` | 拋出 InvalidReferenceException, 400 |
| `BR-CTY-04` | `UC-CTY-09` | **`TC-CTY-10`** | 查詢單筆國家詳情與外部引用計數 | `CountryServiceTest#testGetCountryDetailWithReferenceCounts` | 正確回傳各模組引用統計結構 |

---

## 3. 邊界條件與負面測試矩陣 (Negative & Boundary Test Cases)

| 測試編號 | 邊界測試情境 | 測試輸入參數 | 預期系統行為 |
| :--- | :--- | :--- | :--- |
| `TC-CTY-B01` | 國家代碼長度不符合 2~3 碼 | `code = "A"` 或 `code = "TWNN"` | 正則表達式驗證失敗，回傳 400 Bad Request |
| `TC-CTY-B02` | 勾選制裁但日期為未來日期 | `sanctionDate = 2099-01-01` | 商業邏輯檢核通過（允許預設生效），記錄警示 Log |
| `TC-CTY-B03` | 更新國家嘗試修改 country_code | 傳入不同代碼 | Service 層忽略代碼變更，保持原代碼不變 |
