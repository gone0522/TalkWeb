# 區域測試策略與驗收追溯規格書 (Region QA Specification)

> **模組代碼**：`TASK-006`  
> **驗收閘門**：`services/core-service` -> `mvn test` (必須 100% 通過)  
> **負責角色**：QA Lead / Test Automation Engineer  

---

## 1. 測試策略與品質目標 (Test Strategy)

為確保區域主檔模型的穩健度與防刪保護，本模組採用「金字塔測試架構」：
1. **單元測試層 (Unit Tests - JUnit 5 & Mockito)**：覆蓋 Service 業務檢核、代碼衝突防護、自動排序計算與防刪阻擋邏輯，要求分支覆蓋率 (Branch Coverage) 達到 90% 以上。
2. **整合測試層 (Integration Tests - SpringBootTest)**：驗證 Controller RESTful 端點、DTO 參數驗證、RFC 7807 錯誤模型序列化與資料庫真實交易復原。
3. **品質驗收閘門**：任何任務交付前，強制在 WSL 環境執行 `mvn clean test`，必須達成 **0 Failures, 0 Errors** 方可放行。

---

## 2. 需求與測試追溯矩陣 (Requirements Traceability Matrix - RTM)

| 業務規則 | 使用案例 | 測試案例代碼 | 測試情境說明 | 自動化測試實作方法 | 預期結果 |
| :--- | :--- | :--- | :--- | :--- | :--- |
| `BR-REG-01` | `UC-REG-01` | **`TC-REG-01`** | 分頁檢索區域清單依 sortOrder 排序 | `RegionServiceTest#testListRegionsPagedAndSorted` | 回傳分頁結構，內容嚴格依升冪排序 |
| `BR-REG-02` | `UC-REG-02` | **`TC-REG-02`** | 新增區域未填順序自動指派最大值 + 10 | `RegionServiceTest#testCreateRegionSuccessWithAutoSortOrder` | 自動指派 `max + 10`，回傳 201 |
| `BR-REG-01` | `UC-REG-03` | **`TC-REG-03`** | 重複區域代碼建立衝突阻擋 | `RegionServiceTest#testCreateRegionDuplicateCodeConflict` | 拋出 DuplicateResourceException, 409 |
| `BR-REG-04` | `UC-REG-04` | **`TC-REG-04`** | 更新區域名稱與自訂排序 | `RegionServiceTest#testUpdateRegionSuccess` | 名稱與排序更新，version 自增 |
| `BR-REG-04` | `UC-REG-05` | **`TC-REG-05`** | 切換區域作廢狀態 | `RegionServiceTest#testToggleRegionDisabledStatus` | `is_disabled` 狀態正確翻轉 |
| `BR-REG-04` | `UC-REG-06` | **`TC-REG-06`** | 無國家引用之區域安全物理刪除 | `RegionServiceTest#testDeleteUnreferencedRegionSuccess` | 實體成功自資料庫移除，回傳 204 |
| `BR-REG-04` | `UC-REG-07` | **`TC-REG-07`** | 有國家引用之區域禁止刪除阻擋 | `RegionServiceTest#testDeleteReferencedRegionThrowsException`| 拋出 InvalidReferenceException, 400 |

---

## 3. 邊界條件與負面測試矩陣 (Negative & Boundary Test Cases)

| 測試編號 | 邊界測試情境 | 測試輸入參數 | 預期系統行為 |
| :--- | :--- | :--- | :--- |
| `TC-REG-B01` | 代碼超過 20 字元上限 | `code = "VERY_LONG_REGION_CODE_EXCEEDING_LIMIT"` | Bean Validation 攔截，回傳 400 Bad Request |
| `TC-REG-B02` | 代碼包含非法小寫或特殊字元 | `code = "asia@pacific!"` | 正則檢核失敗，回傳 400 Bad Request |
| `TC-REG-B03` | 樂觀鎖版本不一致併發更新 | `version = 999` (資料庫目前為 0) | 拋出 OptimisticLockingFailureException, 回傳 409 |
| `TC-REG-B04` | 負數排序值驗證 | `sortOrder = -5` | `@Min(0)` 檢核攔截，回傳 400 Bad Request |
