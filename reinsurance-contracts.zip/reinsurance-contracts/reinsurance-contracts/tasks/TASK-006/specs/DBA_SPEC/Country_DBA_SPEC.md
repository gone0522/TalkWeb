# 國家資料庫架構與實體模型規格書 (Country DBA Specification)

> **模組代碼**：`TASK-006`  
> **關聯資料表**：`system_countries` (升級)  
> **目標資料庫**：PostgreSQL 16+  
> **負責角色**：Database Administrator / Data Architect  

---

## 1. 實體領域模型升級思維 (Entity Upgrade Rationale)

原本系統中 `system_countries` 僅作為簡單的下拉選項代碼表。隨著再保險合規管理深化，本次升級重點如下：
1. **聚合至所屬區域**：新增 `region_code` 欄位建立與 `system_regions` 的外鍵邏輯參照，實現區域層級的業務匯總。
2. **內建法遵制裁支援**：新增 `is_sanctioned` 與 `sanction_date` 欄位，由系統在實體層原生記錄制裁狀態，支援秒級合規檢核。
3. **樂觀鎖與防護保障**：引入 `version` 欄位確保併發編輯安全；透過應用層強制統計外部模組（金融機構、再保人、合約）引用計數，落實防刪保護。

---

## 2. 實體關聯圖 (Entity Relationship Diagram - ERD)

```mermaid
erDiagram
    system_regions ||--o{ system_countries : "groups (1:N)"
    system_countries ||--o{ financial_institutions : "referenced by"
    system_countries ||--o{ reinsurers : "referenced by"
    system_countries ||--o{ reinsurance_contracts : "referenced by"
    
    system_countries {
        bigserial id PK "國家主鍵"
        varchar country_code UK "國家代碼 (ISO 2~3 碼)"
        varchar name_zh "中文名稱"
        varchar name_en "英文名稱"
        varchar region_code FK "所屬區域代碼"
        boolean is_sanctioned "是否受制裁"
        date sanction_date "制裁生效日期"
        int sort_order "排序"
        boolean is_disabled "是否停用作廢"
        bigint version "樂觀鎖版本號"
    }
```

---

## 3. 資料表綱要與詳細資料字典 (Data Dictionary)

### 資料表名稱：`system_countries`
- **業務說明**：存放全球國家與地區主檔，支援所屬區域關聯與法遵制裁合規註記。

| 欄位名稱 (Column) | 實體型別 (Type) | 允許空值 (Null) | 預設值 (Default) | 限制條件 (Constraint) | 業務含義與設計考量說明 |
| :--- | :--- | :---: | :--- | :--- | :--- |
| `id` | `BIGSERIAL` | 否 | 自動遞增 | **Primary Key** | 國家實體內部主鍵。 |
| `country_code` | `VARCHAR(10)` | 否 | 無 | **Unique** | ISO 3166-1 alpha-2 或 alpha-3 國家代碼（如 `TW`, `JP`, `USA`）。全域唯一且建立後唯讀鎖定。 |
| `name_zh` | `VARCHAR(100)` | 否 | 無 | Not Blank | 國家中文官方標準名稱。 |
| `name_en` | `VARCHAR(100)` | 否 | 無 | Not Blank | 國家英文官方標準名稱。 |
| `region_code` | `VARCHAR(20)` | 否 | 無 | FK to `system_regions` | 所屬區域代碼。建立或更新時必須參照有效的區域實體。 |
| `is_sanctioned` | `BOOLEAN` | 否 | `FALSE` | Boolean | 法遵制裁註記。`true` 代表該國家目前處於制裁名單內。 |
| `sanction_date` | `DATE` | 是 | `NULL` | | 制裁生效日期。當 `is_sanctioned = true` 時記錄制裁發布日期。 |
| `sort_order` | `INTEGER` | 否 | `0` | Min 0 | 介面清單顯示之排序順序。 |
| `is_disabled` | `BOOLEAN` | 否 | `FALSE` | Boolean | 作廢停用旗標（對應 API 之 `status: ACTIVE/INACTIVE`）。 |
| `version` | `BIGINT` | 否 | `0` | Not Null | 樂觀鎖版本號。 |
| `created_at` | `TIMESTAMPTZ` | 否 | `CURRENT_TIMESTAMP` | | 建立時間戳記。 |
| `created_by` | `VARCHAR(50)` | 否 | `'SYSTEM'` | | 建立者帳號。 |
| `updated_at` | `TIMESTAMPTZ` | 否 | `CURRENT_TIMESTAMP` | | 最後異動時間戳記。 |
| `updated_by` | `VARCHAR(50)` | 否 | `'SYSTEM'` | | 最後異動者帳號。 |

---

## 4. 索引規劃與最佳化 (Indexing Strategy)

```sql
-- 1. 唯一性國家代碼索引
CREATE UNIQUE INDEX IF NOT EXISTS uk_system_countries_code 
    ON system_countries (country_code);

-- 2. 所屬區域外鍵檢索索引 (加速按區域過濾與計數)
CREATE INDEX IF NOT EXISTS idx_system_countries_region 
    ON system_countries (region_code);

-- 3. 制裁狀態與作廢狀態篩選索引 (加速法遵快查)
CREATE INDEX IF NOT EXISTS idx_system_countries_sanction 
    ON system_countries (is_sanctioned, is_disabled);

-- 4. 多維度複合檢索索引 (排序、代碼與名稱)
CREATE INDEX IF NOT EXISTS idx_system_countries_sort_name 
    ON system_countries (sort_order ASC, name_zh);
```

---

## 5. 資料庫遷移腳本 (Flyway DDL Migration Script)

```sql
-- Migration: V20261007_02__upgrade_system_countries.sql
-- Description: Upgrade system_countries with region_code, sanction flags, and versioning

-- 擴充所屬區域與制裁欄位
ALTER TABLE system_countries 
    ADD COLUMN IF NOT EXISTS region_code VARCHAR(20),
    ADD COLUMN IF NOT EXISTS is_sanctioned BOOLEAN NOT NULL DEFAULT FALSE,
    ADD COLUMN IF NOT EXISTS sanction_date DATE,
    ADD COLUMN IF NOT EXISTS version BIGINT NOT NULL DEFAULT 0;

-- 補齊外鍵約束與索引
CREATE INDEX IF NOT EXISTS idx_system_countries_region 
    ON system_countries(region_code);

CREATE INDEX IF NOT EXISTS idx_system_countries_sanction 
    ON system_countries(is_sanctioned, is_disabled);

COMMENT ON COLUMN system_countries.region_code IS '所屬自訂區域代碼 (關聯 system_regions)';
COMMENT ON COLUMN system_countries.is_sanctioned IS '是否受到國際法遵制裁';
COMMENT ON COLUMN system_countries.sanction_date IS '制裁正式生效日期';
```

---

## 6. 跨模組引用防護架構說明 (Reference Integrity Architecture)

在再保險核心系統中，`system_countries` 為多個關鍵子模組的外鍵參照目標：
- `financial_institutions.country_code`（金融機構所屬國）
- `reinsurers.domicile_country`（再保人註冊國）
- `reinsurance_treaties.territory_code`（合約適用區域國）

**防護實作原則**：
1. 資料庫層**不使用** `ON DELETE CASCADE`，防止意外串聯刪除重要交易數據。
2. 應用層 `CountryService.deleteCountry(id)` 執行前，必須先調用跨模組計數聚合器 `countTotalReferences(code)`。
3. 若 `count > 0`，拋出商業例外 `InvalidReferenceException`，禁止資料庫實體刪除操作。
