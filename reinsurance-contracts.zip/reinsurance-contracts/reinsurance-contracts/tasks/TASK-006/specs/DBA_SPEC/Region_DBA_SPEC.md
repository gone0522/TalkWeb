# 區域資料庫架構與實體模型規格書 (Region DBA Specification)

> **模組代碼**：`TASK-006`  
> **關聯資料表**：`system_regions`  
> **目標資料庫**：PostgreSQL 16+  
> **負責角色**：Database Administrator / Data Architect  

---

## 1. 實體領域模型設計思維 (Entity Design Rationale)

在再保險核心系統中，地理資訊是支撐全系統多個子系統（客戶主檔、金融機構、再保合約、承保累計風險）的頂層元資料（Master Metadata）。
為了確保地理維度的彈性，我們將「區域」設計為獨立實體 `system_regions`，具備以下架構優勢：
- **解耦硬編碼**：區域不以 Enum 形式寫死於程式中，允許營運團隊動態擴增（如新增「拉丁美洲新興市場區」）。
- **業務防呆機制**：透過 `is_disabled` 狀態欄位支援軟作廢，配合 `@Version` 樂觀鎖支援多使用者併發安全。
- **即時維護排序**：提供 `sort_order` 欄位，讓管理員能依業務重要性自訂介面顯示順序，而非單純依代碼字母排序。

---

## 2. 實體關聯圖 (Entity Relationship Diagram - ERD)

```mermaid
erDiagram
    system_regions ||--o{ system_countries : "contains (1:N)"
    
    system_regions {
        bigserial id PK "流水主鍵"
        varchar region_code UK "區域唯一代碼 (如 ASIA)"
        varchar name_zh "中文名稱"
        varchar name_en "英文名稱"
        int sort_order "顯示順序"
        boolean is_disabled "是否作廢 (軟刪除)"
        bigint version "樂觀鎖版本號"
        timestamp created_at "建立時間"
        varchar created_by "建立者"
        timestamp updated_at "最後更新時間"
        varchar updated_by "最後更新者"
    }
    
    system_countries {
        bigserial id PK "國家主鍵"
        varchar country_code UK "ISO 國家代碼"
        varchar region_code FK "所屬區域外鍵"
        boolean is_sanctioned "是否受制裁"
    }
```

---

## 3. 資料表綱要與詳細資料字典 (Data Dictionary)

### 資料表名稱：`system_regions`
- **業務說明**：存放自訂風險累積區域主檔，提供國家主檔綁定與核保彙總報表使用。
- **儲存引擎**：PostgreSQL Heap Table
- **字元集**：UTF-8

| 欄位名稱 (Column) | 實體型別 (Type) | 允許空值 (Null) | 預設值 (Default) | 限制條件 (Constraint) | 業務含義與設計考量說明 |
| :--- | :--- | :---: | :--- | :--- | :--- |
| `id` | `BIGSERIAL` | 否 | 自動遞增 | **Primary Key** | 內部實體主鍵，供 ORM 與內部關聯高效索引使用。 |
| `region_code` | `VARCHAR(20)` | 否 | 無 | **Unique** | 業務識別代碼（如 `ASIA`, `EUROPE`, `ME`）。大寫英數字，全域唯一，建立後不可變更。 |
| `name_zh` | `VARCHAR(100)` | 否 | 無 | Not Blank | 區域中文標準顯示名稱（例如：「亞洲及太平洋區」）。 |
| `name_en` | `VARCHAR(100)` | 否 | 無 | Not Blank | 區域英文標準顯示名稱（例如：「Asia Pacific」），供國際報表輸出。 |
| `sort_order` | `INTEGER` | 否 | `0` | Min 0 | 介面展示之升冪排序序號。未提供時由系統自動取現有最大值 + 10。 |
| `is_disabled` | `BOOLEAN` | 否 | `FALSE` | Boolean | 作廢停用旗標。`false`=有效啟用，`true`=作廢停用。作廢後不可於新增國家時被選取。 |
| `version` | `BIGINT` | 否 | `0` | Not Null | 樂觀鎖版本號，防止多管理員同時修改時覆蓋更新。 |
| `created_at` | `TIMESTAMPTZ` | 否 | `CURRENT_TIMESTAMP` | | 建立時間戳記 (UTC / OffsetDateTime)。 |
| `created_by` | `VARCHAR(50)` | 否 | `'SYSTEM'` | | 記錄建立者之使用者帳號。 |
| `updated_at` | `TIMESTAMPTZ` | 否 | `CURRENT_TIMESTAMP` | | 最後異動時間戳記。 |
| `updated_by` | `VARCHAR(50)` | 否 | `'SYSTEM'` | | 最後異動者之使用者帳號。 |

---

## 4. 索引規劃與查詢最佳化 (Indexing Strategy)

```sql
-- 1. 唯一性業務約束索引 (支援高頻代碼比對與存在性檢查)
CREATE UNIQUE INDEX IF NOT EXISTS uk_system_regions_code 
    ON system_regions (region_code);

-- 2. 顯示排序與狀態組合索引 (支援清單依序號排序並篩選有效狀態)
CREATE INDEX IF NOT EXISTS idx_system_regions_sort_status 
    ON system_regions (sort_order ASC, is_disabled);

-- 3. 中英文名稱模糊檢索索引 (加速關鍵字搜尋)
CREATE INDEX IF NOT EXISTS idx_system_regions_names 
    ON system_regions (name_zh, name_en);
```

---

## 5. 資料庫遷移腳本 (Flyway DDL Migration Script)

```sql
-- Migration: V20261007_01__create_system_regions.sql
-- Description: Create system_regions master table with audit columns and indexes

CREATE TABLE IF NOT EXISTS system_regions (
    id BIGSERIAL PRIMARY KEY,
    region_code VARCHAR(20) NOT NULL,
    name_zh VARCHAR(100) NOT NULL,
    name_en VARCHAR(100) NOT NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_disabled BOOLEAN NOT NULL DEFAULT FALSE,
    version BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
    CONSTRAINT uk_system_regions_code UNIQUE (region_code)
);

CREATE INDEX IF NOT EXISTS idx_system_regions_sort_status 
    ON system_regions (sort_order ASC, is_disabled);

CREATE INDEX IF NOT EXISTS idx_system_regions_names 
    ON system_regions (name_zh, name_en);

COMMENT ON TABLE system_regions IS '系統自訂地理區域主檔表';
COMMENT ON COLUMN system_regions.region_code IS '區域唯一識別代碼';
COMMENT ON COLUMN system_regions.sort_order IS '介面顯示排序權重 (升冪)';
COMMENT ON COLUMN system_regions.is_disabled IS '軟作廢狀態 (true=停用, false=有效)';
```

---

## 6. 種子資料規劃 (Baseline Seed Data)

系統初始化時，預設填入國際通用之一級地理區域種子資料：
```sql
INSERT INTO system_regions (region_code, name_zh, name_en, sort_order, is_disabled)
VALUES 
    ('ASIA', '亞洲及太平洋區', 'Asia Pacific', 10, FALSE),
    ('EUROPE', '歐洲區', 'Europe', 20, FALSE),
    ('AMERICA', '美洲區', 'Americas', 30, FALSE),
    ('AFRICA', '非洲區', 'Africa', 40, FALSE),
    ('ME', '中東區', 'Middle East', 50, FALSE)
ON CONFLICT (region_code) DO NOTHING;
```
