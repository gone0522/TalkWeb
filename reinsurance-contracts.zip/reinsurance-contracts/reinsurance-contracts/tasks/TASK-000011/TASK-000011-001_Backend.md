<!--
governance_metadata:
  last_reviewed: "2026-10-14"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-14"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# TASK-000011-001_Backend: 主檔架構不變量加固——徹底根除寫死中文、命名空間收斂與常青適性防線

## 1. 任務核心背景與六維正交不變量 (Context & The 6 Orthogonal Invariants)
前次執行雖移除了部分端點宣告，但在深度代碼稽核中發現 `CountryService.java` 與 `RegionService.java` 內部**依然完整殘留大量硬編碼中文字串**：
- `EXCEL_HEADERS` 靜態字串陣列
- `recordAudit` 欄位中文名稱 `"中文名稱"`、`"英文名稱"`、`"所屬區域"`、`"顯示順序"`、`"受制裁設定"`
- 狀態判斷與變更 `"已作廢"` / `"有效"`、`"是"` / `"否"`
- 預設審計原因 `"國家主檔資料維護更新"`、`"區域主檔資料維護更新"`、審計部門 `"合規風險部"`
- 工作表名稱 `"國家代碼清單"`、`"區域代碼清單"`

本任務落實「六維封閉正交基底」與「直擊原型 (Patch the Archetype)」，徹底清空後端殘留之所有自然語言字串：

1. **【維度 4：呈現層外部化 (Presentation Externalization - RFC-003)】**：
   - **物理拔除靜態表頭陣列**：徹底刪除 `CountryService` 與 `RegionService` 內之 `private static final String[] EXCEL_HEADERS`。
   - **全面鏈結 Agent SDK 匯出原語**：全面採用 `agent-sdk:GenericExcelExportEngine` (`primitive:backend:dynamic-localized-exporter`)。
   - **工作表名稱外部化**：工作表名稱由 `messages.properties`（`export.country.sheet_name`、`export.region.sheet_name`）經由 Spring `MessageSource` 解析。
2. **【維度 3：時間與審計機器代碼化 (Time & Audit Immutability - RFC-005)】**：
   - `recordAudit` 傳入之欄位名稱與狀態變更，嚴禁手寫自然語言，統一使用規範機器鍵：
     * `"中文名稱"` ➔ `audit.field.name_zh`
     * `"英文名稱"` ➔ `audit.field.name_en`
     * `"顯示順序"` ➔ `audit.field.sort_order`
     * `"所屬區域"` ➔ `audit.field.region_code`
     * `"受制裁設定"` ➔ `audit.field.is_sanctioned`
     * `"已作廢"` / `"有效"` ➔ `audit.status.inactive` / `audit.status.active`
     * `"合規風險部"` ➔ `audit.dept.compliance_risk`
   - 審計日誌展示時由表現層解析多語系，業務層只儲存或傳遞 Canonical Machine Keys。
3. **【維度 1：契約唯一真理源 (Contract SSOT)】**：
   - 100% 對齊 `contracts/openapi.yaml`，所有主檔端點統一前綴 `/api/v1/system/*`。
4. **【維度 6：常青適性守門人 (Architecture Sentry - RFC-010)】**：
   - 部署 `ArchitectureFitnessTest` (ArchUnit)，將上述不變量轉化為客觀編譯期測試門禁：
     * `services_must_not_contain_raw_ui_header_arrays`（檢驗 Service 嚴禁出現 String[] 表頭陣列）
     * `domain_and_service_must_not_contain_hardcoded_chinese`（檢驗 Service / Domain 嚴禁非 ASCII 字串常值）

---

## 2. 鏈結 Agent SDK 符號表 (Linked Primitives)
- `foundation:bytecode:task-ir` (`agent-sdk:task-ir-schema-v1.0`)
- `primitive:backend:dynamic-localized-exporter` (`agent-sdk-spring:GenericExcelExportEngine`)
- `primitive:backend:base-auditable-entity` (`agent-sdk-spring:BaseAuditableEntity`)
- `archetype:governance:architecture-fitness-sentry` (`agent-sdk-spring:ArchitectureFitnessTest`)

---

## 3. 中介字節碼執行規格 (Compiled Bytecode Reference)
- 機器字節碼：[tasks/TASK-000011/task.ir.backend.yaml](task.ir.backend.yaml) (Task-IR v1.0)

---

## 4. 影響範圍與交付檔案清單 (Deliverables)
1. `src/main/java/com/reinsurance/core/service/CountryService.java`
2. `src/main/java/com/reinsurance/core/service/RegionService.java`
3. `src/main/java/com/reinsurance/core/domain/CountryAuditLog.java`
4. `src/main/java/com/reinsurance/core/domain/RegionAuditLog.java`
5. `src/main/resources/messages.properties`
6. `src/test/java/com/reinsurance/core/architecture/ArchitectureFitnessTest.java`
