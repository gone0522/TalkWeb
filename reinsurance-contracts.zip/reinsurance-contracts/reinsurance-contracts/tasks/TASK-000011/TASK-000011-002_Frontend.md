<!--
governance_metadata:
  last_reviewed: "2026-10-14"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-14"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# TASK-000011-002_Frontend: 全域導航與主檔共用彈窗字典化——徹底根除寫死中文與 AST 守門防線

## 1. 任務核心背景與六維正交不變量 (Context & The 6 Orthogonal Invariants)
前次執行僅修改了局部頁面，但經深度代碼掃描，**全域側邊導航列 (`Sidebar.tsx`)、頂部導航列 (`TopHeader.tsx`) 與主檔彈窗 (`CountryFormModal.tsx`、`RatingAgencyFormModal.tsx`、`FinancialInstitutionTab.tsx`) 依然硬編碼了超過 60 處中文字串與 `window.confirm` 原生彈窗**！

本任務落實「呈現層外部化」與「確定性防禦」：

1. **【維度 4：呈現層外部化 (Presentation Externalization - 根除全域寫死中文)】**：
   - **全域導航列國際化**：重構 `Sidebar.tsx`，所有選單組標題與選單項目文字，一律改由 `useTranslations('nav')` 動態渲染，嚴禁在 TSX 陣列中寫死中文。
   - **頂部工具列國際化**：重構 `TopHeader.tsx`，所有 Tooltip 與標籤一律透過 `useTranslations('system')` 與 `useTranslations('common')` 渲染。
   - **主檔共用彈窗國際化**：重構 `CountryFormModal.tsx` 與 `RatingAgencyFormModal.tsx`，所有表單標籤、校驗錯誤、placeholder 與操作按鈕全面字典化。
   - **金融機構分頁重構**：重構 `FinancialInstitutionTab.tsx`，拔除 `window.confirm`，改用 Sonner toast，表格標頭與分頁文字全面字典化。
   - **API 客戶端錯誤處理外部化**：重構 `country-api.ts` 與 `region-api.ts`，移除寫死之中文錯誤字串與正則 replace。
2. **【維度 4：字典完整性對稱 (Locale Parity)】**：
   - 在 `messages/zh-TW.json` 與 `messages/en-US.json` 建立完整且 100% 對稱之鍵值。
3. **【維度 4：確定性防禦與優雅按鈕 (Deterministic UX - RFC-002)】**：
   - 所有操作按鈕統一鏈結 `<GracefulActionButton>`，嚴禁宣告空箭頭函式 `onClick={() => {}}`。

---

## 2. 鏈結 Agent SDK 符號表 (Linked Primitives)
- `foundation:bytecode:task-ir` (`agent-sdk:task-ir-schema-v1.0`)
- `archetype:ui:master-data-maintenance` (`@agent-sdk/react:MasterDataMaintenanceView`)
- `primitive:ui:graceful-action-button` (`@agent-sdk/react:GracefulActionButton`)

---

## 3. 中介字節碼執行規格 (Compiled Bytecode Reference)
- 機器字節碼：[tasks/TASK-000011/task.ir.frontend.yaml](task.ir.frontend.yaml) (Task-IR v1.0)

---

## 4. 影響範圍與交付檔案清單 (Deliverables)
1. `src/locales/zh-TW.json`
2. `src/locales/en-US.json`
3. `src/components/layout/Sidebar.tsx`
4. `src/components/layout/TopHeader.tsx`
5. `src/views/settings/lookups/components/CountryFormModal.tsx`
6. `src/views/settings/lookups/components/RatingAgencyFormModal.tsx`
7. `src/views/settings/lookups/components/FinancialInstitutionTab.tsx`
8. `src/services/country-api.ts`
9. `src/services/region-api.ts`
