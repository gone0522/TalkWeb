# 系統設計活體規格書 (SD_SPEC) - TASK-000009 結算幣別治理補強

## 1. 強型別配置模型 (CurrencyProperties)
```java
@ConfigurationProperties(prefix = "reinsurance.currency")
@Validated
public class CurrencyProperties {
    @Min(1000) @Max(100000)
    private int maxExportRows = 50000;

    @Min(5) @Max(100)
    private int defaultPageSize = 20;

    @Min(0) @Max(4)
    private int maxDecimalPlaces = 4;
}
```

## 2. 混沌工程攻防架構 (Chaos Engineering Architecture)
- 模擬並發更新：50 個平行線程同時嘗試修改同一個幣別的狀態或進位規則。
- 驗證版本防禦：僅首個獲取版本號的請求成功提交，其餘 49 個請求安全攔截或重試，資料庫審計紀錄完全不重不漏。

## 3. Micrometer 可觀測性度量 (Metrics Design)
- 計數器：`currency.calculation.preview.count` (Tag: status=success/failure)
- 計數器：`currency.export.requests` (Tag: format=xlsx)
