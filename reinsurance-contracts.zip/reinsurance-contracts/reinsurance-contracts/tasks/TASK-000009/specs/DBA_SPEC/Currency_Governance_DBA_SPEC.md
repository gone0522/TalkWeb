# 資料庫架構活體規格書 (DBA_SPEC) - TASK-000009 結算幣別架構補強

## 1. 資料庫結構與歷史腳本審計 (Database Auditing)
- 當前幣別實體與審計表已於 `V3__create_currencies_and_audit.sql` 定義。
- 本補強切片確認現有結構完全相容最新企業規範：
  - `currencies`：包含 `version` (BIGINT NOT NULL DEFAULT 0，樂觀鎖版本號)、`code` (CHAR(3) PK)、`status`、`sort_order`。
  - `currency_audit_logs`：包含 `id` (BIGSERIAL PK)、`currency_code`、`field_name`、`before_value`、`after_value`、`change_reason`、`changed_by`、`changed_at`。

## 2. 索引覆蓋與查詢優化 (M-Tier 1,000 QPS Indexing)
- `idx_currencies_sort_order`：加速清單升冪排序。
- `idx_currency_audit_code_time`：加速幣別詳情抽屜最近 5 筆審計日誌檢索。
