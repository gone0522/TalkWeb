# 系統分析活體規格書 (SA_SPEC) - TASK-000009 結算幣別企業級治理補強

## 1. 任務由來與問題意識 (Context & Problem Statement)
依據最新工程規範 (Meta-ADR 1 ~ 4) 與企業級架構演進：
1. **歷史基線保護**：TASK-007 作為幣別模組初始交付里程碑已封裝，歷史 Git 軌跡保持不可變。
2. **治理落差修補**：最新引入之 ADR-003 (品質韌性) 與 ADR-004 (Agent SDK 百年長程治理) 需針對幣別模組提供專屬工程補強。
3. **M 級 QoS 達標保證**：確保幣別主檔於 1,000 QPS 併發下具備完整的可觀測性、樂觀鎖併發防護與配置 Fail-Fast 機制。

## 2. 範圍邊界定義 (Scope Definition)
### In Scope
- 後端：`CurrencyProperties` 開機配置校驗、`CurrencyChaosResilienceTest` 混沌工程測試、`CurrencyMetrics` Actuator 監控、`CurrencyOutboxService` 本地事務發件箱接口。
- 前端：批次匯入按鈕優雅降級確認、多語系辭典模組化校驗、即時預覽防抖驗收。
- 契約：對齊 `contracts/openapi.yaml`。

### Out of Scope
- 修改現有已驗收通過之幣別四種捨入演算核心數學邏輯（屬於 Hexagonal Clean Core 領域不可變資產）。
- 實裝完整的批次 Excel 匯入後端解析引擎（列為次期大型模組規劃）。

---

## 5. ADR-009 可演進式架構與邊界防線對齊 (Evolvable Architecture & Soft Boundaries Alignment)
依據 **ADR-009** 與 **ENGINEERING_STANDARDS.md 第八章 (§45 ~ §52)**，本任務全面落實五大抗耦合防線：
1. **全資產領域標籤鐵律 (Domain Tagging Protocol - §45)**：
   - 領域標籤：`domain: { name: "masterdata", subdomain: "currency" }`。
   - OpenAPI 標籤：端點強制具備 `tags: ["domain:masterdata"]`。
2. **軟性外鍵與跨領域 SQL 零 JOIN (Soft FK & Zero Cross-Domain Joins - §46)**：
   - 跨領域引用僅儲存邏輯代碼 (`currency_code VARCHAR(3)`)，資料庫實體層嚴禁建立 `FOREIGN KEY` 約束。
   - Repository 嚴禁跨領域資料表 SQL JOIN，一律於應用層組合。
3. **引用防禦協議與軟刪除 (Referential Guard & Soft-Delete - §47)**：
   - 提供 `GET /api/v1/system/currencies/{code}/references` 端點防禦，狀態異動前先算引用計數。
   - 嚴禁物理 `DELETE FROM`，一律使用邏輯停用 (`status = INACTIVE`)。
4. **後端 Package-Private 封閉性 (Backend Boundary Encapsulation - §48)**：
   - 內部 Repository、Entity 與 Service 實作宣告為 Package-Private，杜絕跨領域直接存取。
5. **前端 Feature-Sliced 垂直內聚組織 (Feature-Sliced Directory - §49)**：
   - 元件與業務邏輯收斂於 `src/features/masterdata/currency/`，對外唯一出口為 `index.ts`。
