# 結算幣別企業級治理介面規格書 (Currency Governance UI Specification)

> **模組代碼**：`TASK-000009`  
> **畫面編號**：`SC-0101-02-01` (清單), `SC-0101-02-02` (彈窗)  
> **規範依據**：`docs/adr/ADR-001`, `ADR-007 §37.2, §43`  

---

## 1. 優雅降級佔位規範 (Graceful Degradation Protocol)
- **按鈕標的**：清單工具列右上角之 `[ 批次匯入 ]`。
- **規格要求**：
  1. 必須具備 `disabled={true}` 屬性。
  2. 外觀樣式為禁用灰底灰字 (`opacity-50 cursor-not-allowed`)。
  3. 必須懸浮提示 Tooltip（由多語系字串 `system.currency.batchImportTooltip` 提供，內容為「規劃中，即將推出」）。
  4. 嚴禁無反應之假可點擊按鈕。

---

## 2. 多語系命名空間模組化防衝突規範 (Modular i18n Guard)
- 所有幣別模組專屬文字收斂於 `src/locales/zh-TW.json` 與 `src/locales/en-US.json` 之 `system.currency.*` 與 `menus.currency.*`。
- 執行 `node scripts/validate-i18n.js` 時，0 處未解析鍵值。
