# 結算幣別企業級治理使用案例規格書 (Currency Governance Use Case Specification)

> **模組代碼**：`TASK-000009`  
> **畫面編號**：`SC-0101-02-01` ~ `SC-0101-02-03`  
> **業務代碼**：`UC-CUR-CONF-01`, `UC-CUR-CHAOS-01`, `UC-CUR-DEGRADE-01`  
> **規範依據**：`docs/adr/ADR-005`, `ADR-006`, `ADR-007`  

---

## 案例導覽與矩陣 (Use Case Inventory)

| 案例代碼 | 使用案例名稱 | 主要參與者 | 流程類型 | 驗收核心重點 |
| :--- | :--- | :--- | :--- | :--- |
| **UC-CUR-CONF-01** | 開機配置強型別驗證與防漂移 | DevOps / 維運系統 | Defense Path | 非法匯出上限或小數位數配置在開機第 1 秒直接中斷，阻斷事故進入生產。 |
| **UC-CUR-CHAOS-01** | 高併發樂觀鎖版本防禦與重試 | 精算師 / 交易系統 | Chaos Path | 1,000 QPS 併發下兩筆同時更新相同幣別規則，樂觀鎖版本攔截髒寫入，審計紀錄不重不漏。 |
| **UC-CUR-DEGRADE-01**| 批次匯入次期功能優雅降級佔位 | 系統管理員 | UX Path | 次期批次匯入按鈕呈現明確 disabled 狀態與 Tooltip「即將推出」，杜絕假死按鈕。 |

---

## 詳細使用案例規格 (Detailed Specifications)

### UC-CUR-CHAOS-01: 高併發樂觀鎖版本防禦與重試 (Chaos Path)
- **參與者**: 多位精算師或交易介面並行請求
- **前置條件**: 資料庫中存在幣別代碼 `USD`，初始 `version = 0`。
- **主要流程**:
  1. 請求 A 與請求 B 同時讀取 `USD` 主檔（version 均為 0）。
  2. 請求 A 搶先送出更新（`PUT /api/v1/system/currencies/USD`，附帶 version 0）。
  3. 資料庫更新成功，version 翻轉為 1，並寫入一筆 Audit Log。
  4. 請求 B 送出更新（`PUT /api/v1/system/currencies/USD`，仍附帶舊版 version 0）。
  5. JPA 樂觀鎖檢測衝突，拋出 `OptimisticLockingFailureException`。
  6. 伺服器回傳 `HTTP 409 Conflict`，說明「該幣別計算規則已被其他使用者更新，請重新載入後再試」。
  7. 資料庫審計表僅有請求 A 之變更，無髒資料覆蓋。
