# 測試驗收活體規格書 (QA_SPEC) - TASK-000009 結算幣別補強

## 1. 測試矩陣 (Test Matrix)
| 測試代碼 | 測試層級 | 測試目標 | 預期結果 |
|:---|:---|:---|:---|
| TC-CUR-CHAOS-01 | 整合測試 | 併發版本衝突防禦 (Optimistic Locking) | 拋出 409 或 VersionConflict，資料無覆蓋 |
| TC-CUR-CONF-01 | 單元測試 | 配置合法性邊界校驗 (ValidationException) | 非法配置開機立即中斷 |
| TC-CUR-METRIC-01| 整合測試 | Actuator 指標累加正確性 | 呼叫端點後 MeterRegistry 計數 +1 |
| TC-CUR-UI-01 | 靜態稽核 | 批次匯入按鈕死按鈕檢查 | disabled={true}，通過 audit-buttons.js |
| TC-CUR-I18N-01 | 靜態稽核 | 多語系辭典對稱完整性 | 通過 validate-i18n.js，0 缺失 |

## 2. 自動化驗收命令
- `docker exec reinsurance-core-service mvn test`
- `docker exec reinsurance-web-portal npm test`
