<!--
governance_metadata:
  last_reviewed: "2026-10-14"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-14"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# TASK-000009-002_Frontend: 結算幣別主檔六分區原型對齊、即時進位試算與平滑適配防線

## 1. 任務核心背景與六維正交不變量 (Context & The 6 Orthogonal Invariants)
本任務落實「主檔六分區標準」、「即時運算試算」與「平滑演進客戶端防禦」：

1. **【維度 4：主檔標準六大功能分區 (MasterDataMaintenanceView - RFC-002)】**：
   - 幣別主檔維護頁面嚴格對齊六大標準分區：
     * Zone 1: HeaderActions（標題與「+ 新增幣別」按鈕）
     * Zone 2: SearchForm（代碼、名稱、狀態、進位複合查詢）
     * Zone 3: Toolbar（批次匯入 disabled 預留、自訂欄位與 Excel 匯出）
     * Zone 4: DataTable（虛擬滾動大數據表格，列狀態標籤）
     * Zone 5: Pagination（雙側對稱、防塌陷 `<MasterDataPagination>`）
     * Zone 6: DetailDrawer（右側檢視/編輯抽屜、變更原因彈窗與審計紀錄）
2. **【維度 5：客戶端平滑演進適配層 (Resilient Client - RFC-011)】**：
   - `currency-api.ts` 採用平滑適配層，優先請求 `/api/v1/system/currencies`，相容回退 `/api/v1/currencies`。
   - 移除寫死之中文檔名 `'結算幣別清單.xlsx'`，改由 HTTP Header `Content-Disposition` 動態提取。
3. **【維度 2：進位試算與即時回饋 (Calculation Preview)】**：
   - 抽屜與即時預覽卡片整合 `/api/v1/system/currencies/calculate`，即時呈現銀行家捨入 (HALF_EVEN) 運算結果。
4. **【維度 4：死按鈕零容忍與確定性優雅降級 (RFC-002)】**：
   - 操作按鈕統一鏈結 `<GracefulActionButton>`，批次匯入按鈕設定 `disabled={true}` 並附帶國際化 Tooltip。

---

## 2. 鏈結 Agent SDK 符號表 (Linked Primitives)
- `foundation:bytecode:task-ir` (`agent-sdk:task-ir-schema-v1.0`)
- `archetype:ui:master-data-maintenance` (`@agent-sdk/react:MasterDataMaintenanceView`)
- `primitive:ui:master-data-pagination` (`@agent-sdk/react:MasterDataPagination`)
- `primitive:ui:graceful-action-button` (`@agent-sdk/react:GracefulActionButton`)
- `runtime:evolution:graceful-sunset-guard` (`@agent-sdk/react:createResilientApiAdapter`)

---

## 3. 中介字節碼執行規格 (Compiled Bytecode Reference)
- 機器字節碼：[tasks/TASK-000009/task.ir.frontend.yaml](task.ir.frontend.yaml) (Task-IR v1.0)

---

## 4. 影響範圍與交付檔案清單 (Deliverables)
1. `src/app/(dashboard)/settings/menus/currencies/page.tsx`
2. `src/components/menus/currency/CurrencyListTable.tsx`
3. `src/components/menus/currency/CalculationPreviewCard.tsx`
4. `src/components/menus/currency/CurrencyRuleChangeModal.tsx`
5. `src/services/currency-api.ts`
6. `src/locales/zh-TW.json`
7. `src/locales/en-US.json`
