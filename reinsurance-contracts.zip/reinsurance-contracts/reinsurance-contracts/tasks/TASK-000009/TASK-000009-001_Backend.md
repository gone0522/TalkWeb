<!--
governance_metadata:
  last_reviewed: "2026-10-14"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-14"
  governance_status: "ACTIVE"
  owner: "Architecture Board / Lead Agent"
-->

# TASK-000009-001_Backend: 結算幣別強型別配置、高併發混沌防線、雙軌日落演進與複式財務精度防禦

## 1. 任務核心背景與六維正交不變量 (Context & The 6 Orthogonal Invariants)
本任務依據企業級標準庫 (Agent SDK) 與六維封閉正交基底進行全量落實：

1. **【維度 5 & 6：平滑演進與客觀日落 (Evolution & Telemetry Sunset - RFC-011)】**：
   - 掛載 `@GracefulSunsetRoute` 雙軌路由外觀：
     同時支援新標準端點 `/api/v1/system/currencies` 與歷史過渡端點 `/api/v1/currencies`。
     歷史路徑自動注入 RFC 8594 日落標頭 (`Deprecation: true`, `Sunset: 2027-01-01T00:00:00Z`)。
   - 整合 Micrometer `MeterRegistry`，自動採集舊端點調用計數 `api.deprecated.requests`，只有當生產監控確認連續 14 天 `QPS == 0` 時方可安全 Contract 拔除。
2. **【維度 4：呈現層外部化 (Presentation Externalization - RFC-003)】**：
   - 幣別匯出與試算異常，**嚴格禁止在 Service 寫死任何自然語言中文字串**。
   - `CurrencyController` 內之 `@NotBlank(message = "幣別中文名稱不可為空")` 等校驗訊息，全面改為 `{validation.currency.*}` 機器代碼。
   - 串流匯出全面鏈結 `GenericExcelExportEngine` (RFC-003)，搭配 `@ExportColumn` 註解之 `CurrencyExportDto`，徹底刪除 `CurrencyExportService` 內之 `EXCEL_HEADERS` 靜態陣列與硬編碼工作表名稱。
3. **【維度 2：契約唯一真理源與財務原型 (Contract SSOT & Financial Ledger - RFC-008)】**：
   - 嚴格遵守 **零浮點數不變量 (Zero-Floating Point Invariant)**：所有金額試算、比率與換算公式必須使用 `BigDecimal`，進位模式強制使用銀行家捨入 `RoundingMode.HALF_EVEN`（標準精度 Scale = 4），嚴禁使用 `float` 或 `double`。
   - 100% 對齊 `contracts/openapi.yaml` 關於 `/api/v1/system/currencies/calculate` 之契約輸入輸出型別。
4. **【維度 3：時間留痕與審計機器代碼 (Time & Audit Immutability - RFC-005)】**：
   - `recordAudit` 欄位全面代碼化：
     `"幣別中文名稱"` ➔ `audit.field.currency_name_zh`
     `"進位設定"` ➔ `audit.field.rounding_mode`
     `"小數位數"` ➔ `audit.field.decimal_places`
     `"財會部"` ➔ `audit.dept.finance`
5. **【維度 2：確定性彈性防禦與混沌神諭 (Deterministic Resilience & Oracles - RFC-004, 006)】**：
   - 樂觀鎖併發衝突防禦：資料庫實體宣告 `@Version`，併發更新衝突精準映射為 RFC 7807 409 Conflict。
   - 混沌工程防線：以 `CurrencyChaosResilienceTest` 模擬多線程高併發爭搶，TDD 見證 0 髒寫入與審計精準留痕。

---

## 2. 鏈結 Agent SDK 符號表 (Linked Primitives)
- `foundation:bytecode:task-ir` (`agent-sdk:task-ir-schema-v1.0`)
- `primitive:backend:dynamic-localized-exporter` (`agent-sdk-spring:GenericExcelExportEngine`)
- `primitive:backend:optimistic-lock-guard` (`agent-sdk-spring:OptimisticLockGuard`)
- `primitive:backend:base-auditable-entity` (`agent-sdk-spring:BaseAuditableEntity`)
- `primitive:telemetry:qos-metrics` (`agent-sdk-spring:AgentSdkMetricsAutoConfiguration`)
- `archetype:domain:financial-ledger` (`agent-sdk-spring:GenericFinancialLedgerEngine`)
- `runtime:evolution:graceful-sunset-guard` (`agent-sdk-spring:GracefulSunsetRoute, GracefulSunsetInterceptor`)
- `archetype:governance:architecture-fitness-sentry` (`agent-sdk-spring:ArchitectureFitnessTest`)

---

## 3. 中介字節碼執行規格 (Compiled Bytecode Reference)
- 機器字節碼：[tasks/TASK-000009/task.ir.backend.yaml](task.ir.backend.yaml) (Task-IR v1.0)

---

## 4. 影響範圍與檔案清單 (Backend Scope)
1. `src/main/java/com/reinsurance/core/currency/controller/CurrencyController.java`
2. `src/main/java/com/reinsurance/core/currency/service/CurrencyService.java`
3. `src/main/java/com/reinsurance/core/currency/service/CurrencyExportService.java`
4. `src/main/java/com/reinsurance/core/currency/config/CurrencyProperties.java`
5. `src/main/java/com/reinsurance/core/currency/metrics/CurrencyMetrics.java`
6. `src/main/java/com/reinsurance/core/currency/service/CurrencyOutboxService.java`
7. `src/main/resources/messages.properties`
8. `src/test/java/com/reinsurance/core/currency/CurrencyChaosResilienceTest.java`
9. `src/test/java/com/reinsurance/core/currency/controller/CurrencyControllerTest.java`
