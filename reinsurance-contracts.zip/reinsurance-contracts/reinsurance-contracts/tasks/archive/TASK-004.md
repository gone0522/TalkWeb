# TASK-002: 保險再保系統主導航架構與基礎設定選單管理前端介面

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- 業務邏輯與隱含需求推演：
  - 系統主框架需改造成保險再保系統專屬導航架構，側邊導覽列（Sidebar）完整呈現業務清單九大模組與其二級子項目：
    1. 基礎設定（選單管理、匯率管理、會計科目管理）
    2. 保單/保險商品/理賠單管理（保單欄位定義、保險商品定義、理賠單欄位定義）
    3. 再保基礎資料管理（風險累計規則、再保商品管理、再保人/再保經紀人管理）
    4. 再保合約管理（團險合約、個險合約、巨災再保）
    5. 分保基礎（事件、危險單位）
    6. 分保/攤賠規則管理（外部輸入資訊維護、再保商品規則設定、分出規則設定）
    7. 匯入保單/理賠單（匯入保單、匯入理賠單）
    8. 查詢交易結果（交易結果查詢、被保人風險累計查詢、被保人身分字號查詢）
    9. 報表管理（再保費支出相關統計報表、再保佣金收入相關統計報表、分保清單、攤賠清單）
  - 點擊「基礎設定」頂層模組時，導向基礎設定首頁，以入口卡片與次導覽呈現「選單管理」、「匯率管理」、「會計科目管理」。點選「選單管理」進入其專屬維護畫面。
  - 「選單管理」內部提供 Tab 切換機制，包含四個子功能：
    1. 國家 (Country)
    2. 結算幣別 (Settlement Currency)
    3. 金融機構 (Financial Institution)
    4. 信用評級機構 (Rating Agency)
  - 每個 Tab 均具備標準主檔維護能力：關鍵字搜尋列、狀態過濾下拉（全部/啟用/停用）、重置與查詢按鈕、新增按鈕、資料分頁表格、編輯彈窗、啟用/停用狀態即時切換。
- 驗收條件：
  - 畫面切換與路由：點選左側或頂部導覽能正確切換路由；點選「基礎設定」進入 `/settings`；點選「選單管理」進入 `/settings/lookups`；Tab 切換同步更新網址 Query Parameter（如 `?tab=countries`）。
  - 操作回饋：
    - 新增或編輯成功時，顯示綠色 Toast「儲存成功」並自動刷新清單。
    - 點擊切換狀態 Switch 時，彈出確認對話框「確認要停用/啟用此項目？」，確認後發送請求並更新狀態 Badge。
    - API 回傳 400 或 409 錯誤時，於彈窗內顯示對應紅色警告訊息（如「代碼已存在」），不關閉彈窗。
  - 表單防呆：代碼（Code）欄位在「編輯」模式下必須為 Disabled 唯讀狀態；必填欄位未填或格式錯誤時，儲存按鈕 Disabled 或提示欄位錯誤。

## 2. 影響範圍與檔案清單 (Scope)
> 腳本將讀取此處清單預先 touch 檔案，請務必列齊本次任務需異動或新建的檔案：

### Backend Files
- (無，前端任務依賴 TASK-001 開發完成之 API 與契約)

### Frontend Files
- src/routes/index.tsx
- src/types/navigation.ts
- src/types/lookup.ts
- src/api/menuApi.ts
- src/api/lookupApi.ts
- src/components/layout/MainLayout.tsx
- src/components/layout/SidebarNav.tsx
- src/components/layout/HeaderNav.tsx
- src/pages/settings/SettingsOverviewPage.tsx
- src/pages/settings/lookups/LookupManagementPage.tsx
- src/pages/settings/lookups/components/CountryTab.tsx
- src/pages/settings/lookups/components/CurrencyTab.tsx
- src/pages/settings/lookups/components/FinancialInstitutionTab.tsx
- src/pages/settings/lookups/components/RatingAgencyTab.tsx
- src/pages/settings/lookups/components/CountryFormModal.tsx
- src/pages/settings/lookups/components/CurrencyFormModal.tsx
- src/pages/settings/lookups/components/FinancialInstitutionFormModal.tsx
- src/pages/settings/lookups/components/RatingAgencyFormModal.tsx
- src/pages/settings/lookups/components/StatusBadge.tsx
- src/pages/placeholder/ModulePlaceholderPage.tsx

## 3. 詳細技術規格（只寫規格，不寫程式碼）
### 3.1 契約規格變更 (contracts/openapi.yaml)
- (無新增契約，完全對接 TASK-001 所定義之 `/api/v1/system/menus` 與 `/api/v1/system/*` 端點)

### 3.2 後端技術規格 (services/core-service)
- (無後端規格異動)

### 3.3 前端技術規格 (apps/web-portal)
- TypeScript 型別定義規格：
  - `NavMenuItem`: 包含 `id` (string), `name` (string), `path` (string), `icon` (string, optional), `children` (NavMenuItem[] optional)。
  - `StatusType`: 列舉 `'ACTIVE' | 'INACTIVE'`。
  - `CountryItem`:
    - `id`: number
    - `code`: string (2-3 碼英文字母)
    - `nameZh`: string
    - `nameEn`: string
    - `status`: StatusType
    - `sortOrder`: number
    - `updatedAt`: string
  - `CurrencyItem`:
    - `id`: number
    - `code`: string (3 碼英文字母)
    - `name`: string
    - `symbol`: string
    - `decimalPlaces`: number (0-4)
    - `status`: StatusType
    - `sortOrder`: number
  - `FinancialInstitutionItem`:
    - `id`: number
    - `code`: string
    - `name`: string
    - `swiftCode`: string | null
    - `countryCode`: string
    - `status`: StatusType
    - `sortOrder`: number
  - `RatingAgencyItem`:
    - `id`: number
    - `code`: string
    - `name`: string
    - `description`: string | null
    - `status`: StatusType
    - `sortOrder`: number
  - `PaginationQuery`: `page` (number), `size` (number), `keyword` (string optional), `status` (string optional)。
- 元件行為與狀態控制：
  - `MainLayout` & `SidebarNav`:
    - 側邊選單依據業務九大模組清單設定靜態/動態導航結構。
    - 支援收合與展開二級項目；若點選一級項目直接導向該模組綜覽頁（如點選「基礎設定」導向 `/settings`）。
    - 頂部導航顯示「保險再保系統」、目前所在路徑麵包屑（Breadcrumb）、使用者資訊與登出鈕。
  - `SettingsOverviewPage` (`/settings`):
    - 呈現三張入口卡片：
      1. 「選單管理」：描述「設定全系統下拉選單項目（國家、結算幣別、金融機構、信用評級機構）」，點擊進入 `/settings/lookups`。
      2. 「匯率管理」：描述「維護再保結算匯率與歷史匯率」，點擊進入 `/settings/exchange-rates`（暫導向 Placeholder）。
      3. 「會計科目管理」：描述「維護再保會計科目與對應規則」，點擊進入 `/settings/accounting-subjects`（暫導向 Placeholder）。
  - `LookupManagementPage` (`/settings/lookups`):
    - 包含四個主頁籤：`國家` (`countries`)、`結算幣別` (`currencies`)、`金融機構` (`financial-institutions`)、`信用評級機構` (`rating-agencies`)。
    - 頁籤切換時監聽與更新 URL Search Params `?tab={category}`，重新整理時維持於當前 Tab。
  - 各 Tab 清單元件 (`CountryTab`, `CurrencyTab`, `FinancialInstitutionTab`, `RatingAgencyTab`)：
    - 頂部篩選器：輸入關鍵字（Enter 觸發）、狀態下拉選單（全部/啟用/停用）、重置按鈕（清空條件並查回第 1 頁）、查詢按鈕。
    - 動作列：包含「+ 新增項目」主要按鈕與「重新整理」圖示按鈕。
    - 資料表格：
      - 欄位包含：代碼、名稱、各類專有屬性（如幣別符號與小數位數、機構 SWIFT 碼、國家代碼）、狀態 Badge（綠色代表啟用、灰色代表停用）、排序序號、操作列。
      - 操作列提供「編輯」按鈕與「啟用/停用」Switch 切換開關。
      - 點擊 Switch 切換前跳出確認視窗，確認後呼叫狀態變更 API；呼叫失敗即時 Rollback 畫面開關狀態並彈出 Toast 警告。
      - 底部分頁元件：支援切換頁碼與變更每頁筆數（預設 10/20/50 筆）。
  - 彈窗表單元件 (`*FormModal`)：
    - 表單驗證規則：
      - `code`: 必填，新增模式允許輸入，輸入時自動轉大寫；編輯模式強制 `disabled`，防範竄改。
      - 各項名稱與長度限制依照 OpenAPI 規格校驗，不合格於欄位下方即時顯示紅字錯誤訊息。
    - 按鈕互動邏輯：
      - 「取消」按鈕：關閉彈窗並清空表單狀態。
      - 「儲存」按鈕：於表單不合法或提交中（`submitting` 為 true）時為 `disabled` 狀態，點擊後觸發 Loading 轉圈效果。
    - 錯誤捕捉：若後端回傳 409 Conflict，精準高亮代碼欄位並顯示「代碼已存在於系統中」；若為 400 關聯錯誤則提示「所選國家代碼不存在或已停用」。