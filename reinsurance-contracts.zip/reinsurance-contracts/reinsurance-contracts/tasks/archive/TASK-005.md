# TASK-005: 依據 UI 規範改寫系統全域佈局與再保首頁卡片

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- **業務背景**：依據新版視覺規範與設計範例，將既有前端頁面改版為「再保險系統」之專用版面，建立頂部 Header、白底橘色高亮側邊欄，以及首頁模組卡片清單。
- **驗收條件**：
  - 開啟 `http://localhost:3000`，全域底色為淺灰色 (`bg-gray-50`)。
  - **頂部導航列**：
    - 左側顯示漢堡圖示、系統標題「再保險系統」與「可編輯」灰底膠囊標籤。
    - 右側顯示使用者資訊膠囊（預設使用者 `katherine.jy.chang`）、設定齒輪、地球語系、帶紅點數量標記的鈴鐺通知，以及登出圖示。
  - **側邊欄導航**：
    - 頂部包含搜尋輸入框與放大鏡圖示。
    - 顯示「再保管理」分組，底下「資料配置」為目前選中項目（呈現 `bg-orange-500 text-white` 鮮橘色高亮）。
    - 顯示「再保資訊管理」可收合分組，包含「風險累計」、「再保商品」、「再保人暨再保經紀人」、「再保合約」、「再保費率」、「再保策略」等次選單項目。
  - **工作區首頁卡片**：
    - 主畫面依序呈現 4 張白底圓角卡片：「風險累計」、「再保商品」、「再保合約」、「再保策略」。
    - 每張卡片標題下方附帶淺橘底文字標籤（Badge）。
    - 卡片右側呈現對應的操作按鈕群：一般動作採用橘色細邊框樣式，刪除類動作（如批次刪除運算檔、批次刪除策略）採用淡紅細邊框樣式。

## 2. 影響範圍與檔案清單 (Scope)
> 注意：本任務為純前端畫面調整，後端清單完全留空。

### Backend Files

### Frontend Files
- src/components/layout/TopHeader.tsx
- src/components/layout/Sidebar.tsx
- src/components/dashboard/ModuleCard.tsx
- src/app/layout.tsx
- src/app/page.tsx

## 3. 詳細技術規格（只寫規格，不寫程式碼）

### 3.1 頂部導航規格 (src/components/layout/TopHeader.tsx)
- 高度設定為 `h-14`，背景為純白，包含底部灰色邊框與水平 Flex 排版。
- 左側：
  - 漢堡圖示按鈕（點擊可切換側邊欄展開/收合狀態）。
  - 標題文字為「再保險系統」，字級 `text-lg font-bold`。
  - 狀態標籤：「可編輯」，微型圓角膠囊樣式 (`text-xs bg-gray-100 text-gray-500 border border-gray-200`)。
- 右側：
  - 使用者資訊膠囊：顯示人像圖示與帳號文字（`katherine.jy.chang`）。
  - 動作按鈕：四組工具圖示（設定、多國語系、通知鈴鐺、登出），Hover 時呈現深灰回饋。
  - 通知鈴鐺右上角需有圓形未讀計數紅點（顯示 `1`）。

### 3.2 側邊導航規格 (src/components/layout/Sidebar.tsx)
- 寬度為 `w-60`，背景為純白，右側帶有淺灰邊框。
- 內部結構：
  1. **搜尋區塊**：上方無框線但帶底線之搜尋 Input，右側附放大鏡圖示。
  2. **群組標題**：「再保管理」，文字樣式為小字灰色 (`text-xs font-semibold text-gray-400`)。
  3. **選中項目**：「資料配置」，套用 `bg-orange-500 text-white font-medium` 鮮橘色塊，帶有資料夾/箱子圖示。
  4. **摺疊子選單**：「再保資訊管理」，右側帶展開箭頭圖示，展開後以縮排呈現各二級選單項目，文字顏色為 `text-gray-600`。

### 3.3 模組卡片元件 (src/components/dashboard/ModuleCard.tsx)
- 可重複使用之展示卡片，Props 介面定義：
  - `title`: string（模組名稱）
  - `badgeText`: string（標籤文字）
  - `actions`: Array<{ label: string; isDanger?: boolean; onClick?: () => void }>
- 卡片外框：白底、圓角 `rounded-xl`、陰影 `shadow-sm`、細邊框 `border-gray-100`。
- 排版：左右水平分佈（左側標題與標籤，右側按鈕清單，支援斷行 `flex-wrap`）。
- 按鈕樣式：
  - 一般按鈕（`isDanger: false`）：橘色外框 (`border-orange-200 text-orange-500 hover:bg-orange-50`)。
  - 危險按鈕（`isDanger: true`）：淡紅外框 (`border-rose-200 text-rose-500 hover:bg-rose-50`)。

### 3.4 頁面整合 (src/app/layout.tsx & src/app/page.tsx)
- **`layout.tsx`**：
  - 將 `Sidebar` 固定於左側，右側上方為 `TopHeader`，下方為 `children` 主要工作區。
  - 主工作區背景設為淺灰 `bg-gray-50`，內縮間距 `p-6`。
- **`page.tsx`**：
  - 渲染範例截圖中的 4 個卡片資料結構：
    1. **風險累計**：按鈕「同步風險累計」。
    2. **再保商品**：按鈕「批次建立再保商品」、「批次建立運算檔」、「批次更新運算檔」、「批次檢查運算檔」、「批次刪除運算檔」(Danger)。
    3. **再保合約**：按鈕「批次建立再保合約」、「批次建立分出設定檔」、「批次更新分出設定檔」、「批次檢查分出設定檔」、「批次刪除分出設定檔」(Danger)。
    4. **再保策略**：按鈕「批次建立策略」、「批次刪除策略」(Danger)。