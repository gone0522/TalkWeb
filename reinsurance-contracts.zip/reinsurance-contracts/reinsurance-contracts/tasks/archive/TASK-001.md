# TASK-001: 使用者個人檔案新增簡介 (bio) 欄位

## 1. 需求描述
我們需要在使用者個人資料中新增「個人簡介 (bio)」欄位，最大長度為 200 字，非必填。

## 2. API 契約變更需求
- 在 `contracts/openapi.yaml` 的 `UserProfile` 物件中新增 `bio` 屬性（string，非必填）。

## 3. 後端實作需求 (services/core-service)
- 更新 UserProfile DTO 與 Entity，納入 `bio` 欄位。
- 在取得使用者資料時正常返回 `bio`。
- 新增/修改單元測試，驗證 `bio` 正常讀取。

## 4. 前端實作需求 (apps/web-portal)
- 更新使用者資料介面型別定義。
- 在個人資料頁面顯示 `bio` 區塊，若無設定則顯示「尚未填寫簡介」。
- 確保前端單元測試無報錯。
