# TASK-003: 系統導覽與基礎設定-選單管理字典服務 API

## 1. 需求描述與驗收標準 (Acceptance Criteria)
- 業務邏輯與隱含需求推演：
  - 保險再保系統具備九大核心業務模組階層，系統需提供選單導航元數據端點，支援前端動態渲染雙層功能清單。
  - 「選單管理」為全系統代碼字典（Lookup Master Data）的核心維護中心，下游模組（保單、再保合約、分保規則、報表）均需引用其資料；本階段需提供「國家」、「結算幣別」、「金融機構」、「信用評級機構」四類主檔的完整維護能力。
  - 系統代碼唯一性限制：國家代碼（ISO 2碼/3碼）、幣別代碼（ISO 4217）、金融機構代碼、信用評級機構代碼於系統內必須具備唯一性，不允許重複建立。
  - 參照完整性與資料保護：主檔資料一旦建立，禁止硬刪除；若需停用應透過狀態旗標（ACTIVE/INACTIVE）切換。若有金融機構參照國家代碼，需防範參照失效。
  - 通用下拉選單快取與效能：提供針對前端 Select 下拉選單專用的輕量化讀取端點，僅回傳有效（ACTIVE）項目的代碼與名稱，並具備快取機制。
- 驗收條件：
  - HTTP 狀態碼：查詢成功回傳 200 OK；新增成功回傳 201 Created；更新與狀態切換回傳 200 OK；驗證錯誤回傳 400 Bad Request；查無資料回傳 404 Not Found；代碼重複衝突回傳 409 Conflict。
  - DB 落盤確認：檢驗 `system_country`, `system_currency`, `system_financial_institution`, `system_rating_agency`, `system_menu` 資料表，資料正確寫入且包含審計欄位（`created_by`, `created_at`, `updated_by`, `updated_at`, `version`）。

## 2. 影響範圍與檔案清單 (Scope)
> 腳本將讀取此處清單預先 touch 檔案，請務必列齊本次任務需異動或新建的檔案：

### Backend Files
- contracts/openapi.yaml
- src/main/resources/db/migration/V1__init_reinsurance_menu_and_lookups.sql
- src/main/java/com/reinsurance/core/menu/entity/SystemMenuEntity.java
- src/main/java/com/reinsurance/core/menu/repository/SystemMenuRepository.java
- src/main/java/com/reinsurance/core/menu/service/SystemMenuService.java
- src/main/java/com/reinsurance/core/menu/controller/SystemMenuController.java
- src/main/java/com/reinsurance/core/lookup/entity/CountryEntity.java
- src/main/java/com/reinsurance/core/lookup/entity/CurrencyEntity.java
- src/main/java/com/reinsurance/core/lookup/entity/FinancialInstitutionEntity.java
- src/main/java/com/reinsurance/core/lookup/entity/RatingAgencyEntity.java
- src/main/java/com/reinsurance/core/lookup/dto/request/CountryCreateRequest.java
- src/main/java/com/reinsurance/core/lookup/dto/request/CountryUpdateRequest.java
- src/main/java/com/reinsurance/core/lookup/dto/request/CurrencyCreateRequest.java
- src/main/java/com/reinsurance/core/lookup/dto/request/CurrencyUpdateRequest.java
- src/main/java/com/reinsurance/core/lookup/dto/request/FinancialInstitutionCreateRequest.java
- src/main/java/com/reinsurance/core/lookup/dto/request/FinancialInstitutionUpdateRequest.java
- src/main/java/com/reinsurance/core/lookup/dto/request/RatingAgencyCreateRequest.java
- src/main/java/com/reinsurance/core/lookup/dto/request/RatingAgencyUpdateRequest.java
- src/main/java/com/reinsurance/core/lookup/dto/request/StatusUpdateRequest.java
- src/main/java/com/reinsurance/core/lookup/dto/response/CountryResponse.java
- src/main/java/com/reinsurance/core/lookup/dto/response/CurrencyResponse.java
- src/main/java/com/reinsurance/core/lookup/dto/response/FinancialInstitutionResponse.java
- src/main/java/com/reinsurance/core/lookup/dto/response/RatingAgencyResponse.java
- src/main/java/com/reinsurance/core/lookup/dto/response/LookupOptionResponse.java
- src/main/java/com/reinsurance/core/lookup/repository/CountryRepository.java
- src/main/java/com/reinsurance/core/lookup/repository/CurrencyRepository.java
- src/main/java/com/reinsurance/core/lookup/repository/FinancialInstitutionRepository.java
- src/main/java/com/reinsurance/core/lookup/repository/RatingAgencyRepository.java
- src/main/java/com/reinsurance/core/lookup/service/CountryService.java
- src/main/java/com/reinsurance/core/lookup/service/CurrencyService.java
- src/main/java/com/reinsurance/core/lookup/service/FinancialInstitutionService.java
- src/main/java/com/reinsurance/core/lookup/service/RatingAgencyService.java
- src/main/java/com/reinsurance/core/lookup/controller/CountryController.java
- src/main/java/com/reinsurance/core/lookup/controller/CurrencyController.java
- src/main/java/com/reinsurance/core/lookup/controller/FinancialInstitutionController.java
- src/main/java/com/reinsurance/core/lookup/controller/RatingAgencyController.java
- src/main/java/com/reinsurance/core/lookup/controller/CommonLookupController.java
- src/test/java/com/reinsurance/core/lookup/CountryServiceTest.java
- src/test/java/com/reinsurance/core/lookup/CurrencyServiceTest.java
- src/test/java/com/reinsurance/core/lookup/FinancialInstitutionServiceTest.java
- src/test/java/com/reinsurance/core/lookup/RatingAgencyServiceTest.java
- src/test/java/com/reinsurance/core/lookup/CountryControllerIntegrationTest.java

### Frontend Files
- (無，本任務為純後端 API 與契約規格定義)

## 3. 詳細技術規格（只寫規格，不寫程式碼）
### 3.1 契約規格變更 (contracts/openapi.yaml)
- `GET /api/v1/system/menus`
  - 說明：取得系統九大模組與子項目之完整階層清單。
  - 回傳：200 OK，包含 `items` 陣列（`menuCode` String, `menuName` String, `level` Integer, `parentCode` String, `routePath` String, `sortOrder` Integer, `children` Array）。
- `GET /api/v1/system/lookups/{category}/options`
  - 說明：供業務下拉選單快速讀取有效選項。
  - 參數：`category` (Path: `countries` | `currencies` | `financial-institutions` | `rating-agencies`)。
  - 回傳：200 OK，陣列包含 `code` String, `label` String, `extra` Object。
- 國家維護端點群 (`/api/v1/system/countries`)：
  - `GET`: 支援分頁（`page`, `size`）與篩選（`keyword`, `status`），回傳 200 OK 與分頁資料。
  - `POST`: 接收新增資料，回傳 201 Created。
  - `PUT /{id}`: 更新國家名稱與排序，回傳 200 OK。
  - `PATCH /{id}/status`: 更新狀態（ACTIVE/INACTIVE），回傳 200 OK。
- 結算幣別維護端點群 (`/api/v1/system/currencies`)：
  - `GET`: 支援分頁與關鍵字篩選，回傳 200 OK。
  - `POST`: 接收幣別代碼、名稱、符號、小數位數、排序，回傳 201 Created。
  - `PUT /{id}`: 更新幣別名稱、符號、小數位數、排序，回傳 200 OK。
  - `PATCH /{id}/status`: 更新狀態，回傳 200 OK。
- 金融機構維護端點群 (`/api/v1/system/financial-institutions`)：
  - `GET`: 支援分頁與關鍵字、國家代碼、狀態篩選，回傳 200 OK。
  - `POST`: 接收機構代碼、名稱、SWIFT Code、關聯國家代碼、排序，回傳 201 Created。
  - `PUT /{id}`: 更新名稱、SWIFT Code、關聯國家代碼、排序，回傳 200 OK。
  - `PATCH /{id}/status`: 更新狀態，回傳 200 OK。
- 信用評級機構維護端點群 (`/api/v1/system/rating-agencies`)：
  - `GET`: 支援分頁與關鍵字、狀態篩選，回傳 200 OK。
  - `POST`: 接收評級機構代碼、名稱、說明描述、排序，回傳 201 Created。
  - `PUT /{id}`: 更新名稱、描述、排序，回傳 200 OK。
  - `PATCH /{id}/status`: 更新狀態，回傳 200 OK。

### 3.2 後端技術規格 (services/core-service)
- DTO 欄位規格與驗證條件：
  - `CountryCreateRequest`:
    - `code`: String，必填，長度 2 至 3 碼，符合大寫英文字母正則 `^[A-Z]{2,3}$`。
    - `nameZh`: String，必填，長度上限 100 字元。
    - `nameEn`: String，必填，長度上限 100 字元。
    - `sortOrder`: Integer，必填，最小值 0。
  - `CountryUpdateRequest`:
    - `nameZh`: String，必填，長度上限 100 字元。
    - `nameEn`: String，必填，長度上限 100 字元。
    - `sortOrder`: Integer，必填，最小值 0。
  - `CurrencyCreateRequest`:
    - `code`: String，必填，固定 3 碼大寫英文字母 `^[A-Z]{3}$`。
    - `name`: String，必填，長度上限 50 字元。
    - `symbol`: String，選填，長度上限 10 字元。
    - `decimalPlaces`: Integer，必填，數值範圍 0 至 4。
    - `sortOrder`: Integer，必填，最小值 0。
  - `FinancialInstitutionCreateRequest`:
    - `code`: String，必填，長度上限 20 字元，英數組合。
    - `name`: String，必填，長度上限 150 字元。
    - `swiftCode`: String，選填，長度 8 或 11 碼英數字正則 `^[A-Z0-9]{8}([A-Z0-9]{3})?$`。
    - `countryCode`: String，必填，長度 2 至 3 碼，需存在於國家主檔。
    - `sortOrder`: Integer，必填，最小值 0。
  - `RatingAgencyCreateRequest`:
    - `code`: String，必填，長度上限 30 字元，英數與底線 `^[A-Z0-9_]{2,30}$`。
    - `name`: String，必填，長度上限 100 字元。
    - `description`: String，選填，長度上限 500 字元。
    - `sortOrder`: Integer，必填，最小值 0。
  - `StatusUpdateRequest`:
    - `status`: String，必填，列舉值限 `ACTIVE` 或 `INACTIVE`。
- Service 交易邏輯要點：
  - 所有新增、修改、狀態變更方法必須標註 `@Transactional(rollbackFor = Exception.class)`。
  - 唯一性防護：新增前依據代碼查詢各實體庫存，若已存在則拋出自訂 `DuplicateResourceException`，對應 HTTP 409。
  - 關聯校驗：新增/修改金融機構時，需檢驗 `countryCode` 是否存在且狀態為 `ACTIVE`，否則拋出 `InvalidReferenceException`，對應 HTTP 400。
  - 樂觀鎖：各實體表配置 `@Version private Long version;`，修改發生衝突拋出 `OptimisticLockingFailureException`，對應 HTTP 409。
  - 查無資料：以 ID 查詢查無記錄時拋出 `ResourceNotFoundException`，對應 HTTP 404。
  - 字典快取機制：`CommonLookupController` 選項查詢採用 Spring Cache (`@Cacheable(value = "system_lookups", key = "#category")`)，主檔異動時透過 `@CacheEvict(value = "system_lookups", allEntries = true)` 清理快取。
- Controller 端點與測試案例需求：
  - 單元測試（Service Test）：
    - 驗證主檔建立與欄位保存成功。
    - 驗證代碼重複拋出 409 衝突。
    - 驗證更新查無 ID 拋出 404 例外。
    - 驗證金融機構關聯無效國家代碼拋出 400 例外。
    - 驗證狀態變更正常切換為 INACTIVE。
  - 整合測試（MockMvc Test）：
    - 驗證各請求輸入格式驗證（如幣別長度不符、小數位數超過 4）回傳 400 與格式化錯誤訊息。
    - 驗證分頁查詢結果包含 `totalPages`, `totalElements`, `content`。

### 3.3 前端技術規格 (apps/web-portal)
- (本任務不包含前端實作，規格交由 TASK-002 執行)