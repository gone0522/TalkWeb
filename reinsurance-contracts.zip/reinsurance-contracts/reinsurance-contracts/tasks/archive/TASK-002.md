# TASK-002: 後端使用者資料串接 PostgreSQL 真實資料庫

## 1. 需求描述
將 `UserService` 的記憶體模擬資料替換為 PostgreSQL 資料庫存取。系統啟動時若資料庫無資料，需透過 Data Seeder 自動寫入初始預設資料以利驗收。

## 2. 後端範疇 (Backend Scope)

### Backend Files
- src/main/resources/application.properties
- src/main/java/com/example/entity/UserEntity.java
- src/main/java/com/example/repository/UserRepository.java
- src/main/java/com/example/dto/UserProfile.java
- src/main/java/com/example/service/UserService.java
- src/main/java/com/example/service/UserServiceImpl.java
- src/main/java/com/example/config/DataSeeder.java
- src/main/java/com/example/config/CorsConfig.java
- src/main/java/com/example/controller/UserController.java
- src/test/java/com/example/service/UserServiceTest.java
- src/test/java/com/example/controller/UserControllerTest.java

## 3. 前端範疇 (Frontend Scope)

### Frontend Files
- src/types/user.ts
- src/components/UserProfileCard.tsx
- src/app/page.tsx

## 4. 詳細規格細節

### 4.1 契約規格 (OpenAPI)
- 保持 `contracts/openapi.yaml` 現有定義，確保相容。

### 4.2 後端規格 (services/core-service)
- **依賴管理 (`pom.xml`)**：
  - 引入 `spring-boot-starter-data-jpa`
  - 引入 `org.postgresql:postgresql`（runtime 作用域）
  - 引入 `com.h2database:h2`（test 作用域，支援離線單元測試）
- **資料庫連線 (`src/main/resources/application.properties`)**：
  - URL: `jdbc:postgresql://localhost:5432/app_db`
  - Username: `dev_user`
  - Password: `dev_password`
  - JPA 設定：`spring.jpa.hibernate.ddl-auto=update`、`spring.jpa.show-sql=true`
- **資料庫映射**：
  - `UserEntity`：映射至資料表 `users`，包含 `id` (主鍵)、`username`、`email`、`bio`。
  - `UserRepository`：繼承 `JpaRepository<UserEntity, String>`。
- **業務邏輯重構 (`UserServiceImpl`)**：
  - 注入 `UserRepository`，使用 `findById` 查詢資料。
  - 查無資料時拋出 `ResponseStatusException(HttpStatus.NOT_FOUND)`。
  - 查詢方法加上 `@Transactional(readOnly = true)`。
- **資料初始化 (`DataSeeder`)**：
  - 實作 `CommandLineRunner`。當 `userRepository.count() == 0` 時，自動寫入預設測試資料：
    - ID: `1`
    - Username: `kenny_db`
    - Email: `kenny@example.com`
    - Bio: `這是一段從 PostgreSQL 資料庫真實查詢出的個人簡介！`

### 4.3 前端規格 (apps/web-portal)
- 確保 `UserProfileCard.tsx` 與 `page.tsx` 完整渲染由 DB 查詢出的 `bio` 資訊。
- 當後端回應 404 時，畫面上需呈現清楚的「找不到使用者」提示訊息。
