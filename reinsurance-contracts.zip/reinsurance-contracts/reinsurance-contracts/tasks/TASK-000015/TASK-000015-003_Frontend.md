# TASK-000015-003: 險別選單樹狀/平面切換清單表格、折疊展開與 Excel 匯出畫面 (SC-0101-05-01)

## 1. 需求描述與驗收標準
- **規格依據**：`specs/UI_SPEC/LineOfBusiness_UI_SPEC.md` (`SC-0101-05-01`), `mockups/1.jpg`
- **業務背景**：實作險別清單畫面、支援「樹狀結構」與「平面清單」雙檢視切換、節點折疊/展開與 Excel 匯出。

### 驗收條件 (BDD)
- **場景 1 (畫面載入與檢視切換 - mockups/1.jpg)**：訪問 `/settings/menus/lines-of-business`，預設為樹狀結構，提供「樹狀結構 / 平面清單」切換按鈕。
- **場景 2 (樹狀節點折疊展開)**：點擊壽險業務 (`A01`) 或產險業務 (`B01`) 前方折疊箭頭，平滑切換子險別呈現/收攏。
- **場景 3 (表格欄位渲染)**：渲染 7 大欄位（顯示順序 ⇅、代碼、中文名稱含階層縮排、英文名稱、上層險別、狀態、功能）。
- **場景 4 (Excel 匯出)**：點擊「匯出 Excel」下載完整階層清單。

## 2. 影響範圍 (嚴格 4 檔)
- `src/app/(dashboard)/settings/menus/lines-of-business/page.tsx`
- `src/components/menus/lob/LineOfBusinessSearchForm.tsx`
- `src/components/menus/lob/LineOfBusinessTreeTable.tsx`
- `src/services/line-of-business-api.ts`
