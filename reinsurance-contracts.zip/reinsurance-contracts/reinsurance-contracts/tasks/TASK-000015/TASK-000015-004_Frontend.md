# TASK-000015-004: 險別新增畫面、上層險別連動與循環參照防呆彈窗 (SC-0101-05-02)

## 1. 需求描述與驗收標準
- **規格依據**：`specs/UI_SPEC/LineOfBusiness_UI_SPEC.md` (`SC-0101-05-02`), `mockups/2.jpg`
- **業務背景**：提供險別新增表單，支援上層險別選擇、排序建議值自動帶入與循環參照即時提示橫幅。

### 驗收條件 (BDD)
- **場景 1 (排序建議值帶入 - mockups/2.jpg)**：打開新增表單，顯示順序自動填入 max + 10；代碼聚焦。
- **場景 2 (上層險別選取)**：上層險別下拉選單支援單選與搜尋，未選取者為頂層節點。
- **場景 3 (階層檢核提示橫幅 - mockups/2.jpg)**：畫面清晰展示警示橫幅「階層檢核：儲存時系統將檢核完整之上層險別鏈，若形成循環參照則拒絕儲存...」。
- **場景 4 (409 與 400 反饋)**：代碼重複回傳 409 時精確標紅；循環參照回傳 400 時彈出防呆警示。

## 2. 影響範圍 (嚴格 4 檔)
- `src/components/menus/lob/LineOfBusinessFormModal.tsx`
- `src/components/menus/lob/HierarchyWarningBanner.tsx`
- `src/locales/zh-TW.json`
- `src/locales/en-US.json`
