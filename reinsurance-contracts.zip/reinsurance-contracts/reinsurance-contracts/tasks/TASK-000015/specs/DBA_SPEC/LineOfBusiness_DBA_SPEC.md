<!--
governance_metadata:
  last_reviewed: "2026-10-15"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-15"
  governance_status: "ACTIVE"
-->

# 險別資料庫架構與實體模型規格書 (Line of Business DBA Spec)

> **模組代碼**：`TASK-000015`  
> **關聯資料表**：`system_lines_of_business`  
> **目標資料庫**：PostgreSQL 16+  

```sql
CREATE TABLE IF NOT EXISTS system_lines_of_business (
    id BIGSERIAL PRIMARY KEY,
    lob_code VARCHAR(20) NOT NULL,
    name_zh VARCHAR(100) NOT NULL,
    name_en VARCHAR(100) NOT NULL,
    parent_code VARCHAR(20),
    sort_order INTEGER NOT NULL DEFAULT 0,
    is_disabled BOOLEAN NOT NULL DEFAULT FALSE,
    version BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
    updated_at TIMESTAMPTZ NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_by VARCHAR(50) NOT NULL DEFAULT 'SYSTEM',
    CONSTRAINT uk_system_lob_code UNIQUE (lob_code),
    CONSTRAINT fk_system_lob_parent FOREIGN KEY (parent_code) 
        REFERENCES system_lines_of_business(lob_code) ON UPDATE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_system_lob_sort_status 
    ON system_lines_of_business (sort_order ASC, is_disabled);

CREATE INDEX IF NOT EXISTS idx_system_lob_parent 
    ON system_lines_of_business (parent_code);

COMMENT ON TABLE system_lines_of_business IS '險別主檔表 (支援樹狀父子階層)';
COMMENT ON COLUMN system_lines_of_business.lob_code IS '險別唯一識別代碼 (如 B01, B02)';
COMMENT ON COLUMN system_lines_of_business.parent_code IS '上層險別代碼 (自關聯外鍵，為空代表頂層險別)';
```

### 種子資料規劃
```sql
INSERT INTO system_lines_of_business (lob_code, name_zh, name_en, parent_code, sort_order, is_disabled)
VALUES 
    ('A01', '壽險業務', 'Life Insurance', NULL, 10, FALSE),
    ('A02', '壽險', 'Life', 'A01', 20, FALSE),
    ('A03', '健康險', 'Health', 'A01', 30, FALSE),
    ('A04', '傷害險', 'Personal Accident', 'A01', 40, FALSE),
    ('B01', '產險業務', 'Property & Casualty', NULL, 50, FALSE),
    ('B02', '火災保險', 'Fire', 'B01', 60, FALSE),
    ('B03', '住宅火險', 'Residential Fire', 'B02', 70, FALSE),
    ('B04', '汽車保險', 'Motor', 'B01', 80, FALSE)
ON CONFLICT (lob_code) DO NOTHING;
```
