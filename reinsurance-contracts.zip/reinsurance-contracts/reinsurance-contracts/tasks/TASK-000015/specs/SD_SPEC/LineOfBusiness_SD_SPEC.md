<!--
governance_metadata:
  last_reviewed: "2026-10-15"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-15"
  governance_status: "ACTIVE"
-->

# 險別系統與 API 詳細設計規格書 (Line of Business SD Spec)

> **模組代碼**：`TASK-000015`  
> **API 基礎路徑**：`/api/v1/system/lines-of-business`  
> **領域標籤**：`domain:masterdata`  

### API 端點表
- `GET /api/v1/system/lines-of-business` (分頁/清單查詢，支援 `viewMode=TREE` 或 `viewMode=FLAT`)
- `POST /api/v1/system/lines-of-business` (新增險別，含循環參照檢核與建議順序 max + 10)
- `GET /api/v1/system/lines-of-business/{id}` (取得單筆詳情、上下層清單與引用筆數)
- `PUT /api/v1/system/lines-of-business/{id}` (修改險別，含 DAG 無環檢核與樂觀鎖)
- `PATCH /api/v1/system/lines-of-business/{id}/status` (切換作廢/啟用狀態)
- `DELETE /api/v1/system/lines-of-business/{id}` (物理刪除，有子節點或被業務引用時回傳 400 阻擋)
- `GET /api/v1/system/lines-of-business/{id}/audit-logs` (查詢最近異動審計歷程)
- `GET /api/v1/system/lines-of-business/export` (匯出 Excel)
