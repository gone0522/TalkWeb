<!--
governance_metadata:
  last_reviewed: "2026-10-15"
  review_cadence: "QUARTERLY"
  next_review_due: "2027-01-15"
  governance_status: "ACTIVE"
-->

# 險別測試驗收規格書 (Line of Business QA Spec)

> **模組代碼**：`TASK-000015`  

- **TC-LOB-01**: 樹狀與平面分頁查詢，樹狀節點關聯正確。
- **TC-LOB-02**: 單筆新增與自動計算 `sortOrder` (`max + 10`)。
- **TC-LOB-03**: 循環參照檢核（A -> B -> A 或 A -> A），拋出 `400 Bad Request` (`ERR_CIRCULAR_PARENT_LOB`)。
- **TC-LOB-04**: 尚有下層險別時禁止刪除 (`400 Bad Request`, `ERR_LOB_HAS_CHILDREN`)。
- **TC-LOB-05**: 被外部保單/合約引用時禁止刪除 (`400 Bad Request`, `ERR_LOB_REFERENCED_CANNOT_DELETE`)。
- **TC-LOB-06**: 無下層且無引用險別允許物理刪除 (`204 No Content`)。
- **TC-LOB-07**: 樂觀鎖併發衝突檢驗 (`409 Conflict`)。
- **TC-LOB-08**: Excel 匯出檢驗。
