# TASK-000015-002: 循環參照檢核演算法、階層與保單合約引用防刪保護、審計日誌與 Excel 匯出 API

## 1. 需求描述與驗收標準
- **規格依據**：`specs/SA_SPEC.md` (§2 BR-LOB-02, BR-LOB-03, BR-LOB-04)
- **業務背景**：實作 DAG 拓撲無環循環參照檢核演算法、下層險別防刪、保單合約引用防刪、異動審計日誌與 Excel 匯出。

### 驗收條件 (BDD)
- **場景 1 (循環參照檢核阻擋 400 - TC-LOB-03)**：新增或修改險別時，若將上層險別設為自身、或形成循環鏈（如 A -> B -> A），回傳 400 Bad Request (`ERR_CIRCULAR_PARENT_LOB`)。
- **場景 2 (有下層險別禁止刪除 400 - TC-LOB-04)**：刪除尚有子節點之險別，回傳 400 Bad Request (`ERR_LOB_HAS_CHILDREN`)。
- **場景 3 (業務引用禁止刪除 400 - TC-LOB-05)**：已被保單主檔、商品或合約引用之險別調用 DELETE，回傳 400 Bad Request (`ERR_LOB_REFERENCED_CANNOT_DELETE`)。
- **場景 4 (無子節點且無引用物理刪除 204 - TC-LOB-06)**：獨立孤立險別調用 DELETE，回傳 204 No Content，實體移除。
- **場景 5 (Excel 匯出 - TC-LOB-08)**：調用 `/export` 匯出 xlsx 串流，包含階層路徑、代碼、名稱與狀態。

## 2. 影響範圍 (嚴格 4 檔)
- `src/main/java/com/reinsurance/core/dto/lob/LineOfBusinessDto.java`
- `src/main/java/com/reinsurance/core/service/LineOfBusinessHierarchyService.java`
- `src/main/java/com/reinsurance/core/service/LineOfBusinessExportService.java`
- `src/test/java/com/reinsurance/core/service/LineOfBusinessServiceTest.java`
