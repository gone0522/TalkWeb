# TASK-000015-005: 險別檢視/編輯畫面、上下層階層關係面板、多模組引用防護與審計歷程 (SC-0101-05-03)

## 1. 需求描述與驗收標準
- **規格依據**：`specs/UI_SPEC/LineOfBusiness_UI_SPEC.md` (`SC-0101-05-03`), `mockups/3.jpg`
- **業務背景**：提供檢視/編輯側邊抽屜，展示上層/下層險別標籤、下層存在防刪橫幅、保單合約引用面板與最近 5 筆審計歷程。

### 驗收條件 (BDD)
- **場景 1 (已引用代碼鎖定唯讀 - mockups/3.jpg)**：開啟已被保單/合約引用之險別，代碼欄位呈現鎖頭圖示（`[🔒]`），強制 disabled 唯讀。
- **場景 2 (階層關係與下層防刪橫幅 - mockups/3.jpg)**：展示上層險別與下層險別標籤徽章；若存在下層險別，頂部展示警示橫幅「本險別尚有 X 筆下層險別，不可刪除...」，「刪除」按鈕鎖定 disabled。
- **場景 3 (多模組引用狀況面板 - mockups/3.jpg)**：條列展示「保單主檔」、「再保商品管理」與「再保合約」之引用筆數與說明文字。
- **場景 4 (審計歷程面板)**：展示最近 5 筆異動紀錄，提供查看全部與匯出。
- **場景 5 (設為作廢)**：點擊「設為作廢」確認後送出，狀態刷新。

## 2. 影響範圍 (嚴格 4 檔)
- `src/components/menus/lob/LineOfBusinessDetailDrawer.tsx`
- `src/components/menus/lob/LineOfBusinessHierarchySection.tsx`
- `src/components/menus/lob/LineOfBusinessReferenceSection.tsx`
- `src/components/menus/lob/LineOfBusinessDeleteConfirmModal.tsx`
