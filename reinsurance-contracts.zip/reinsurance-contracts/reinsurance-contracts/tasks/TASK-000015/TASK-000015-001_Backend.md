# TASK-000015-001: 險別領域實體、自關聯資料表綱要、樹狀查詢與核心 CRUD API

## 1. 需求描述與驗收標準
- **規格依據**：`specs/SA_SPEC.md` (§2 BR-LOB-01, BR-LOB-06), `specs/DBA_SPEC/LineOfBusiness_DBA_SPEC.md`
- **業務背景**：建立險別主檔實體模型、自關聯外鍵 `parent_code`、自動排序計算（max + 10）與代碼唯一性檢核。

### 驗收條件 (BDD)
- **場景 1 (樹狀與平面分頁查詢 - TC-LOB-01)**：發送 `GET /api/v1/system/lines-of-business?viewMode=TREE`，回傳階層結構物件（頂層節點包含 `children` 清單）。
- **場景 2 (新增險別與排序計算 - TC-LOB-02)**：提供代碼 `"B03"`、中英文名稱、上層險別 `"B02"`，未提供 `sortOrder`。回傳 201 Created，`sortOrder` 自動設為 max + 10。
- **場景 3 (代碼重複衝突 409)**：代碼已存在時新增，回傳 409 Conflict (`ERR_DUPLICATE_LOB_CODE`)。
- **場景 4 (樂觀鎖更新 - TC-LOB-07)**：帶入 `version = 0` 更新名稱，回傳 200 OK，`version` 遞增；版本不符時回傳 409 Conflict。

## 2. 影響範圍 (嚴格 5 檔)
- `src/main/resources/db/migration/V20261015_03__create_system_lines_of_business.sql`
- `src/main/java/com/reinsurance/core/domain/lob/LineOfBusiness.java`
- `src/main/java/com/reinsurance/core/repository/LineOfBusinessRepository.java`
- `src/main/java/com/reinsurance/core/service/LineOfBusinessService.java`
- `src/main/java/com/reinsurance/core/controller/LineOfBusinessController.java`
