# 專案全生命週期與 AI 原生架構開發規範 (Fullstack Agent Conventions)

本專案採行 **雙軌規格體系 (Dual-Track)**、**多庫獨立契約先行分支治理 (Meta-ADR 2)** 與 **可演進式垂直聚合抗耦合防線**。
架構規範分為兩大層級：
1. **通用軟體工廠基底**：參閱 [docs/framework/AI_SOFTWARE_FACTORY_BLUEPRINT.md](docs/framework/AI_SOFTWARE_FACTORY_BLUEPRINT.md)
2. **再保險業務領域規範**：參閱 [docs/domain/REINSURANCE_DOMAIN_STANDARDS.md](docs/domain/REINSURANCE_DOMAIN_STANDARDS.md)
3. **三大統合架構決策**：參閱 [docs/adr/README.md](docs/adr/README.md) (ADR-001 ~ ADR-003)

---

## 【至高鐵律】五階規格驅動演進自閉環流水線與嚴禁打地鼠 (The 5-Stage Evolution Pipeline & Ban on Whac-A-Mole)

**核心演進鐵律：【有問題先討論 ➔ 調整規範 ➔ 產生任務 ➔ 確認執行 ➔ 驗收覆盤與自閉環】**  
**核心精神：嚴禁遇到問題就急著修改業務程式碼（打地鼠）。每一項調整都必須著眼於「如何讓未來的軟體資產更好、百年可重現、全域可免疫」。即便完全重啟對話，本流程亦必須強制執行！**

1. **第一階：有問題先討論 (Stage 1: Root Cause & HCI Alignment)**：
   - 嚴禁直接開分支動代碼。回歸第一性原則、認知心理學、社會心理學、行為經濟學、跨國貿易經濟學與反脆弱架構哲學，深入釐清本質原因，杜絕打地鼠。
2. **第二階：調整規範 (Stage 2: Spec & Governance Codification)**：
   - 將共識 100% 寫入 `UI_SPEC.md`, `SD_SPEC.md`, `ENGINEERING_STANDARDS.md`, `TASK_EXECUTION_RULES.md` 與 SDK 原語。
   - 清除歷史「打地鼠條款」，通過 `scripts/audit-specs.py` 驗證並提交至 `reinsurance-contracts:dev`。
3. **第三階：產生任務 (Stage 3: Contract-Driven Task Synthesis)**：
   - 合成標準 6 位數任務包 (`tasks/TASK-{06d}/`) 與 Task-IR 字節碼，明確定界 `target_files` 與驗收閘門。
4. **第四階：確認執行 (Stage 4: Explicit Confirmation & Sentry Execution)**：
   - **未獲人類明確指示前，絕對不修改業務代碼！** 獲得確認後始得建立分支並按 TDD 嚴格落地。
5. **第五階：驗收覆盤與反脆弱自閉環 (Stage 5: Verify, Reconcile & Retro)**：
   - 客觀神諭驗收、主規格回寫、問題聚類沉澱 (Pattern Clustering & Rule of Three)，同類問題達 3 次強制提煉 SDK 原語，達成全系統永久免疫。

---

## 階段一：需求規劃拆解 (Task Planning & Generation)
- **觸發時機**：使用者提出新的業務想法、功能需求，或要求拆解任務規格時。
- **技能支援**：啟用 `task-planner` 技能。
- **標準流程與抗耦合鐵律 (Meta-ADR 1 & Meta-ADR 2)**：
  1. **記憶檢索與現狀盤點**：強制檢索 `docs/governance/RETROSPECTIVE.md` 與 Meta-ADR 1 ~ 3，確認系統等級 (預設 M 級: 1,000 QPS, P95 < 100ms) 與現有代碼資產。
  2. **自動決定模組編號與內聚目錄**：掃描 `tasks/` 現有模組編號遞增建立 `tasks/TASK-{模組編號}/`。
  3. **六大活體規格套件 (Six-Core Living Spec Suite)**：
     - `specs/SA_SPEC.md` (架構分析、SLA/SLO、軟性外鍵防線)
     - `specs/USE_CASE_SPEC/` (Gherkin 場景)
     - `specs/UI_SPEC/` (視覺規範、元件佈局、i18n 字典)
     - `specs/DBA_SPEC/` (DDL、索引策略、軟刪除與領域族譜表)
     - `specs/SD_SPEC/` (系統時序圖、Package-Private 封閉設計)
     - `specs/QA_SPEC/` (測試驗收矩陣、混沌工程注入)
  4. **機器可執行契約 (Machine Task Manifest) 與依賴預授權**：
     - 產出 `manifest.yaml`（或雙軌切片 `manifest-api.yaml` / `manifest-ui.yaml`）。
     - **強制注入領域標籤 (Meta-ADR 2 §3.2)**：
       ```yaml
       domain:
         name: "<領域名稱>"        # 例如: masterdata, treaty, claim
         subdomain: "<子模組名稱>"   # 例如: currency, country-region
       ```
     - **依賴預授權宣告 (Authorized Dependencies - Meta-ADR 1 §3.8)**：
       ```yaml
       authorized_dependencies:
         maven:
           - groupId: "org.mapstruct"
             artifactId: "mapstruct"
             purpose: "Entity to DTO compile-time mapping"
         npm:
           - package: "sonner"
             purpose: "Global declarative toast notifications"
       ```
     - 嚴格限定 `target_files` 檔案修改邊界（路徑統一從 `src/` 開始，杜絕舊路徑前綴）。
  5. **OpenAPI 契約同步 (Contract-First)**：
     - 所有新端點必須更新至 `contracts/openapi.yaml`，並標註 `tags: ["domain:<領域名稱>"]`。
     - 被引用主檔實體必須規劃 `GET /api/v1/{entity}/{id}/references` 引用防禦端點。
  6. **規格完整性稽核**：發布前必須執行 `python3 scripts/audit-specs.py` 確保 4 道閘門 100% 通過。

---

## 階段二：任務開發執行 (Task Execution & Verification)
- **觸發時機**：執行 `tasks/TASK-{模組編號}/` 下之任務開發時。
- **技能支援**：啟用 `task-runner` 技能。
- **標準流程與邊界防線**：
  1. **獨立分支生命週期 (Meta-ADR 2 鐵律)**：
     - 後端任務：強制從後端倉庫 (`reinsurance-core-service`) 之 `dev` 切出 `feature/<TASK_NAME>`。
     - 前端任務：強制從前端倉庫 (`reinsurance-web-portal`) 之 `dev` 切出 `feature/<TASK_NAME>`（以 Mock 獨立平行開發）。
     - **嚴禁跨倉庫切分支**，彼此無代碼分支耦合。
  2. **現代工程基準、Tier-1 BOM 與抗耦合實作規範 (Meta-ADR 1 ~ 3)**：
     - **相依性自動引進開通 (Step 0 Dependency Bootstrap)**：檢查 Manifest 中 `authorized_dependencies`，若未安裝自動注入 `pom.xml` 或執行 `npm install`，強制使用主流標準套件，**嚴格禁止手刻輪子**！
     - **後端 Tier-1 BOM**：Lombok (`@RequiredArgsConstructor` 等), MapStruct, Spring Data JPA Auditing, JaVers/Envers, EasyExcel, springdoc-openapi, ArchUnit, Testcontainers。
     - **前端 Tier-1 Approved BOM 與強制架構標準**：
       * RSC 服務端渲染邊界：頁面入口/佈局預設 Server Components；`'use client'` 僅限末端互動葉節點。
       * 三層狀態管理：`@tanstack/react-query` (非同步伺服器狀態), `zustand` (全域客戶端狀態), `react-hook-form` + `zod` (表單校驗)。
       * 傳輸層標準：集中式 Client，內建 JWT 自動注入、401 無感 Token 輪轉、`X-Trace-ID` 追蹤、`AbortController` 防競爭、RFC 7807 錯誤規範化。
       * 設計系統：`tokens.css` Design Tokens（4px 網格、HSL 色系），**嚴格禁止 JSX 行內 `style={{ ... }}`**。
       * 無障礙 Headless 原語：Radix UI Primitives，內建 Focus Trap 與全鍵盤操作。
       * 虛擬滾動：資料量 > 100 筆強制啟用 `@tanstack/react-virtual`。
       * 容錯防線：`react-error-boundary` 錯誤兜底與 Suspense 骨架屏；重型組件採用 `next/dynamic` 延遲載入。
       * 圖示與提示：`lucide-react`（零手寫 inline SVG）與 `sonner`（全域 Toast）。
     - **全語言零自然語言寫死鐵律**：
       * 傳輸層 API Client 嚴禁構造自然語言句子（英文如 `'Export failed'` 亦違規），只傳遞機器錯誤代碼 (`errorCode`) 與 HTTP 狀態。
       * 審計資料表 `change_reason` 必須儲存 **Canonical Identifiers / Standard Keys**（如 `SYSTEM_DEFAULT_UPDATE`），嚴禁存入自然語言文字。
       * 呈現層 (UI) 以 `t('errors.' + errorCode)` 與 `t('audit.reasons.' + changeReason)` 動態解析多語系。
       * Excel 匯出表頭與列舉名稱必須動態注入 `MessageSource` 依請求語系即時解析。
     - **資料庫遷移安全**：`spring.jpa.hibernate.ddl-auto` 嚴格禁止 `update`；遷移腳本宣告 `SET lock_timeout = '5s';`。
     - **軟性外鍵與跨庫零 JOIN**：只存邏輯代碼，嚴禁實體外鍵約束；Repository 嚴禁跨領域資料表 SQL JOIN。
     - **Package-Private 封閉性**：內部 DAO、Entity 與 Service 實作宣告為 Package-Private，杜絕跨領域直接存取。
     - **前端 Feature-Sliced 組織**：畫面與邏輯落實於 `src/features/<domain>/<subdomain>/`，外部僅由 `index.ts` 引用。
     - **引用防禦協議**：實體變更狀態前必須調用 `/references` 檢核有效合約引用計數，禁止物理刪除。
  3. **品質閘門 (Quality Gates)**：
     - 後端：`mvn test` (單元測試 + 參數化審計矩陣) 100% 綠燈。
     - 前端：`npx tsc --noEmit`、`npm test` (i18n 完整性) 與 AST 死按鈕靜態稽核 100% 綠燈。
  4. **嚴守分支紀律**：任務完成後**絕對禁止擅自執行 `git merge dev`**，統一提交 Pull Request 等待人類簽核。
  5. **常規提交與語意化版本**：Git Commit 訊息強制遵守 Conventional Commits (`feat:`, `fix:`, `refactor:`, `docs:`, `test:`, `chore:`, `perf:`)。
  6. **架構自適應升級與踩坑程式化自閉環 (Rules-as-Tests Pipeline)**：
     * 面對人類糾正或踩坑，**嚴格禁止僅作單次代碼修訂**。
     * 強制依據 5 Whys 記入 `RETROSPECTIVE.md`，並轉化為客觀門禁腳本（AST Linter / ArchUnit / Playwright），開工前由記憶檢索協議強制繼承，永不犯第二次錯。
